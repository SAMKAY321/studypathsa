# CV outline for a first application

**Guidance template only. Last reviewed: 26 October 2026.** Follow the university/funder's required format if it has one.

## Contact details
Name, a suitable email address and phone number. Do not include an ID number or full home address unless explicitly required.

## Profile
Two or three sentences about your academic interests and goals.

## Education
School, qualification/grade, subjects where relevant, and expected completion year.

## Projects and activities
School projects, community work, sport, clubs, volunteering or responsibilities. Include dates and your role.

## Skills and achievements
Only skills and achievements you can explain or demonstrate.

## References
Provide only when requested; ask permission before sharing another person's contact details.
