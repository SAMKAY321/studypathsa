# Motivation letter planning template

**Not a legal document and not a guarantee of acceptance or funding. Last reviewed: 26 October 2026.**

Use the application instructions provided by the university or funder first. This guide is for drafting only.

1. **Purpose** — State the programme or opportunity you are applying for.
2. **Why this path** — Describe your interests and experience in your own words.
3. **Evidence** — Give specific examples from school, community or work.
4. **Goals** — Explain how the programme fits your study and career goals.
5. **Practical information** — Include only requested facts; do not include unnecessary identity or financial data.
6. **Review** — Check length, spelling, required questions, source instructions and deadline.

Replace every prompt with your own writing. Do not claim achievements you cannot support.
