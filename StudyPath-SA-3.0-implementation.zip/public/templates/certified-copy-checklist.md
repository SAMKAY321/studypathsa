# Certified-copy preparation checklist

**Checklist only. Requirements and validity periods differ by institution. Last reviewed: 26 October 2026.**

- [ ] Confirm which document and page sides the application needs.
- [ ] Check the institution's certification rules, including who may certify and how recent the certification must be.
- [ ] Ensure every page is legible, complete and correctly oriented.
- [ ] Check that stamps, dates and signatures are visible.
- [ ] Save an unaltered scan/photo in the requested format and size.
- [ ] Keep the original document safe.
- [ ] Recheck the uploaded copy before submitting.
