# Bursary application checklist

**General preparation aid only. It does not guarantee eligibility or funding. Last reviewed: 26 October 2026.** The funder's own checklist always takes precedence.

- [ ] Read the current official opportunity page and record the closing date.
- [ ] Confirm citizenship, province, field, year of study and academic requirements against the published criteria.
- [ ] Gather the documents explicitly requested by the funder.
- [ ] Prepare a motivation letter only if required.
- [ ] Check certification/format rules and file sizes.
- [ ] Submit through the funder's official channel and save the confirmation.
- [ ] Verify any changes directly with the funder before relying on a deadline or requirement.
