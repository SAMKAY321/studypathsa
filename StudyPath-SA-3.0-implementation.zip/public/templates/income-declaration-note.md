# Income evidence cover-note checklist

**General preparation aid only; this is not a statutory declaration or legal advice. Last reviewed: 26 October 2026.** Use the exact form requested by the funding provider.

- Confirm which household members and income period the funder asks about.
- Collect only the documents listed by the funder (for example, payslips or an official letter, where required).
- Do not alter official documents.
- If a household member has no formal payslip, ask the funder which alternative evidence it accepts.
- Check the required certification date, upload size, format and submission deadline.
- Store copies securely and do not email sensitive documents unless the funder specifies a secure method.
