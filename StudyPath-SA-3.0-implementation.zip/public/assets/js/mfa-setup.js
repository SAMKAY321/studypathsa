import { api } from './api.js';
const feedback = document.querySelector('#feedback'),
  start = document.querySelector('#mfa-start'),
  enrolment = document.querySelector('#mfa-enrolment'),
  confirm = document.querySelector('#mfa-confirm'),
  recovery = document.querySelector('#recovery-section');
let csrf = '';
const request = (path, body) =>
  api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
    body: JSON.stringify(body),
  });
try {
  csrf = (await api('/api/me')).csrf;
} catch (error) {
  feedback.textContent = 'Sign in as an administrator to set up multi-factor authentication.';
  start.hidden = true;
}
start.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  try {
    const result = await request('/api/me/mfa/setup', Object.fromEntries(new FormData(start)));
    document.querySelector('#mfa-secret').textContent = result.secret;
    document.querySelector('#mfa-uri').textContent = result.provisioningUri;
    enrolment.hidden = false;
    start.hidden = true;
    feedback.textContent = 'Add the key to your authenticator app, then enter its current code.';
  } catch (error) {
    feedback.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
confirm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  try {
    const result = await request('/api/me/mfa/confirm', Object.fromEntries(new FormData(confirm)));
    csrf = result.csrf;
    document.querySelector('#recovery-codes').textContent = result.recoveryCodes.join('\n');
    document.querySelector('#recovery-section').hidden = false;
    enrolment.hidden = true;
    feedback.textContent = result.message;
  } catch (error) {
    feedback.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
document
  .querySelector('#finish-mfa')
  .addEventListener('click', () => location.assign('/admin/overview.html'));
