document.addEventListener('DOMContentLoaded', async () => {
  window.lucide?.createIcons();
  try {
    const response = await fetch('/api/public-config', { headers: { Accept: 'application/json' } });
    if (!response.ok) return;
    const { supportEmail } = await response.json();
    if (!supportEmail) return;
    const address = document.querySelector('[data-support-email]');
    const copy = document.querySelector('[data-support-copy]');
    if (address && copy) {
      address.href = `mailto:${supportEmail}`;
      address.textContent = supportEmail;
      address.hidden = false;
      copy.textContent = 'Email StudyPath SA support at ';
      document.querySelector('[data-support-fallback]')?.setAttribute('hidden', '');
    }
  } catch {
    // The IT administrator instructions remain available if the optional contact is unset.
  }
});
