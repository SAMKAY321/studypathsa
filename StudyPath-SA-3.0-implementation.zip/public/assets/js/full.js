import { api } from './api.js';
import { assessSubjects } from '/shared/scoring/subjects.js';
import { reconcileResultDraftRows } from '/shared/scoring/results-draft.js';
let user,
  csrf,
  catalog,
  offerings,
  supportEmail = '',
  emailEnabled = false,
  intakeYear = 2027;
const main = document.querySelector('#main'),
  page = document.body.dataset.page;
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
  );
const safeHttps = (value) => {
  try {
    const url = new URL(String(value));
    return url.protocol === 'https:' ? url.href : '';
  } catch {
    return '';
  }
};
const nav = {
  learner: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['results', 'Results', 'file-chart-column'],
    ['subjects', 'Subjects', 'book-open'],
    ['universities', 'Universities', 'building-2'],
    ['requirements', 'Requirements', 'list-checks'],
    ['applications', 'My Applications', 'send'],
    ['documents', 'Documents', 'folder-open'],
    ['prospectuses', 'Prospectuses', 'book-open'],
    ['pilot-programmes', 'Verified pilot programmes', 'badge-check'],
    ['whatif', 'What-If simulator', 'sliders-horizontal'],
    ['funding', 'Funding matches', 'wallet'],
    ['credit-transfer', 'Credit transfer guidance', 'arrow-left-right'],
    ['deadlines', 'Deadlines and alerts', 'calendar-clock'],
    ['privacy', 'Privacy and consent', 'shield-check'],
  ],
  teacher: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['learners', 'Learners', 'users'],
    ['results', 'Results', 'file-check-2'],
    ['applications', 'Applications', 'send'],
    ['documents', 'Documents', 'folder-open'],
  ],
  representative: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['applications', 'Applications', 'inbox'],
    ['decisions', 'Admission Decisions', 'clipboard-check'],
    ['offerings', 'Programme Requirements', 'list-checks'],
    ['prospectuses', 'Prospectuses', 'book-open'],
  ],
  admin: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['accounts', 'Accounts', 'users'],
    ['directories', 'Directories', 'map-pinned'],
    ['lookups', 'Academic Lookups', 'table-properties'],
    ['offerings', 'Programme Requirements', 'list-checks'],
    ['policies', 'Requirements Review', 'book-open'],
    ['audit', 'Audit History', 'history'],
    ['applications', 'Applications', 'inbox'],
    ['verification', 'Pilot verification ledger', 'badge-check'],
    ['funding-admin', 'Funding records', 'wallet'],
    ['pilot', 'Pilot outcomes', 'chart-no-axes-combined'],
  ],
};
const navigationGroups = {
  learner: [
    ['Workspace', ['overview', 'profile']],
    ['My academic record', ['results', 'subjects', 'documents', 'privacy']],
    ['University applications', ['universities', 'requirements', 'applications', 'prospectuses', 'pilot-programmes', 'whatif']],
    ['Funding and planning', ['funding', 'credit-transfer', 'deadlines']],
  ],
  teacher: [
    ['Workspace', ['overview', 'profile']],
    ['Learner support', ['learners', 'results', 'documents']],
    ['Application tracking', ['applications']],
  ],
  representative: [
    ['Workspace', ['overview', 'profile']],
    ['Admissions', ['applications', 'decisions']],
    ['University information', ['offerings', 'prospectuses']],
  ],
  admin: [
    ['Workspace', ['overview', 'profile']],
    ['People and institutions', ['accounts', 'directories']],
    ['Academic configuration', ['lookups', 'offerings', 'policies']],
    ['Pilot operations', ['verification', 'funding-admin', 'pilot']],
    ['Oversight', ['applications', 'audit']],
  ],
};
const verifiedLabel = (id) =>
  catalog.verificationStatuses.find((s) => String(s.VERIFICATION_STATUS_ID) === String(id))
    ?.VERIFICATION_STATUS_NAME || 'Unknown';
const icons = () => window.lucide?.createIcons();
const request = (path, method = 'GET', body) =>
  api(path, {
    method,
    headers: {
      ...(body instanceof Blob ? {} : { 'Content-Type': 'application/json' }),
      ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
const title = (name, description = '') => /* HTML */ `
  <div class="page-heading">
    <span class="eyebrow">${intakeYear} UNIVERSITY ENTRY</span>
    <h1>${esc(name)}</h1>
    <p>${esc(description)}</p>
  </div>
`;
const link = (path, label) => /* HTML */ `
  <a class="inline-link" href="${path}">
    ${esc(label)}
    <i data-lucide="arrow-right" aria-hidden="true"></i>
  </a>
`;
const badge = (s) => /* HTML */ `
  <span class="state-badge">${esc(s)}</span>
`;
const table = (heads, rows) => /* HTML */ `
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          ${heads
            .map(
              (h) => /* HTML */ `
                <th scope="col">${esc(h)}</th>
              `,
            )
            .join('')}
        </tr>
      </thead>
      <tbody>
        ${
          rows.length
            ? rows.join('')
            : /* HTML */ `
                <tr><td colspan="${heads.length}">No records yet.</td></tr>
              `
        }
      </tbody>
    </table>
  </div>
`;
const auditDetail = (raw) => {
  try {
    const data = JSON.parse(raw),
      allowed = new Set([
        'role',
        'invitation',
        'method',
        'count',
        'table',
        'operator',
        'target',
        'status',
        'bytes',
      ]),
      items = Object.entries(data)
        .filter(
          ([key, value]) =>
            allowed.has(key) && ['string', 'number', 'boolean'].includes(typeof value),
        )
        .map(
          ([key, value]) =>
            `${key.replaceAll('_', ' ')}: ${value === true ? 'yes' : value === false ? 'no' : value}`,
        );
    return items.length ? items.join(' · ') : 'Activity recorded';
  } catch {
    return 'Activity recorded';
  }
};
const auditAction = (event) =>
  String(event || 'Activity')
    .replaceAll('.', ' ')
    .replaceAll('_', ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase());
const select = (items, idField, labelField, selected) =>
  items
    .map(
      (x) => /* HTML */ `
        <option
          value="${esc(x[idField])}"
          ${String(x[idField]) === String(selected) ? 'selected' : ''}
        >
          ${esc(x[labelField])}
        </option>
      `,
    )
    .join('');
const examSelect = () => /* HTML */ `
  <label>
    Examination milestone
    <select id="exam">
      ${select(catalog.examTypes, 'EXAM_TYPE_ID', 'EXAM_TYPE_NAME')}
    </select>
  </label>
`;
const feedback = (message) => {
  let node = document.querySelector('#feedback');
  if (!node) {
    node = document.createElement('p');
    node.id = 'feedback';
    node.className = 'feedback';
    node.setAttribute('role', 'status');
  }
  const heading = main.querySelector('.page-heading');
  if (heading) heading.after(node);
  else if (!node.isConnected) main.prepend(node);
  node.textContent = message;
  node.scrollIntoView?.({ block: 'nearest' });
};
function show(html) {
  main.innerHTML = html + '<p id="feedback" class="feedback" role="status"></p>';
  icons();
}
const pendingActions = new WeakSet();
function guard(fn) {
  return async (e) => {
    const target = e?.currentTarget;
    if (target && pendingActions.has(target)) {
      e.preventDefault();
      return;
    }
    const button = target?.matches?.('button') ? target : e?.submitter;
    const wasDisabled = button?.disabled;
    if (target) {
      pendingActions.add(target);
      target.setAttribute('aria-busy', 'true');
    }
    if (button) button.disabled = true;
    try {
      await fn(e);
    } catch (error) {
      if (error.status === 401) location.assign('/login.html');
      else feedback(error.message);
    } finally {
      if (target) {
        pendingActions.delete(target);
        target.removeAttribute('aria-busy');
      }
      if (button) button.disabled = wasDisabled;
    }
  };
}
async function upload(path, file, extra = {}) {
  if (!file) throw new Error('Choose a file first.');
  return api(path, {
    method: 'POST',
    headers: {
      'Content-Type': file.type,
      'X-CSRF-Token': csrf,
      'X-File-Name': encodeURIComponent(file.name),
      ...extra,
    },
    body: file,
  });
}
function shell() {
  document.body.dataset.role = user.role;
  document.querySelector('#navigation').innerHTML = navigationGroups[user.role]
    .map(
      ([heading, pages], index) => `
      <section class="navigation-group" aria-labelledby="nav-group-${index}">
        <h2 id="nav-group-${index}" class="navigation-group-title">${esc(heading)}</h2>
        ${pages
          .map((key) => {
            const [p, n, i] = nav[user.role].find((entry) => entry[0] === key);
            const current = p === page || (page === 'verification' && p === 'results');
            return `<a href="/${user.role}/${p}.html" ${current ? 'aria-current="page"' : ''}>
            <i data-lucide="${i}" aria-hidden="true"></i>${esc(n)}</a>`;
          })
          .join('')}
      </section>`,
    )
    .join('');
  document.querySelector('#role-label').textContent =
    {
      learner: 'Learner',
      teacher: 'Career Guidance Teacher',
      representative: 'University Representative',
      admin: 'IT Administrator',
    }[user.role] + ' workspace';
  document.querySelector('#breadcrumb').textContent =
    nav[user.role].find((n) => n[0] === page)?.[1] || 'Workspace';
  document.querySelector('.topbar').lastElementChild.textContent = ['pilot-programmes','whatif','funding','credit-transfer','deadlines','privacy','verification','funding-admin','pilot'].includes(page) ? `${intakeYear} pilot · verified scope only` : `${intakeYear} entry`;
  document.querySelector('.brand').href = '/' + user.role + '/overview.html';
  document.querySelector('.brand').innerHTML = /* HTML */ `
    <img src="/assets/images/varsity-vault-mark.svg" alt="" />
    <span>StudyPath SA</span>
  `;
  document.querySelector('.portal-account').innerHTML =
    '<i data-lucide="log-out" aria-hidden="true"></i>Sign out';
  document.querySelector('.portal-account').href = '#';
  document.querySelector('.portal-account').addEventListener(
    'click',
    guard(async (e) => {
      e.preventDefault();
      await request('/api/auth/logout', 'POST', {});
      location.assign('/');
    }),
  );
  document.querySelector('.page-footer').innerHTML = /* HTML */ `
    <div class="footer-grid">
      <section>
        <strong class="footer-brand">StudyPath SA</strong>
        <p>Explore sourced study pathways, funding guidance and application planning.</p>
        <span class="footer-coverage">
          <i data-lucide="shield-check" aria-hidden="true"></i>
          Pilot recommendations are shown only when verified
        </span>
      </section>
      <nav aria-label="Help and guidance">
        <strong>Help &amp; guidance</strong>
        <a href="/help.html">Help centre</a>
        <a href="/help.html#application-checklist">Application checklist</a>
        <a href="/help.html#access-support">Account access help</a>
      </nav>
      <section>
        <strong>Support</strong>
        <p>
          ${
            supportEmail
              ? /* HTML */ `
                  Email
                  <a href="mailto:${esc(supportEmail)}">${esc(supportEmail)}</a>
                  for account support.
                `
              : 'For staff account access or password resets, contact your institution’s IT administrator.'
          }
        </p>
        <small>
          For programme decisions, follow the university’s official application instructions.
        </small>
      </section>
    </div>
    <div class="footer-bottom">
      <span>© ${new Date().getFullYear()} StudyPath SA</span>
      <span>${intakeYear} university entry</span>
    </div>
  `;
  document.title =
    (nav[user.role].find((n) => n[0] === page)?.[1] || 'Workspace') + ' | StudyPath SA';
  icons();
}
async function login() {
  catalog = await api('/api/catalog');
  const registrationSchools = catalog.schools.filter(
    (school) => school.EMIS_NUMBER !== 'LOCAL-ONLY',
  );
  document.body.classList.add('is-auth');
  document.querySelector('.sidebar').hidden = true;
  document.querySelector('.shell').classList.add('auth-shell');
  document.querySelector('.portal-header').hidden = true;
  document.querySelector('.topbar').hidden = true;
  document.querySelector('.page-footer').hidden = true;
  show(/* HTML */ `
    <section class="auth-layout">
      <aside class="auth-story">
        <a href="/" class="auth-brand" aria-label="StudyPath SA home">
          <span class="auth-brand-mark">
            <img src="/assets/images/varsity-vault-mark.svg" alt="" />
          </span>
          <span>
            StudyPath SA
            <small>UNIVERSITY PATHWAYS</small>
          </span>
        </a>
        <div class="auth-story-content">
          <span class="auth-overline">
            <i data-lucide="sparkles" aria-hidden="true"></i>
            ${intakeYear} UNIVERSITY ENTRY
          </span>
          <h1>
            Your next chapter
            <br />
            <span>starts here.</span>
          </h1>
          <p>
            Bring your results, documents and university applications together in one secure place.
          </p>
          <div class="auth-story-actions">
            <a href="#auth-tab-register" id="auth-create-account" class="auth-story-cta">
              Create learner account
              <i data-lucide="arrow-right" aria-hidden="true"></i>
            </a>
            <a href="/help.html#application-checklist" class="auth-story-secondary">
              How applications work
            </a>
          </div>
          <div class="auth-feature-list">
            <div>
              <span class="auth-feature-icon">
                <i data-lucide="chart-no-axes-column-increasing" aria-hidden="true"></i>
              </span>
              <span>
                <strong>Understand your results</strong>
                <small>Capture marks and see your APS clearly.</small>
              </span>
            </div>
            <div>
              <span class="auth-feature-icon">
                <i data-lucide="landmark" aria-hidden="true"></i>
              </span>
              <span>
                <strong>Explore your options</strong>
                <small>Compare requirements across South Africa.</small>
              </span>
            </div>
            <div>
              <span class="auth-feature-icon">
                <i data-lucide="file-check-2" aria-hidden="true"></i>
              </span>
              <span>
                <strong>Keep applications organised</strong>
                <small>Follow progress from one workspace.</small>
              </span>
            </div>
          </div>
        </div>
        <div class="auth-story-footer">
          <span>26 UNIVERSITY PROFILES</span>
          <span>Compare your options before you apply.</span>
        </div>
      </aside>
      <section class="auth-main">
        <a href="/" class="auth-mobile-brand" aria-label="StudyPath SA home">
          <span class="auth-brand-mark">
            <img src="/assets/images/varsity-vault-mark.svg" alt="" />
          </span>
          <span>StudyPath SA</span>
        </a>
        <div class="auth-card" id="auth-card">
          <div class="auth-card-heading">
            <span class="auth-overline">WELCOME TO STUDYPATH SA</span>
            <h2 id="auth-title">Welcome back</h2>
            <p id="auth-subtitle">Sign in to continue to your workspace.</p>
          </div>
          <div class="auth-tabs" role="tablist" aria-label="Account access">
            <button
              id="auth-tab-login"
              type="button"
              role="tab"
              aria-selected="true"
              aria-controls="auth-login-panel"
            >
              Sign in
            </button>
            <button
              id="auth-tab-register"
              type="button"
              role="tab"
              aria-selected="false"
              aria-controls="auth-register-panel"
            >
              Create learner account
            </button>
          </div>
          <div id="auth-login-panel" role="tabpanel" aria-labelledby="auth-tab-login">
            <form id="login" class="auth-form">
              <label>
                Email or username
                <input
                  name="username"
                  type="text"
                  autocomplete="username"
                  placeholder="you@example.com"
                  required
                />
              </label>
              <label>
                Password
                <input
                  name="password"
                  type="password"
                  autocomplete="current-password"
                  placeholder="Enter your password"
                  required
                  maxlength="128"
                />
              </label>
              <button class="auth-submit" type="submit">
                Sign in
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </button>
            </form>
            <a class="inline-link" href="/account-recovery.html">
              Forgot password or need an email verification link?
            </a>
            <p class="auth-secondary-note">
              Staff and representative accounts are provided by your IT administrator.
            </p>
          </div>
          <div id="auth-register-panel" role="tabpanel" aria-labelledby="auth-tab-register" hidden>
            <form id="register" class="auth-form">
              <div class="auth-name-fields">
                <label>
                  First name
                  <input
                    name="firstName"
                    required
                    maxlength="100"
                    autocomplete="given-name"
                    placeholder="First name"
                  />
                </label>
                <label>
                  Last name
                  <input
                    name="lastName"
                    required
                    maxlength="100"
                    autocomplete="family-name"
                    placeholder="Last name"
                  />
                </label>
              </div>
              <label>
                Email address
                <input
                  name="email"
                  type="email"
                  autocomplete="email"
                  placeholder="you@example.com"
                  required
                  maxlength="255"
                />
              </label>
              <label>
                Your school
                <select name="schoolId" required>
                  <option value="" selected disabled>Choose your school</option>
                  ${select(registrationSchools, 'SCHOOL_ID', 'SCHOOL_NAME')}
                </select>
              </label>
              <p class="form-help">
                ${registrationSchools.length ? 'If your school is not listed, ask your school administrator to request an update.' : 'No schools are configured yet. Ask your institution administrator to add your school before creating an account.'}
              </p>
              <label>
                Create password
                <input
                  name="password"
                  type="password"
                  autocomplete="new-password"
                  placeholder="At least 12 characters"
                  minlength="12"
                  maxlength="128"
                  required
                />
              </label>
              <button
                class="auth-submit"
                type="submit"
                ${registrationSchools.length ? '' : 'disabled'}
              >
                Create learner account
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </button>
            </form>
            <p class="auth-secondary-note">
              Teachers and representatives receive accounts from your IT administrator.
            </p>
          </div>
        </div>
        <p class="auth-privacy">
          <i data-lucide="shield-check" aria-hidden="true"></i>
          Your academic journey, organised in one secure workspace.
        </p>
      </section>
    </section>
  `);
  const setTab = (register) => {
    const loginButton = document.querySelector('#auth-tab-login'),
      registerButton = document.querySelector('#auth-tab-register'),
      loginPanel = document.querySelector('#auth-login-panel'),
      registerPanel = document.querySelector('#auth-register-panel');
    loginButton.setAttribute('aria-selected', String(!register));
    registerButton.setAttribute('aria-selected', String(register));
    loginButton.tabIndex = register ? -1 : 0;
    registerButton.tabIndex = register ? 0 : -1;
    loginPanel.hidden = register;
    registerPanel.hidden = !register;
    document.querySelector('#auth-title').textContent = register
      ? 'Create your account'
      : 'Welcome back';
    document.querySelector('#auth-subtitle').textContent = register
      ? 'Start organising your university applications.'
      : 'Sign in to continue to your workspace.';
    icons();
  };
  document.querySelector('#auth-tab-login').addEventListener('click', () => setTab(false));
  document.querySelector('#auth-tab-register').addEventListener('click', () => setTab(true));
  document.querySelector('#auth-create-account').addEventListener('click', (event) => {
    event.preventDefault();
    setTab(true);
    document.querySelector('#auth-card')?.scrollIntoView?.({ block: 'start' });
    document.querySelector('#auth-tab-register').focus();
  });
  window.addEventListener('hashchange', () => {
    if (location.hash === '#auth-tab-register') setTab(true);
  });
  setTab(location.hash === '#auth-tab-register');
  document.querySelector('#login').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const button = e.submitter || e.target.querySelector('button');
      if (!button) return;
      button.disabled = true;
      button.classList.add('is-loading');
      try {
        const data = Object.fromEntries(new FormData(e.target)),
          out = await request('/api/auth/login', 'POST', data);
        if (out.mfaRequired) {
          location.assign('/mfa-challenge.html');
          return;
        }
        location.assign('/' + out.user.role + '/overview.html');
      } finally {
        button.disabled = false;
        button.classList.remove('is-loading');
      }
    }),
  );
  document.querySelector('#register').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const button = e.submitter || e.target.querySelector('button');
      if (!button) return;
      button.disabled = true;
      try {
        const data = Object.fromEntries(new FormData(e.target));
        data.schoolId = Number(data.schoolId);
        const out = await request('/api/auth/register', 'POST', data);
        feedback(out.message);
        e.target.reset();
        setTab(false);
      } finally {
        button.disabled = !catalog.schools.some((school) => school.EMIS_NUMBER !== 'LOCAL-ONLY');
      }
    }),
  );
}
async function profile() {
  const { person } = await request('/api/me/profile'),
    school = catalog.schools.find((item) => String(item.SCHOOL_ID) === String(user.schoolId)),
    university = catalog.universities.find(
      (item) => String(item.UNIVERSITY_ID) === String(user.universityId),
    ),
    scope =
      school?.SCHOOL_NAME ||
      university?.UNIVERSITY_NAME ||
      (user.role === 'admin' ? 'System administration' : 'Institution not assigned');
  show(
    title('My Profile', 'Your identity and assigned portal scope.') +
      /* HTML */ `
        <section class="panel">
          <form id="profile">
            <div class="fields">
              <label>
                First name
                <input
                  name="firstName"
                  value="${esc(person.FIRST_NAME)}"
                  required
                  maxlength="100"
                />
              </label>
              <label>
                Last name
                <input name="lastName" value="${esc(person.LAST_NAME)}" required maxlength="100" />
              </label>
              <label>
                Phone number
                <input name="phone" value="${esc(person.PHONE_NUMBER)}" maxlength="10" />
              </label>
              <label>
                Email
                <input value="${esc(person.EMAIL)}" readonly />
              </label>
            </div>
            <button>Save profile</button>
          </form>
          <p class="muted">
            ${esc({ learner: 'Learner', teacher: 'Career Guidance Teacher', representative: 'University Representative', admin: 'IT Administrator' }[user.role])}
            · ${esc(scope)}
          </p>
        </section>
      `,
  );
  document.querySelector('#profile').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      feedback(
        (await request('/api/me/profile', 'PUT', Object.fromEntries(new FormData(e.target))))
          .message,
      );
    }),
  );
  main.insertAdjacentHTML(
    'beforeend',
    /* HTML */ `
      <section class="panel">
        <h2>Change password</h2>
        <form id="password-change">
          <div class="fields">
            <label>
              Current password
              <input
                name="currentPassword"
                type="password"
                required
                autocomplete="current-password"
              />
            </label>
            <label>
              New password
              <input
                name="newPassword"
                type="password"
                minlength="12"
                maxlength="128"
                required
                autocomplete="new-password"
              />
            </label>
          </div>
          <button>Change password and sign out</button>
        </form>
      </section>
    `,
  );
  document.querySelector('#password-change').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      await request('/api/me/password', 'POST', Object.fromEntries(new FormData(e.target)));
      location.assign('/login.html');
    }),
  );
}
function learnerExamKey() {
  return 'vv-results-exam-' + user.personId;
}
function rememberedExam() {
  try {
    return localStorage.getItem(learnerExamKey()) || '';
  } catch {
    return '';
  }
}
function rememberExam(examId) {
  try {
    localStorage.setItem(learnerExamKey(), String(examId));
  } catch {}
}
function learnerResultsDraftKey(examId) {
  return 'vv-results-draft-' + user.personId + '-' + examId;
}
function readLearnerResultsDraft(examId) {
  try {
    const value = localStorage.getItem(learnerResultsDraftKey(examId));
    return value === null ? null : JSON.parse(value);
  } catch {
    return null;
  }
}
function writeLearnerResultsDraft(examId, rows) {
  try {
    localStorage.setItem(learnerResultsDraftKey(examId), JSON.stringify(rows));
  } catch {}
}
function clearLearnerResultsDraft(examId) {
  try {
    localStorage.removeItem(learnerResultsDraftKey(examId));
  } catch {}
}
function sameResultRows(first, second) {
  if (!Array.isArray(first) || !Array.isArray(second) || first.length !== second.length)
    return false;
  const normalize = (rows) =>
    rows
      .map((row) => [String(row.SUBJECT_ID), Number(row.PERCENTAGE)])
      .sort(([a], [b]) => a.localeCompare(b));
  const left = normalize(first),
    right = normalize(second);
  return left.every(
    ([subjectId, mark], index) =>
      subjectId === right[index][0] && Number.isFinite(mark) && mark === right[index][1],
  );
}
async function resultsPage() {
  let learners = [];
  if (user.role === 'teacher') learners = (await request('/api/teacher/learners')).learners;
  show(
    title(
      user.role === 'teacher' ? 'Results Verification' : 'Academic Results',
      'Capture and review percentage marks by examination milestone.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">
            ${
              user.role === 'teacher'
                ? /* HTML */ `
                    <label>
                      Learner
                      <select id="learner">
                        ${select(learners, 'LEARNER_ID', 'name')}
                      </select>
                    </label>
                  `
                : ''
            }${examSelect()}
          </div>
          <div id="result-grid"></div>
        </section>
      `,
  );
  const examSelectElement = document.querySelector('#exam'),
    queryExam = new URLSearchParams(location.search).get('examTypeId'),
    preferred = queryExam || rememberedExam();
  if (
    user.role === 'learner' &&
    catalog.examTypes.some((item) => String(item.EXAM_TYPE_ID) === String(preferred))
  )
    examSelectElement.value = String(preferred);
  let rows = [],
    loadSequence = 0;
  const persistDraft = (examId) => {
    if (user.role === 'learner') writeLearnerResultsDraft(examId, rows);
  };
  const renderLearner = (examId) => {
    const grid = document.querySelector('#result-grid');
    grid.innerHTML =
      table(
        ['Subject', 'Percentage', 'Action'],
        rows.map(
          (row, index) => /* HTML */ `
            <tr>
              <th>
                ${esc(row.SUBJECT_NAME)}
                ${row.__subjectResolutionError ? `<small class="muted">${esc(row.__subjectResolutionError)}</small>` : ''}
              </th>
              <td>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  data-mark="${index}"
                  value="${row.PERCENTAGE ?? ''}"
                />
              </td>
              <td>
                <button type="button" class="secondary compact" data-remove="${index}">
                  Remove
                </button>
              </td>
            </tr>
          `,
        ),
      ) +
      /* HTML */ `
        <div class="fields">
          <label>
            Add subject
            <select id="subject">
              ${select(
                catalog.subjects.filter(
                  (subject) =>
                    !rows.some(
                      (row) =>
                        !row.__subjectResolutionError &&
                        String(row.SUBJECT_ID) === String(subject.SUBJECT_ID),
                    ) &&
                    (subject.SCHOOL_ID == null ||
                      Number(subject.SCHOOL_ID) === Number(user.schoolId)),
                ),
                'SUBJECT_ID',
                'SUBJECT_NAME',
              )}
            </select>
          </label>
        </div>
        <div class="actions">
          <button type="button" class="secondary" id="add">Add subject</button>
          <button type="button" id="save-results">Save results</button>
        </div>
      `;
    grid.querySelectorAll('[data-mark]').forEach((input) =>
      input.addEventListener('input', () => {
        rows[Number(input.dataset.mark)].PERCENTAGE =
          input.value === '' ? null : Number(input.value);
        persistDraft(examId);
      }),
    );
    grid.querySelectorAll('[data-remove]').forEach((button) =>
      button.addEventListener('click', () => {
        rows.splice(Number(button.dataset.remove), 1);
        persistDraft(examId);
        renderLearner(examId);
      }),
    );
    grid.querySelector('#add').addEventListener('click', () => {
      const subjectId = grid.querySelector('#subject').value,
        subject = catalog.subjects.find((item) => String(item.SUBJECT_ID) === String(subjectId));
      if (subject && !rows.some((row) => String(row.SUBJECT_ID) === String(subject.SUBJECT_ID))) {
        rows.push({ ...subject, PERCENTAGE: 0 });
        persistDraft(examId);
        renderLearner(examId);
      }
    });
    grid.querySelector('#save-results').addEventListener(
      'click',
      guard(async (event) => {
        const button = event.currentTarget;
        button.disabled = true;
        button.textContent = 'Saving results…';
        try {
          const reconciled = reconcileResultDraftRows(rows, catalog.subjects, user.schoolId);
          if (reconciled.unresolved.length) {
            rows = reconciled.rows;
            persistDraft(examId);
            renderLearner(examId);
            throw new Error(
              `These draft subjects are not available in the current database: ${reconciled.unresolved.join(', ')}. Remove each marked row, then add the matching subject from the current subject list. Your marks have been kept in this browser.`,
            );
          }
          rows = reconciled.rows;
          persistDraft(examId);
          const submittedRows = rows.map((row) => ({
            SUBJECT_ID: Number(row.SUBJECT_ID),
            PERCENTAGE: row.PERCENTAGE,
          }));
          if (
            submittedRows.some(
              (row) =>
                !Number.isFinite(row.PERCENTAGE) || row.PERCENTAGE < 0 || row.PERCENTAGE > 100,
            )
          ) {
            throw new Error(
              'Enter a valid percentage from 0 to 100 for every subject before saving.',
            );
          }
          const result = await request('/api/results', 'PUT', {
            examTypeId: Number(examId),
            rows: submittedRows.map((row) => ({
              subjectId: row.SUBJECT_ID,
              percentage: row.PERCENTAGE,
            })),
          });
          // Confirm the write from the API before clearing the local draft.
          // If SQL Server rejects the write, the learner's entries are retained.
          const saved = await request('/api/results?examTypeId=' + encodeURIComponent(examId));
          const confirmed = sameResultRows(submittedRows, saved.rows);
          if (confirmed) clearLearnerResultsDraft(examId);
          await load({ ignoreDraft: confirmed });
          feedback(
            confirmed
              ? `${result.message} Saved ${saved.rows.length} subject result(s) for this milestone.`
              : 'The server did not confirm these marks. Your browser draft has been kept. Check the VS Code terminal for the database error, then retry.',
          );
          syncPathwayWithResults(confirmed && saved.rows.length > 0);
          icons();
        } finally {
          if (button.isConnected) {
            button.disabled = false;
            button.textContent = 'Save results';
          }
        }
      }),
    );
  };
  const load = async ({ ignoreDraft = false } = {}) => {
    const learner = document.querySelector('#learner')?.value;
    if (user.role === 'teacher' && !learner) {
      document.querySelector('#result-grid').textContent = 'No learners enrolled at your school.';
      return false;
    }
    const examId = examSelectElement.value,
      sequence = ++loadSequence,
      data = await request(
        '/api/results?examTypeId=' + examId + (learner ? '&learnerId=' + learner : ''),
      );
    if (sequence !== loadSequence) return false;
    rows = data.rows;
    if (user.role === 'learner') {
      const draft = ignoreDraft ? null : readLearnerResultsDraft(examId);
      if (ignoreDraft) {
        rows = data.rows;
      } else if (Array.isArray(draft)) {
        // Browser drafts can outlive a database reseed. Subject IDs are IDENTITY
        // values and may change; remap by stable code/name before sending them.
        const reconciled = reconcileResultDraftRows(draft, catalog.subjects, user.schoolId);
        rows = reconciled.rows;
        if (reconciled.unresolved.length) {
          persistDraft(examId);
          feedback(
            `Some saved browser-draft subjects are no longer in the current subject catalogue: ${reconciled.unresolved.join(', ')}. Remove each marked row and re-add it from the subject list; your percentages are retained.`,
          );
        } else if (sameResultRows(rows, data.rows)) {
          clearLearnerResultsDraft(examId);
          rows = data.rows;
        } else {
          persistDraft(examId);
          feedback(
            'Your unsaved marks were restored and matched to the current subject catalogue. Save results to add them to your account.',
          );
        }
      }
      const confirmed =
        ignoreDraft ||
        !Array.isArray(draft) ||
        (!rows.some((row) => row.__subjectResolutionError) && sameResultRows(rows, data.rows));
      renderLearner(examId);
      return confirmed;
    }
    const grid = document.querySelector('#result-grid');
    grid.innerHTML =
      table(
        ['Subject', 'Percentage', 'Verification', 'Action'],
        rows.map(
          (row) => /* HTML */ `
            <tr>
              <th>${esc(row.SUBJECT_NAME)}</th>
              <td>${row.PERCENTAGE}%</td>
              <td>${esc(verifiedLabel(row.VERIFICATION_STATUS_ID))}</td>
              <td></td>
            </tr>
          `,
        ),
      ) +
      /* HTML */ `
        <div class="actions">
          <button type="button" id="verify">Verify against report</button>
          <button type="button" class="secondary" id="reject">Reject / unlock results</button>
          ${link('/teacher/documents.html', 'Review learner reports')}
        </div>
        <p class="muted">
          Download and compare the report before verifying. Your confirmation records that the marks
          match.
        </p>
      `;
    for (const [button, decision] of [
      ['verify', 'Verified'],
      ['reject', 'Rejected'],
    ])
      grid.querySelector('#' + button).addEventListener(
        'click',
        guard(async () => {
          feedback(
            (
              await request('/api/teacher/verify', 'POST', {
                learnerId: Number(learner),
                examTypeId: Number(examId),
                decision,
              })
            ).message,
          );
          await load();
        }),
      );
    icons();
    return true;
  };
  examSelectElement.addEventListener(
    'change',
    guard(() => {
      if (user.role === 'learner') rememberExam(examSelectElement.value);
      return load();
    }),
  );
  document.querySelector('#learner')?.addEventListener('change', guard(load));
  if (user.role === 'learner') rememberExam(examSelectElement.value);
  await load();
}
async function requirements() {
  offerings = (await request('/api/offerings')).offerings;
  let learnerDocuments = [],
    learnerApplications = [],
    learnerRecordsLoaded = true;
  if (user.role === 'learner') {
    const [documentsResult, applicationsResult] = await Promise.allSettled([
      request('/api/documents'),
      request('/api/applications'),
    ]);
    if (documentsResult.status === 'fulfilled')
      learnerDocuments = documentsResult.value.documents || [];
    else learnerRecordsLoaded = false;
    if (applicationsResult.status === 'fulfilled')
      learnerApplications = applicationsResult.value.applications || [];
    else learnerRecordsLoaded = false;
  }
  show(
    title(
      'Start an application',
      'Choose your university and results, select a programme, then review your eligibility before submitting.',
    ) +
      /* HTML */ `
        <section class="panel">
          <ol class="application-steps" aria-label="Application steps">
            <li data-wizard-indicator="1">1. University and results</li>
            <li data-wizard-indicator="2">2. Choose programme</li>
            <li data-wizard-indicator="3">3. Review and apply</li>
          </ol>
          <div class="fields" id="wizard-context">
            <label>
              University
              <select id="university">
                ${select(catalog.universities, 'UNIVERSITY_ID', 'UNIVERSITY_NAME')}
              </select>
            </label>
            ${examSelect()}
          </div>
          <div id="wizard-programme">
            <label class="search">
              Programme
              <select id="offering"></select>
            </label>
          </div>
          <div id="requirements-content"></div>
          <div class="actions application-step-actions">
            <button type="button" class="secondary" id="wizard-back">Previous step</button>
            <button type="button" id="wizard-next">Choose programme</button>
          </div>
        </section>
      `,
  );
  let wizardStep = 1;
  function setWizardStep(step) {
    wizardStep = step;
    document.querySelector('#wizard-context').hidden = step !== 1;
    document.querySelector('#wizard-programme').hidden = step !== 2;
    document.querySelector('#requirements-content').hidden = step !== 3;
    document.querySelector('#wizard-back').hidden = step === 1;
    document.querySelector('#wizard-next').hidden = step === 3;
    document.querySelector('#wizard-next').textContent =
      step === 1 ? 'Choose programme' : 'Review requirements';
    document.querySelectorAll('[data-wizard-indicator]').forEach((item) => {
      if (Number(item.dataset.wizardIndicator) === step) item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
  }
  document
    .querySelector('#wizard-back')
    .addEventListener('click', () => setWizardStep(wizardStep - 1));
  document.querySelector('#wizard-next').addEventListener('click', () => {
    if (
      wizardStep === 1 &&
      (!document.querySelector('#university').value || !document.querySelector('#exam').value)
    ) {
      feedback('Choose a university and examination milestone.');
      return;
    }
    if (wizardStep === 2 && !document.querySelector('#offering').value) {
      feedback('Choose a programme before reviewing your application.');
      return;
    }
    feedback('');
    setWizardStep(wizardStep + 1);
  });
  setWizardStep(1);
  const params = new URLSearchParams(location.search),
    requestedExam = params.get('examTypeId'),
    remembered = rememberedExam();
  if (
    requestedExam &&
    catalog.examTypes.some((item) => String(item.EXAM_TYPE_ID) === String(requestedExam))
  )
    document.querySelector('#exam').value = String(requestedExam);
  else {
    const summary = await request('/api/results/summary'),
      saved = new Set((summary.examTypeIds || []).map(String));
    const rememberedHasResults = saved.has(String(remembered));
    const latestSaved = [...catalog.examTypes]
      .reverse()
      .find((item) => saved.has(String(item.EXAM_TYPE_ID)));
    const preferred = rememberedHasResults ? remembered : (latestSaved?.EXAM_TYPE_ID ?? remembered);
    if (catalog.examTypes.some((item) => String(item.EXAM_TYPE_ID) === String(preferred)))
      document.querySelector('#exam').value = String(preferred);
  }
  const load = async () => {
    const universityId = document.querySelector('#university').value,
      examId = Number(document.querySelector('#exam').value),
      offerId = document.querySelector('#offering').value,
      o = offerings.find((item) => String(item.UNI_QUAL_ID) === String(offerId));
    const assessment = o
      ? await request('/api/offerings/' + offerId + '/requirements?examTypeId=' + examId)
      : assessSubjects((await request('/api/results?examTypeId=' + examId)).rows, null, {});
    const grade11 = catalog.examTypes.find((item) => item.EXAM_TYPE_NAME === 'Grade 11 Final'),
      isApplicationMilestone =
        !grade11 || String(document.querySelector('#exam').value) === String(grade11.EXAM_TYPE_ID),
      requiredDocs = catalog.documentTypes.filter(
        (item) =>
          item.IS_MANDATORY ||
          o?.config.requiredDocumentIds?.includes(Number(item.DOCUMENT_TYPE_ID)),
      ),
      missingDocs = requiredDocs.filter(
        (type) =>
          !learnerDocuments.some(
            (doc) => String(doc.DOCUMENT_TYPE_ID) === String(type.DOCUMENT_TYPE_ID),
          ),
      ),
      closingDate = String(o?.APPLICATION_CLOSING_DATE || '').slice(0, 10),
      today = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Africa/Johannesburg',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(new Date()),
      deadlineOpen = o?.availability
        ? o.availability === 'Open'
        : /^\d{4}-\d{2}-\d{2}$/.test(closingDate) && closingDate >= today,
      alreadyApplied =
        !!o &&
        learnerApplications.some(
          (item) =>
            String(item.UNI_QUAL_ID) === String(o.UNI_QUAL_ID) &&
            Number(item.ACADEMIC_YEAR) === intakeYear,
        ),
      studyModesAvailable = Array.isArray(catalog.studyModes) && catalog.studyModes.length > 0,
      ready =
        !!assessment.eligible &&
        isApplicationMilestone &&
        !missingDocs.length &&
        learnerRecordsLoaded &&
        deadlineOpen &&
        !alreadyApplied;
    const readiness = o
      ? /* HTML */ `
          <ul class="apply-checklist">
            <li
              class="${isApplicationMilestone && assessment.eligible ? 'is-ready' : 'is-pending'}"
            >
              <span>${isApplicationMilestone && assessment.eligible ? 'Ready' : 'Check'}</span>
              ${isApplicationMilestone ? (assessment.eligible ? 'Grade 11 Final results meet the listed requirements.' : 'Grade 11 Final results do not yet meet the listed requirements.') : `Select Grade 11 Final to check application eligibility.`}
            </li>
            ${requiredDocs
              .map((type) => {
                const uploaded = !missingDocs.some(
                  (item) => String(item.DOCUMENT_TYPE_ID) === String(type.DOCUMENT_TYPE_ID),
                );
                return /* HTML */ `
                  <li class="${uploaded ? 'is-ready' : 'is-pending'}">
                    <span>${uploaded ? 'Ready' : 'Needed'}</span>
                    ${esc(type.DOCUMENT_TYPE_NAME)}${
                      uploaded
                        ? ' uploaded'
                        : /* HTML */ `
                            ·
                            <a href="/learner/documents.html">Upload in Documents</a>
                          `
                    }
                  </li>
                `;
              })
              .join('')}${
              !learnerRecordsLoaded
                ? /* HTML */ `
                    <li class="is-pending">
                      <span>Check</span>
                      Could not confirm your documents and existing applications. Reload this page
                      to try again.
                    </li>
                  `
                : ''
            }
            <li class="${deadlineOpen ? 'is-ready' : 'is-pending'}">
              <span>${esc(o?.availability || (deadlineOpen ? 'Open' : 'Closed'))}</span>
              Application deadline: ${esc(closingDate || 'not confirmed')}
            </li>
            ${
              alreadyApplied
                ? /* HTML */ `
                    <li class="is-pending">
                      <span>Already applied</span>
                      You already submitted an application for this programme in ${intakeYear}.
                      <a href="/learner/applications.html">View your application</a>
                    </li>
                  `
                : ''
            }
          </ul>
        `
      : '';
    document.querySelector('#requirements-content').innerHTML = /* HTML */ `
      <div class="split">
        <section>
          <h2>${esc(assessment.metric)}</h2>
          <div class="score">
            ${assessment.total === null ? 'Not calculated' : assessment.total}
          </div>
          ${table(
            ['Subject', 'Percentage', o?.config.scoring ? 'Score contribution' : 'APS points'],
            assessment.contributions.map(
              (row) => /* HTML */ `
                <tr>
                  <th>${esc(row.SUBJECT_NAME)}</th>
                  <td>${row.PERCENTAGE}%</td>
                  <td>${row.points}</td>
                </tr>
              `,
            ),
          )}
          <p class="muted">
            ${o?.config.scoring ? 'This programme uses its configured subject selection, weights and score scale.' : 'Life Orientation is excluded. Each academic subject contributes 1–7 points; the total uses up to six subjects.'}
          </p>
        </section>
        <section class="requirements-review">
          <div class="notice">
            <strong>${esc(assessment.status)}</strong>
            ${assessment.issues
              .map(
                (issue) => /* HTML */ `
                  <p>${esc(issue)}</p>
                `,
              )
              .join('')}
          </div>
          ${
            o
              ? /* HTML */ `
                  <div class="review-meta">
                    <p>
                      <strong>Minimum APS</strong>
                      <br />
                      ${esc(o.config.minScore)} ${esc(o.config.scoring?.label || '/ 42')}
                    </p>
                    <p>
                      <strong>Minimum English</strong>
                      <br />
                      ${o.config.minEnglish == null ? 'Not specified' : esc(o.config.minEnglish) + '%'}
                    </p>
                    <p>
                      <strong>Minimum Mathematics</strong>
                      <br />
                      ${o.config.minMath == null ? 'Not specified' : esc(o.config.minMath) + '%'}
                    </p>
                    <p>
                      <strong>Closing date</strong>
                      <br />
                      ${esc(closingDate || 'Not confirmed')}
                    </p>
                    <p>
                      ${esc(o.config.notes || 'Check the official programme instructions for complete conditions.')}
                    </p>
                    <p>
                      <a
                        href="${esc(safeHttps(o.config.source))}"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Official programme requirements
                      </a>
                    </p>
                  </div>
                  ${assessment.provenance ? /* HTML */ `
                    <section class="notice provenance-block" aria-label="Programme source and verification">
                      <h3>Source and verification</h3>
                      <p><a href="${esc(safeHttps(assessment.provenance.source?.url))}" target="_blank" rel="noopener noreferrer">${esc(assessment.provenance.source?.title || 'Official source')}</a>${assessment.provenance.source?.year ? ` (${esc(assessment.provenance.source.year)})` : ''}${assessment.provenance.source?.pageRef ? `, ${esc(assessment.provenance.source.pageRef)}` : ''}</p>
                      <p>Last updated: ${esc(String(assessment.provenance.lastUpdated || 'Not recorded').slice(0, 10))}. Verification role: ${esc(assessment.provenance.lastVerifiedByRole || 'admin')}.</p>
                      <p><strong>Conditions</strong></p>
                      <ul>${(assessment.provenance.conditions || []).map((condition) => `<li>${esc(condition)}</li>`).join('')}</ul>
                    </section>
                  ` : ''}
                  ${
                    (o.config.subjectGroups || []).length
                      ? `<section><h3>Subject requirements</h3><p>Meet at least one alternative in each group.</p>${table(
                          ['Group', 'Subject', 'Minimum'],
                          o.config.subjectGroups.map(
                            (r) =>
                              `<tr><td>${esc(r.group)}</td><td>${esc(catalog.subjects.find((s) => s.SUBJECT_CODE === r.code)?.SUBJECT_NAME || r.code)}</td><td>${esc(r.minimum)}%</td></tr>`,
                          ),
                        )}</section>`
                      : ''
                  }
                  <div class="apply-panel">
                    <span class="section-kicker">Your next step</span>
                    <h3>Apply for ${esc(o.qualification)}</h3>
                    <p>
                      Submit your application here. Eligibility is checked using Grade 11 Final
                      results. Your teacher reviews the submission before it goes to the university
                      representative.
                    </p>
                    ${readiness}
                    ${assessment.pilotGuard?.acknowledgementRequired && isApplicationMilestone ? /* HTML */ `
                      <div class="notice" role="note" aria-live="polite">
                        <strong>Subject requirement warning</strong>
                        <p>${esc(assessment.pilotGuard.reason)}</p>
                        <label class="application-confirmation">
                          <span><input id="unsuitable-confirm" type="checkbox" /> I understand this subject warning and will verify the programme requirements with the institution.</span>
                        </label>
                        <p class="muted">Acknowledging the warning does not override published requirements or make an ineligible application eligible.</p>
                      </div>
                    ` : ''}
                    ${
                      grade11 && !isApplicationMilestone
                        ? /* HTML */ `
                            <div class="actions">
                              <button type="button" class="secondary" id="review-grade11">
                                Review Grade 11 eligibility
                              </button>
                            </div>
                          `
                        : ''
                    }${
                      assessment.eligible && isApplicationMilestone
                        ? /* HTML */ `
                            ${
                              studyModesAvailable
                                ? /* HTML */ `
                                    <label>
                                      Study mode
                                      <select id="study-mode" required>
                                        <option value="" selected disabled>
                                          Choose a study mode
                                        </option>
                                        ${select(catalog.studyModes, 'STUDY_MODE_ID', 'STUDY_MODE_NAME')}
                                      </select>
                                    </label>
                                  `
                                : /* HTML */ `
                                    <div class="notice" role="status">
                                      <strong>Study modes are not configured</strong>
                                      <p>
                                        Ask the IT administrator to add Full-time or Part-time in
                                        Academic Lookups. Applications cannot be submitted until a
                                        study mode is available.
                                      </p>
                                    </div>
                                  `
                            }
                            <div class="actions">
                              ${
                                ready && studyModesAvailable
                                  ? /* HTML */ `
                                      <label class="application-confirmation">
                                        <span>
                                          <input id="application-confirm" type="checkbox" />
                                          I checked the programme requirements and my supporting
                                          documents.
                                        </span>
                                      </label>
                                      <button id="apply" type="button">
                                        Submit application
                                        <i data-lucide="arrow-right" aria-hidden="true"></i>
                                      </button>
                                    `
                                  : !studyModesAvailable
                                    ? ''
                                    : /* HTML */ `
                                        <a
                                          class="button-link secondary"
                                          href="/learner/results.html"
                                        >
                                          Review my results
                                          <i data-lucide="arrow-right" aria-hidden="true"></i>
                                        </a>
                                        <a
                                          class="button-link secondary"
                                          href="/learner/documents.html"
                                        >
                                          Prepare documents
                                          <i data-lucide="arrow-right" aria-hidden="true"></i>
                                        </a>
                                      `
                              }
                            </div>
                          `
                        : /* HTML */ `
                            <p class="muted">
                              Complete the checklist above before submitting. Applications are
                              assessed from verified programme rules and Grade 11 Final results.
                            </p>
                            <div class="actions">
                              <a class="button-link" href="/learner/results.html">
                                Review my results
                                <i data-lucide="arrow-right" aria-hidden="true"></i>
                              </a>
                              <a class="button-link secondary" href="/learner/documents.html">
                                Prepare documents
                                <i data-lucide="arrow-right" aria-hidden="true"></i>
                              </a>
                            </div>
                          `
                    }
                  </div>
                `
              : '<p>No programme is listed for this university yet. You can still review your standard APS; check back when the university publishes its programme listing.</p>'
          }
          <p class="muted">${esc(assessment.disclaimer || 'Meeting listed minimums does not guarantee an admission offer.')}</p>
        </section>
      </div>
    `;
    document.querySelector('#review-grade11')?.addEventListener('click', () => {
      document.querySelector('#exam').value = String(grade11.EXAM_TYPE_ID);
      document.querySelector('#exam').dispatchEvent(new Event('change', { bubbles: true }));
    });
    document.querySelector('#unsuitable-confirm')?.addEventListener('change', guard(async (event) => {
      const checkbox = event.currentTarget;
      if (!checkbox.checked || assessment.eligible) return;
      try {
        const out = await request('/api/pilot/unsuitable-acknowledgement', 'POST', { offeringId: Number(offerId) });
        feedback(out.message);
      } catch (error) {
        checkbox.checked = false;
        throw error;
      }
    }));
    document.querySelector('#apply')?.addEventListener(
      'click',
      guard(async () => {
        if (!document.querySelector('#application-confirm')?.checked) {
          feedback('Confirm that you checked the requirements and supporting documents.');
          return;
        }
        if (assessment.pilotGuard?.acknowledgementRequired && !document.querySelector('#unsuitable-confirm')?.checked) {
          feedback('Acknowledge the subject requirement warning before continuing.');
          return;
        }
        const studyModeId = Number(document.querySelector('#study-mode')?.value);
        if (!Number.isInteger(studyModeId) || studyModeId < 1) {
          feedback('Choose a study mode before submitting your application.');
          return;
        }
        const out = await request('/api/applications', 'POST', {
          offeringId: Number(offerId),
          studyModeId,
          acknowledgeUnsuitable: Boolean(assessment.pilotGuard?.acknowledgementRequired && document.querySelector('#unsuitable-confirm')?.checked),
        });
        learnerApplications.push({ UNI_QUAL_ID: o.UNI_QUAL_ID, ACADEMIC_YEAR: intakeYear });
        await load();
        feedback(out.message);
      }),
    );
    icons();
  };
  const updateOptions = async (selectedOfferingId = '') => {
    const universityId = document.querySelector('#university').value,
      available = offerings.filter((item) => String(item.UNIVERSITY_ID) === String(universityId));
    document.querySelector('#offering').innerHTML =
      '<option value="">APS overview only</option>' +
      available
        .map(
          (item) => /* HTML */ `
            <option value="${item.UNI_QUAL_ID}">
              ${esc(item.qualification)} ·
              ${item.config.status === 'verified' ? 'requirements verified' : 'requirements pending verification'}
            </option>
          `,
        )
        .join('');
    if (available.some((item) => String(item.UNI_QUAL_ID) === String(selectedOfferingId)))
      document.querySelector('#offering').value = String(selectedOfferingId);
    await load();
  };
  document.querySelector('#university').addEventListener('change', guard(updateOptions));
  document.querySelector('#offering').addEventListener('change', guard(load));
  document.querySelector('#exam').addEventListener(
    'change',
    guard(async () => {
      rememberExam(document.querySelector('#exam').value);
      await load();
    }),
  );
  const requested = offerings.find((item) => String(item.UNI_QUAL_ID) === params.get('offeringId'));
  if (requested) {
    document.querySelector('#university').value = String(requested.UNIVERSITY_ID);
    await updateOptions(requested.UNI_QUAL_ID);
  } else await updateOptions();
}
async function subjectsPage() {
  show(
    title(
      'My Subjects',
      'Review saved marks and any unsaved changes for each examination milestone.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">${examSelect()}</div>
          <div id="subject-records"></div>
          <div class="actions" id="subject-actions"></div>
        </section>
      `,
  );
  const examControl = document.querySelector('#exam'),
    preferred = rememberedExam();
  if (catalog.examTypes.some((item) => String(item.EXAM_TYPE_ID) === String(preferred)))
    examControl.value = String(preferred);
  const load = async () => {
    const examId = Number(examControl.value),
      out = await request('/api/results?examTypeId=' + examId),
      saved = out.rows || [];
    let rows = saved,
      draft = readLearnerResultsDraft(examId),
      state = saved.length ? 'Saved for this milestone' : 'No results saved for this milestone';
    if (Array.isArray(draft) && sameResultRows(draft, saved)) clearLearnerResultsDraft(examId);
    else if (Array.isArray(draft)) {
      rows = draft;
      state = 'Draft · not saved';
    }
    const examName =
      catalog.examTypes.find((item) => String(item.EXAM_TYPE_ID) === String(examId))
        ?.EXAM_TYPE_NAME || 'Selected milestone';
    document.querySelector('#subject-records').innerHTML =
      /* HTML */ `<h2>${esc(examName)}</h2><p class="muted">${esc(state)}</p>` +
      table(
        ['Subject', 'Category', 'Percentage'],
        rows.map(
          (row) => /* HTML */ `
            <tr>
              <th>
                ${esc(row.SUBJECT_NAME || catalog.subjects.find((subject) => String(subject.SUBJECT_ID) === String(row.SUBJECT_ID))?.SUBJECT_NAME || 'Subject')}
              </th>
              <td>
                ${esc({ HOME_LANGUAGE: 'Home language', FIRST_ADDITIONAL_LANGUAGE: 'First additional language', MATHEMATICS: 'Mathematics', MATHEMATICAL_LITERACY: 'Mathematical literacy', LIFE_ORIENTATION: 'Life Orientation', ELECTIVE: 'Elective' }[row.SUBJECT_CATEGORY] || 'Other subject')}
              </td>
              <td>${row.PERCENTAGE == null ? 'Not entered' : esc(row.PERCENTAGE) + '%'}</td>
            </tr>
          `,
        ),
      );
    document.querySelector('#subject-actions').innerHTML = link(
      '/learner/results.html?examTypeId=' + encodeURIComponent(examId),
      'Add or update results',
    );
  };
  document.querySelector('#exam').addEventListener('change', guard(load));
  await load();
}
async function documentsPage() {
  let learners = [];
  if (user.role === 'teacher') learners = (await request('/api/teacher/learners')).learners;
  show(
    title(
      'Documents',
      user.role === 'teacher'
        ? 'Download reports and identity documents before verifying.'
        : 'Upload PDF, PNG or JPEG documents up to 6 MB.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${
            user.role === 'teacher'
              ? /* HTML */ `
                  <div class="fields">
                    <label>
                      Learner
                      <select id="learner">
                        ${select(learners, 'LEARNER_ID', 'name')}
                      </select>
                    </label>
                  </div>
                `
              : ''
          }
          <div id="documents-grid"></div>
          ${
            user.role === 'learner'
              ? /* HTML */ `
                  <form id="upload">
                    <div class="fields">
                      <label>
                        Document type
                        <select name="type">
                          ${select(catalog.documentTypes, 'DOCUMENT_TYPE_ID', 'DOCUMENT_TYPE_NAME')}
                        </select>
                      </label>
                      <label>
                        File
                        <input
                          name="file"
                          type="file"
                          accept="application/pdf,image/png,image/jpeg"
                          required
                        />
                      </label>
                    </div>
                    <button>Upload document</button>
                  </form>
                `
              : ''
          }
        </section>
      `,
  );
  const load = async () => {
    const learner = document.querySelector('#learner')?.value;
    if (user.role === 'teacher' && !learner) return;
    const { documents } = await request(
      '/api/documents' + (learner ? '?learnerId=' + learner : ''),
    );
    document.querySelector('#documents-grid').innerHTML = table(
      ['Document', 'Uploaded', 'Verification', 'Action'],
      documents.map(
        (d) => /* HTML */ `
          <tr>
            <th>${esc(d.DOCUMENT_NAME)}</th>
            <td>${esc(d.UPLOAD_DATE)}</td>
            <td>${esc(verifiedLabel(d.VERIFICATION_STATUS_ID))}</td>
            <td>
              <a href="/api/documents/${d.DOCUMENT_ID}/download">Download</a>
              ${
                user.role === 'teacher'
                  ? /* HTML */ `
                      <button class="secondary compact" data-doc="${d.DOCUMENT_ID}">Verify</button>
                      <button class="secondary compact" data-reject="${d.DOCUMENT_ID}">
                        Reject
                      </button>
                    `
                  : ''
              }
            </td>
          </tr>
        `,
      ),
    );
    for (const [attribute, decision] of [
      ['data-doc', 'Verified'],
      ['data-reject', 'Rejected'],
    ])
      document.querySelectorAll('[' + attribute + ']').forEach((b) =>
        b.addEventListener(
          'click',
          guard(async () => {
            feedback(
              (
                await request('/api/teacher/verify', 'POST', {
                  learnerId: Number(learner),
                  documentId: Number(b.getAttribute(attribute)),
                  decision,
                })
              ).message,
            );
            await load();
          }),
        ),
      );
  };
  document.querySelector('#learner')?.addEventListener('change', guard(load));
  document.querySelector('#upload')?.addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const form = e.target,
        file = form.elements.namedItem('file'),
        type = form.elements.namedItem('type');
      feedback(
        (await upload('/api/documents', file.files[0], { 'X-Document-Type': type.value })).message,
      );
      await load();
      form.reset();
    }),
  );
  await load();
}
async function prospectuses() {
  const data = await request('/api/prospectuses'),
    universityNames = new Map(
      catalog.universities.map((item) => [String(item.UNIVERSITY_ID), item.UNIVERSITY_NAME]),
    );
  show(
    title(
      'Prospectuses',
      user.role === 'representative'
        ? 'Share the latest official prospectus with learners.'
        : 'Download university prospectuses to explore programme options.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${table(
            ['University', 'Prospectus', 'Published'],
            data.prospectuses.map(
              (item) => /* HTML */ `
                <tr>
                  <th>${esc(universityNames.get(String(item.UNIVERSITY_ID)) || 'University')}</th>
                  <td>
                    <a href="/api/prospectuses/${encodeURIComponent(item.PROSPECTUS_ID)}/download">
                      ${esc(item.PROSPECTUS_FILENAME)}
                    </a>
                  </td>
                  <td>${esc(item.PROSPECTUS_DATE)}</td>
                </tr>
              `,
            ),
          )}
        </section>
        ${
          user.role === 'representative'
            ? /* HTML */ `
                <section class="panel">
                  <h2>Upload a prospectus</h2>
                  <form id="prospectus-upload">
                    <div class="fields">
                      <label>
                        PDF prospectus
                        <input type="file" name="file" accept="application/pdf" required />
                      </label>
                    </div>
                    <button>Upload prospectus</button>
                  </form>
                  <p class="muted">Use a current, official prospectus in PDF format, up to 6 MB.</p>
                </section>
              `
            : ''
        }
      `,
  );
  document.querySelector('#prospectus-upload')?.addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const file = event.target.elements.namedItem('file').files[0];
      if (!file) return;
      await api('/api/prospectuses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/pdf',
          'X-CSRF-Token': csrf,
          'X-File-Name': encodeURIComponent(file.name),
        },
        body: await file.arrayBuffer(),
      });
      await prospectuses();
      feedback('Prospectus uploaded.');
    }),
  );
}
async function applicationsPage() {
  const { applications } = await request('/api/applications');
  const allowed =
    user.role === 'teacher'
      ? { Submitted: ['Screened by Career Teacher'] }
      : user.role === 'representative'
        ? {
            'Screened by Career Teacher': ['Provisionally Accepted', 'Rejected'],
            'Provisionally Accepted': ['Final Matric Verified'],
            'Final Matric Verified': ['Admitted', 'Offer Revoked'],
          }
        : {};
  show(
    title(
      page === 'decisions' ? 'Admission Decisions' : 'Applications',
      'Track verification, decisions and the permanent application timeline.',
    ) +
      (user.role === 'learner'
        ? /* HTML */ `
            <section class="panel" aria-labelledby="start-application-title">
              <h2 id="start-application-title">
                ${applications.length ? 'Apply to another programme' : 'Start your first application'}
              </h2>
              <p>
                Choose a university and programme, compare your Grade 11 Final results with its
                entry requirements, and submit your application once your required documents are
                uploaded.
              </p>
              <a class="button-link" id="start-application" href="/learner/requirements.html">
                Start an application
              </a>
            </section>
          `
        : '') +
      /* HTML */ `
        <section class="panel">
          ${table(
            ['Learner', 'Qualification', 'Status', 'Actions'],
            applications.map(
              (a) => /* HTML */ `
                <tr>
                  <th>${esc(a.learnerName)}</th>
                  <td>
                    ${esc(a.offering.qualification)}
                    <small class="cell-note">
                      ${esc(a.offering.university)} · ${a.ACADEMIC_YEAR}
                    </small>
                  </td>
                  <td>${badge(a.status)}</td>
                  <td>
                    <button class="secondary compact" data-history="${a.APPLICATION_ID}">
                      Timeline
                    </button>
                    ${(allowed[a.status] || [])
                      .map(
                        (status) => /* HTML */ `
                          <button
                            class="secondary compact"
                            data-transition="${a.APPLICATION_ID}"
                            data-status="${status}"
                          >
                            ${esc(status)}
                          </button>
                        `,
                      )
                      .join('')}${
                      user.role === 'representative'
                        ? /* HTML */ `
                            <button
                              class="secondary compact"
                              data-files="${a.LEARNER_ID}"
                              data-app="${a.APPLICATION_ID}"
                            >
                              Evidence
                            </button>
                          `
                        : ''
                    }
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel" id="detail" hidden></section>
      `,
  );
  document.querySelectorAll('[data-transition]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const notes = window.prompt('Decision / review notes (optional):', '');
        if (notes === null) return;
        const out = await request(
          '/api/applications/' + b.dataset.transition + '/transition',
          'POST',
          { status: b.dataset.status, notes },
        );
        await applicationsPage();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-history]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request('/api/applications/' + b.dataset.history + '/timeline'),
          detail = document.querySelector('#detail');
        detail.hidden = false;
        detail.innerHTML =
          /* HTML */ `<h2>Application Timeline</h2><ol class="timeline">` +
          out.timeline
            .map(
              (t) => /* HTML */ `
                <li>
                  <strong>${esc(t.status)}</strong>
                  <span>${esc(t.ACTION_DATE)} UTC</span>
                </li>
              `,
            )
            .join('') +
          '</ol>';
      }),
    ),
  );
  document.querySelectorAll('[data-files]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request('/api/applications/' + b.dataset.app + '/evidence'),
          detail = document.querySelector('#detail');
        detail.hidden = false;
        detail.innerHTML =
          '<h2>Applicant Evidence</h2>' +
          out.exams
            .map(
              (ex) => /* HTML */ `
                <h3>${esc(ex.name)}</h3>
                ${table(
                  ['Subject', 'Mark', 'Verification'],
                  ex.rows.map(
                    (r) => /* HTML */ `
                      <tr>
                        <td>${esc(r.SUBJECT_NAME)}</td>
                        <td>${r.PERCENTAGE}%</td>
                        <td>${esc(verifiedLabel(r.VERIFICATION_STATUS_ID))}</td>
                      </tr>
                    `,
                  ),
                )}
              `,
            )
            .join('') +
          table(
            ['Document', 'Download'],
            out.documents.map(
              (d) => /* HTML */ `
                <tr>
                  <td>${esc(d.DOCUMENT_NAME)}</td>
                  <td><a href="/api/documents/${d.DOCUMENT_ID}/download">Download</a></td>
                </tr>
              `,
            ),
          );
      }),
    ),
  );
}
function pathwayProgress() {
  try {
    return JSON.parse(localStorage.getItem('vv-pathway-' + user.personId) || '{}');
  } catch {
    return {};
  }
}
function savePathwayProgress(progress) {
  try {
    localStorage.setItem('vv-pathway-' + user.personId, JSON.stringify(progress));
  } catch {}
}
function syncPathwayWithResults(hasResults) {
  const progress = pathwayProgress();
  if (!hasResults || progress.resultsReady !== true) {
    delete progress.explored;
    delete progress.requirementsReviewed;
  }
  progress.resultsReady = hasResults;
  savePathwayProgress(progress);
}
function markPathwayVisit() {
  if (user.role !== 'learner') return;
  const progress = pathwayProgress();
  if (progress.resultsReady !== true) return;
  if (page === 'universities') progress.explored = true;
  if (page === 'requirements' && progress.explored === true) progress.requirementsReviewed = true;
  savePathwayProgress(progress);
}
function dashboardDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.valueOf())
    ? 'Date unavailable'
    : new Intl.DateTimeFormat('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' }).format(
        date,
      );
}
async function dashboard() {
  const summary = await request('/api/dashboard/summary'),
    { applications, applicationCount, actionQueue, counts } = summary,
    learner = user.role === 'learner';
  if (learner) syncPathwayWithResults(counts.results > 0);
  const journey = learner
    ? [
        {
          number: '01',
          icon: 'file-chart-column-increasing',
          title: 'Capture your results',
          description: 'Add Grade 11 or NSC marks to see your starting point.',
          href: '/learner/results.html',
          action: counts.results ? 'Review results' : 'Add results',
          complete: counts.results > 0,
        },
        {
          number: '02',
          icon: 'landmark',
          title: 'Explore universities',
          description: 'Compare institutions and discover where you could study.',
          href: '/learner/universities.html',
          action: 'Explore universities',
          complete: counts.results > 0 && pathwayProgress().explored === true,
        },
        {
          number: '03',
          icon: 'list-checks',
          title: 'Check entry requirements',
          description: 'Review subject rules, score scales and programme deadlines.',
          href: '/learner/requirements.html',
          action: 'Check requirements',
          complete:
            counts.results > 0 &&
            pathwayProgress().explored === true &&
            pathwayProgress().requirementsReviewed === true,
        },
        {
          number: '04',
          icon: 'send',
          title: 'Apply with confidence',
          description:
            'Choose a programme, check its requirements and submit from the programme review.',
          href: '/learner/requirements.html',
          action: applicationCount ? 'Apply to another programme' : 'Find a programme to apply',
          complete: applicationCount > 0,
        },
      ]
    : [];
  const activeStep = learner ? journey.findIndex((step) => !step.complete) : -1,
    active = learner ? journey[activeStep] : null;
  const heroActions = {
    learner: active
      ? { href: active.href, label: active.action }
      : { href: '/learner/applications.html', label: 'View applications' },
    teacher: actionQueue.length
      ? { href: '/teacher/applications.html', label: 'Review oldest submission' }
      : { href: '/teacher/results.html', label: 'Review learner results' },
    representative: actionQueue.length
      ? { href: '/representative/decisions.html', label: 'Review oldest application' }
      : { href: '/representative/applications.html', label: 'View applications' },
    admin: actionQueue.length
      ? { href: '/admin/offerings.html', label: 'Verify programme requirements' }
      : { href: '/admin/offerings.html', label: 'Manage 2027 offerings' },
  };
  const welcomeCopy = {
    learner: 'Plan your journey from results to the right university application.',
    teacher: 'Review the oldest learner submissions and keep verification moving.',
    representative: 'Review teacher-screened applications and record admission decisions.',
    admin: 'Keep university programme requirements accurate and source-verified.',
  }[user.role];
  const journeyMarkup = learner
    ? /* HTML */ `
        <section class="journey-section" aria-labelledby="journey-title">
          <div class="section-heading">
            <div>
              <span class="section-kicker">Your progress</span>
              <h2 id="journey-title">Your university journey</h2>
              <p>
                Add results first. Then explore universities and check entry rules. Visits are
                remembered in this browser; results and applications stay with your account.
              </p>
            </div>
            <span class="journey-progress-count">
              ${journey.filter((step) => step.complete).length} of 4 steps complete
            </span>
          </div>
          <ol class="journey-grid">
            ${journey
              .map(
                (step, index) => /* HTML */ `
                  <li
                    class="journey-card ${step.complete ? 'is-complete' : ''} ${index === activeStep ? 'is-current' : ''}"
                    ${index === activeStep ? 'aria-current="step"' : ''}
                  >
                    <div class="journey-card-top">
                      <span class="journey-number">${step.number}</span>
                      <span class="journey-state">
                        ${
                          step.complete
                            ? /* HTML */ `
                                <i data-lucide="circle-check" aria-hidden="true"></i>
                                Done
                              `
                            : index === activeStep
                              ? 'Next step'
                              : 'Up next'
                        }
                      </span>
                    </div>
                    <div class="journey-card-title">
                      <i data-lucide="${step.icon}" aria-hidden="true"></i>
                      <h3>${step.title}</h3>
                    </div>
                    <p>${step.description}</p>
                    <a href="${step.href}" class="journey-action">
                      ${step.action}
                      <i data-lucide="arrow-right" aria-hidden="true"></i>
                    </a>
                  </li>
                `,
              )
              .join('')}
          </ol>
        </section>
      `
    : '';
  const recentRows = applications.map(
    (a) => /* HTML */ `
      <tr>
        <td>${esc(a.offering.university)}</td>
        <td>${esc(a.offering.qualification)}</td>
        <td>${badge(a.status)}</td>
      </tr>
    `,
  );
  const learnerApplications =
    learner && !recentRows.length
      ? /* HTML */ `
          <div class="application-empty">
            <span class="empty-illustration">
              <i data-lucide="file-check-2" aria-hidden="true"></i>
            </span>
            <div>
              <h3>Your application story starts here</h3>
              <p>
                Choose a university programme, review its requirements and submit your application
                from that page.
              </p>
              <a class="button-link" href="/learner/requirements.html">
                Find a programme to apply
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        `
      : `${table(learner ? ['University', 'Programme', 'Status'] : ['Learner', 'Qualification', 'Status'], recentRows)}${link('/' + user.role + '/applications.html', learner ? 'View all applications' : 'Open application queue')}${
          learner
            ? /* HTML */ `
                <p>
                  <a class="inline-link" href="/learner/requirements.html">
                    Apply to another programme
                    <i data-lucide="arrow-right" aria-hidden="true"></i>
                  </a>
                </p>
              `
            : ''
        }`;
  const roleMetrics =
    {
      teacher: [
        [String(counts.learners || 0), 'learners at your school'],
        [String(counts.awaitingScreening || 0), 'applications awaiting screening'],
      ],
      representative: [
        [String(applicationCount), 'applications for your institution'],
        [String(counts.awaitingReview || 0), 'ready for admission review'],
      ],
      admin: [
        [String(counts.accounts || 0), counts.accounts === 1 ? 'user account' : 'user accounts'],
        [
          String(counts.universities || 0),
          counts.universities === 1 ? 'university' : 'universities',
        ],
        [
          String(counts.offerings || 0),
          counts.offerings === 1 ? 'configured offering' : 'configured offerings',
        ],
      ],
    }[user.role] || [];
  const queueTitle =
    {
      teacher: 'Applications to screen',
      representative: 'Admission decisions to make',
      admin: 'Programme requirements to verify',
    }[user.role] || 'Your action queue';
  const queueHint =
    {
      teacher: 'Oldest submissions first',
      representative: 'Oldest screened applications first',
      admin: 'Nearest closing dates first',
    }[user.role] || '';
  const queueEmpty =
    {
      teacher:
        'No submitted applications are waiting for screening. Check learner results if a school has just added marks.',
      representative: 'No teacher-screened applications are waiting for an admission decision.',
      admin: counts.offerings
        ? 'All configured programmes are verified.'
        : 'No programme offerings are configured yet.',
    }[user.role] || '';
  const queueMarkup = !learner
    ? /* HTML */ `
        <section class="panel action-queue">
          <div class="panel-heading-row">
            <div>
              <span class="section-kicker">Needs your action</span>
              <h2>${queueTitle}</h2>
            </div>
            <span class="queue-order">${queueHint}</span>
          </div>
          ${
            actionQueue.length
              ? /* HTML */ `
                  <ol class="queue-list">
                    ${actionQueue
                      .slice(0, 6)
                      .map(
                        (item) => /* HTML */ `
                          <li>
                            <div class="queue-copy">
                              <strong>${esc(item.title)}</strong>
                              <span>${esc(item.detail)} | ${esc(item.context)}</span>
                              <small>
                                ${item.date ? dashboardDate(item.date) : 'Deadline to confirm'}
                              </small>
                            </div>
                            <a class="queue-action" href="${item.href}">
                              ${item.label}
                              <i data-lucide="arrow-right" aria-hidden="true"></i>
                            </a>
                          </li>
                        `,
                      )
                      .join('')}
                  </ol>
                `
              : /* HTML */ `
                  <div class="queue-empty">
                    <i
                      data-lucide="${user.role === 'admin' ? 'list-checks' : 'inbox'}"
                      aria-hidden="true"
                    ></i>
                    <div>
                      <strong>${queueEmpty}</strong>
                      ${
                        user.role === 'admin' && !counts.offerings
                          ? /* HTML */ `
                              <p>
                                Use the short setup checklist to add and verify your first
                                programme.
                              </p>
                              <a class="inline-link" href="/help.html#admin-programme-setup">
                                View setup checklist
                                <i data-lucide="arrow-right" aria-hidden="true"></i>
                              </a>
                            `
                          : /* HTML */ `
                              <a class="inline-link" href="${heroActions[user.role].href}">
                                ${heroActions[user.role].label}
                                <i data-lucide="arrow-right" aria-hidden="true"></i>
                              </a>
                            `
                      }
                    </div>
                  </div>
                `
          }
        </section>
      `
    : '';
  const learnerHistory = learner
    ? /* HTML */ `
        <section class="panel recent-applications">
          <div class="panel-heading-row">
            <div>
              <span class="section-kicker">Your submitted choices</span>
              <h2>Recent Applications</h2>
            </div>
            ${
              applicationCount
                ? /* HTML */ `
                    <span class="application-count">
                      ${applicationCount} ${applicationCount === 1 ? 'application' : 'applications'}
                    </span>
                  `
                : ''
            }
          </div>
          ${learnerApplications}
        </section>
      `
    : '';
  const metrics = roleMetrics.length
    ? /* HTML */ `
        <section class="role-metrics" aria-label="Workspace summary">
          ${roleMetrics
            .map(
              ([number, label]) => /* HTML */ `
                <div>
                  <strong>${number}</strong>
                  <span>${label}</span>
                </div>
              `,
            )
            .join('')}
        </section>
      `
    : '';
  const closingSoon =
    learner && summary.closingSoon?.length
      ? /* HTML */ `
          <section class="closing-soon" aria-label="Applications closing soon">
            <div class="closing-soon-heading">
              <span class="section-kicker">Verified programme deadlines</span>
              <h2>Closing soon</h2>
              <p>Published application deadlines in the next 30 days.</p>
            </div>
            <ul>
              ${summary.closingSoon
                .map(
                  (item) => /* HTML */ `
                    <li>
                      <span>
                        <strong>${esc(item.title)}</strong>
                        <small>${esc(item.university)}</small>
                      </span>
                      <span class="closing-date">Closes ${esc(dashboardDate(item.date))}</span>
                      <a
                        href="/learner/requirements.html?offeringId=${encodeURIComponent(item.id)}"
                      >
                        Check requirements
                        <i data-lucide="arrow-right" aria-hidden="true"></i>
                      </a>
                    </li>
                  `,
                )
                .join('')}
            </ul>
          </section>
        `
      : '';
  show(/* HTML */ `
    <section class="welcome-panel">
      <div class="welcome-copy">
        <span>${esc(user.role)} portal | ${intakeYear} entry</span>
        <h1>Welcome back, ${esc(user.firstName)}</h1>
        <p>${welcomeCopy}</p>
        <a class="welcome-cta" href="${heroActions[user.role].href}">
          ${heroActions[user.role].label}
          <i data-lucide="arrow-right" aria-hidden="true"></i>
        </a>
      </div>
      <span class="welcome-cycle" aria-label="${intakeYear} admissions">
        <strong>${intakeYear}</strong>
        <small>ADMISSIONS</small>
      </span>
    </section>
    ${learner ? journeyMarkup : metrics + queueMarkup}${closingSoon}${learnerHistory}
  `);
}
async function directory() {
  const adminDirectory = user.role === 'admin' && page === 'directories',
    provinceNames = new Map(
      catalog.provinces.map((item) => [String(item.PROVINCE_ID), item.PROVINCE_NAME]),
    );
  if (page === 'policies' && user.role === 'admin') {
    const data = await request('/api/offerings');
    show(
      title(
        'Programme requirements',
        'Review the real offerings and source verification maintained by your administrators.',
      ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              [
                'University',
                'Qualification',
                'Minimum APS',
                'Status',
                'Closing date',
                'Official source',
              ],
              data.offerings.map(
                (item) => /* HTML */ `
                  <tr>
                    <th>${esc(item.university)}</th>
                    <td>${esc(item.qualification)}</td>
                    <td>
                      ${item.config.minScore == null ? 'Not set' : esc(item.config.minScore) + ' ' + esc(item.config.scoring?.label || '/ 42')}
                    </td>
                    <td>${badge(item.config.status)}</td>
                    <td>${esc(String(item.APPLICATION_CLOSING_DATE).slice(0, 10))}</td>
                    <td>
                      ${
                        item.config.source
                          ? /* HTML */ `
                              <a
                                href="${esc(safeHttps(item.config.source))}"
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                View source
                              </a>
                            `
                          : 'Not set'
                      }
                    </td>
                  </tr>
                `,
              ),
            )}
          </section>
          <section class="panel">
            <p>Use the programme requirements workspace to add or update offerings.</p>
            ${link('/admin/offerings.html', 'Manage programme requirements')}
          </section>
        `,
    );
    return;
  }
  if (!adminDirectory) {
    const data = await request('/api/offerings'),
      list = () => {
        const term = document.querySelector('#search').value.trim().toLowerCase(),
          province = document.querySelector('#province').value;
        const rows = catalog.universities
          .filter((item) => {
            const city =
              catalog.cities.find((c) => String(c.CITY_ID) === String(item.CITY_ID))?.CITY_NAME ||
              '';
            return (
              `${item.UNIVERSITY_NAME} ${city} ${provinceNames.get(String(item.PROVINCE_ID)) || ''}`
                .toLowerCase()
                .includes(term) &&
              (!province || String(item.PROVINCE_ID) === province)
            );
          })
          .map((item) => {
            const city =
                catalog.cities.find((c) => String(c.CITY_ID) === String(item.CITY_ID))?.CITY_NAME ||
                'Location not recorded',
              provinceName = provinceNames.get(String(item.PROVINCE_ID)) || 'Province not recorded',
              programmes = data.offerings.filter(
                (o) => String(o.UNIVERSITY_ID) === String(item.UNIVERSITY_ID),
              );
            return /* HTML */ `
              <tr>
                <th>${esc(item.UNIVERSITY_NAME)}</th>
                <td>${esc(city)}</td>
                <td>${esc(provinceName)}</td>
                <td>
                  ${programmes.length ? programmes.map((o) => `${esc(o.qualification)} · ${badge(o.config.status)} ${link('/learner/requirements.html?offeringId=' + encodeURIComponent(o.UNI_QUAL_ID), 'Check requirements')}`).join('<br>') : 'No programme offerings listed yet'}
                </td>
              </tr>
            `;
          });
        document.querySelector('#directory-grid').innerHTML = table(
          ['University', 'City', 'Province', 'Programmes'],
          rows,
        );
      };
    show(
      title(
        'Universities',
        'Search by institution, city or province and compare programme requirements.',
      ) +
        /* HTML */ `
          <section class="panel">
            <div class="fields">
              <label>
                Search university or city
                <input id="search" type="search" aria-label="Search universities and cities" />
              </label>
              <label>
                Province
                <select id="province">
                  <option value="">All provinces</option>
                  ${catalog.provinces
                    .map(
                      (item) => /* HTML */ `
                        <option value="${item.PROVINCE_ID}">${esc(item.PROVINCE_NAME)}</option>
                      `,
                    )
                    .join('')}
                </select>
              </label>
            </div>
            <div id="directory-grid"></div>
          </section>
        `,
    );
    document.querySelector('#search').addEventListener('input', list);
    document.querySelector('#province').addEventListener('change', list);
    list();
    return;
  }
  show(
    title(
      'Directories',
      'Manage schools, university campus locations, cities, provinces and academic reference records.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">
            <label>
              Directory
              <select id="directory-type">
                <option value="schools">Schools</option>
                <option value="universities">Universities</option>
                <option value="cities">Cities</option>
                <option value="provinces">Provinces</option>
                <option value="subjects">Subjects</option>
                <option value="exams">Examination milestones</option>
                <option value="studyModes">Study modes</option>
              </select>
            </label>
          </div>
          <div id="managed-directory"></div>
          <form id="directory-form">
            <div class="fields" id="directory-fields"></div>
            <div class="actions">
              <button id="directory-submit">Save record</button>
              <button class="secondary" id="directory-cancel" type="button" hidden>
                Cancel edit
              </button>
            </div>
          </form>
        </section>
      `,
  );
  let editing = null;
  const fields = {
      schools: ['SCHOOL_NAME', 'EMIS_NUMBER', 'CITY_ID', 'PROVINCE_ID'],
      universities: ['UNIVERSITY_NAME', 'WEBSITE', 'STREET_NAME', 'CITY_ID', 'PROVINCE_ID'],
      cities: ['CITY_NAME'],
      provinces: ['PROVINCE_NAME'],
      subjects: ['SUBJECT_NAME', 'SUBJECT_CODE', 'SUBJECT_CATEGORY'],
      exams: ['EXAM_TYPE_NAME'],
      studyModes: ['STUDY_MODE_NAME'],
    },
    primary = {
      schools: 'SCHOOL_ID',
      universities: 'UNIVERSITY_ID',
      cities: 'CITY_ID',
      provinces: 'PROVINCE_ID',
      subjects: 'SUBJECT_ID',
      exams: 'EXAM_TYPE_ID',
      studyModes: 'STUDY_MODE_ID',
    },
    labels = {
      SCHOOL_NAME: 'School name',
      EMIS_NUMBER: 'EMIS number',
      CITY_ID: 'City',
      PROVINCE_ID: 'Province',
      UNIVERSITY_NAME: 'University name',
      WEBSITE: 'Official website',
      STREET_NAME: 'Campus address',
      CITY_NAME: 'City name',
      PROVINCE_NAME: 'Province name',
      SUBJECT_NAME: 'Subject name',
      SUBJECT_CODE: 'Subject code',
      SUBJECT_CATEGORY: 'NSC category',
      EXAM_TYPE_NAME: 'Examination milestone',
      STUDY_MODE_NAME: 'Study mode',
    };
  const display = (type, row, field) =>
    field === 'CITY_ID'
      ? catalog.cities.find((item) => String(item.CITY_ID) === String(row[field]))?.CITY_NAME ||
        'Not assigned'
      : field === 'PROVINCE_ID'
        ? provinceNames.get(String(row[field])) || 'Not assigned'
        : field === 'SUBJECT_CATEGORY'
          ? {
              HOME_LANGUAGE: 'Home language',
              FIRST_ADDITIONAL_LANGUAGE: 'First additional language',
              MATHEMATICS: 'Mathematics',
              MATHEMATICAL_LITERACY: 'Mathematical literacy',
              LIFE_ORIENTATION: 'Life Orientation',
              ELECTIVE: 'Elective',
            }[row[field]] || 'Not assigned'
          : type === 'schools' && field === 'SCHOOL_NAME' && row.EMIS_NUMBER === 'LOCAL-ONLY'
            ? `${row[field]} (local setup)`
            : (row[field] ?? '');
  const reset = () => {
    editing = null;
    for (const field of fields[document.querySelector('#directory-type').value] || []) {
      const control = document.querySelector('#directory-form').elements.namedItem(field);
      if (control) {
        if (control.tagName === 'SELECT') control.selectedIndex = 0;
        else control.value = '';
      }
    }
    document.querySelector('#directory-submit').textContent = 'Save record';
    document.querySelector('#directory-cancel').hidden = true;
  };
  const drawFields = () => {
    const type = document.querySelector('#directory-type').value;
    document.querySelector('#directory-fields').innerHTML = fields[type]
      .map(
        (field) => /* HTML */ `
          <label>
            ${labels[field]}${
              field === 'PROVINCE_ID'
                ? /* HTML */ `
                    <select name="${field}" required>
                      <option value="" selected disabled>Choose a province</option>
                      ${select(catalog.provinces, 'PROVINCE_ID', 'PROVINCE_NAME')}
                    </select>
                  `
                : field === 'CITY_ID'
                  ? /* HTML */ `
                      <select name="${field}" required>
                        <option value="" selected disabled>Choose a city</option>
                        ${select(catalog.cities, 'CITY_ID', 'CITY_NAME')}
                      </select>
                    `
                  : field === 'SUBJECT_CATEGORY'
                    ? /* HTML */ `
                        <select name="${field}" required>
                          ${[
                            ['HOME_LANGUAGE', 'Home language'],
                            ['FIRST_ADDITIONAL_LANGUAGE', 'First additional language'],
                            ['MATHEMATICS', 'Mathematics'],
                            ['MATHEMATICAL_LITERACY', 'Mathematical literacy'],
                            ['LIFE_ORIENTATION', 'Life Orientation'],
                            ['ELECTIVE', 'Elective'],
                          ]
                            .map(
                              ([value, label]) => /* HTML */ `
                                <option value="${value}">${label}</option>
                              `,
                            )
                            .join('')}
                        </select>
                      `
                    : /* HTML */ `
                        <input
                          name="${field}"
                          ${field === 'WEBSITE' ? 'type="url"' : field === 'EMIS_NUMBER' ? 'maxlength="20"' : ''}
                          ${field === 'STREET_NAME' ? 'maxlength="150"' : ''}
                          required
                        />
                      `
            }
          </label>
        `,
      )
      .join('');
  };
  const redraw = async () => {
    reset();
    drawFields();
    const type = document.querySelector('#directory-type').value,
      rows = (await request('/api/admin/directories/' + type)).rows;
    const showPilotScope = type === 'universities';
    const inPilot = (name) => /walter\s*sisulu|fort\s*hare|university\s*of\s*johannesburg/i.test(String(name || ''));
    document.querySelector('#managed-directory').innerHTML = table(
      [...fields[type].map((field) => labels[field]), ...(showPilotScope ? ['Pilot scope'] : []), 'Action'],
      rows.map(
        (row) => /* HTML */ `
          <tr>
            ${fields[type]
              .map(
                (field) => /* HTML */ `
                  <td>${esc(display(type, row, field))}</td>
                `,
              )
              .join('')}
            ${showPilotScope ? `<td>${inPilot(row.UNIVERSITY_NAME) ? '2027 pilot' : 'Roadmap'}</td>` : ''}
            <td>
              <button
                type="button"
                class="secondary compact"
                data-directory-edit="${esc(row[primary[type]])}"
              >
                Edit
              </button>
            </td>
          </tr>
        `,
      ),
    );
    document.querySelectorAll('[data-directory-edit]').forEach((button) =>
      button.addEventListener('click', () => {
        const row = rows.find(
          (item) => String(item[primary[type]]) === button.dataset.directoryEdit,
        );
        if (!row) return;
        editing = String(row[primary[type]]);
        for (const field of fields[type]) {
          const control = document.querySelector('#directory-form').elements.namedItem(field);
          if (control) control.value = row[field] ?? '';
        }
        document.querySelector('#directory-submit').textContent = 'Update record';
        document.querySelector('#directory-cancel').hidden = false;
        document
          .querySelector('#directory-form')
          .scrollIntoView?.({ block: 'center', behavior: 'smooth' });
      }),
    );
  };
  document.querySelector('#directory-type').addEventListener('change', guard(redraw));
  document.querySelector('#directory-cancel').addEventListener('click', () => {
    reset();
    drawFields();
  });
  await redraw();
  document.querySelector('#directory-form').addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const type = document.querySelector('#directory-type').value,
        data = Object.fromEntries(new FormData(event.target));
      for (const key of Object.keys(data)) if (key.endsWith('_ID')) data[key] = Number(data[key]);
      const path =
        '/api/admin/directories/' +
        type +
        (editing !== null ? '/' + encodeURIComponent(editing) : '');
      const result = await request(path, editing !== null ? 'PATCH' : 'POST', data);
      catalog = await request('/api/catalog');
      await redraw();
      feedback(result.message || 'Directory record saved.');
    }),
  );
}
async function accounts() {
  const data = await request('/api/admin/accounts');
  show(
    title('Accounts', 'Create role-scoped accounts; learners can also register themselves.') +
      /* HTML */ `
        <section class="panel">
          ${table(
            ['Name', 'Username', 'Role', 'State', 'Action'],
            data.accounts.map(
              (a) => /* HTML */ `
                <tr>
                  <td>${esc(a.user?.firstName)} ${esc(a.user?.lastName)}</td>
                  <td>${esc(a.username ?? a.user?.username)}</td>
                  <td>${esc(a.user?.role)}</td>
                  <td>
                    ${a.disabled ? 'Disabled' : 'Active'}${a.emailVerified ? '' : ' · Email pending'}
                  </td>
                  <td>
                    ${
                      a.user?.personId !== user.personId
                        ? /* HTML */ `
                            ${
                              !a.disabled
                                ? /* HTML */ `
                                    <button
                                      class="secondary compact"
                                      data-account-password-reset="${esc(a.accountId)}"
                                    >
                                      ${a.emailVerified ? 'Send password reset' : a.accountSetupPending ? 'Resend setup link' : 'Send verification email'}
                                    </button>
                                  `
                                : ''
                            }
                            <button
                              class="secondary compact"
                              data-account-action="${a.disabled ? 'enable' : 'disable'}"
                              data-account-id="${esc(a.accountId)}"
                            >
                              ${a.disabled ? 'Restore access' : 'Disable'}
                            </button>
                          `
                        : ''
                    }
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel">
          <h2>Create an account</h2>
          <form id="account">
            <div class="fields">
              <label>
                First name
                <input name="firstName" required />
              </label>
              <label>
                Last name
                <input name="lastName" required />
              </label>
              <label>
                Email
                <input name="email" type="email" required />
              </label>
              <p class="form-help">
                The user will receive a secure link to verify their email and set their own
                password.
              </p>
              <label>
                Role
                <select name="role">
                  <option value="learner">Learner</option>
                  <option value="teacher">Career Guidance Teacher</option>
                  <option value="representative">University Representative</option>
                  <option value="admin">IT Administrator</option>
                </select>
              </label>
              <label>
                School (learner / teacher)
                <select name="schoolId">
                  ${select(catalog.schools, 'SCHOOL_ID', 'SCHOOL_NAME')}
                </select>
              </label>
              <label>
                Institution (representative)
                <select name="universityId">
                  ${select(catalog.universities, 'UNIVERSITY_ID', 'UNIVERSITY_NAME')}
                </select>
              </label>
            </div>
            <button>Create account</button>
          </form>
        </section>
      `,
  );
  document.querySelector('#account').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const b = Object.fromEntries(new FormData(e.target));
      b.schoolId = Number(b.schoolId);
      b.universityId = Number(b.universityId);
      const out = await request('/api/admin/accounts', 'POST', b);
      await accounts();
      feedback(out.message);
    }),
  );
  document.querySelectorAll('[data-account-password-reset]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request(
          '/api/admin/accounts/' + b.dataset.accountPasswordReset + '/password-reset',
          'POST',
          {},
        );
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-account-action]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const action = b.dataset.accountAction;
        const out = await request(
          '/api/admin/accounts/' + b.dataset.accountId + '/' + action,
          'POST',
          {},
        );
        await accounts();
        feedback(out.message);
      }),
    ),
  );
  const unlinked = (await request('/api/admin/unlinked')).people;
  if (unlinked.length) {
    main.insertAdjacentHTML(
      'beforeend',
      /* HTML */ `
        <section class="panel">
          <h2>Enable sign-in for an existing database person</h2>
          <form id="link-account">
            <div class="fields">
              <label>
                Existing person
                <select name="personId">
                  ${unlinked
                    .map(
                      (p) => /* HTML */ `
                        <option value="${p.personId}">
                          ${esc(p.firstName)} ${esc(p.lastName)} · ${esc(p.role)}
                        </option>
                      `,
                    )
                    .join('')}
                </select>
              </label>
              <label>
                Login email
                <input name="email" type="email" required />
              </label>
              <p class="form-help">
                The user will receive a secure link to verify their email and set their own
                password.
              </p>
            </div>
            <button>Enable sign-in</button>
          </form>
        </section>
      `,
    );
    document.querySelector('#link-account').addEventListener(
      'submit',
      guard(async (e) => {
        e.preventDefault();
        const b = Object.fromEntries(new FormData(e.target));
        b.personId = Number(b.personId);
        const out = await request('/api/admin/accounts/link', 'POST', b);
        await accounts();
        feedback(out.message);
      }),
    );
  }
}
async function offeringAdmin() {
  let editing = null;
  const data = await request('/api/offerings');
  const subjectOptions = catalog.subjects
    .map(
      (subject) => /* HTML */ `
        <option value="${esc(subject.SUBJECT_CODE)}">${esc(subject.SUBJECT_NAME)}</option>
      `,
    )
    .join('');
  show(
    title(
      'Programme Requirements',
      'Manage the score scale, subject requirements, documents and application window for each programme.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${table(
            [
              'University',
              'Qualification',
              'Programme category',
              'Minimum APS',
              'Verification',
              'Closing date',
              'Action',
            ],
            data.offerings.map(
              (item) => /* HTML */ `
                <tr>
                  <td>${esc(item.university)}</td>
                  <td>${esc(item.qualification)}</td>
                  <td>${esc(item.program)}</td>
                  <td>
                    ${item.config.minScore == null ? 'Not set' : esc(item.config.minScore) + ' ' + esc(item.config.scoring?.label || '/ 42')}
                  </td>
                  <td>${badge(item.config.status)}</td>
                  <td>${esc(String(item.APPLICATION_CLOSING_DATE).slice(0, 10))}</td>
                  <td>
                    <button
                      type="button"
                      class="secondary compact"
                      data-edit-offering="${item.UNI_QUAL_ID}"
                    >
                      Edit requirements
                    </button>
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel">
          <h2>Add a programme offering</h2>
          <form id="offering-form">
            <div class="fields">
              <label>
                University
                <select name="universityId" required>
                  ${select(
                    catalog.universities.filter(
                      (item) =>
                        user.role !== 'representative' ||
                        String(item.UNIVERSITY_ID) === String(user.universityId),
                    ),
                    'UNIVERSITY_ID',
                    'UNIVERSITY_NAME',
                  )}
                </select>
              </label>
              <label>
                Qualification name
                <input name="name" required maxlength="150" />
              </label>
              <label>
                Programme category
                <input name="program" required maxlength="100" />
              </label>
              <label>
                Application closing date
                <input name="closingDate" type="date" required />
              </label>
              <label>
                Minimum academic score
                <input name="minScore" type="number" min="0" max="32767" step="1" required />
              </label>
              <label>
                Final admission APS (optional)
                <input name="finalMinScore" type="number" min="0" max="32767" step="0.01" />
              </label>
              <label>
                Minimum English (%)
                <input name="minEnglish" type="number" min="0" max="100" />
              </label>
              <label>
                Minimum Mathematics (%)
                <input name="minMath" type="number" min="0" max="100" />
              </label>
              <label>
                Required additional subjects (optional)
                <select name="requiredCodes" multiple size="5">
                  ${subjectOptions}
                </select>
                <span class="form-help">
                  Select only compulsory subjects in addition to English and Mathematics.
                </span>
              </label>
              <label>
                Opening date (optional for existing listings)
                <input name="openingDate" type="date" />
              </label>
              <label>
                Closing time (South Africa)
                <input name="closingTime" type="time" value="23:59" />
              </label>
              <label>
                Offering availability
                <select name="active">
                  <option value="yes">Active</option>
                  <option value="no">Inactive</option>
                </select>
              </label>
              <label>
                Score method
                <select name="scoringMode">
                  <option value="standard">Standard six-subject APS</option>
                  <option value="BANDS">Custom points bands</option>
                  <option value="RAW">Percentage total / average</option>
                </select>
              </label>
              <div class="search fields" id="custom-scoring" hidden>
                <label>
                  Score label
                  <input name="scoreLabel" value="Academic score" maxlength="80" />
                </label>
                <label>
                  Number of subjects counted
                  <input name="scoreCount" type="number" min="1" max="10" value="6" />
                </label>
                <label>
                  Divide total by
                  <input
                    name="scoreDivisor"
                    type="number"
                    min="0.01"
                    max="1000"
                    step="0.01"
                    value="1"
                  />
                </label>
                <label>
                  Marks below this percentage earn zero
                  <input name="scoreFloor" type="number" min="0" max="100" value="0" />
                </label>
                <label>
                  Subjects excluded from score
                  <select name="scoreExclude" multiple size="5">
                    ${subjectOptions}
                  </select>
                </label>
                <label>
                  Subject weights: one SUBJECT_CODE, multiplier per line
                  <textarea name="scoreWeights" rows="4" placeholder="MATH, 2"></textarea>
                </label>
                <label class="search">
                  Points bands: lower mark, upper boundary (excluded), points
                  <textarea name="scoreBands" rows="7">
0,30,1
30,40,2
40,50,3
50,60,4
60,70,5
70,80,6
80,101,7</textarea>
                  <span class="form-help">
                    Use 101 as the final upper boundary to include 100%. Bands are unused for
                    percentage scoring.
                  </span>
                </label>
              </div>
              <label class="search">
                Subject alternatives: group, subject code, minimum percentage
                <textarea
                  name="subjectGroups"
                  rows="4"
                  placeholder="1, MATH, 50&#10;1, MLIT, 70"
                ></textarea>
                <span class="form-help">
                  At least one subject must pass in each group. Use different group numbers for
                  requirements that must both be met. Available codes:
                  ${catalog.subjects.map((x) => esc(x.SUBJECT_CODE)).join(', ')}.
                </span>
              </label>
              <label class="search">
                Additional documents required before applying
                <select name="requiredDocumentIds" multiple size="4">
                  ${select(
                    catalog.documentTypes.filter((x) => !x.IS_LOCKED_UNTIL_FINAL),
                    'DOCUMENT_TYPE_ID',
                    'DOCUMENT_TYPE_NAME',
                  )}
                </select>
                <span class="form-help">The system's mandatory documents remain required.</span>
              </label>
              <label>
                Official programme source
                <input name="source" type="url" placeholder="https://" required />
              </label>
              <label class="search">
                Additional selection conditions
                <input name="notes" required maxlength="400" />
              </label>
              <label class="search">
                <span>
                  <input name="verified" type="checkbox" class="inline-checkbox" />
                  I checked this qualification’s 2027 requirements and closing date against its
                  official source.
                </span>
              </label>
            </div>
            <div class="actions">
              <button id="offering-submit">Save offering</button>
              <button class="secondary" id="offering-cancel" type="button" hidden>
                Cancel edit
              </button>
            </div>
          </form>
          <p class="muted">
            Only mark requirements verified after checking the official 2027 source. Custom scoring
            applies only to this programme; existing listings keep their current scale.
          </p>
        </section>
      `,
  );
  const form = document.querySelector('#offering-form');
  const syncScoring = () => {
    document.querySelector('#custom-scoring').hidden =
      form.elements.scoringMode.value === 'standard';
  };
  form.elements.scoringMode.addEventListener('change', syncScoring);
  const lines = (value) =>
    value
      .split(/\r?\n/)
      .map((v) => v.trim())
      .filter(Boolean)
      .map((v) => v.split(',').map((x) => x.trim()));

  form.addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const b = Object.fromEntries(new FormData(form));
      b.universityId = Number(b.universityId);
      b.intake = 2027;
      b.minScore = Number(b.minScore);
      b.finalMinScore = b.finalMinScore === '' ? null : Number(b.finalMinScore);
      for (const key of ['minEnglish', 'minMath']) b[key] = b[key] === '' ? null : Number(b[key]);
      b.requiredCodes = [...form.elements.namedItem('requiredCodes').selectedOptions].map(
        (option) => option.value,
      );
      b.subjectMinimums =
        editing === null
          ? {}
          : data.offerings.find((x) => String(x.UNI_QUAL_ID) === editing)?.config.subjectMinimums ||
            {};
      b.active = b.active !== 'no';
      b.requiredDocumentIds = [...form.elements.requiredDocumentIds.selectedOptions].map((o) =>
        Number(o.value),
      );
      b.subjectGroups = lines(b.subjectGroups).map((row) => {
        if (row.length !== 3)
          throw new Error('Use group, subject code, minimum percentage on each requirements line.');
        return { group: Number(row[0]), code: row[1], minimum: Number(row[2]) };
      });
      b.scoring =
        b.scoringMode === 'standard'
          ? null
          : {
              mode: b.scoringMode,
              count: Number(b.scoreCount),
              divisor: Number(b.scoreDivisor),
              floor: Number(b.scoreFloor),
              label: b.scoreLabel,
              bands: lines(b.scoreBands).map((row) => {
                if (row.length !== 3) throw new Error('Each band needs lower, upper and points.');
                return row.map(Number);
              }),
              exclude: [...form.elements.scoreExclude.selectedOptions].map((o) => o.value),
              overrides: lines(b.scoreWeights).map((row) => {
                if (row.length !== 2)
                  throw new Error('Each weighting needs subject code and multiplier.');
                return { codes: [row[0]], weight: Number(row[1]) };
              }),
            };
      b.verified = form.elements.namedItem('verified').checked;
      await request(
        '/api/' +
          (user.role === 'representative' ? 'representative' : 'admin') +
          '/offerings' +
          (editing !== null ? '/' + encodeURIComponent(editing) : ''),
        editing !== null ? 'PATCH' : 'POST',
        b,
      );
      await offeringAdmin();
      feedback('Programme offering saved.');
    }),
  );
  document.querySelectorAll('[data-edit-offering]').forEach((button) =>
    button.addEventListener('click', () => {
      const item = data.offerings.find(
        (row) => String(row.UNI_QUAL_ID) === button.dataset.editOffering,
      );
      if (!item) return;
      editing = String(item.UNI_QUAL_ID);
      const values = {
        universityId: item.UNIVERSITY_ID,
        name: item.qualification,
        program: item.program || 'Undergraduate',
        closingDate: String(item.APPLICATION_CLOSING_DATE).slice(0, 10),
        minScore: item.config.minScore ?? '',
        finalMinScore: item.config.finalMinScore ?? '',
        minEnglish: item.config.minEnglish ?? '',
        minMath: item.config.minMath ?? '',
        openingDate: item.config.openingDate || '',
        closingTime: item.config.closingTime || '23:59',
        active: item.config.active === false ? 'no' : 'yes',
        scoringMode: item.config.scoring?.mode || 'standard',
        scoreLabel: item.config.scoring?.label || 'Academic score',
        scoreCount: item.config.scoring?.count || 6,
        scoreDivisor: item.config.scoring?.divisor || 1,
        scoreFloor: item.config.scoring?.floor || 0,
        scoreBands: (
          item.config.scoring?.bands || [
            [0, 30, 1],
            [30, 40, 2],
            [40, 50, 3],
            [50, 60, 4],
            [60, 70, 5],
            [70, 80, 6],
            [80, 101, 7],
          ]
        )
          .map((row) => row.join(','))
          .join('\n'),
        scoreWeights: (item.config.scoring?.overrides || [])
          .map((o) => o.codes[0] + ', ' + o.weight)
          .join('\n'),
        subjectGroups: (item.config.subjectGroups || [])
          .map((r) => [r.group, r.code, r.minimum].join(', '))
          .join('\n'),
        source: item.config.source || '',
        notes:
          item.config.notes ||
          'Check the official programme instructions for complete selection conditions.',
      };
      for (const [key, value] of Object.entries(values)) form.elements.namedItem(key).value = value;
      for (const option of form.elements.scoreExclude.options)
        option.selected = (item.config.scoring?.exclude || []).includes(option.value);
      for (const option of form.elements.requiredDocumentIds.options)
        option.selected = (item.config.requiredDocumentIds || []).includes(Number(option.value));
      syncScoring();
      const required = new Set(item.config.requiredCodes || []);
      for (const option of form.elements.namedItem('requiredCodes').options)
        option.selected = required.has(option.value);
      form.elements.namedItem('verified').checked =
        item.config.status === 'verified' && item.config.intake === 2027;
      form.elements.namedItem('name').readOnly = true;
      form.elements.namedItem('program').readOnly = true;
      document.querySelector('#offering-submit').textContent = 'Update offering';
      document.querySelector('#offering-cancel').hidden = false;
      form.scrollIntoView?.({ block: 'start', behavior: 'smooth' });
    }),
  );
  document.querySelector('#offering-cancel').addEventListener('click', () => {
    editing = null;
    form.reset();
    syncScoring();
    form.elements.namedItem('name').readOnly = false;
    form.elements.namedItem('program').readOnly = false;
    document.querySelector('#offering-submit').textContent = 'Save offering';
    document.querySelector('#offering-cancel').hidden = true;
  });
}

const pilotDisclaimer = 'Guidance only. Meeting a published minimum does not guarantee admission; selection, space, NBTs and final results may affect the outcome.';
const safeLink = (url, label = 'Open source') => {
  const safe = safeHttps(url);
  return safe ? `<a class="inline-link" href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>` : '<span class="muted">Source not available</span>';
};
const sourceBlock = (row) => row.source ? `<dl class="details-grid"><dt>Source</dt><dd>${safeLink(row.source.url, row.source.title || 'Read source')}</dd><dt>Document year / page</dt><dd>${esc(row.source.year || 'Not recorded')} · ${esc(row.source.pageRef || 'Page not recorded')}</dd><dt>Last updated</dt><dd>${esc(row.lastUpdated || 'Not recorded')}</dd><dt>Conditions</dt><dd>${esc(Array.isArray(row.conditions) ? row.conditions.join(' · ') : row.conditions || 'Not recorded')}</dd></dl>` : '<p class="muted">Source details are incomplete; this is not an actionable recommendation.</p>';
async function pilotProgrammesPage() {
  const exam = catalog.examTypes.find((item) => /Grade 11 Final/i.test(item.EXAM_TYPE_NAME)) || catalog.examTypes[0];
  const out = await request('/api/pilot/recommendations' + (exam ? `?examTypeId=${encodeURIComponent(exam.EXAM_TYPE_ID)}` : ''));
  show(title('Verified pilot programmes', 'The pilot is limited to undergraduate pathways at WSU, UFH and UJ. Anything without complete source evidence and independent review remains unverified.') + `<section class="panel"><p><strong>${esc(out.verifiedCount || 0)} verified programmes</strong> currently meet the published minimum in this profile.</p><p>${esc(out.disclaimer || pilotDisclaimer)}</p><div class="cards-grid">${(out.recommendations || []).map((item) => `<article class="panel sub-panel"><div class="card-header"><h2>${esc(item.institution)}</h2>${badge(item.label)}</div><p>${esc(item.programmeCode || 'Programme rule not submitted')}</p>${item.score == null ? '' : `<p><strong>${esc(item.metric || 'Indicative score')}:</strong> ${esc(item.score)}</p>`}<p>${esc(item.reason || (item.issues || []).join(' ') || 'No additional notes.')}</p>${sourceBlock(item)}${item.label === 'Meets published minimum' && item.programmeCode ? `<button type="button" class="secondary-button" data-whatif-code="${esc(item.institutionCode)}" data-whatif-programme="${esc(item.programmeCode)}">Try What-If</button>` : ''}</article>`).join('')}</div></section>`);
  main.querySelectorAll('[data-whatif-code]').forEach((button) => button.addEventListener('click', () => { location.href = `/learner/whatif.html?institutionCode=${encodeURIComponent(button.dataset.whatifCode)}&programmeCode=${encodeURIComponent(button.dataset.whatifProgramme)}`; }));
}
async function whatIfPage() {
  const params = new URLSearchParams(location.search), exam = catalog.examTypes.find((item) => /Grade 11 Final/i.test(item.EXAM_TYPE_NAME)) || catalog.examTypes[0];
  if (!exam) { show(title('What-If simulator', 'A saved Grade 11 result set is required.') + '<p>No examination milestones are available.</p>'); return; }
  const [out, saved] = await Promise.all([request('/api/pilot/recommendations?examTypeId=' + encodeURIComponent(exam.EXAM_TYPE_ID)), request('/api/results?examTypeId=' + encodeURIComponent(exam.EXAM_TYPE_ID))]);
  const verified = (out.recommendations || []).filter((item) => item.label === 'Meets published minimum' && item.programmeCode);
  const selectedCode = params.get('institutionCode') || verified[0]?.institutionCode || '';
  const selectedProgramme = params.get('programmeCode') || verified.find((item) => item.institutionCode === selectedCode)?.programmeCode || '';
  const rows = saved.rows || [];
  show(title('What-If simulator', 'Change one or more saved marks or simulate a subject substitution. Hypothetical values are sent to a stateless API and never saved.') + `<section class="panel"><p><strong>Hypothetical — not saved.</strong> ${esc(out.disclaimer || pilotDisclaimer)}</p>${rows.length ? `<form id="whatif-form"><div class="fields"><label>Verified programme<select name="programme" required ${verified.length ? '' : 'disabled'}>${verified.map((item) => `<option value="${esc(item.institutionCode)}|${esc(item.programmeCode)}" ${item.institutionCode===selectedCode&&item.programmeCode===selectedProgramme?'selected':''}>${esc(item.institution)} — ${esc(item.programmeCode)}</option>`).join('')}</select></label></div><h2>Edit marks</h2><div class="fields">${rows.map((row) => `<label>${esc(row.SUBJECT_NAME || row.SUBJECT_CODE)} (${esc(row.SUBJECT_CODE)})<input type="number" min="0" max="100" step="1" name="mark:${esc(row.SUBJECT_CODE)}" value="${esc(row.PERCENTAGE)}" required /></label>`).join('')}</div><h2>Optional subject change</h2><div class="fields"><label>Replace subject<select name="fromSubjectCode"><option value="">No substitution</option>${rows.map((row) => `<option value="${esc(row.SUBJECT_CODE)}">${esc(row.SUBJECT_NAME || row.SUBJECT_CODE)}</option>`).join('')}</select></label><label>With subject<select name="toSubjectCode"><option value="">Choose replacement</option>${catalog.subjects.map((row) => `<option value="${esc(row.SUBJECT_CODE)}">${esc(row.SUBJECT_NAME)} (${esc(row.SUBJECT_CODE)})</option>`).join('')}</select></label></div><button type="submit" ${verified.length ? '' : 'disabled'}>Calculate hypothetical outcome</button></form>` : '<p>There are no saved marks for Grade 11 Final. Add marks in Results before using What-If.</p>'}${verified.length ? '' : '<p class="feedback" role="status">No programmes have passed the verification gate yet, so no programme-specific outcome is calculated. This is intentional.</p>'}<div id="whatif-result" aria-live="polite"></div></section>`);
  const form = main.querySelector('#whatif-form');
  form?.addEventListener('submit', guard(async (event) => {
    event.preventDefault(); const fd = new FormData(form); const [institutionCode, programmeCode] = String(fd.get('programme') || '').split('|');
    const changes = rows.map((row) => ({ subjectCode: row.SUBJECT_CODE, percentage: Number(fd.get(`mark:${row.SUBJECT_CODE}`)) }));
    if (fd.get('fromSubjectCode')) {
      if (!fd.get('toSubjectCode')) throw new Error('Choose a replacement subject.');
      const replaced = String(fd.get('fromSubjectCode'));
      changes.splice(changes.findIndex((change) => change.subjectCode === replaced), 1);
      changes.push({ fromSubjectCode: replaced, toSubjectCode: fd.get('toSubjectCode'), percentage: Number(fd.get(`mark:${replaced}`)) });
    }
    const result = await request('/api/pilot/whatif', 'POST', { institutionCode, programmeCode, examTypeId: exam.EXAM_TYPE_ID, changes });
    main.querySelector('#whatif-result').innerHTML = `<section class="panel sub-panel"><h2>Hypothetical result</h2><p><strong>Before:</strong> ${esc(result.before.total ?? 'Not calculable')} · ${esc(result.before.status)}</p><p><strong>After:</strong> ${esc(result.after.total ?? 'Not calculable')} · ${esc(result.after.status)}</p><p><strong>Change:</strong> ${esc(result.delta ?? 'N/A')} APS points · ${esc(result.outcome)}</p>${result.guard ? `<p class="feedback" role="alert">${esc(result.guard.reason)} This is a warning, not an admission decision.</p>` : ''}<p>${esc(result.disclaimer)}</p>${sourceBlock(result)}</section>`;
  }));
}
async function fundingPage() {
  const [consentOut, matches] = await Promise.all([request('/api/privacy/consents'), request('/api/funding/matches')]);
  const consent = (consentOut.consents || []).find((row) => row.purpose === 'funding-matching' && row.granted);
  show(title('Funding matches', 'Compare your voluntarily entered study profile only with sourced, current funding opportunities. Unknown criteria are not guessed.') + `<section class="panel"><p>${esc(matches.message || matches.disclaimer || 'Funding guidance only.')}</p><p>${esc(matches.disclaimer || 'Verify with the institution/funder before applying. Criteria, funding and deadlines change.')}</p><form id="funding-profile"><h2>Study and household profile</h2><div class="fields"><label>Field of study<input name="fieldOfStudy" maxlength="120" /></label><label>Province<input name="province" maxlength="120" /></label><label>Citizenship category<input name="citizenship" maxlength="120" placeholder="Use a category from a published criterion" /></label><label>Household income band<input name="householdIncomeBand" maxlength="120" placeholder="Use the funder's published band label" /></label><label>Year of study<input name="yearOfStudy" maxlength="120" /></label><label>Academic average (%)<input name="academicAverage" type="number" min="0" max="100" step="0.1" /></label></div><button type="submit" ${consent?'':'disabled'}>Save encrypted profile</button></form><p>${consent ? 'Funding matching consent is active.' : 'Enable funding-matching consent on the Privacy and consent page before saving profile data.'} ${link('/learner/privacy.html','Manage consent')}</p><div id="funding-results" aria-live="polite"></div></section>`);
  const form = main.querySelector('#funding-profile');
  form?.addEventListener('submit', guard(async (event) => { event.preventDefault(); const payload = Object.fromEntries(new FormData(form).entries()); if (payload.academicAverage === '') delete payload.academicAverage; else if (payload.academicAverage != null) payload.academicAverage = Number(payload.academicAverage); for (const key of Object.keys(payload)) if (payload[key] === '') delete payload[key]; const saved = await request('/api/funding/profile','POST',payload); feedback(saved.message); await loadMatches(); }));
  async function loadMatches() {
    const data = await request('/api/funding/matches');
    main.querySelector('#funding-results').innerHTML = `<h2>Available opportunities</h2>${data.matches?.length ? data.matches.map((item) => `<article class="panel sub-panel"><div class="card-header"><h3>${esc(item.title)}</h3>${badge(item.label)}</div><p>${esc(item.funder)} · Closing date: ${esc(item.deadline || 'No published closing date — verify')}</p><p>Criteria compared: ${esc((item.criteriaCompared || []).map((c) => `${c.field}: ${c.actual ?? 'not provided'} → ${c.expected} (${c.result})`).join('; ') || 'No criteria summary')}</p>${sourceBlock(item)}<p>${esc(item.disclaimer)}</p><button type="button" data-alert-funding="${esc(item.id)}">Schedule deadline reminders</button></article>`).join('') : `<p>${esc(data.message || 'No actionable opportunities are available yet.')}</p>`}`;
    main.querySelectorAll('[data-alert-funding]').forEach((button) => button.addEventListener('click', guard(async () => { const r = await request('/api/deadline-alerts/schedule','POST',{itemType:'funding',itemId:Number(button.dataset.alertFunding)}); feedback(r.message); })));
  }
  await loadMatches();
}
async function creditTransferPage() {
  const out = await request('/api/credit-transfer/guidance');
  show(title('Credit transfer guidance', 'Indicative guidance only. Receiving institutions decide whether prior study or modules can be recognised.') + `<section class="panel"><p><strong>${esc(out.disclaimer || 'Guidance only — each institution decides credit and exemption. Final decision by the institution.')}</strong></p><div class="fields"><label>Prior institution filter<input id="credit-filter" maxlength="120" placeholder="Filter available guidance" /></label><label>Programme / qualification filter<input id="credit-programme-filter" maxlength="120" /></label></div><div id="credit-results">${out.guidance?.length ? out.guidance.map((item) => `<article class="panel sub-panel" data-prior="${esc(item.priorInstitution)}" data-programme="${esc(item.programmeCode)}"><h2>${esc(item.institutionCode.toUpperCase())} — ${esc(item.programmeCode)}</h2><p>Prior study: ${esc(item.priorInstitution || 'Not specified')} · ${esc(item.priorQualification || 'Qualification not specified')}</p><p>Status: ${esc(item.status)}</p><p>${esc((item.moduleAlignment || []).map((v) => typeof v === 'string' ? v : `${v.priorModule || ''} → ${v.receivingModule || ''}`).join('; ') || 'No module alignment has been sourced.')}</p>${sourceBlock(item)}${item.policyContact ? safeLink(item.policyContact,'Institution credit / RPL policy or contact') : ''}<p>${esc(item.disclaimer)}</p></article>`).join('') : `<p>${esc(out.message || 'No verified institution policies are available yet.')}</p>`}</div></section>`);
  const filter = () => { const a=main.querySelector('#credit-filter').value.toLowerCase(), b=main.querySelector('#credit-programme-filter').value.toLowerCase(); main.querySelectorAll('[data-prior]').forEach((node)=>{node.hidden=!node.dataset.prior.toLowerCase().includes(a)||!node.dataset.programme.toLowerCase().includes(b);}); };
  main.querySelector('#credit-filter')?.addEventListener('input', filter); main.querySelector('#credit-programme-filter')?.addEventListener('input', filter);
}
async function deadlinesPage() {
  const [alerts, opportunities] = await Promise.all([request('/api/deadline-alerts'), request('/api/funding/opportunities')]);
  show(title('Deadlines and reminders', 'Reminders are limited to published closing dates. Email reminders are sent only when separate email-reminder consent is active.') + `<section class="panel"><h2>Your reminder schedule</h2><div id="alert-list">${alerts.alerts?.length ? table(['Item','Deadline','Days before','Channel','Status','Action'], alerts.alerts.map((a) => `<tr><td>${esc(a.ItemType)} #${esc(a.ItemId)}</td><td>${esc(String(a.ClosingDate).slice(0,10))}</td><td>${esc(a.DaysBefore)}</td><td>${esc(a.Channel)}</td><td>${esc(a.Status)}</td><td><button type="button" data-mute-alert="${esc(a.AlertId)}">Mute</button></td></tr>`)) : '<p>No deadline reminders are scheduled.</p>'}</div><h2>Verified funding deadlines</h2>${opportunities.opportunities?.length ? opportunities.opportunities.map((o) => `<article class="panel sub-panel"><h3>${esc(o.title)}</h3><p>Closing: ${esc(o.deadline || 'No published closing date — verify')}</p>${sourceBlock(o)}${o.deadline ? `<button type="button" data-schedule-alert="${esc(o.id)}">Schedule reminders</button>` : ''}</article>`).join('') : `<p>${esc(opportunities.message || 'No currently verified funding deadlines are available.')}</p>`}</section>`);
  main.querySelectorAll('[data-mute-alert]').forEach((button)=>button.addEventListener('click',guard(async()=>{const r=await request('/api/deadline-alerts/mute','POST',{alertId:Number(button.dataset.muteAlert)}); feedback(r.message); await deadlinesPage();})));
  main.querySelectorAll('[data-schedule-alert]').forEach((button)=>button.addEventListener('click',guard(async()=>{const r=await request('/api/deadline-alerts/schedule','POST',{itemType:'funding',itemId:Number(button.dataset.scheduleAlert)}); feedback(r.message); await deadlinesPage();})));
}
async function privacyPage() {
  const out = await request('/api/privacy/consents');
  const purposes = [['process-results','Processing academic results'],['funding-matching','Funding matching (includes encrypted income band)'],['share-with-school','Sharing with school / institution'],['pilot-research','Pilot research instrumentation'],['email-reminders','Email deadline reminders'],['document-processing','Document Vault processing']];
  const current = new Map((out.consents||[]).map((row)=>[row.purpose,row]));
  show(title('Privacy and consent', 'Review each purpose separately. You can withdraw consent. A self-attested age status is not identity verification; under-18 features require recorded guardian confirmation.') + `<section class="panel"><h2>Your data</h2><p>${esc(out.notice || 'Your data is used only for purposes you consent to. You can request access or deletion.')}</p><ul><li>Academic records remain in the academic database.</li><li>Uploaded documents are encrypted before storage when the vault key is configured.</li><li>Household income is stored as an encrypted band, not an exact amount.</li><li>Teachers and representatives remain limited to their existing institutional scope.</li></ul><p><strong>Age / guardian attestation:</strong> For a real pilot with minors, staff must collect and verify guardian confirmation outside this self-attestation control before enabling sensitive functions.</p><form id="consents-form"><div class="fields"><label>Age status<select name="ageStatus"><option value="adult">I attest I am 18 or older</option><option value="under18">I am under 18</option></select></label><label>Parent/guardian confirmed<input type="checkbox" name="guardianConfirmed" /></label></div><fieldset><legend>Consent purposes</legend>${purposes.map(([key,label])=>`<label class="checkbox-row"><input type="checkbox" name="purpose:${key}" ${current.get(key)?.granted?'checked':''}/><span>${esc(label)}</span><small>${current.get(key)?.granted?'Currently granted':'Currently not granted'}</small></label>`).join('')}</fieldset><button type="submit">Save consent choices</button></form><div class="actions"><button type="button" id="export-data">Export my data (JSON + uploaded documents)</button><button type="button" id="delete-request" class="danger-button">Request account and document deletion</button><button type="button" id="cancel-delete" class="secondary-button">Cancel scheduled deletion</button></div></section>`);
  main.querySelector('#consents-form').addEventListener('submit',guard(async(event)=>{event.preventDefault();const fd=new FormData(event.currentTarget);const ageStatus=fd.get('ageStatus'),guardianConfirmed=fd.get('guardianConfirmed')==='on';for(const [purpose] of purposes){const granted=fd.get(`purpose:${purpose}`)==='on';await request('/api/privacy/consents','POST',{purpose,granted,ageStatus,guardianConfirmed});}feedback('Consent choices saved.');}));
  main.querySelector('#export-data').addEventListener('click',guard(async()=>{const exportResult=await request('/api/privacy/export');const blob=new Blob([JSON.stringify(exportResult.data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=exportResult.filename;a.click();URL.revokeObjectURL(url);feedback('Your export was prepared for download. Keep the file in a secure location.');}));
  main.querySelector('#delete-request').addEventListener('click',guard(async()=>{const confirmation=prompt('To request deletion, type exactly: DELETE MY ACCOUNT');if(confirmation!=='DELETE MY ACCOUNT') { feedback('Deletion request not submitted.'); return; } const result=await request('/api/privacy/delete-request','POST',{confirmation});feedback(result.message);}));
  main.querySelector('#cancel-delete').addEventListener('click',guard(async()=>{const result=await request('/api/privacy/delete-request/cancel','POST',{});feedback(result.message);}));
}
async function adminVerificationPage() {
  const load = () => request('/api/admin/verification');
  const data = await load();
  show(title('Programme verification ledger', 'Only source-backed undergraduate 2027 rules for WSU, UFH and UJ can be verified. Two distinct administrator sign-offs and a passing set of at least 25 official golden cases are mandatory.') + `
    <section class="panel">
      <h2>Propose or update a rule</h2>
      <form id="verification-form">
        <div class="fields">
          <label>Institution<select name="institutionCode" required><option value="wsu">Walter Sisulu University (WSU)</option><option value="ufh">University of Fort Hare (UFH)</option><option value="uj">University of Johannesburg (UJ)</option></select></label>
          <label>Programme code<input name="programmeCode" required maxlength="100" pattern="[A-Za-z0-9._-]+" /></label>
          <label>Official source title<input name="sourceTitle" maxlength="300" required /></label>
          <label>Official source URL (HTTPS)<input name="sourceUrl" type="url" pattern="https://.*" required /></label>
          <label>Document year<input name="documentYear" type="number" min="2000" max="2100" required /></label>
          <label>Page / section reference<input name="pageRef" required maxlength="100" /></label>
          <label>Retrieved date<input name="retrievedOn" type="date" required /></label>
          <label>Rules last updated date<input name="lastUpdatedOn" type="date" required /></label>
          <label>Evidence PDF (max 10 MB)<input name="evidence" type="file" accept="application/pdf" required /></label>
          <label>Requirement JSON<textarea name="requirement" required rows="7" placeholder="Enter the rule exactly as supported by the official source; do not guess thresholds."></textarea></label>
          <label>Published conditions (one per line)<textarea name="conditions" rows="4" required></textarea></label>
        </div>
        <button type="submit">Archive evidence and submit draft</button>
      </form>
      <div id="verification-result" role="status" aria-live="polite"></div>
    </section>
    <section class="panel">
      <h2>Bulk programme import</h2>
      <p>Use the supplied CSV template. Each archive path must reference a PDF already uploaded to the evidence archive. Dry-run validates every row and hash. Import creates draft rules only; CSV reviewer/status columns never count as real approvals.</p>
      <form id="verification-import-form">
        <label>Programme CSV (maximum 2 MB)<input name="csv" type="file" accept=".csv,text/csv" required /></label>
        <button type="submit">Preview import diff</button>
      </form>
      <div id="verification-import-result" role="status" aria-live="polite"></div>
    </section>
    <section class="panel"><h2>Current ledger</h2><div id="verification-ledger">${renderVerificationRows(data.verifications || [])}</div></section>`);

  function renderVerificationRows(rows) {
    if (!rows.length) return '<p>No rules have been proposed yet. The pilot correctly remains unverified.</p>';
    return rows.map((item) => `<article class="panel sub-panel">
      <div class="card-header"><h3>${esc(String(item.InstitutionCode || '').toUpperCase())} / ${esc(item.ProgrammeCode)}</h3>${badge(item.VerificationStatus)}</div>
      <p>Intake ${esc(item.IntakeYear)} · ${item.Enabled ? 'Learner-visible' : 'Not learner-visible'}</p>
      <p>Source: ${esc(item.source?.SourceTitle || 'Missing source')} ${item.source?.PageRef ? `· page ${esc(item.source.PageRef)}` : ''}</p>
      <p>Last updated: ${esc(String(item.provenance?.LastUpdatedOn || 'not recorded').slice(0, 10))} · Conditions: ${esc((item.provenance?.Conditions && (Array.isArray(item.provenance.Conditions) ? item.provenance.Conditions : [item.provenance.Conditions])).join('; ') || 'missing')}</p>
      <p>Golden accuracy: ${item.accuracy?.ready ? 'PASS' : 'BLOCKED'} · ${esc(item.accuracy?.cases ?? 0)} cases. ${esc(item.accuracy?.reason || 'At least 25 exact sourced cases are required for every programme.')}</p>
      <p>Sign-offs: ${(item.signoffs || []).map((a) => `${esc(a.ReviewerRole)} ${esc(a.Decision)}`).join(', ') || 'None'}</p>
      ${item.source?.SourceUrl ? safeLink(item.source.SourceUrl, 'Open cited source') : ''}
      <div class="actions"><button type="button" data-signoff="${esc(item.VerificationId)}" data-decision="approve" ${item.VerificationStatus === 'verified' ? 'disabled' : ''}>Approve</button><button type="button" data-signoff="${esc(item.VerificationId)}" data-decision="reject" ${item.VerificationStatus === 'verified' ? 'disabled' : ''}>Reject</button></div>
    </article>`).join('');
  }
  async function refreshLedger() {
    const refreshed = await load();
    main.querySelector('#verification-ledger').innerHTML = renderVerificationRows(refreshed.verifications || []);
    bindSignoffs();
  }
  const form = main.querySelector('#verification-form');
  form.addEventListener('submit', guard(async (event) => {
    event.preventDefault();
    const fd = new FormData(form);
    let requirement;
    try { requirement = JSON.parse(fd.get('requirement')); } catch { throw new Error('Requirement JSON is not valid JSON.'); }
    const conditions = String(fd.get('conditions')).split(/\r?\n/).map((v) => v.trim()).filter(Boolean);
    const uploadResult = await upload('/api/admin/verification/evidence', fd.get('evidence'));
    const result = await request('/api/admin/verification', 'POST', { institutionCode: fd.get('institutionCode'), programmeCode: fd.get('programmeCode').toLowerCase(), intakeYear: 2027, sourceTitle: fd.get('sourceTitle'), sourceUrl: fd.get('sourceUrl'), documentYear: Number(fd.get('documentYear')), pageRef: fd.get('pageRef'), retrievedOn: fd.get('retrievedOn'), lastUpdatedOn: fd.get('lastUpdatedOn'), conditions, requirement, contentHash: uploadResult.contentHash, archivedCopyPath: uploadResult.archivedCopyPath });
    main.querySelector('#verification-result').textContent = result.message;
    form.reset();
    await refreshLedger();
  }));

  let pendingCsv = '';
  const importForm = main.querySelector('#verification-import-form');
  importForm.addEventListener('submit', guard(async (event) => {
    event.preventDefault();
    const file = new FormData(importForm).get('csv');
    if (!file || !file.size) throw new Error('Choose a CSV file first.');
    if (file.size > 2_000_000) throw new Error('CSV must be 2 MB or smaller.');
    pendingCsv = await file.text();
    const result = await request('/api/admin/import/pilot-programmes', 'POST', { csv: pendingCsv, dryRun: true });
    const target = main.querySelector('#verification-import-result');
    target.innerHTML = `<p>${esc(result.message)}</p><pre>${esc(JSON.stringify(result.diff || [], null, 2))}</pre>${(result.diff || []).some((row) => row.action !== 'unchanged') ? '<button type="button" id="apply-programme-import">Apply draft import</button>' : ''}`;
    main.querySelector('#apply-programme-import')?.addEventListener('click', guard(async () => {
      if (!pendingCsv || !confirm('Apply these programme rows as drafts? Changed rules will lose old sign-offs.')) return;
      const applied = await request('/api/admin/import/pilot-programmes', 'POST', { csv: pendingCsv, dryRun: false });
      target.textContent = applied.message;
      pendingCsv = '';
      importForm.reset();
      await refreshLedger();
    }));
  }));

  function bindSignoffs() {
    main.querySelectorAll('[data-signoff]').forEach((button) => button.addEventListener('click', guard(async () => {
      const notes = prompt('Reviewer note:') || '';
      const out = await request(`/api/admin/verification/${button.dataset.signoff}/signoff`, 'POST', { decision: button.dataset.decision, notes });
      feedback(out.message);
      await refreshLedger();
    })));
  }
  bindSignoffs();
}
async function adminFundingPage() {
  const load = () => request('/api/admin/funding');
  const out = await load();
  show(title('Funding records', 'Funding data remains a draft until an administrator verifies published criteria, source, conditions and dates. Closed, stale or incomplete opportunities are not actionable.') + `
    <section class="panel">
      <h2>Bulk funding import</h2>
      <p>Use database/import/funding.template.csv. Source, conditions and criteria must come from published funder material. Dry-run validates the import and displays a diff; imported rows remain drafts.</p>
      <form id="funding-import-form"><label>Funding CSV (maximum 2 MB)<input name="csv" type="file" accept=".csv,text/csv" required /></label><button type="submit">Preview import diff</button></form>
      <div id="funding-import-result" role="status" aria-live="polite"></div>
    </section>
    <section class="panel">
      <h2>Add a sourced opportunity</h2>
      <form id="funding-admin-form"><div class="fields">
        <label>Funder name<input name="funderName" required maxlength="250"/></label>
        <label>Funder type<input name="funderType" required maxlength="50"/></label>
        <label>Opportunity title<input name="title" required maxlength="300"/></label>
        <label>Source title<input name="sourceTitle" required maxlength="300"/></label>
        <label>Source URL<input name="sourceUrl" type="url" pattern="https://.*" required/></label>
        <label>Source year<input name="sourceYear" type="number" min="2000" max="2100"/></label>
        <label>Last verified / updated<input name="lastUpdatedOn" type="date" required/></label>
        <label>Application opens<input name="applicationOpens" type="date"/></label>
        <label>Application closes<input name="applicationCloses" type="date"/></label>
        <label>Conditions<textarea name="conditions" rows="3" required></textarea></label>
        <label>Criteria JSON<textarea name="criteria" rows="6" required placeholder="Paste a JSON array of criteria taken from the official source."></textarea></label>
        <label>Required documents JSON<textarea name="requiredDocuments" rows="3" placeholder="Paste a JSON array of document names."></textarea></label>
        <label>Postgraduate only<input name="postgraduateOnly" type="checkbox"/></label>
      </div><button type="submit">Save as draft</button></form><div id="funding-admin-result" role="status" aria-live="polite"></div>
    </section>
    <section class="panel"><h2>Current opportunities</h2><div id="funding-admin-list">${renderFundingRows(out.opportunities || [])}</div></section>`);

  function renderFundingRows(rows) {
    return rows.length ? rows.map((item) => `<article class="panel sub-panel"><div class="card-header"><h3>${esc(item.OpportunityTitle)}</h3>${badge(item.Status)}</div><p>${esc(item.funder)} · Last updated ${esc(String(item.LastUpdatedOn || '').slice(0, 10))} · Deadline ${esc(item.ApplicationCloses ? String(item.ApplicationCloses).slice(0, 10) : 'No published closing date — verify')}</p>${safeLink(item.SourceUrl, item.SourceTitle || 'Open source')}<p>Criteria: ${(item.criteria || []).map((c) => `${esc(c.FieldName)} ${esc(c.Operator)} ${esc(c.value)}`).join('; ') || 'No criteria'}</p><button type="button" data-verify-funding="${esc(item.OpportunityId)}" ${item.Status === 'verified' ? 'disabled' : ''}>Verify sourced record</button></article>`).join('') : '<p>No funding opportunities submitted. None are invented or seeded as verified.</p>';
  }
  const form = main.querySelector('#funding-admin-form');
  form.addEventListener('submit', guard(async (event) => {
    event.preventDefault();
    const fd = new FormData(form);
    let criteria, requiredDocuments;
    try { criteria = JSON.parse(fd.get('criteria')); requiredDocuments = fd.get('requiredDocuments') ? JSON.parse(fd.get('requiredDocuments')) : []; }
    catch { throw new Error('Criteria and required documents must be valid JSON.'); }
    const payload = { funderName: fd.get('funderName'), funderType: fd.get('funderType'), title: fd.get('title'), sourceTitle: fd.get('sourceTitle'), sourceUrl: fd.get('sourceUrl'), sourceYear: fd.get('sourceYear') ? Number(fd.get('sourceYear')) : null, lastUpdatedOn: fd.get('lastUpdatedOn'), applicationOpens: fd.get('applicationOpens') || null, applicationCloses: fd.get('applicationCloses') || null, conditions: fd.get('conditions'), criteria, requiredDocuments, postgraduateOnly: fd.get('postgraduateOnly') === 'on' };
    const result = await request('/api/admin/funding', 'POST', payload);
    main.querySelector('#funding-admin-result').textContent = result.message;
    form.reset();
    const refreshed = await load();
    main.querySelector('#funding-admin-list').innerHTML = renderFundingRows(refreshed.opportunities || []);
    bindVerification();
  }));

  let pendingCsv = '';
  const importForm = main.querySelector('#funding-import-form');
  importForm.addEventListener('submit', guard(async (event) => {
    event.preventDefault();
    const file = new FormData(importForm).get('csv');
    if (!file || !file.size) throw new Error('Choose a CSV file first.');
    if (file.size > 2_000_000) throw new Error('CSV must be 2 MB or smaller.');
    pendingCsv = await file.text();
    const result = await request('/api/admin/import/funding', 'POST', { csv: pendingCsv, dryRun: true });
    const target = main.querySelector('#funding-import-result');
    target.innerHTML = `<p>${esc(result.message)}</p><pre>${esc(JSON.stringify(result.diff || [], null, 2))}</pre>${(result.diff || []).some((row) => row.action !== 'unchanged') ? '<button type="button" id="apply-funding-import">Apply draft import</button>' : ''}`;
    main.querySelector('#apply-funding-import')?.addEventListener('click', guard(async () => {
      if (!pendingCsv || !confirm('Apply these funding rows as drafts?')) return;
      const applied = await request('/api/admin/import/funding', 'POST', { csv: pendingCsv, dryRun: false });
      target.textContent = applied.message;
      pendingCsv = '';
      importForm.reset();
      const refreshed = await load();
      main.querySelector('#funding-admin-list').innerHTML = renderFundingRows(refreshed.opportunities || []);
      bindVerification();
    }));
  }));

  function bindVerification() {
    main.querySelectorAll('[data-verify-funding]').forEach((button) => button.addEventListener('click', guard(async () => {
      const result = await request(`/api/admin/funding/${button.dataset.verifyFunding}/verify`, 'POST', {});
      feedback(result.message);
      const refreshed = await load();
      main.querySelector('#funding-admin-list').innerHTML = renderFundingRows(refreshed.opportunities || []);
      bindVerification();
    })));
  }
  bindVerification();
}
async function adminPilotPage() {
  const load=()=>request('/api/admin/pilot/dashboard'); const out=await load();
  show(title('Pilot outcomes', 'Measure research time, unsuitable-application warnings and deadline behaviour. Groups under five are suppressed.')+`<section class="panel"><h2>Create a cohort</h2><form id="cohort-form"><div class="fields"><label>Cohort name<input name="name" required maxlength="150"/></label><label>Starts on<input name="startsOn" type="date"/></label><label>Ends on<input name="endsOn" type="date"/></label></div><button type="submit">Create active cohort</button></form><p id="pilot-admin-note" role="status">${esc(out.privacy||'')}</p><div class="actions"><button id="refresh-pilot" type="button">Refresh outcomes</button><button id="export-pilot" type="button">Download pseudonymous CSV</button></div><div id="pilot-dashboard">${renderCohorts(out.cohorts||[])}</div></section>`);
  function renderCohorts(rows){return rows.length?rows.map((item)=>`<article class="panel sub-panel"><div class="card-header"><h3>${esc(item.name)}</h3>${badge(item.status)}</div><p>Participants: ${esc(item.participantCount)}${item.suppressed?' · small group suppressed':''}</p><div class="stats-grid"><div><strong>${item.medianMinutesSaved==null?'Suppressed / not available':esc(item.medianMinutesSaved)+' min'}</strong><span>Median time saved</span></div><div><strong>${item.meanBaselineSeconds==null?'Suppressed / not available':esc(item.meanBaselineSeconds)+' sec'}</strong><span>Mean baseline research time</span></div><div><strong>${item.meanStudyPathSeconds==null?'Suppressed / not available':esc(item.meanStudyPathSeconds)+' sec'}</strong><span>Mean StudyPath time</span></div></div><p>Baseline tasks: ${esc(item.baselineComplete??'Suppressed')} · StudyPath tasks: ${esc(item.studyPathComplete??'Suppressed')}</p><p>Pre-surveys: ${esc(item.preSurveyResponses??'Suppressed')} · Post-surveys: ${esc(item.postSurveyResponses??'Suppressed')}</p><p>Guard / pilot events: ${esc(JSON.stringify(item.eventTypes||{}))}</p></article>`).join(''):'<p>No pilot cohort exists yet. Create a cohort only after participant consent and recruitment are in place.</p>';}
  main.querySelector('#cohort-form').addEventListener('submit',guard(async(event)=>{event.preventDefault();const fd=new FormData(event.currentTarget);const result=await request('/api/admin/pilot/cohorts','POST',{name:fd.get('name'),startsOn:fd.get('startsOn')||null,endsOn:fd.get('endsOn')||null});feedback('Cohort created: '+result.status);const refreshed=await load();main.querySelector('#pilot-dashboard').innerHTML=renderCohorts(refreshed.cohorts||[]);event.currentTarget.reset();}));
  main.querySelector('#refresh-pilot').addEventListener('click',guard(async()=>{const refreshed=await load();main.querySelector('#pilot-dashboard').innerHTML=renderCohorts(refreshed.cohorts||[]);feedback('Pilot dashboard refreshed.');}));
  main.querySelector('#export-pilot').addEventListener('click',guard(async()=>{const response=await fetch('/api/admin/pilot/export.csv',{headers:{Accept:'text/csv','X-CSRF-Token':csrf}});if(!response.ok){const data=await response.json().catch(()=>({}));throw new Error(data.error||'Export failed.');}const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='studypath-pilot-pseudonymous.csv';a.click();URL.revokeObjectURL(url);feedback('Pseudonymous export downloaded.');}));
}

export async function startFullApp() {
  const toggle = document.querySelector('#sidebar-toggle');
  toggle?.addEventListener('click', () => {
    const mobile = window.matchMedia('(max-width: 700px)').matches;
    const state = document.body.classList.toggle(mobile ? 'nav-open' : 'nav-collapsed');
    toggle.setAttribute('aria-expanded', String(mobile ? state : !state));
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  document.querySelector('#navigation')?.addEventListener('click', (e) => {
    if (e.target.closest('a') && window.matchMedia('(max-width: 700px)').matches) {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  document.querySelector('.shell')?.addEventListener('click', (e) => {
    if (document.body.classList.contains('nav-open') && e.target === e.currentTarget) {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  try {
    await api('/api/health');
    const publicConfig = await api('/api/public-config');
    intakeYear = Number.isInteger(Number(publicConfig.intakeYear)) ? Number(publicConfig.intakeYear) : 2027;
    supportEmail = publicConfig.supportEmail || '';
    emailEnabled = publicConfig.emailEnabled === true;
    if (page === 'login') {
      await login();
      return;
    }
    try {
      const me = await api('/api/me');
      user = me.user;
      csrf = me.csrf;
    } catch (e) {
      if (e.status === 401) {
        location.replace('/login.html');
        return;
      }
      throw e;
    }
    const declared = document.body.dataset.role;
    if (declared !== user.role) {
      location.replace('/' + user.role + '/overview.html');
      return;
    }
    shell();
    markPathwayVisit();
    show(title('Loading your workspace', 'Loading your role-specific records…'));
    catalog = await request('/api/catalog');
    if (page === 'overview') await dashboard();
    else if (page === 'profile') await profile();
    else if (page === 'results' || (page === 'verification' && user.role !== 'admin')) await resultsPage();
    else if (page === 'requirements') await requirements();
    else if (page === 'documents') await documentsPage();
    else if (page === 'applications' || page === 'decisions') await applicationsPage();
    else if (page === 'universities' || page === 'directories' || page === 'policies')
      await directory();
    else if (page === 'accounts') await accounts();
    else if (page === 'offerings') await offeringAdmin();
    else if (page === 'prospectuses') await prospectuses();
    else if (page === 'pilot-programmes') await pilotProgrammesPage();
    else if (page === 'whatif') await whatIfPage();
    else if (page === 'funding') await fundingPage();
    else if (page === 'credit-transfer') await creditTransferPage();
    else if (page === 'deadlines') await deadlinesPage();
    else if (page === 'privacy') await privacyPage();
    else if (page === 'verification' && user.role === 'admin') await adminVerificationPage();
    else if (page === 'funding-admin' && user.role === 'admin') await adminFundingPage();
    else if (page === 'pilot' && user.role === 'admin') await adminPilotPage();
    else if (page === 'audit') {
      const out = await request('/api/admin/audit');
      show(
        title(
          'Audit History',
          'Account, verification and application actions are recorded with UTC timestamps.',
        ) +
          /* HTML */ `
            <section class="panel">
              ${table(
                ['Time', 'Account', 'Action', 'Summary'],
                out.events.map(
                  (v) => /* HTML */ `
                    <tr>
                      <td>${esc(v.CREATED_AT)}</td>
                      <td>${esc(v.actor || 'System')}</td>
                      <td>${esc(auditAction(v.EVENT))}</td>
                      <td>${esc(auditDetail(v.DETAIL))}</td>
                    </tr>
                  `,
                ),
              )}
            </section>
          `,
      );
    } else if (page === 'learners') {
      const out = await request('/api/teacher/learners');
      show(
        title('My Learners', 'Learners enrolled at your school.') +
          /* HTML */ `
            <section class="panel">
              ${table(
                ['Name', 'Email'],
                out.learners.map(
                  (l) => /* HTML */ `
                    <tr>
                      <td>${esc(l.name)}</td>
                      <td>${esc(l.email)}</td>
                    </tr>
                  `,
                ),
              )}
            </section>
          `,
      );
    } else if (page === 'subjects') await subjectsPage();
    else if (page === 'lookups')
      show(
        title(
          'Academic Lookups',
          'National subject categories and examination milestones from the database.',
        ) +
          /* HTML */ `
            <section class="panel">
              ${table(
                ['Subject', 'Code', 'Category'],
                catalog.subjects.map(
                  (s) => /* HTML */ `
                    <tr>
                      <td>${esc(s.SUBJECT_NAME)}</td>
                      <td>${esc(s.SUBJECT_CODE)}</td>
                      <td>${esc(s.SUBJECT_CATEGORY)}</td>
                    </tr>
                  `,
                ),
              )}
            </section>
          `,
      );
    else show(title('Workspace', 'Select a page from the navigation.'));
    document.body.dataset.ready = 'true';
  } catch (error) {
    show(title('Unable to load workspace', error.message));
  }
}
