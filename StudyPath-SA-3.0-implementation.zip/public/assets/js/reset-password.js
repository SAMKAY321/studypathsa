import { api } from './api.js';
const form = document.querySelector('#reset-form'),
  feedback = document.querySelector('#feedback'),
  token = new URLSearchParams(location.search).get('token') || '';
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  try {
    const body = Object.fromEntries(new FormData(form));
    body.token = token;
    const result = await api('/api/auth/password-reset/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    feedback.textContent = result.message;
    form.hidden = true;
  } catch (error) {
    feedback.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
