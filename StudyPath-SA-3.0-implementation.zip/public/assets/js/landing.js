const refreshIcons = () => window.lucide?.createIcons();
if (document.readyState === 'loading')
  document.addEventListener('DOMContentLoaded', refreshIcons, { once: true });
else refreshIcons();
