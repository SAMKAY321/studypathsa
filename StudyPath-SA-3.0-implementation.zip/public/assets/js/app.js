import { startFullApp } from './full.js';
startFullApp();
