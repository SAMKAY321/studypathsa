import { api } from './api.js';
const feedback = document.querySelector('#feedback');
const submit = (selector) =>
  document.querySelector(selector).addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = event.submitter;
    button.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(event.target));
      const result = await api(
        selector === '#reset-request' ? '/api/auth/password-reset' : '/api/auth/email/resend',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        },
      );
      feedback.textContent = result.message;
    } catch (error) {
      feedback.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
submit('#reset-request');
submit('#verification-request');
api('/api/public-config')
  .then((config) => {
    if (!config.emailEnabled) {
      feedback.textContent =
        'Email delivery is not configured yet. Contact your institution administrator for account recovery.';
      document.querySelectorAll('form button').forEach((button) => (button.disabled = true));
    }
  })
  .catch(() => {
    feedback.textContent =
      'Account recovery is temporarily unavailable. Contact your institution administrator.';
  });
