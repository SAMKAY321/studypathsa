Lucide 1.8.0, ISC licence. Vendored from the official lucide package. See LICENSE. No external icon requests.
