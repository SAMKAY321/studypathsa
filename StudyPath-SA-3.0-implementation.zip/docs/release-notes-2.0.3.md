# Varsity Vault 2.0.3 — stale result draft reconciliation

## Observed failure

The Results `PUT /api/results` request returned HTTP 400 with `Choose an available subject and a percentage from 0–100.` The visible percentage values were within range. The API used a subject ID lookup against current `SUBJECTS`; the frontend restored `localStorage` drafts unchanged when they differed from server results. Because `SUBJECT_ID` is an SQL Server `IDENTITY` value and can change when a database is rebuilt/reseeded, a saved browser draft can contain stale IDs.

## Changes

- Added `shared/scoring/results-draft.js` to resolve browser-draft rows against the current subject catalogue using `SUBJECT_CODE`, then normalized `SUBJECT_NAME`, with current-ID fallback only when no stable label exists.
- Ensured school-scoped subjects are only remapped to records available to the learner's school.
- Preserved unresolved draft marks and visibly marked unmatched/duplicate subjects, so the learner can remove and re-add them without losing unrelated marks.
- Reconciled rows again before submission to avoid sending stale IDs.
- Made API validation compare SQL ID values numerically and return specific errors for missing subjects, school-scope mismatches and invalid percentages.
- Added five pure unit tests for stale ID mapping, name mapping, missing subjects, school scoping and duplicate rows, plus an API regression assertion for unknown IDs.

## Verification

- `node --check` passes for the changed frontend and API source.
- `node --test tests/results-draft.test.js`: 5/5 tests pass.
- `npm test` starts, but the complete suite cannot finish in this environment because `express`, `jsdom` and `nodemailer` are missing from the runtime's partial `node_modules`; use `npm ci` on the supported Node version before running the full suite.
- Live SQL Server writes could not be executed here. The browser's exact 400 response shows the server-side validation path rejected the submitted subject/percentage before any database reconciliation.

## Applying the fix

Stop the currently running Node server, back up the project folder, extract this release into a new folder, preserve the existing `.env` file, run `npm ci` under Node.js 24.15+ (24.x) or 26+, then start the application again. The local browser draft is preserved by the application; it is not necessary to clear browser storage.
