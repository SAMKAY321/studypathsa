# Information Systems III review — 2.0.1 source alignment

## Submitted database design preserved

The uploaded `unilink_script_improved.sql` and ERD PDF are included unchanged under `database/source/` and `docs/source/`. The application table map was compared against the SQL script; it was already aligned at 30 tables / 128 columns, so no core academic schema alteration was made. The generated relationship inventory and ERD Markdown were corrected to describe the DDL's 42 declared foreign keys. Keep your existing working `.env` and live database; do not rerun database creation or setup when updating an existing installation.

## Changes

- All four live portal menus group related tasks beneath labelled headings, with every destination visible. My Profile and My Applications remain named consistently.
- Current navigation marks the teacher verification alias as Results.
- Guarded requests prevent repeated submission while pending, expose a busy state and restore controls after failure.
- Verification status labels compare text and numeric identifiers consistently.
- Keyboard navigation has a visible focus outline and reduced-motion preferences are respected.

## Rubric evidence

| Criterion                     | Marks | Evidence to demonstrate                                                                                                        |
| ----------------------------- | ----- | ------------------------------------------------------------------------------------------------------------------------------ |
| ERD                           | 35    | Present the original submitted entities, relationships and cardinalities.                                                      |
| Normalization                 | 10    | Explain the submitted design and dependencies; no redesign in this release.                                                    |
| ERD/database alignment        | 15    | The application mapping matches all 30 tables and 128 column names/types in the supplied SQL. `source-schema-audit.md` enumerates 42 foreign keys; live database state still needs `npm run db:check`. |
| SQL documentation             | 10    | Use the original submitted SQL script.                                                                                         |
| UI design                     | 5     | Grouped role navigation, clear active destination, accessible focus and feedback.                                              |
| Functionality and integration | 20    | Demonstrate the real learner-to-teacher-to-representative lifecycle below.                                                     |
| Presentation                  | 5     | Both group members explain their actual contributions.                                                                         |

## Live demonstration checklist

1. Learner: save a complete subject/mark set, reload and confirm persistence; upload required documents.
2. Career educator: open the assigned learner, inspect evidence, verify results and documents.
3. Learner: compare marks against a configured programme, submit an eligible application, and open its history.
4. Career educator: screen the submitted application.
5. Representative: open the assigned university queue and record a provisional decision with reasons.
6. Learner: reload My Applications and show the changed status and dated history.
7. Demonstrate final verification/admission only when its existing prerequisites are met.
8. Administrator: show account/institution scope and audit history. Show validation for invalid marks and incomplete submissions.

Use your existing configured records. Do not invent programme requirements to make a demonstration pass.

## Verification and limits

Current source-alignment check: all JavaScript syntax checks passed. The focused test set passed 13 subtests, including two new tests that compare the supplied SQL DDL to the app table/column contract and ERD FK edge set. The full API/interface suite is not verified in this workspace because dependencies (`express`, `jsdom`, `nodemailer`) are not installed and the available Node.js 22.16.0 is below the project’s supported runtime. No live SQL Server connection was performed. Run `npm ci` with a supported Node.js version, then `npm test` and `npm run db:check`, followed by the real four-role smoke test before submission.

## Update in VS Code

Stop the running server. Keep your existing .env and .data folder. Replace application source with this ZIP, run npm ci, then npm test and npm start. No database scripts or setup command are needed for an already configured installation.


## Updated rubric evidence pack

Use [`rubric-alignment.md`](rubric-alignment.md) as the current rubric map, [`erd.md`](erd.md) for the source-aligned ERD and FK cardinalities, [`source-schema-audit.md`](source-schema-audit.md) for the 42 constraint inventory, [`schema-data-dictionary.md`](schema-data-dictionary.md) for attributes and keys, [`normalization-review.md`](normalization-review.md) for normalization notes, and [`presentation-and-demo.md`](presentation-and-demo.md) for the demo. The DDL-source mapping is checked; live SQL Server state still needs verification.
