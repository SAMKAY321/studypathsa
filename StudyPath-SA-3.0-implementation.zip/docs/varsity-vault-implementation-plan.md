# Varsity Vault — implementation plan

Prepared 5 October 2026. Target intake: **2027**.

This is the next planning deliverable for the VS Code project. No production project, database connection or database migration has been executed. The current interface is a review prototype. All 26 universities have scoped scoring profiles; full 2027 programme verification remains incomplete.

## Decisions carried into implementation

| Area                 | Decision                                                                                                                      |
| -------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Frontend             | HTML, CSS and JavaScript; separate page files with shared navigation and components                                           |
| Backend              | Node.js and Express; the backend owns SQL access and authoritative validation                                                 |
| Database             | Existing SQL Server database `VARSITYVAULT2`; SSMS remains its management tool                                                |
| Submitted work       | Preserve the ERD, tables, columns, views, functions, procedures, triggers and constraints                                     |
| Authentication       | Separately approved `VarsityVaultSecurity` database for credentials and sessions; do not add password columns to `PERSONS`    |
| University policies  | Versioned application configuration, scoped by institution, programme, intake and examination milestone                       |
| Visual design        | White surfaces, black text, blue navigation and actions, restrained gold highlights; supplied Lucide icons, no emojis         |
| Application boundary | Representatives review within Varsity Vault; no connection to universities’ internal admissions systems or payment processing |

The implementation target is a browser-based HTML/CSS/JavaScript web application with a Node/Express API and Microsoft SQL Server persistence. This plan records the application workflows, requirements and implementation constraints.

## Pages and the data they use

| Role / page                                    | Main behaviour                                                                                                                  | Existing SQL objects                                                                                                |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Learner — Overview                             | Show profile completeness, required documents and recent application activity                                                   | `LEARNERS`, `PERSONS`, `VIEW_LEARNER_SUBMISSION_CHECK`, `DOCUMENTS`, application views                              |
| Learner — Academic results                     | Select actual subjects and exam milestone; capture 0–100 percentages; save and recalculate                                      | `SUBJECTS`, `LEARNER_SUBJECTS`, `EXAM_TYPES`, `LEARNER_RESULTS`, `VIEW_LEARNER_RESULTS_DETAIL`                      |
| Learner — Requirements                         | Dedicated sidebar item; compare selected offering’s score, subjects and evidence with learner results                           | `UNI_QUALIFICATIONS`, `QUALIFICATIONS`, `QUALIFICATION_REQUIREMENTS`, results plus versioned policies               |
| Learner — University / qualification directory | Browse all 26 policy profiles; filter real offerings by university, province and search                                         | `UNIVERSITIES`, directory views, `QUALIFICATIONS`, `PROGRAMS`, `UNI_QUALIFICATIONS`                                 |
| Learner — Documents                            | Upload and download own documents; show mandatory items and final-certificate availability                                      | `DOCUMENTS`, `DOCUMENT_TYPES`, `VERIFICATION_STATUSES`, existing document trigger                                   |
| Learner — Applications                         | Submit an eligible, complete application; view status and chronological history                                                 | `usp_SubmitApplication`, `APPLICATIONS`, `VIEW_LEARNER_APPLICATIONS`, `VIEW_APPLICATION_TIMELINE`                   |
| Career Guidance Teacher — School queue         | Review only learners at the teacher’s school; compare marks against report cards; verify documents and results before screening | `TEACHERS`, `LEARNERS`, `LEARNER_RESULTS`, `DOCUMENTS`, `usp_ScreenApplication`                                     |
| University Representative — Institution queue  | Review screened applications for the representative’s university; provisional/rejection decision and final review               | `UNIVERSITY_REPS`, `VIEW_UNIVERSITY_APPLICATIONS`, `usp_ReviewApplication`, `APPLICATIONS`, `APPLICATION_PROCESSES` |
| IT Administrator — Directories / lookups       | Maintain operational directory and lookup records without changing schema; inspect policy verification status                   | `PROVINCES`, `CITIES`, `SCHOOLS`, `UNIVERSITIES`, academic lookup tables                                            |

The directory distinguishes a **scoring profile** from a **real qualification offering**. A profile without verified programme requirements has no Apply action. Listing all 26 policies does not imply that corresponding university or qualification records already exist in the live database.

## The learner Requirements page

Keep Requirements visible in learner navigation and reachable through every offering’s “View requirements” action. Selecting a university loads its actual offerings and policy profiles. The page shows:

1. University, qualification, study mode, examination milestone and 2027 intake.
2. Programme-specific score measure, learner total and minimum on the same scale.
3. Required subject marks, language alternatives and Mathematics/Mathematical Literacy conditions.
4. Each subject’s scoring contribution, including LO treatment and any verified bonus.
5. Source, source year and verification status; missing evidence remains visible.
6. Closing date and application-window status separately from academic eligibility.
7. Submission checklist: complete curriculum, mandatory documents and screening information.

Use explicit states: **Listed academic requirements met**, **Below listed requirements**, **Results incomplete**, and **Requirements pending verification**. Display that meeting minimums does not constitute an admission offer. Unknown scores or thresholds cannot produce a positive eligibility result.

## University scoring contract

Replace the prototype’s fixed subject positions with records carrying `SUBJECT_ID`, `SUBJECT_CODE`, `SUBJECT_CATEGORY`, language level and percentage. Support seven or more captured subjects, selecting the exact count and compulsory subjects required by the chosen policy. Do not assume English is always FAL or that Mathematics is always selected.

Each policy contains a stable policy key; institution key; approved mapping to `UNIVERSITY_ID` and, where applicable, `UNI_QUAL_ID`; programme scope; intake; accepted examination milestones; metric and units; band table; subject selection; LO rule; prerequisites; programme thresholds; source metadata; verification state; and version.

The evaluator returns a total or null, metric, subject contributions, included/excluded subjects, unmet prerequisites, missing inputs, policy version and evidence status. The backend recalculates from persisted marks. Browser calculations provide immediate feedback using the same rules.

Preserve `dbo.fn_GetLearnerAps` and `dbo.fn_GetEligibility`. Their generic totals may be shown explicitly as the baseline required by the submitted specification. They must not decide eligibility for a weighted, percentage, average or faculty-specific programme. The existing application views expose generic `APS_SCORE` and `ELIGIBILITY`; backend response objects must separately label these values and the institution-specific assessment.

Keep decimal results in application configuration and responses. `MIN_APS_SCORE` is `SMALLINT`, so a fractional threshold cannot be rounded into that column. An institution score of 432/600 cannot be compared with a generic APS threshold of 30 points.

Carry forward the complete 26-university verification register. UKZN and UL high-mark conflicts, VUT’s missing bands, CPUT method assignments, older/undated rules and other documented gaps remain gates. No generic fallback is permitted. Programme submission stays unavailable where its 2027 policy is unverified.

## Proposed API contract

All routes below are proposed, not implemented. `/api/me` identifies the signed-in person and role; the server derives learner, teacher and representative IDs from that identity.

| Route                                                                                                                      | Access / purpose                                              |
| -------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/me`                                                             | Session establishment, termination and identity               |
| `GET /api/universities`, `GET /api/offerings`                                                                              | Directory filters and clearly separated evidence status       |
| `GET /api/offerings/:id/requirements?intake=2027&examTypeId=…`                                                             | Learner-specific comparison using the mapped programme policy |
| `GET /api/me/results`, `PUT /api/me/results`                                                                               | Learner’s own enrolled subjects and selected exam milestone   |
| `GET /api/me/documents`, `POST /api/me/documents`                                                                          | Learner document listing and validated upload                 |
| `GET /api/documents/:id/download`                                                                                          | Owner or explicitly authorised reviewer download              |
| `GET /api/me/applications`, `POST /api/me/applications`                                                                    | Own application list and server-validated submission          |
| `GET /api/applications/:id/timeline`                                                                                       | Scoped history, with stable ordering                          |
| `GET /api/teacher/applications`, `POST /api/teacher/applications/:id/screen`                                               | Same-school queue and screening                               |
| `POST /api/teacher/results/:learnerId/verify`, `POST /api/teacher/documents/:id/verify`                                    | Same-school evidence verification                             |
| `GET /api/representative/applications`, `POST /api/representative/applications/:id/decision`                               | Own-university queue and provisional/rejection decision       |
| `POST /api/representative/applications/:id/final-verification`, `POST /api/representative/applications/:id/final-decision` | Guarded final-result workflow                                 |
| `GET /api/admin/directories/:type`, `POST /api/admin/directories/:type`, `PATCH /api/admin/directories/:type/:id`          | Allowlisted operational directory maintenance                 |

Use server-side sessions, password hashes in the separate security store, parameterised SQL, role and record checks, and validation for every mutation. Do not accept client-supplied ownership, school, university or acting-user IDs as authority. Reject ambiguous multi-role identities: `VIEW_USER_CONTEXT` uses precedence and does not itself enforce mutual exclusivity across role tables.

## Working with the frozen SQL implementation

| Finding in submitted script                                            | Backend handling                                                                                                                       |
| ---------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Submission, screening and provisional review procedures exist          | Use those procedures after policy, ownership, completeness and workflow checks                                                         |
| Screening procedure does not prove that marks/documents were verified  | Require verified relevant evidence before calling `usp_ScreenApplication`                                                              |
| No final-verification or final-decision procedure exists               | Use parameterised updates and timeline inserts in one guarded transaction; lock/recheck current state and scope                        |
| Procedure status checks occur before their transactions                | Backend transaction locks the target application before invoking a transition and rechecks its state                                   |
| Final-document trigger applies to INSERT only                          | Check the same lifecycle restrictions in every upload/replacement endpoint; never expose unrestricted document updates                 |
| Application dates and history dates are stored as text                 | Write consistent ISO-format values within existing field sizes; sort parsed date plus `APP_PROC_ID`                                    |
| Timeline rows have no actor column                                     | Keep the existing timeline; record actor, exact UTC timestamp, policy version and request outcome in the separate security audit store |
| One closing date per offering; no intake field on `UNI_QUALIFICATIONS` | Require an explicit 2027 offering mapping and a matching verified closing date; conflicting or unknown dates disable submission        |
| University has one `PROVINCE_ID`                                       | Filter using the recorded province; additional campus coverage must be an explicitly labelled configuration overlay                    |
| Mandatory document checks test row existence                           | Backend also requires usable file bytes, recognised type and ownership before submission                                               |

Acquire the application lock before reading status for transitions. Do not permit two simultaneous decisions to append conflicting history. Keep audit failure handling explicit: do not report a successful mutation while silently losing its required audit event.

Lifecycle: Submitted → Screened by Career Teacher → Provisionally Accepted or Rejected. After provisional acceptance, final evidence is verified → Final Matric Verified → Admitted or Offer Revoked. Final verification uses final NSC results, not the Grade 11 score. Never jump over a verification stage.

## VS Code file layout

The proposed repository root is `varsity-vault/`. Layout is recorded as a table so each responsibility has one clear location.

| Path                                                         | Responsibility                                                                    |
| ------------------------------------------------------------ | --------------------------------------------------------------------------------- |
| `package.json`, `package-lock.json`                          | Scripts and pinned dependency resolution                                          |
| `.env.example`, `.gitignore`, `README.md`                    | Connection placeholders, excluded secrets and Windows/VS Code setup               |
| `public/login.html`                                          | Login screen                                                                      |
| `public/learner/`                                            | Overview, requirements, results, documents, offerings and applications pages      |
| `public/teacher/`, `public/representative/`, `public/admin/` | Role-specific pages                                                               |
| `public/assets/css/`                                         | Design tokens, shared layout and page styles                                      |
| `public/assets/js/`                                          | API client, shared navigation, session handling and page controllers              |
| `public/assets/icons/`                                       | Pinned Lucide assets and licence                                                  |
| `server/app.js`, `server/index.js`                           | Express setup and process entry                                                   |
| `server/db/`                                                 | SQL Server pools and repository queries                                           |
| `server/middleware/`                                         | Authentication, role checks, scope, validation and errors                         |
| `server/routes/`, `server/services/`                         | Route handlers and workflow/document/eligibility logic                            |
| `shared/scoring/`                                            | Pure subject selection, band lookup and policy evaluation                         |
| `config/universities/2027/`                                  | All 26 scoped policies and verification metadata                                  |
| `config/offerings/2027/`                                     | Explicit real-offering mappings, thresholds and deadlines                         |
| `tests/`                                                     | Scoring, record access, lifecycle and submission tests                            |
| `docs/`                                                      | This plan, requirements traceability, university register and frozen-schema notes |

Credentials remain outside public files and source control. SQL Server runs independently; SSMS manages it. The browser talks to Express rather than directly to SQL Server. Startup must not run the submitted database creation script, insert data or modify schema automatically.

## Build sequence and completion checks

| Milestone                         | Deliverable                                                                                         | Completion check                                                                                                        |
| --------------------------------- | --------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| 1 — Foundation                    | Repository, shared design, role navigation, connection configuration and schema compatibility check | VS Code startup documented; no automatic schema changes; Requirements appears in learner navigation                     |
| 2 — Policy engine                 | Port all 26 review profiles to subject-record evaluation; add explicit programme mappings           | Verified arithmetic and selection boundaries; unknown policies and missing subjects cannot become eligible              |
| 3 — Learner flow                  | Results, Requirements, documents, offerings and applications                                        | Save/reload preserves marks; seven-subject and category gates work; missing documents and closed dates block submission |
| 4 — Reviewer flow                 | School screening, university decisions and final verification                                       | Cross-school/university requests denied; required stages cannot be skipped; every transition has history                |
| 5 — Administration and validation | Directories, policy evidence review and end-to-end checks                                           | Role access verified; desktop/mobile/browser navigation checked; all 26 directory profiles remain represented           |

Before opening a programme for submissions, resolve every verification gate that applies to that programme and intake. Remaining evidence gaps can stay visible in the directory without enabling Apply.

## Planning validation and limits

This plan was mapped against the current three-page requirements PDF, the complete submitted 857-line SQL script and the current 26-university register. No SQL Server instance has been connected, no production code has been tested and no live offering IDs have been verified. Actual database metadata must be checked read-only before repository queries are implemented. Preserve existing spellings such as `ITADMIN_IID` and `ADRRESS_TYPE_ID`; use application aliases rather than renaming columns.

Source documents: `Group 3 - Kagiso Mathabathe & Mantoa Moletsane VarsityVault Requiremnts.pdf`, `unilink_script_improved(1).sql`, and `varsity-vault-26-university-register.md`. The submitted ERD remains an immutable project constraint.
