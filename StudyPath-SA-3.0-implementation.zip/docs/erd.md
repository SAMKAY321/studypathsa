# Varsity Vault Entity-Relationship Diagram (ERD) and relationship inventory

This supporting reference is reconciled to the group-supplied ERD PDF and the SQL Server database script included in this project. The PDF in `docs/source/` is the submitted ERD; this Markdown reference supplies searchable entity/attribute definitions and a DDL-derived FK/cardinality inventory for review against the rubric. The database script is preserved unchanged.

## Visual diagrams

The high-level SVGs are easier to read than the complete 30-entity view at normal zoom. Open them in a browser or VS Code to zoom in:

- [Identity, roles and locations](erd-identity.svg)
- [Academic catalogue and learner records](erd-academic.svg)
- [Applications, documents and decisions](erd-workflow.svg)
- [All-entity ERD overview](erd-overview.svg)

The `.dot` files beside the SVGs are editable Graphviz source files; `.png` previews are included for quick viewing.

## Source authority and schema reconciliation

The authoritative project sources are the group-submitted ERD PDF at `docs/source/Group 3 - Kagiso Mathabathe & Mantoa Moletsane VarsityVault ERD.pdf` and the SQL Server DDL at `database/source/unilink_script_improved.sql` (copied byte-for-byte from the supplied file). The project contract was checked against that DDL: all 30 core tables and all 128 table columns match by name and SQL type. The DDL declares 42 named foreign-key constraints. The relationship lines below are reconciled against those constraints; line-end cardinalities are generated from FK nullability, primary-key membership and single-column uniqueness. The submitted PDF is preserved unchanged and should be treated as the group’s ERD presentation artefact. The generated SVG/PNG drawings are zoomable companions, not replacements for the submitted PDF.

Authentication/session hardening is stored separately in `VarsityVaultSecurity` via `database/security.sql`; those application-support tables are not entities in the submitted academic ERD and are not counted among the 30 core tables.

## Full logical ERD

```mermaid
erDiagram
    ACTIONS {
        int ACTION_ID PK
        varchar_100 ACTION_NAME
    }
    ADDRESS_TYPES {
        int ADDRESS_TYPE_ID PK
        varchar_50 ADDRESS_TYPE_NAME
    }
    CITIES {
        int CITY_ID PK
        varchar_100 CITY_NAME
    }
    DOCUMENT_TYPES {
        int DOCUMENT_TYPE_ID PK
        varchar_50 DOCUMENT_TYPE_NAME
        bit IS_MANDATORY
        bit IS_LOCKED_UNTIL_FINAL
    }
    EXAM_TYPES {
        int EXAM_TYPE_ID PK
        varchar_50 EXAM_TYPE_NAME
    }
    PROGRAMS {
        int PROGRAM_ID PK
        varchar_100 PROGRAM_NAME
    }
    STUDY_MODES {
        int STUDY_MODE_ID PK
        varchar_50 STUDY_MODE_NAME
    }
    VERIFICATION_STATUSES {
        int VERIFICATION_STATUS_ID PK
        varchar_50 VERIFICATION_STATUS_NAME
    }
    PROVINCES {
        int PROVINCE_ID PK
        varchar_50 PROVINCE_NAME
    }
    APPLICATION_STATUSES {
        int STATUS_ID PK
        varchar_50 STATUS_NAME
        bit USES_FINAL_RESULTS
    }
    ACHIEVEMENT_LEVELS {
        tinyint LEVEL_NO PK
        varchar_50 LEVEL_DESCRIPTION
        decimal_5_2 MIN_PERCENT
        tinyint APS_POINTS
    }
    PERSONS {
        int PERSON_ID PK
        varchar_100 FIRST_NAME
        varchar_100 LAST_NAME
        varchar_255 EMAIL
        varchar_100 USERNAME
        varchar_10 PHONE_NUMBER
        varchar_13 SA_ID_NUMBER
    }
    SCHOOLS {
        int SCHOOL_ID PK
        varchar_150 SCHOOL_NAME
        varchar_30 EMIS_NUMBER
        int CITY_ID
        int PROVINCE_ID
    }
    UNIVERSITIES {
        int UNIVERSITY_ID PK
        varchar_150 UNIVERSITY_NAME
        varchar_255 WEBSITE
        int PROVINCE_ID
    }
    QUALIFICATIONS {
        int QUAL_ID PK
        varchar_150 QUAL_NAME
        int PROGRAM_ID
    }
    SUBJECTS {
        int SUBJECT_ID PK
        varchar_100 SUBJECT_NAME
        varchar_20 SUBJECT_CODE
        int SCHOOL_ID
        varchar_30 SUBJECT_CATEGORY
    }
    TEACHERS {
        int TEACHER_ID PK
        int PERSON_ID
        int SCHOOL_ID
        varchar_100 DEPARTMENT
        varchar_50 DESIGNATION
    }
    LEARNERS {
        int LEARNER_ID PK
        int PERSON_ID
        int SCHOOL_ID
    }
    ITADMINS {
        int ITADMIN_IID PK
        int PERSON_ID
        int SCHOOL_ID
    }
    PERSON_ADDRESSES {
        int ADDRESS_ID PK
        int PERSON_ID
        int ADDRESS_TYPE_ID
        varchar_150 STREET_NAME
        int CITY_ID
    }
    UNIVERSITY_ADDRESSES {
        int ADDRESS_ID PK
        int UNIVERSITY_ID
        int ADRRESS_TYPE_ID
        varchar_150 STREET_NAME
        int CITY_ID
    }
    UNIVERSITY_REPS {
        int REP_ID PK
        int PERSON_ID
        int UNIVERSITY_ID
    }
    PROSPECTUSES {
        int PROSPECTUS_ID PK
        int UNIVERSITY_ID
        varbinary_MAX PROSPECTUS_FILE
        varchar_255 PROSPECTUS_FILENAME
        varchar_100 PROSPECTUS_MIMETYPE
        varchar_20 PROSPECTUS_DATE
    }
    UNI_QUALIFICATIONS {
        int UNI_QUAL_ID PK
        int UNIVERSITY_ID
        int QUAL_ID
        date APPLICATION_CLOSING_DATE
    }
    QUALIFICATION_REQUIREMENTS {
        int REQUIREMENT_ID PK
        int UNI_QUAL_ID
        smallint MIN_APS_SCORE
        decimal_5_2 MIN_MATH_SCORE
        decimal_5_2 MIN_ENG_SCORE
        varchar_400 NOTES
    }
    APPLICATIONS {
        int APPLICATION_ID PK
        varchar_20 APPLICATION_DATE
        smallint ACADEMIC_YEAR
        int STUDY_MODE_ID
        int UNI_QUAL_ID
        int LEARNER_ID
        int TEACHER_ID
        int STATUS_ID
        int REVIEWED_BY_REP_ID
        varchar_20 REVIEW_DATE
        varchar_400 REVIEW_NOTES
    }
    APPLICATION_PROCESSES {
        int APP_PROC_ID PK
        int APPLICATION_ID
        int ACTION_ID
        varchar_20 ACTION_DATE
    }
    DOCUMENTS {
        int DOCUMENT_ID PK
        varchar_150 DOCUMENT_NAME
        int DOCUMENT_TYPE_ID
        varchar_20 UPLOAD_DATE
        int PERSON_ID
        varchar_255 FILE_NAME
        varchar_255 MIME_TYPE
        varbinary_MAX DOCUMENT_BLOB
        int VERIFICATION_STATUS_ID
        int VERIFIED_BY_TEACHER_ID
        varchar_20 VERIFIED_DATE
    }
    LEARNER_RESULTS {
        int LEARNER_ID PK
        int SUBJECT_ID PK
        int EXAM_TYPE_ID PK
        decimal_5_2 PERCENTAGE
        int VERIFICATION_STATUS_ID
        int VERIFIED_BY_TEACHER_ID
        varchar_20 VERIFIED_DATE
    }
    LEARNER_SUBJECTS {
        int LEARNER_SUBJECT_ID PK
        int LEARNER_ID
        int SUBJECT_ID
        varchar_20 ENROLLMENT_DATE
    }
    PROVINCES ||--o{ SCHOOLS : "contains schools"
    PROVINCES ||--o{ UNIVERSITIES : "contains universities"
    CITIES o|--o{ SCHOOLS : "locates schools"
    CITIES o|--o{ PERSON_ADDRESSES : "locates person addresses"
    CITIES o|--o{ UNIVERSITY_ADDRESSES : "locates university addresses"
    PERSONS o|--o| LEARNERS : "has learner role"
    PERSONS o|--o| TEACHERS : "has teacher role"
    PERSONS o|--o| ITADMINS : "has administrator role"
    PERSONS ||--o| UNIVERSITY_REPS : "has representative role"
    SCHOOLS o|--o{ LEARNERS : "enrols learners"
    SCHOOLS o|--o{ TEACHERS : "employs teachers"
    SCHOOLS o|--o{ ITADMINS : "assigns administrators"
    SCHOOLS o|--o{ SUBJECTS : "offers subjects"
    ADDRESS_TYPES o|--o{ PERSON_ADDRESSES : "classifies person address"
    ADDRESS_TYPES o|--o{ UNIVERSITY_ADDRESSES : "classifies university address"
    PERSONS o|--o{ PERSON_ADDRESSES : "has addresses"
    UNIVERSITIES o|--o{ UNIVERSITY_ADDRESSES : "has campuses/addresses"
    UNIVERSITIES ||--o{ UNIVERSITY_REPS : "has representatives"
    UNIVERSITIES o|--o{ PROSPECTUSES : "publishes prospectuses"
    UNIVERSITIES o|--o{ UNI_QUALIFICATIONS : "offers qualifications"
    PROGRAMS o|--o{ QUALIFICATIONS : "groups qualifications"
    QUALIFICATIONS o|--o{ UNI_QUALIFICATIONS : "is offered as"
    UNI_QUALIFICATIONS ||--o| QUALIFICATION_REQUIREMENTS : "has requirements"
    LEARNERS o|--o{ APPLICATIONS : "submits applications"
    UNI_QUALIFICATIONS o|--o{ APPLICATIONS : "is applied for"
    STUDY_MODES o|--o{ APPLICATIONS : "selects study mode"
    APPLICATION_STATUSES ||--o{ APPLICATIONS : "sets application status"
    TEACHERS o|--o{ APPLICATIONS : "screens application"
    UNIVERSITY_REPS o|--o{ APPLICATIONS : "reviews applications"
    APPLICATIONS o|--o{ APPLICATION_PROCESSES : "has process history"
    ACTIONS o|--o{ APPLICATION_PROCESSES : "labels process action"
    LEARNERS o|--o{ LEARNER_SUBJECTS : "enrols in subjects"
    SUBJECTS o|--o{ LEARNER_SUBJECTS : "is selected by learners"
    LEARNERS ||--o{ LEARNER_RESULTS : "has results"
    SUBJECTS ||--o{ LEARNER_RESULTS : "is assessed in"
    EXAM_TYPES ||--o{ LEARNER_RESULTS : "categorizes result milestone"
    VERIFICATION_STATUSES o|--o{ LEARNER_RESULTS : "sets result verification"
    TEACHERS o|--o{ LEARNER_RESULTS : "verifies results"
    DOCUMENT_TYPES o|--o{ DOCUMENTS : "classifies documents"
    PERSONS o|--o{ DOCUMENTS : "owns documents"
    VERIFICATION_STATUSES o|--o{ DOCUMENTS : "sets document verification"
    TEACHERS o|--o{ DOCUMENTS : "verifies documents"
```

## Relationship and cardinality notes

These are physical foreign-key relationships declared by the supplied SQL script, not assumed joins. “Required parent” means the child FK cannot be NULL (including composite-PK FK fields); “optional parent” means the child FK allows NULL. The parent has 0..1 children where the child FK has a single-column UNIQUE constraint, otherwise 0..many. Delete behaviour is taken from each FK declaration. Nullable columns and retained source spellings are not silently changed.

| Constraint | Child FK | References | Parent requirement | Children per parent | On parent delete |
|---|---|---|---|---|---|
| `FK_SCHOOL_CITY` | `SCHOOLS.CITY_ID` | `CITIES.CITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_SCHOOL_PROVINCE` | `SCHOOLS.PROVINCE_ID` | `PROVINCES.PROVINCE_ID` | required (NOT NULL / PK) | 0..many | NO ACTION (default) |
| `FK_UNI_PROVINCE` | `UNIVERSITIES.PROVINCE_ID` | `PROVINCES.PROVINCE_ID` | required (NOT NULL / PK) | 0..many | NO ACTION (default) |
| `FK_QUAL_PROG` | `QUALIFICATIONS.PROGRAM_ID` | `PROGRAMS.PROGRAM_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_SUB_SCHOOL` | `SUBJECTS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_TEACHER_PERSON` | `TEACHERS.PERSON_ID` | `PERSONS.PERSON_ID` | optional (NULL allowed) | 0..1 | CASCADE |
| `FK_TEACHER_SCHOOL` | `TEACHERS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_LEARNER_PERSON` | `LEARNERS.PERSON_ID` | `PERSONS.PERSON_ID` | optional (NULL allowed) | 0..1 | CASCADE |
| `FK_LEARNER_SCHOOL` | `LEARNERS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_ITADMIN_PERSON` | `ITADMINS.PERSON_ID` | `PERSONS.PERSON_ID` | optional (NULL allowed) | 0..1 | CASCADE |
| `FK_ITADMIN_SCHOOL` | `ITADMINS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_PADDR_CITY` | `PERSON_ADDRESSES.CITY_ID` | `CITIES.CITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_PADDR_PERSON` | `PERSON_ADDRESSES.PERSON_ID` | `PERSONS.PERSON_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_PADDR_TYPE` | `PERSON_ADDRESSES.ADDRESS_TYPE_ID` | `ADDRESS_TYPES.ADDRESS_TYPE_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_UADDR_CITY` | `UNIVERSITY_ADDRESSES.CITY_ID` | `CITIES.CITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_UADDR_TYPE` | `UNIVERSITY_ADDRESSES.ADRRESS_TYPE_ID` | `ADDRESS_TYPES.ADDRESS_TYPE_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_UADDR_UNI` | `UNIVERSITY_ADDRESSES.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_REP_PERSON` | `UNIVERSITY_REPS.PERSON_ID` | `PERSONS.PERSON_ID` | required (NOT NULL / PK) | 0..1 | CASCADE |
| `FK_REP_UNI` | `UNIVERSITY_REPS.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | required (NOT NULL / PK) | 0..many | CASCADE |
| `FK_PROS_UNI` | `PROSPECTUSES.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_UNIQUAL_QUAL` | `UNI_QUALIFICATIONS.QUAL_ID` | `QUALIFICATIONS.QUAL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_UNIQUAL_UNI` | `UNI_QUALIFICATIONS.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_QREQ_UNIQUAL` | `QUALIFICATION_REQUIREMENTS.UNI_QUAL_ID` | `UNI_QUALIFICATIONS.UNI_QUAL_ID` | required (NOT NULL / PK) | 0..1 | CASCADE |
| `FK_APPS_LEARNER` | `APPLICATIONS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_APPS_STUDYMODE` | `APPLICATIONS.STUDY_MODE_ID` | `STUDY_MODES.STUDY_MODE_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_APPS_TEACHER` | `APPLICATIONS.TEACHER_ID` | `TEACHERS.TEACHER_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_APPS_UNIQUAL` | `APPLICATIONS.UNI_QUAL_ID` | `UNI_QUALIFICATIONS.UNI_QUAL_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_APPS_STATUS` | `APPLICATIONS.STATUS_ID` | `APPLICATION_STATUSES.STATUS_ID` | required (NOT NULL / PK) | 0..many | NO ACTION (default) |
| `FK_APPS_REVIEWER` | `APPLICATIONS.REVIEWED_BY_REP_ID` | `UNIVERSITY_REPS.REP_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_APPPROC_ACTION_FK` | `APPLICATION_PROCESSES.ACTION_ID` | `ACTIONS.ACTION_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_APPPROC_APPLICATION_FK` | `APPLICATION_PROCESSES.APPLICATION_ID` | `APPLICATIONS.APPLICATION_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_DOCS_VERSTATUS` | `DOCUMENTS.VERIFICATION_STATUS_ID` | `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_DOCS_VERTEACHER` | `DOCUMENTS.VERIFIED_BY_TEACHER_ID` | `TEACHERS.TEACHER_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_DOC_PERSON` | `DOCUMENTS.PERSON_ID` | `PERSONS.PERSON_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_DOC_TYPES` | `DOCUMENTS.DOCUMENT_TYPE_ID` | `DOCUMENT_TYPES.DOCUMENT_TYPE_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_LRESULTS_EXAMTYPE_FK` | `LEARNER_RESULTS.EXAM_TYPE_ID` | `EXAM_TYPES.EXAM_TYPE_ID` | required (NOT NULL / PK) | 0..many | CASCADE |
| `FK_LRESULTS_LEARNER_FK` | `LEARNER_RESULTS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | required (NOT NULL / PK) | 0..many | CASCADE |
| `FK_LRESULTS_SUBJECT_FK` | `LEARNER_RESULTS.SUBJECT_ID` | `SUBJECTS.SUBJECT_ID` | required (NOT NULL / PK) | 0..many | NO ACTION (default) |
| `FK_LRESULTS_VERSTATUS` | `LEARNER_RESULTS.VERIFICATION_STATUS_ID` | `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_LRESULTS_VERTEACHER` | `LEARNER_RESULTS.VERIFIED_BY_TEACHER_ID` | `TEACHERS.TEACHER_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |
| `FK_LSUBJ_LEARNER` | `LEARNER_SUBJECTS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | optional (NULL allowed) | 0..many | CASCADE |
| `FK_LSUBJ_SUBJECT` | `LEARNER_SUBJECTS.SUBJECT_ID` | `SUBJECTS.SUBJECT_ID` | optional (NULL allowed) | 0..many | NO ACTION (default) |

**DDL count: 42 foreign-key constraints.** The diagram models the cardinality implemented by the DDL; the relationship remains separate from any additional application-level rule.


## Additional modelling notes

- `LEARNER_RESULTS` has a composite primary key `(LEARNER_ID, SUBJECT_ID, EXAM_TYPE_ID)`, which models one result per learner, subject and exam milestone.
- `UNI_QUALIFICATIONS` is the associative entity connecting a university to a qualification it offers. It also carries offering-specific data such as the application closing date.
- `APPLICATION_PROCESSES` is a history/associative table: a single application can have multiple dated actions, and `ACTIONS` defines the action lookup.
- `PERSONS` stores shared identity/contact attributes while the role tables store role-specific facts.
- Lookup/reference entities include `ACTIONS`, `ADDRESS_TYPES`, `CITIES`, `DOCUMENT_TYPES`, `EXAM_TYPES`, `PROGRAMS`, `STUDY_MODES`, `VERIFICATION_STATUSES`, `PROVINCES`, `APPLICATION_STATUSES`, and `ACHIEVEMENT_LEVELS`.
- `ACHIEVEMENT_LEVELS` is used for scoring/rules; the supplied contract does not identify a direct FK relationship from it to a transactional table.

## Validation and source-boundary notes

1. The source-level DDL reconciliation is complete for table/column names, declared SQL types and the 42 foreign-key declarations.
2. A live SQL Server check is still environment-dependent. Run `npm run db:check` against the database instance that was created from the provided script to verify object visibility and column presence.
3. The database script is preserved as supplied; the app package does not modify or rerun it.
4. Source spellings such as `ITADMIN_IID` and `ADRRESS_TYPE_ID` are retained because they are part of the supplied database contract.
5. The code's security-support database is separate from the submitted academic ERD. It should not be drawn as part of the core Varsity Vault ERD unless the group deliberately extends its submitted design.
