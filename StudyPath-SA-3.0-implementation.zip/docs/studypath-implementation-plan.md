# StudyPath SA — implementation plan

**Planning baseline:** supplied `varsity-vault-v2.1.1.zip`, assessed 26 October 2026.  
**Delivery order:** W0 → W11, following `StudyPath-SA-build-prompt.md`.

## Principles and invariants

1. Extend the current Express/static-frontend/shared-module architecture; do not introduce a frontend framework or bundler.
2. Keep `database/source/unilink_script_improved.sql` and its 30-table academic schema byte-for-byte unchanged. Add StudyPath-specific structures only in a separate `StudyPathPilot` database.
3. The server remains the source of truth for eligibility and funding matches. What-If calls the same scoring engine without saving hypothetical values.
4. Fail closed when a rule is missing, conflicting, stale, unverified or lacks provenance. Never seed guessed university requirements or funding criteria.
5. All recommendation, credit-transfer and funding language comes from centralized trust/disclaimer modules and carries source, freshness and conditions.
6. Treat documents, income bands, personal details and under-18 accounts as high-risk personal information; no personal data in logs, analytics, URLs or error messages.
7. Preserve all existing tests and add workstream-specific tests. Run `npm test` after each workstream and `npm run verify` when available.

## Workstream sequence and file-level change map

| Workstream | Planned files / areas | Key outputs and acceptance evidence |
|---|---|---|
| **W0 — Baseline and planning** | `docs/baseline.md`; `docs/studypath-implementation-plan.md`; `docs/decisions.md`; `README.md`; `START-HERE.md`; `docs/build-status.md`; user-facing strings in `public/`, relevant email/authenticator labels in `server/`; rebrand tests | Record actual baseline results; document ADRs and file/migration plan; rebrand visible product text; do not rename internal database, package or asset identifiers unnecessarily. Baseline is currently blocked by the available Node/npm environment, as recorded in `docs/baseline.md`. |
| **W1 — Pilot scope and verified admissions data** | `config/pilot.json`; `config/universities/2027/register.json`; new verification contract/config; new `public/admin/` verification page and JS; new `database/import/pilot-programmes.template.csv`; transactional CSV importer; `shared/` verification helpers; `tests/fixtures/golden/{wsu,ufh,uj}.json`; `tests/accuracy/` or equivalent; `scripts/accuracy` and `package.json`; `docs/accuracy-report.md`, `docs/data-verification-process.md`, `docs/open-items.md` | Learners see only Walter Sisulu University, University of Fort Hare and University of Johannesburg, and only verified undergraduate programmes are presented as meeting published minimums. Each verified rule has source/page, retrieved date, archived-content hash/path and two distinct reviewer sign-offs. Exact golden tests use only attributable published examples/calculators; unknown data remains draft/unverified. Other 23 institutions remain in the register but are hidden from learner use. |
| **W2 — What-If simulator** | `public/learner/whatif.html`; matching browser script/styles; `server/full-api.js` / route registration in `server/app.js`; reusable validation/scoring in `shared/scoring/`; new API/UI tests | Add stateless, validated, rate-limited `POST /api/whatif`; return APS/outcome changes using the exact scoring path as live evaluation. Mark all output “Hypothetical — not saved”. Add plain-language mismatch guard and acknowledgement event; test What-If parity with real evaluation. |
| **W3 — Credit-transfer guidance** | migration `database/migrations/004_credit_transfer.sql`; `server/` routes/storage adapter; `shared/trust/`; learner guidance page/components; contract and wording-lint tests | Provide guidance-only alignment plus sourced receiving-institution policy, conditions and contact. Do not predict an exemption or credit outcome; seed only data with verifiable sources. |
| **W4 — Funding matching** | migration `003_funding.sql`; `database/import/funding.template.csv`; funder importer; `server/` matching routes and scheduled stale-state job; staff maintenance UI; learner funding components; tests | Add funders/opportunities/criteria/document requirements with mandatory source/title, last-updated date, conditions, open/close information and draft/verified/stale/closed status. Match only user-supplied fields and display exact criteria compared. Closed opportunities cannot be actionable. Funding data remains unseeded until an authoritative source has been read and recorded. |
| **W5 — Document Vault, privacy and POPIA** | migration `005_privacy.sql`; migration additions for access log/requests as specified; `server/security.js`, `server/storage.js`, `server/full-api.js`, `server/db/config.js`; upload/download routes; `public/privacy.html`; Vault UI/help/landing footer; `scripts/` encryption and key-rotation commands; `.env.example`; `database/hardening/tde.sql`; privacy/security tests | Implement versioned AES-256-GCM envelope encryption with per-document data keys; key ID and external master key; safe, resumable encryption of legacy rows; encrypted income bands; purpose-specific withdrawable consent, parent/guardian confirmation under 18, access audit, export/delete, retention and privacy notice. Add TDE and SQL TLS operational guidance without claiming database hardening has run. |
| **W6 — Provenance and trust layer** | `shared/trust/disclaimers.js`; server `withProvenance()` serializer; shared/front-end `ProvenanceBlock`; eligibility/funding/credit routes; freshness settings; contract tests | Every returned recommendation includes source title/URL/year/page reference, updated/verified fields, role-only reviewer display, conditions, status and stale-after threshold. Missing provenance prevents a record from being returned as a recommendation. |
| **W7 — Checklists, alerts and templates** | migration `006_vault_alerts_templates.sql`; `server/jobs/alerts.js`; mailer and scheduler entry points; learner dashboard/Vault UI; `public/templates/`; `scripts/` or npm alert runner; tests | Requirement-driven checklists track missing/uploaded/verified/expired documents. Idempotent in-app/email reminders at 14/7/3/1 days respect consent, mute state and Africa/Johannesburg time. Templates are informational, dated and explicitly not legal or funder-certified documents. |
| **W8 — Competitor comparison** | web-verified source log; `docs/competitor-analysis.md`; `docs/competitor-verification-checklist.md`; `public/compare.html`; migration `007_pilot_and_competitors.sql`; data-driven comparison API/UI; tests | Compare Careers Portal, ApplyNow and substantiated alternatives by sourced, dated claims. Any unverified feature/cost/privacy claim is labelled “Not verified”. The product’s narrower verified scope is described honestly. |
| **W9 — Pilot instrumentation** | migration `007_pilot_and_competitors.sql`; event services/routes; `public/admin/pilot.html` and script; survey components; CSV export; `docs/pilot-plan.md`; metric calculation tests | Track baseline vs StudyPath research time, suitability-guard outcomes, deadline actions and pre/post survey only for participants with research consent. Store a pseudonymous pilot code; isolate identity mapping; suppress dashboard cells below five participants. |
| **W10 — Quality/security/release engineering** | security/API/workflow tests; accessibility test helpers; CI/verification scripts; `package.json`; `docs/decisions.md`; `npm run verify`; performance/SQL tests | Retain original tests; target ≥200 passing tests including tenant boundaries, encryption/tamper/wrong-key, rotation/migration idempotency, wording, provenance, golden accuracy, What-If parity, alert idempotency, export/delete and accessibility. Verify CSP/security headers, CSRF, rate limits, SQL parameterization and no PII logs. Performance target <300 ms is measured only against a stated local SQL Server fixture. |
| **W11 — Documentation and handover** | `README.md`; `START-HERE.md`; `docs/release-notes-3.0.0.md`; security/POPIA, accuracy, verification, pilot, competitor, incident, ERD and demo documentation; `docs/build-status.md`; package version | Provide stepwise Windows/PowerShell and SSMS upgrade steps, verified command output, clear live-SQL status, an honest 5-minute demo, prioritised open items and version `3.0.0` only after acceptance criteria are met. |

## Database migration order

The academic database `VARSITYVAULT2` is a protected invariant and is not modified by these migrations.

1. `001_create_studypath_database.sql` — create `StudyPathPilot` and `sp` schema.
2. `002_trust_and_verification.sql` — sources, provenance, scoring-policy verification and sign-offs.
3. `003_funding.sql` — funders, opportunities, criteria and document requirements.
4. `004_credit_transfer.sql` — credit-transfer guidance.
5. `005_privacy.sql` — consents, encrypted financial-profile payloads, document access logs, data-subject requests and retention policy.
6. `006_vault_alerts_templates.sql` — deadline alerts, document templates and checklist items.
7. `007_pilot_and_competitors.sql` — pilot cohort/events/surveys and competitor evidence.
8. `008_feature_flags_and_views.sql` — feature flags, stale/provenance/pilot views and indexes.
9. `999_rollback.sql` — separately reviewed safe rollback, never touching `VARSITYVAULT2`.

Run migrations in order through SSMS or `scripts/migrate.ps1`. Re-run them to validate idempotency. Confirm all migrations against SQL Server 2019+ in a non-production database before a production upgrade; mocks and SQLite cannot prove T-SQL compatibility.

## Cross-cutting testing and release gates

- After each workstream: run the existing and new relevant tests; record commands, totals and failures. Do not mark a workstream complete when an environment blocker prevents its checks.
- Before release: `npm run format:check`, `npm run accuracy`, wording-lint, provenance contract suite and `npm run verify` must pass.
- Run schema contract/migration alignment tests and confirm the protected academic SQL checksum did not change.
- Validate sign-in, role boundaries, document access, email reminders and database migrations on a dedicated SQL Server test instance; record whether Windows authentication or SQL credentials were used.
- Perform manual keyboard/mobile checks and role-based smoke testing, then rehearse `docs/demo-script.md` on the running app.

## Risks and dependencies

| Risk | Mitigation / release rule |
|---|---|
| Baseline dependencies cannot currently install; runtime is below the `engines` range | Re-run baseline on Node.js 24.15+ or 26+ with complete npm access before treating test failures as code regressions or accepting changes. |
| Official prospectus examples and current rules are not available for every programme | Never infer requirements. Expose only programmes with source artefacts, dates, two sign-offs and passing golden tests. Capture missing inputs in `docs/open-items.md`. |
| Academic DB schema must remain immutable | Add separate StudyPath DB and contracts. Add byte/checksum guard tests and keep the original schema alignment tests passing. |
| Envelope encryption may encounter legacy plaintext, malformed or partially migrated blobs | Versioned format, dry-run, per-document rollback-safe transactions, resumable/idempotent migration, tamper and wrong-key tests, counts-only logs. Do not destroy legacy data on decryption failure. |
| Cross-database IDs are not foreign-key enforceable across separate databases | Validate ownership/tenant scope in application code and where possible with views/procedures; add cross-database contract tests. |
| Minors’ personal data, document access and household income pose high privacy risk | Separate purposes/consents, parent/guardian confirmation, minimal income band, encryption, short-lived downloads, restricted scopes, access logs and export/delete flows. Complete privacy/incident review before a real learner pilot. |
| Reminder jobs may duplicate, ignore withdrawals or use the wrong local time | Idempotency keys, consent checks at send time, learner timezone handling and tests for retries, mutes and deadline boundaries. |
| Small/self-selected pilot samples can mislead | Pre-register measurement method and sample limitations; suppress small cells; publish distributions and limitations, not unsupported causal claims. |
| Competitor features and costs change over time | Store URL and retrieval date for every claim; display “Not verified” if the claim could not be checked. |
| No live SQL Server access in the current execution environment | State this explicitly in each affected build-status section; do not claim SQL migrations, TDE, encryption-at-rest integration or performance were live-tested until they are. |

## Open items requiring team evidence

- Verified 2027 source documents/calculators and worked examples for enabled programmes at WSU, UFH and UJ, including page references and archived source copies.
- Two independent verification accounts/reviewers per enabled scoring policy.
- Approved funding source records and each programme’s exact funding criteria/deadline evidence.
- Receiving-institution credit-transfer/RPL policies and contact details.
- Configured Information Officer contact, retention defaults and approved privacy/consent language.
- SQL Server test instance access and approved operational account/TDE/backup configuration.
- Recruitment and parent/guardian workflow for learners under 18, plus pilot ethics/research approval as applicable.
