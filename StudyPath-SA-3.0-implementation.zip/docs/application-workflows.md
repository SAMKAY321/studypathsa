# Application workflows and feature coverage

## Learner journey

1. Create an account and verify the email address.
2. Maintain the personal profile and choose the relevant examination milestone.
3. Capture academic subjects and marks; save and revisit the results.
4. Upload required documents and review universities/programmes.
5. Check programme-specific conditions, application status and closing date.
6. Submit an eligible application and follow the dated history through teacher screening and institution decisions.

## Career Guidance Teacher journey

1. Sign in to the assigned school workspace.
2. Find learners within the school scope.
3. Review and verify results and required documents.
4. Screen submitted applications once the required evidence is verified.

## University Representative journey

1. Manage programmes/offerings and current requirements for the assigned university.
2. Upload and maintain prospectuses.
3. Review screened applications, evidence and verified academic results.
4. Record provisional/final decisions or revoke an offer where allowed by the workflow.

## IT Administrator journey

1. Set up staff accounts and role assignments.
2. Maintain school/university directory data, qualification offerings, requirements and authoritative sources.
3. Review audit events and account recovery controls.
4. Enable optional multi-factor authentication for administrator accounts.

## Guardrails

Access scope is checked on the server, not just hidden in the UI. A teacher cannot access learners outside their school; a university representative cannot act on another university's applications. Server validation rejects invalid/duplicate subjects, duplicate applications, missing mandatory documents, unverified results, invalid workflow transitions and submissions after the close date. Application changes are recorded in dated history and audit events.

Programme eligibility relies on the actual configured data for the active intake. Administrator-entered score thresholds, required subjects and official source URLs must be verified against current institution sources before use. Missing or unverified conditions intentionally block definitive eligibility claims.

## Validation boundaries

The automated tests target isolated test data and mocked/adapter-compatible data paths. They do not replace a live SQL Server read-only check and role-by-role smoke test. External university APIs, payment gateways and live admission decisions are not bundled.
