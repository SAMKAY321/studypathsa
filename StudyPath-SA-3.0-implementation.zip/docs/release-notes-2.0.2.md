# Varsity Vault 2.0.2 — result-saving fix

## Changes

- Changed result submission from delete-and-recreate to transactional reconciliation: existing rows are updated, newly added rows inserted, and removed subjects deleted individually.
- Kept result validation, verified-mark locking, learner scope checks, subject enrolments and audit writes inside the existing transaction.
- Added explicit client-side percentage validation before sending a save.
- Changed the learner Results page to re-read the selected exam milestone after PUT and compare persisted subject IDs/percentages with the submitted rows. The local draft is cleared only after the API confirms a matching save.
- Improved non-production API error logging so the VS Code terminal includes method/path, error code and message, while the browser continues to receive a generic safe message for server errors.
- Added an API regression assertion for updating an existing result row and reloading the persisted value.

## Verification

- JavaScript syntax checks pass for the changed files.
- Source schema alignment, scoring and workflow test groups pass in the available environment.
- The full API/interface suite could not be run here because npm dependency installation did not complete within the available execution window and the container Node.js version is 22.16.0, below the app's supported runtime.
- No connection to the user's SQL Server instance is available from this environment, so live database write verification remains outstanding.

## Applying the fix

Replace the user's project folder with this release (preserving their `.env`), install dependencies using Node.js 24.15+ in the 24.x line or Node.js 26+, restart the server, then retry **Save results**. If it still fails, the VS Code terminal now logs the underlying development error to identify the exact database-side cause.
