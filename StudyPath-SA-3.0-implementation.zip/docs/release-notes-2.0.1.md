# Varsity Vault 2.0.1 — source-schema alignment

## Source files

- Added the group-supplied `unilink_script_improved.sql` under `database/source/`, byte-for-byte unchanged.
- Added the group-submitted ERD PDF under `docs/source/`, byte-for-byte unchanged.

## Schema alignment

- Verified all 30 core table names and all 128 column names and SQL types against the supplied DDL.
- Reconciled the 42 declared foreign-key constraints to the ERD relationship inventory.
- Updated Mermaid cardinalities and generated ERD companion diagrams to reflect FK nullability and single-column uniqueness.
- Added `docs/source-schema-audit.md` with the object and FK inventory and updated the normalization and rubric evidence notes.
- Added source-alignment tests to prevent drift between the supplied DDL, `config/table-map.json`, `config/schema-contract.json` and the ERD relationship list.

## Verification

- All JavaScript source files passed syntax checks.
- Thirteen focused tests passed, including both new source-schema alignment tests.
- The full API/interface test suite and live SQL Server workflow were not verified in this packaging environment because the complete dependencies are not installed and the available Node.js version is below the project's declared runtime requirement.

## Scope

The source SQL and submitted ERD are included as references but were not modified. The app's authentication/session support remains in the separate `VarsityVaultSecurity` database defined by `database/security.sql`; it is not added to the core academic ERD.
