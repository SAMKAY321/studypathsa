# Competitor claims: verification checklist

As at 26 October 2026, do not market feature superiority based on the incomplete evidence below.

| Competitor/resource | Item to verify | Current status | Evidence/next action |
|---|---|---|---|
| Careers Portal | Current feature set, calculator availability, application portal status, prices (if any), accessibility, privacy/security posture, use of third-party funding links | Partially reviewed; detailed feature claims not verified | Re-check https://www.careersportal.co.za/ and https://www.careersportal.co.za/funding; record the exact page and retrieval date. |
| ApplyNow | Confirm official South African service identity/domain; determine product owner; verify application, APS, bursary, price, privacy and platform claims | Not verified | Identify authoritative official URL first. Do not assign features or use a lookalike service without identity confirmation. |
| Central Applications Office | Scope of participating institutions for the current intake, fees, application/document functions, accessibility and privacy materials | Basic official workflow reviewed; broader claims not verified | Re-check https://www.cao.ac.za and the current 2027 handbook; do not imply it covers WSU/UJ/UFH unless participating-institution source confirms it. |
| Walter Sisulu University | Current undergraduate admissions, programme rules, programme-specific subject requirements, dates and official worked examples | Official application process page found; programme-level golden fixtures not loaded | https://wsu.ac.za/index.php/en/study-with-us/application-and-registration/how-to-apply-the-process |
| University of Fort Hare | Current undergraduate admissions, course-specific rules, published APS calculator result examples | Admissions page found; programme-level golden fixtures not loaded | https://www.ufh.ac.za/admission |
| University of Johannesburg | Official 2027 programme guide(s), scoring method, calculator/calculation examples, rule version/date | Not yet captured into pilot ledger | Admissions verification team must supply source PDFs/pages, retrieved date, archive hash and golden outputs. |

For each competitor feature add one `sp.CompetitorFeature` row with a carefully worded observation, a status (`verified` or `not-verified`), and a `sp.CompetitorEvidence` record containing exact `SourceTitle`, `SourceUrl`, `RetrievedOn` and notes. Record the reviewing staff member in an operational change log if an accountable reviewer column is added. A website home page alone is not sufficient evidence for privacy, security, price or unsupported feature claims.
