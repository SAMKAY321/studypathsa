# StudyPath SA security, privacy and POPIA implementation notes

**Status:** implementation guidance for the 3.0 pilot; this is not a legal opinion or a compliance certification. Reviewed 26 October 2026.

## Data-flow and storage boundaries

The browser talks only to the Express API. The application uses the existing `VARSITYVAULT2` academic database and a separate `StudyPathPilot` database for new trust, funding, privacy and research tables. The submitted academic schema is intentionally not changed. Local mode uses SQLite for development/demo only; production must use SQL Server and the configured Windows/service identity or least-privilege SQL login.

### Documents at rest

`server/vault-crypto.js` uses AES-256-GCM with a random 32-byte data-encryption key per document. Document content is encrypted with the data key; the data key is separately wrapped with the master key. The existing `DOCUMENTS.DOCUMENT_BLOB VARBINARY(MAX)` column stores a versioned binary envelope with IVs, authentication tags, key ID and ciphertext. A tampered blob or unavailable key fails decryption. Legacy plaintext rows are detected as legacy by the migration utility and must be migrated before calling the system production-ready.

Set `VAULT_MASTER_KEY` to base64-encoded 32 random bytes from a secret manager or protected environment variable. Set `VAULT_KEY_ID` to a stable rotation identifier. During rotation, retain old keys in `VAULT_PREVIOUS_MASTER_KEYS` as a JSON object mapping previous key IDs to base64 keys until all envelopes have been rewrapped and tested. Never place keys in the repository, web root, logs, issue tracker or exported learner data. The production server validates the key at startup.

PowerShell operator workflow (from the project root):

```powershell
# Review a dry-run first; no document bytes are logged.
npm run vault:encrypt-existing -- --dry-run
# Migrate legacy plaintext rows after backup and approval.
npm run vault:encrypt-existing
# Configure a new master key and key ID, keep the old key in VAULT_PREVIOUS_MASTER_KEYS,
# then re-wrap each encrypted document's data key.
npm run vault:rotate-key
```

A rotation operation is not a substitute for a tested recovery backup. Make a protected database backup before bulk encryption or key rotation and verify restore/decrypt against a non-production copy. Rotation cannot recover documents when all wrapping keys have been lost.

### SQL Server hardening

`database/hardening/tde.sql` is an optional SSMS script to be reviewed and run by a SQL Server sysadmin; it is not run automatically by this application. Production configuration should use `Encrypt=yes` and certificate validation (`DB_TRUST_SERVER_CERTIFICATE=false`) with a certificate trusted by the host. Use least-privilege database users, separate credentials for app and migration tasks, encrypted backups, controlled backup retention and tested restore procedures. Do not run the application as `sysadmin` or `db_owner`. Ensure the application login can write only the objects it requires.

The existing `database/security.sql` and the new numbered `database/migrations/*.sql` must be applied to the intended SQL Server instance using a reviewed operational change. The migrations are designed for SQL Server 2019+ and should be applied by `scripts/migrate.ps1`; they have **not been tested against a live SQL Server in this work session**.

## Consent and learner age

New personal-data purposes are recorded separately in `sp.Consent` with a policy version and grant/withdraw timestamps: result processing, funding matching, school/institution sharing, pilot research, email reminders and document processing. Features read the relevant purpose-specific consent; withdrawal must not be inferred from consent to another purpose. Pilot-research events should be emitted only for participants with research consent.

The current implementation stores an age attestation and a guardian-confirmation flag and blocks selected finance/document features when the under-18 consent conditions are not recorded. The flag is a **recorded confirmation, not identity verification**. Before onboarding real minors, the organisation must approve and implement a reliable parent/guardian identity and relationship verification flow, evidence-retention period, safeguarding escalation and withdrawal process. Do not treat a learner's self-set flag as verified guardian identity.

## Household income

The UI collects an income **band**, not an exact amount. The financial profile is encrypted as an application-level AES-256-GCM envelope in `sp.LearnerFinancialProfile`. Access requires the funding-matching consent. Do not place income, identity numbers, marks tied to named learners or raw documents in analytics, URLs, application logs or crash reports. The profile JSON should remain limited to the matching fields the user supplied.

## Access logging, export, deletion and retention

Document downloads are authenticated, authorisation-checked, served as attachments and use `Cache-Control: no-store`. Download events record the document ID, accessor, timestamp, role and purpose without recording content. The application must preserve the existing tenant/school/university scope and only share documents where the consent purpose permits it.

Learners can request an export; the endpoint returns their learner-specific JSON and document bytes. The delete request enters a 30-day cooling-off window and can be cancelled before the scheduled date. `npm run privacy:process-deletions` processes due deletion jobs. The job attempts to remove the user's application/results/documents/account records and pseudonymise the relevant audit and consent records. Because academic and privacy data live in separate databases, deletion cannot be one atomic cross-database SQL transaction. Failed requests are marked for operator reconciliation; an administrator must check both databases and re-run only after reconciling the partial outcome. The operator log must not expose names, ID numbers or data content.

Initial retention rows are operational defaults, not legal determinations: inactive accounts 730 days; expired documents 365 days. The retention scheduler, legal holds, retention exemptions and final period require approval by the organisation's Information Officer before production use. Publish the approved Information Officer contact through configuration and the privacy notice.

## Malware and upload handling

Uploads are restricted by the existing size/content-type checks and document magic-byte validation, filename sanitisation and authenticated route. `CLAMAV_ENABLED=false` is the default; ClamAV is not an active malware scan until a reviewed hook and a real scanner are configured and tested. Do not state that uploads are antivirus-scanned when the flag is disabled.

## Incident response readiness

Follow `docs/incident-response.md` for containment, investigation, evidence preservation and notification assessment. The Information Officer and legal/privacy lead must decide notification obligations based on the actual incident and applicable law. This implementation does not itself certify POPIA compliance.

## Before production

- Run tests and formatting on the declared Node runtime (Node 24.15+ or 26+).
- Apply migrations to a disposable SQL Server first; verify re-run idempotency, rollback, indexes and permissions.
- Set and back up vault keys securely; encrypt all existing document rows and prove authenticated decrypt/restore.
- Test tenant boundaries, consent withdrawal, export and deletion on anonymised test data.
- Verify parent/guardian identity flow, Information Officer details, retention defaults and final notices with accountable owners.
- Enable ClamAV only after integration testing; confirm TLS, TDE, backup encryption and restore.
