# W0 baseline — StudyPath SA

**Assessment date:** 26 October 2026  
**Input archive:** `varsity-vault-v2.1.1.zip`  
**Build prompt:** `StudyPath-SA-build-prompt.md`

## Existing application baseline

The supplied application is inherited from Varsity Vault 2.1.1 and is being rebranded as StudyPath SA, an ES-module Node.js/Express application with static HTML/CSS/vanilla JavaScript, shared scoring/workflow modules, and Microsoft SQL Server persistence. A local SQLite mode is available for isolated demonstration/tests. Existing access-control, session, account verification/recovery, auditing, optional administrator MFA, role workspaces, application workflow and programme-specific scoring should be extended rather than replaced.

The main academic schema is provided by `database/source/unilink_script_improved.sql` and documented by `config/schema-contract.json` and the ERD/data-dictionary documents. The build prompt requires this source SQL and its 30-table contract to remain unchanged. Existing application-security objects are separate in `database/security.sql` / `VarsityVaultSecurity`.

## Environment and commands

| Check | Result | Evidence / limitation |
|---|---|---|
| Runtime | **Blocked by runtime mismatch** | Available Node.js is `v22.16.0`; `package.json` requires Node `^24.15.0 || >=26.0.0`. |
| `npm ci` | **Did not complete** | Attempted twice, including `--prefer-offline`; both attempts exceeded the execution time limit. npm emitted `EBADENGINE` warnings and left `node_modules` incomplete. |
| `npm test` (pre-W0) | **41 passed, 3 failed** | The failures were test-file load failures because dependencies were incomplete: `express`, `jsdom`, and `nodemailer` were missing their package entry points. Node reported 44 top-level test entries. |
| `npm test` (after W0) | **43 passed, 3 failed** | The same three test files fail to load because the dependencies remain incomplete. The two new rebrand tests pass when run independently. The full run had 46 top-level test entries. |
| `npm run format:check` | **Could not run** | The command exits with `prettier: not found`, consistent with incomplete dependency installation. |
| Live SQL Server | **Not tested** | No live SQL Server connection was attempted. The supplied academic SQL file SHA-256 after W0 edits is `77a006020a9ec2242acc22ae3d1644d19ffb8ba45c6f60bc7597e58b3924de1e`; it is expected to match the source archive because it was not edited. Existing build-status documentation says previous tests used isolated SQLite/test data and SQL Server adapter mocks. |
| Browser visual inspection | **Not tested** | No real desktop/mobile browser review was performed during W0. Existing build-status notes say a previous Chromium download failed. |

### Reproducible next baseline step

Run these commands from PowerShell on a machine with Node.js 24.15+ (or Node.js 26+) and working npm registry access:

```powershell
node --version
npm ci
npm test
npm run format:check
```

Record the new output here before declaring the baseline clean. Do not reinterpret the partial run above as a pass.

## Known starting limitations from the supplied code/docs

- Funding matching, household income capture, credit-transfer guidance, deadline alerts/templates, What-If simulation, per-recommendation provenance, verification-ledger workflow, pilot instrumentation, encryption of uploaded documents, consent records and POPIA self-service are not present as complete end-to-end workstreams in the supplied baseline.
- Documents are stored in `DOCUMENTS.DOCUMENT_BLOB VARBINARY(MAX)` and were documented as unencrypted at rest at application level.
- Programme thresholds and admissions data are staff-maintained; the current app does not automatically certify that prospectus rules are current or accurate.
- The supplied build prompt says current 2027 prospectus content must not be invented. Data that is not verified from attributable institutional sources must remain unverified.
