# StudyPath SA 3.0.0 — implementation release notes

**Build date:** 26 October 2026. This is an implementation-stage release, not a production certification. Read `docs/build-status.md` and `docs/open-items.md` before installation.

## Product changes

- Rebranded user-facing content to StudyPath SA while preserving internal Varsity Vault/database identifiers.
- Restricted the new pilot pathways to undergraduate WSU, UFH and UJ scope; postgraduate matching is disabled.
- Added a new `StudyPathPilot` operational database with numbered SSMS migrations, source provenance, two-reviewer verification ledger, funding, credit-transfer guidance, consent, financial profile, deadline alerts, templates, pilot measurement and competitor evidence tables.
- Added a fail-closed provenance serializer and API surfaces for programme status, What-If, funding matching, credit-transfer guidance and “why am I seeing this?” style provenance.
- Added a source evidence upload with SHA-256, CSV dry-run import flows for programme/funding records, idempotent record updates and status gates so CSVs cannot sign off a rule.
- Added document encryption using AES-256-GCM and envelope keys, existing-row migration/key rewrap commands, download access logs and no-store download responses.
- Added purpose-specific consent records, age/guardian flags, income-band encryption, learner export/delete request paths and a delayed deletion job.
- Added deadline/checklist/template features, idempotent reminder processing, What-If UI/endpoint, application unsuitability acknowledgement logging, pilot cohort tasks/survey/dashboard/export with minimum-cell suppression, and a data-driven comparator page.
- Added trust, security, POPIA, incident response, data-verification, competitor-review and pilot-process documentation.

## Validation boundary

New focused trust/encryption/operational tests are run separately from the full suite. In the working environment for this build, Node 22.16.0 is installed although the project requires Node 24.15+ or 26+, and dependency installation did not complete. The complete Express/jsdom/Nodemailer suite and formatting check therefore cannot be represented as green. No live SQL Server migration, route integration, guardian identity, or production vault recovery test was run. See `docs/baseline.md` and `docs/build-status.md`.

## Data deliberately not supplied

No institution 2027 scoring golden fixtures are fabricated. WSU/UFH/UJ programmes remain unverified until official source documents/calculator outputs are archived, their rules are reviewed by two different accounts and exact fixtures pass. No funding opportunity is pre-seeded as a verified actionable recommendation. Careers Portal and ApplyNow feature claims remain `not-verified` in the data store unless a reviewer adds evidence.

## Operational caution

Back up databases before applying migrations, encrypting legacy documents or rotating keys. The academic source SQL is preserved; new schema belongs only to `StudyPathPilot`. A live release requires Node runtime alignment, all dependencies, successful full tests and formatting, verified source data, real SQL Server migration/idempotency validation, approved guardian workflow, Information Officer details and security hardening.
