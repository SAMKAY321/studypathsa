# StudyPath SA learner pilot plan

**Purpose:** test whether the prototype reduces research time, prevents unsuitable applications and helps learners track deadlines. Planned pilot; no outcome claims are made by this document.

## Questions and measures

1. **Research time:** compare the time to find the learner's potentially eligible courses from official WSU, UFH and UJ sources with time-to-first-list in StudyPath. Record seconds and number of courses listed for baseline and tool task. Report median, interquartile range and each task's completion count.
2. **Unsuitable choices:** capture the learner's intended programme list before the tool, every subject-requirement guard shown, and their self-reported outcome (continue after acknowledgement, change course, or cancel). The guard count alone is not proof an unsuitable application was prevented; compare to intended choices and report each outcome category.
3. **Deadlines:** report alerts scheduled/sent, click/open where available, completed checklist/application actions before closing, and missed deadlines. Collect a baseline answer on deadlines missed in the prior year.

## Recruitment and consent

Recruit learners with a participating school/teacher and approved admissions/pilot contact. Obtain the required research consent before recording a participant event. Minors require the organisation-approved parent/guardian consent process and applicable safeguarding/ethics approval before participation. The current app's guardian flag records an attestation but does not verify identity, so do not enrol minors in a live research study until that gap is closed. Participation must be voluntary and must not affect school or admission outcomes. Explain the purpose, fields recorded, retention, withdrawal, privacy contact and limits of a small self-selected sample.

## Suggested task script

1. Read the participant information and confirm the required consents.
2. Ask participant to begin the baseline timer, then find potentially qualifying undergraduate courses on the official university sites/prospectuses. Stop at a fixed agreed time or when the participant reports completion; record elapsed time, courses found and task completion.
3. The participant enters their marks in StudyPath once. Show only supported statuses, including “Not yet verified” where appropriate. Do not imply that the current pilot has all verified programme rules.
4. Complete the equivalent task in StudyPath. Record time-to-first-list and number of relevant results, then run a clearly labelled hypothetical What-If and observe any subject warning/acknowledgement.
5. Ask participant to review the document checklist and deadline panel using non-sensitive demo items if live evidence is not required. Avoid collecting real ID or income during usability testing unless the relevant approved consent and security conditions are active.
6. Complete pre/post survey, allow free-text comment, and debrief participants about indicative results and verification limitations.

## Sample size and interpretation

Choose the sample size with the pilot/research owner before recruitment. For a small formative pilot, report the number invited, enrolled, completed, and excluded with reasons. Treat differences as descriptive, not causal or generalisable to all South African learners. Report missing tasks, outliers, self-selection and any service outages. Do not publish identifiable quotes or small-cell cohorts.

## Data minimisation and dashboard

Use random `PilotCode` values; do not include names, email addresses, identity numbers, exact income, document contents or free-text PII in event metadata/CSV exports. Keep the person-to-pilot mapping access restricted. Dashboard and export suppress groups with fewer than five participants. Survey free text must be reviewed for accidental identifiers before inclusion in a report. Stop collection if consent or access-control checks fail.

## Reporting template

- Cohort/recruitment dates and consent method:
- Invited / enrolled / baseline complete / tool task complete:
- Research-time baseline median and spread; StudyPath median and spread; paired difference:
- Courses found in baseline vs StudyPath, with definition of “found”:
- Guards shown; continued/changed/cancelled; intended-but-unsuitable count:
- Alerts delivered/opened; actions completed before deadline; missed deadlines:
- Survey completion, confidence/clarity/usability change:
- Technical failures, missing data, sample limitations and adverse events:
- What changed next and what remains unproven:

No participant results are present in the initial release; the dashboard should be empty until an approved, consented pilot takes place.
