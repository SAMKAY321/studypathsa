# Presentation and live demonstration plan

Use the group's real configured SQL Server data. Avoid fabricated thresholds or rows that could make an eligibility outcome misleading. This runbook is organized around the rubric's emphasis on ERD/database alignment and UI/database integration. Suggested split for two presenters; adjust to the actual team size and each person's real contribution.

## Suggested speaking split

### Presenter A — design and database (about half the explanation)

1. State the problem Varsity Vault solves and the four user roles.
2. Walk through `docs/erd.md`: start with `PERSONS` and role tables, then the school/university directory, offered qualifications, requirements, learner results, documents and application history.
3. Explain cardinalities and show matching PK/FK constraints in the submitted SQL Server DDL/SSMS. Clearly distinguish physical constraints from logical joins if any relationship is not enforced by a DB FK.
4. Explain normalization using `docs/normalization-review.md`: central lookup tables, person/role separation, the `LEARNER_RESULTS` composite key, offering/requirement separation, and application process history.

### Presenter B — application behavior and integration

1. Sign in as a learner; enter valid marks for the correct exam milestone, save, reload, and show the values persisted.
2. Upload required documents and show their verification state.
3. Switch to the school-scoped teacher account; inspect the assigned learner and verify the saved evidence. Show that an unrelated school's learner is not visible.
4. Return as learner; open configured programme requirements, review eligibility, submit an application only if eligible and required evidence is complete, then open the dated history.
5. Switch to the teacher for screening, then the assigned university representative for a provisional decision with a reason. Return to the learner and show the updated status/history after reload.
6. Show administration directory/account scope and audit history. Demonstrate one blocked invalid input, incomplete submission or unauthorized record access.

## Live checks that matter

- **Persistence:** refresh the page after each key write and confirm data remains.
- **Validation:** a percentage outside 0–100 and an incomplete application must not be accepted.
- **Workflow:** statuses move only through allowed stages, with actor/time/history recorded.
- **Access scope:** teachers only access their school, and university representatives only access their assigned university.
- **Database integration:** keep SQL Server available during the demo; do not use a mock/local fallback and describe it as SQL Server.
- **Real policy data:** show the source used for configured programme requirements. Do not fabricate a threshold to force an acceptance.

## Keep ready before the presentation

- Working SQL Server connection and the actual database script.
- One test learner, one school-scoped teacher, one representative, and one administrator account.
- One programme offering with verified official requirements and a future/current closing date.
- A learner with complete documents and marks that give a meaningful valid outcome; a second invalid/incomplete example.
- `docs/erd.md`, `docs/schema-data-dictionary.md`, `docs/normalization-review.md`, and `docs/rubric-alignment.md` opened in VS Code.
- Passing test output from the supported Node.js runtime and a successful `npm run db:check` from the real database.

## Honesty during Q&A

The supplied DDL declares 42 foreign-key constraints; the source audit lists each constraint and its cardinality basis. Distinguish that script-level evidence from the live SQL Server instance: do not claim the live database was tested solely because static checks or unit tests passed. If a rubric item is implemented at application level rather than by a database constraint, state that distinction and explain the trade-off.
