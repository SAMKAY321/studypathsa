# StudyPath SA admissions and funding data verification process

**Scope:** 2027 undergraduate pilot at WSU, UFH and UJ only. This process defines how evidence can become eligible for display; it does not itself verify programme requirements. Updated 26 October 2026.

## Allowed statuses

- `draft`: imported or proposed; never shown as a verified recommendation.
- `verified`: complete provenance, an intact archived source and two independent administrator sign-offs; for programme rules, the API also requires the configured intake and passing accuracy fixtures.
- `stale`: source freshness threshold passed; recommendations are demoted and must be checked again.
- `closed`: removed from the current actionable scope or the published opportunity is closed.

## Evidence capture

1. Select an official institution/funder URL; do not rely on unofficial reposts for the authoritative rule unless the institution explicitly identifies that resource as the source.
2. Record exact title, document year/cycle, relevant page/section or calculator version, retrieval date, last-updated/verified date, URL, conditions and known constraints.
3. Upload the PDF or captured evidence through the authenticated evidence upload endpoint. The server validates PDF magic bytes, imposes size limits, stores the archived file outside the public root and returns a SHA-256 content hash and archive path. Hash verification alone does not prove the source is authoritative; the reviewers must inspect the content.
4. Create the rule as `draft` with machine-readable requirements. Do not fill a requirement with a plausible threshold to make a programme appear complete. Keep uncertainty, alternative qualification routes, subject equivalence, Life Orientation treatment, weighted subjects, extra documents and dates explicit.
5. A reviewer with appropriate admissions/funding responsibility checks the source and enters a sign-off with notes. A second reviewer using a different account independently repeats the check. A second click by the same account is rejected. Representatives may propose changes; only an authorised administrator can approve them in this pilot.
6. Re-check archive hash, source dates, required fields and conditions before status transition. The database trigger rejects a verified programme without provenance and two distinct approvals.
7. Build sourced golden test cases for boundary values and official worked examples/calculator outputs. Store the specific source with each case. Tests must compare exact score and outcome, plus deterministic/monotonic/order-independence properties. Do not use generated expectations as “institution-verified” fixtures.
8. Publish only the API result. If a source is missing, stale, incomplete or conflicting, show `Not yet verified` or `Cannot confirm — see institution`, not a recommendation.

## Freshness and re-verification

Programme provenance expires after 180 days by default; funding opportunities expire after 90 days. Review sooner when the institution publishes a changed prospectus, requirements page, correction, deadline, or funder criteria. Re-verification captures a new retrieval/update date and content hash and requires the correct review workflow. The staleness job demotes old records. Confirm programme intake/year on every cycle; a prior year's rule is not proof for 2027.

## Imports

Use `database/import/pilot-programmes.template.csv` and `database/import/funding.template.csv`. Dry-run imports first and review the row-by-row diff. Programme CSV rows must identify the archive file returned by evidence upload and its exact content hash; reviewer columns in a CSV do **not** count as sign-offs. Funding imports do not become verified by CSV; they remain `draft` until an authorised reviewer checks source/conditions/criteria and changes status through the admin workflow. Imports must be repeatable without duplicating the same institution/programme or funder opportunity.

## Golden test coverage

For each institution aim for at least 25 source-backed cases covering all boundary bands, LO handling, HL/FAL equivalence, Mathematics/Mathematical Literacy/Technical Mathematics, weighted subjects, fewer than six subjects, duplicate rows, 0 and 100 percent, and best-six selection as appropriate to that institution's own rules. If the official source does not document one case or the programme is not in scope, do not invent a golden result. Record test gaps in `docs/accuracy-report.md`.

## Current verified scope

No programme-level golden examples are seeded in the delivered package. Therefore WSU, UFH and UJ may appear as pilot institutions, but all programme outcomes must remain `Not yet verified` until the evidence workflow and golden suite have been completed by the admissions verification team. This is deliberate, not an indication that the institutions lack programmes.
