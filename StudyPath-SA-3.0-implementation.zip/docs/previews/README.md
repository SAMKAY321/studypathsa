# Varsity Vault previews

The screenshots in this folder belonged to the 1.0.0 blue-and-gold interface and have been removed so they are not mistaken for the current design. The current interface is in `public/`; run `npm ci` and `npm start` to preview it at `http://127.0.0.1:3000`.

Fresh desktop and mobile captures could not be rendered in the release environment: its cached Chromium binary crashes, and the Playwright browser download returned a truncated archive. The interface checks cover the updated screens and responsive rules, but this folder will need new browser captures when a working Chromium runtime is available.
