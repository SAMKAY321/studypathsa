# Whole-application audit — Varsity Vault 2.0.5

## Scope

Reviewed the four role workspaces (learner, career guidance teacher, university representative and IT administrator), API routes, result/eligibility workflow, database adapter boundaries, lookup/reference data, document upload/download paths, account security and project setup instructions.

## Corrections

1. **Required study mode data:** the submitted `unilink_script_improved.sql` creates `STUDY_MODES` but does not seed it. The app needs that lookup for application submission. Startup now idempotently inserts only the missing `Full-time` and `Part-time` values. No institution/programme/person data is fabricated.
2. **Empty study-mode UI:** requirements now shows a visible placeholder and a clear configuration warning rather than an empty select. Submit handlers validate the selected mode.
3. **Database identifier normalization:** server joins and scope/status decisions now use the shared `sameId` helper where SQL INT values could be returned as numbers or numeric strings. This complements the results-to-subject join fix in 2.0.4.
4. **Destructive empty result save:** the API rejects an empty result array before any rows can be removed. A regression is added to confirm existing results remain intact.

## Validation performed here

- `node --check` completed successfully across JavaScript under `server/`, `shared/`, `public/assets/js/` and `tests/`.
- A local resource audit checked all 39 HTML pages and 4 CSS files; no broken local page, script, stylesheet, or image references were found.
- 37 standalone test cases passed in the available run, including a new check of all local HTML/CSS asset references. A mailer test suite could not load because `nodemailer` was absent after dependency installation timed out.
- The initial full `node --test` run was blocked by incomplete packages (`express`, `jsdom`, `nodemailer`). Therefore the full HTTP lifecycle/API and real DOM suite has not been certified in this environment.
- Live SQL Server persistence, SQL Server security database permissions, and the four role workflows have not been exercised against the user's configured instance.

## Required release smoke test

After running `npm ci` on supported Node.js, run `npm test` and `npm run db:check`. Then verify:

- Learner: sign in, save/reload marks for each exam milestone, confirm APS, upload/download mandatory documents, choose Full-time or Part-time and submit an eligible application.
- Teacher: only see school-scoped learners; verify/reject marks and documents; screen a complete application only after required evidence is verified.
- University representative: see only assigned university applications, review evidence and perform allowed decision transitions.
- IT administrator: maintain accounts/directories/requirements and inspect the audit log.
- Confirm result marks, document metadata/blob, application status and application timeline persist after server restart.

The audit report deliberately distinguishes code-level/isolated test results from live database certification.
