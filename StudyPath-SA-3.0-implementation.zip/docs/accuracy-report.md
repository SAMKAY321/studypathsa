# StudyPath SA scoring accuracy report

Generated: 2026-10-26T21:45:08.698Z

**Overall status: blocked-unverified.** 0/0 golden cases passed.

An institution-level source is required, every case must identify its programme and source, exact expected outputs must match, and each programme must have at least 25 source-backed cases for the release gate. A missing fixture or source is not a pass. No 2027 requirements are inferred.

| Institution | Golden cases | Passed | Pass rate | Programme coverage | Source | Release gate |
|---|---:|---:|---:|---|---|---|
| WSU | 0 | 0 | N/A | Missing programme cases | Missing source metadata | BLOCKED |
| UFH | 0 | 0 | N/A | Missing programme cases | Missing source metadata | BLOCKED |
| UJ | 0 | 0 | N/A | Missing programme cases | Missing source metadata | BLOCKED |

## Open discrepancies

- **WSU**: No official worked examples or calculator results imported. Admissions reviewers must provide rule sources, archived examples, page references, retrieval date and expected calculation results.
- **UFH**: No official worked examples or calculator results imported. Admissions reviewers must provide rule sources, archived examples, page references, retrieval date and expected calculation results.
- **UJ**: No official worked examples or calculator results imported. Admissions reviewers must provide rule sources, archived examples, page references, retrieval date and expected calculation results.

## Interpretation

A 100% rate is meaningful only for a non-empty, per-programme golden suite with official sources and at least 25 exact passing cases per programme. Empty suites are deliberately blocked, not reported as accurate. The status in this report is one of the server-side gates for enabling a programme.
