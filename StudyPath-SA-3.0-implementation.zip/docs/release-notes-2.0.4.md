# Release notes — 2.0.4

## Fix: saved marks now retain subject metadata in requirements review

The results read path previously joined saved `LEARNER_RESULTS` rows to the `SUBJECTS` catalogue using strict JavaScript identifier equality. If one adapter returned an ID as a number and another as a numeric string, saved rows loaded without `SUBJECT_NAME`, `SUBJECT_CODE`, or `SUBJECT_CATEGORY`. The Requirements page's curriculum check consequently rejected the records and rendered an empty contribution table even though the save route had accepted the marks.

The `attachSubjectsToResults` helper now normalizes ID values before joining. It preserves saved mark/status values, enriches records with current catalogue metadata, and uses an explicit diagnostic label if a result references a subject that no longer exists in the catalogue.

A regression test uses the seven marks from the reported case and confirms the rows satisfy the curriculum rules and calculate an APS of 33/42 (six academic subjects, excluding Life Orientation). This is an isolated code-level test; a live SQL Server smoke test must still be performed in the user's environment.
