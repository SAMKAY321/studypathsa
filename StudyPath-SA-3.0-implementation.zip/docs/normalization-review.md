# Normalization review and design rationale

## Purpose and basis

This review is grounded in the group-supplied `database/source/unilink_script_improved.sql` and ERD PDF at `docs/source/Group 3 - Kagiso Mathabathe & Mantoa Moletsane VarsityVault ERD.pdf`. The script declares 30 core tables, 128 columns and 42 foreign-key constraints. `config/table-map.json` matches all supplied table/column names and SQL types. This is a static source review, not a live check against a running SQL Server instance.

## First Normal Form (1NF)

A relation satisfies 1NF when each field stores one value for the row and repeated groups are represented by separate rows rather than repeating columns. The contract generally follows this pattern:

- `PERSONS` stores one person's contact/identity attributes per row.
- `LEARNER_RESULTS` stores each learner/subject/exam-milestone result as its own row rather than a set of repeated `SUBJECT_1`, `SUBJECT_2`, etc. columns.
- `APPLICATION_PROCESSES` stores each dated workflow event as a separate row.
- `DOCUMENTS` represents each uploaded document separately, with its document type and verification information.

When explaining 1NF, use actual column examples from the database script and confirm that any multi-value content is not stored as comma-delimited text.

## Second Normal Form (2NF)

2NF requires 1NF and that each non-key attribute depends on the whole candidate key, not only part of a composite key.

- `LEARNER_RESULTS` has a composite primary key of `(LEARNER_ID, SUBJECT_ID, EXAM_TYPE_ID)`. `PERCENTAGE` and the verification fields describe the result for that precise learner/subject/exam combination; they should not depend on only one part of the key.
- Other tables use a single-column key such as `APPLICATION_ID`, `PERSON_ID`, `DOCUMENT_ID`, or `UNI_QUAL_ID`, making partial-key dependency less likely. Additional candidate keys are enforced where the submitted DDL explicitly declares them.
- `LEARNER_SUBJECTS` uses `LEARNER_SUBJECT_ID` as its declared primary key and also declares `UNIQUE (LEARNER_ID, SUBJECT_ID)`, preventing duplicate learner/subject pairs at the database level.

## Third Normal Form (3NF)

3NF requires 2NF and discourages non-key attributes depending transitively on another non-key attribute.

- Reference names are separated into lookup entities such as `PROVINCES`, `CITIES`, `APPLICATION_STATUSES`, `VERIFICATION_STATUSES`, `DOCUMENT_TYPES`, `STUDY_MODES`, `EXAM_TYPES`, and `ACTIONS`. Transaction records store IDs rather than duplicating lookup descriptions.
- Shared person attributes are in `PERSONS`; role-specific fields live in `LEARNERS`, `TEACHERS`, `ITADMINS`, and `UNIVERSITY_REPS`.
- `PROGRAMS` and `QUALIFICATIONS` are separated, with `QUALIFICATIONS.PROGRAM_ID` linking a qualification to its programme.
- `UNI_QUALIFICATIONS` separates an institution's offered qualification from the general qualification definition and stores per-offering data such as closing dates.
- `QUALIFICATION_REQUIREMENTS` separates selection criteria from the offering itself and supports explicit requirement records.

## Strengths to explain in the presentation

1. Lookup values are maintained centrally, improving consistency in statuses and categories.
2. The application history is separate from the current application status, preserving multiple dated workflow events.
3. The composite key on `LEARNER_RESULTS` prevents duplicate rows for the same learner, subject and exam milestone at the key level.
4. University offerings and their requirements are modelled separately from general qualification definitions.
5. Role data is separated from shared personal details.

## Observed design trade-offs and risks

The following points are grounded in the supplied DDL; they are not instructions to change the submitted schema without group approval:

- **School location:** `SCHOOLS` contains both `CITY_ID` and `PROVINCE_ID`, while `CITIES` stores only `CITY_ID` and `CITY_NAME`. This allows direct province filtering, but the schema does not itself enforce which province a city belongs to.
- **Address design:** `PERSON_ADDRESSES` and `UNIVERSITY_ADDRESSES` repeat address structure. This may be intentional because they have different owner types and constraints; document the reason rather than changing the submitted schema late.
- **Document storage:** `DOCUMENTS.DOCUMENT_BLOB` places binary file content in the database contract. Explain the trade-off between database-integrated backup/security and storage/database size.
- **Date text columns:** the submitted DDL explicitly stores `APPLICATION_DATE`, `REVIEW_DATE`, `PROSPECTUS_DATE`, `ACTION_DATE`, `UPLOAD_DATE`, `VERIFIED_DATE` and `ENROLLMENT_DATE` as `VARCHAR`. This can make chronological sorting and validation less robust than date/time types; the app keeps the supplied schema unchanged.
- **Duplicate prevention:** verify unique constraints for `PERSONS.EMAIL`, `PERSONS.USERNAME`, `SCHOOLS.EMIS_NUMBER`, role subtype `PERSON_ID` values, and the `(LEARNER_ID, SUBJECT_ID)` learner-subject pair if required by the business rules.
- **Repeated requirements:** confirm whether each `UNI_QUALIFICATIONS` offering has one requirements row or many. Cardinality should match the intended policy model.

## Suggested evidence for 10 normalization marks

Show one concrete example from the submitted SQL script for each normal form, identify the primary key, name a functional dependency (for example `PERSON_ID -> FIRST_NAME, LAST_NAME, EMAIL`), and explain why the separate lookup / bridge / history tables reduce duplicated facts. State the actual constraints rather than assuming a column with an `_ID` suffix is automatically a foreign key.
