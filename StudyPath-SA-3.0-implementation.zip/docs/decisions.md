# Architecture decision log — StudyPath SA

This file records decisions for the StudyPath SA 3.0 production workstream. Entries are updated as implementation evidence arrives.

## ADR-001 — Extend the current application instead of rewriting it

- **Status:** Accepted
- **Context:** The supplied codebase already contains learner/teacher/representative/admin workflows, role and tenant checks, SQL Server/SQLite storage adapters, shared scoring logic, account security and a substantial test suite.
- **Decision:** Keep HTML, CSS, vanilla browser JavaScript, Node.js ES modules and Express. Extend existing route registration, storage adapters and shared pure functions. Do not introduce a frontend framework, bundler or runtime dependency without a documented reason.
- **Consequences:** Lower migration risk and preserves existing workflow conventions; new features must fit the present architecture and tests.

## ADR-002 — Preserve the academic source schema and create a separate StudyPath database

- **Status:** Accepted
- **Context:** `database/source/unilink_script_improved.sql` and its 30-table ERD are a fixed academic-schema deliverable. StudyPath requires additional trust, funding, privacy, alerts, pilot and competitor records.
- **Decision:** Do not edit the academic SQL/ERD. Add a separate `StudyPathPilot` database with `sp` schema and numbered, idempotent SQL Server migrations. Retain `VarsityVaultSecurity` for current authentication/session support unless a later reviewed migration explicitly says otherwise.
- **Consequences:** Same-instance cross-database relationships require application-level ID/tenant validation; the academic source-schema contract remains independently testable.

## ADR-003 — Keep eligibility and recommendation decisions server-authoritative

- **Status:** Accepted
- **Context:** Browser-side eligibility calculations can drift from the rules used at application submission and could be manipulated.
- **Decision:** All eligibility and funding results are produced by API routes using server-side/shared engines. The What-If endpoint calls the same calculation path but does not persist hypothetical marks.
- **Consequences:** APIs require strict validation, rate limits and parity tests. The UI renders structured outcomes rather than recomputing eligibility.

## ADR-004 — Fail closed on unverified scoring rules or missing provenance

- **Status:** Accepted
- **Context:** Institution-specific APS logic and funding criteria vary and can change. Incorrect guidance can lead to unsuitable applications.
- **Decision:** A recommendation needs a source title/URL/year/page, retrieval/verification date and conditions. Programme scoring requires two independent reviewer sign-offs. Missing, stale, conflicting or unverified inputs are presented as unverified/cannot confirm, not guessed values.
- **Consequences:** Some universities/programmes may appear only on the roadmap until valid source evidence is available; that is preferable to a false assurance.

## ADR-005 — Narrow learner pilot to WSU, UFH and UJ undergraduate programmes

- **Status:** Accepted per build prompt
- **Context:** The target is a small pilot whose accuracy can be demonstrated rather than an unsupported claim across all 26 institutions.
- **Decision:** Only WSU, UFH and UJ are learner-visible during pilot. Postgraduate matching is disabled. Other institution records stay preserved but roadmap-only.
- **Consequences:** Pilot flags and tests must guard both page/API access; no programme from the excluded institutions may be calculated or applied to by learners.

## ADR-006 — Use envelope encryption for documents and encrypted income-band storage

- **Status:** Accepted; implementation pending
- **Context:** Current document blobs are documented as unencrypted. Documents and household income are high-risk personal information.
- **Decision:** Encrypt documents before persistence using AES-256-GCM, per-document random data keys, and a master key held outside the repository. Store a versioned envelope in the existing blob column and identify the wrapping key by key ID. Encrypt income-band payloads before storage as well.
- **Consequences:** Encryption key availability becomes a deployment requirement; legacy plaintext migration must be dry-run, resumable and idempotent. Decryption failures must never be silently treated as empty data.

## ADR-007 — Treat consent and privacy purpose as first-class records

- **Status:** Accepted; implementation pending
- **Context:** Learners may be under 18 and results, household income, documents, reminders, sharing and research participation have different purposes.
- **Decision:** Store separate, versioned, timestamped and withdrawable consent for each purpose. Require recorded parent/guardian confirmation before under-18 income or document features unlock. Only record research pilot metrics where research consent exists.
- **Consequences:** UI flows and APIs must re-check consent at operation time; opt-out must stop future processing/reminders that depend on that purpose.

## ADR-008 — Keep uncertain funding and institution records out of verified seed data

- **Status:** Accepted
- **Context:** The source material explicitly prohibits invented requirements and asks for honest provenance.
- **Decision:** Seed only records whose source has actually been read and whose retrieval date/conditions are recorded. Other records remain `draft`/`unverified`; CSV templates and import/verification tools provide a way to fill evidence gaps later.
- **Consequences:** The app may launch its pilot with fewer recommendations than planned. Empty verified result sets are not filled with plausible-looking placeholders.

## ADR-009 — Accuracy claims require auditable golden fixtures

- **Status:** Accepted; implementation pending
- **Context:** A scoring result cannot be described as accurate based only on implementation logic or a developer-authored expected value.
- **Decision:** Use exact expected APS and eligibility outcomes from the institution’s own published worked examples/calculator. Each fixture records its source. Run deterministic and property checks, report mismatches, and only use a “100% accurate” claim for a verified programme that passes its complete golden set.
- **Consequences:** Golden fixtures remain incomplete until authoritative examples are obtained; missing cases are reported as open work instead of reverse-engineered assumptions.

## ADR-010 — Do not claim live SQL Server or browser validation without execution evidence

- **Status:** Accepted
- **Context:** Unit tests, SQLite and SQL adapter mocks do not prove production SQL Server behaviour; DOM tests do not prove visual quality.
- **Decision:** Reports must distinguish automated mock/local tests from real SQL Server migrations/smoke tests and manual desktop/mobile review. The W0 runtime/dependency blocker is recorded explicitly.
- **Consequences:** Production release is gated on a separate SQL Server test instance, complete dependencies, full test/format/accuracy suites and human accessibility/UI review.
