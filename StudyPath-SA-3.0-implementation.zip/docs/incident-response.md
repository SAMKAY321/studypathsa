# StudyPath SA incident response runbook

**Owner:** the organisation's designated incident commander with the Information Officer and platform/database administrators. **Review date:** 26 October 2026. Contact names and phone numbers must be filled from the organisation's own on-call register before launch.

## 1. Detect and classify

Treat unexpected document access, suspected vault-key exposure, account/session compromise, cross-tenant data exposure, bulk export, SQL access anomalies, malware, exposed backups, lost devices containing data and suspicious deletion/export activity as reportable security events for triage. Record the time first detected, reporter, affected service, known scope and evidence location. Do not paste PII, tokens, document contents, passwords or keys into tickets or chat.

## 2. Contain

1. Page the incident commander and the Information Officer using the private on-call contact list.
2. Disable or throttle the affected route/account/session, rotate exposed credentials, revoke active sessions and restrict the relevant SQL login where necessary.
3. If a vault master key may be exposed, preserve the old key and encrypted evidence under restricted access, prepare a replacement key, and coordinate rotation. Do not delete old keys until every affected envelope is successfully rewrapped and a recovery test is complete.
4. If a database exposure is suspected, preserve logs, restrict network access and take a verified forensic backup according to the organisation's evidence policy. Avoid destructive “cleanup” before evidence is preserved.
5. Do not shut down or rebuild the only affected host before determining whether volatile evidence is required, unless immediate shutdown is necessary to stop ongoing harm.

## 3. Assess and investigate

Establish a UTC timeline, likely entry point, system/version, affected routes and databases, data categories, number of data subjects, whether minors or financial data are involved, evidence of exfiltration, whether ciphertext/key material was exposed together and whether the attacker still has access. Compare server and SQL audit logs and relevant `sp.DocumentAccessLog` records; do not place record contents or PII into the incident report.

Preserve SHA-256 checksums for exported log/evidence files and restrict access to evidence. Document hypotheses separately from facts. Do not use production learner data as a convenient debugging fixture.

## 4. Recover safely

Patch or disable the root cause, rotate compromised credentials/keys, restore from known-good encrypted backups if required, verify data integrity, re-run the test suite and security checks, inspect audit events, and have a second operator verify the recovery. Keep enhanced monitoring in place. For a cross-database privacy deletion that fails midway, reconcile `VARSITYVAULT2` and `StudyPathPilot` before retrying and record the operator decision without reproducing personal data.

## 5. Notification and communications

The Information Officer and legal/privacy lead must assess the current applicable legal notification requirements, notify the Information Regulator and affected people where required, and coordinate any additional contractual or sector obligations. This runbook intentionally does not prescribe a fixed legal deadline or claim a legal conclusion. Provide accurate, plain-language information about what happened, what data may be involved, actions taken, protective steps and a reliable contact channel. Do not speculate or promise no harm before the assessment supports it.

## 6. Close and learn

Record root cause, impact and confidence, containment/recovery actions, notification decision and rationale, evidence retention owner, remediation items with owners/dates, and a post-incident review. Re-test the specific failure path and confirm the new tests run in CI. Review the incident with a need-to-know audience and remove PII from non-essential copies.

## Pre-launch checklist

- [ ] Fill the incident commander, Information Officer and after-hours contacts.
- [ ] Test account/session revocation, SQL credential rotation and vault-key recovery in staging.
- [ ] Confirm encrypted backups and an audited restore exercise.
- [ ] Confirm evidence storage and access-control procedure.
- [ ] Approve notification decision workflow and external communications template.
