# Five-minute StudyPath SA demonstration script

**Honesty rule:** show the verification status first. The current package intentionally has no verified programme golden examples, so do not stage a “qualified” result by inserting made-up WSU/UFH/UJ minima. Use this demo to show the workflow and then import real evidence once the verification team supplies it.

## 0:00–0:30 — Learner home

Open the StudyPath SA landing/login flow and enter the learner portal with a test account. Explain that a learner's marks are captured once and the app reuses the profile. Do not use live learner PII in a public demo.

## 0:30–1:15 — Pilot admissions and provenance

Open **Pilot programmes**. Point out that the pilot is WSU, UFH and UJ undergraduate scope. Show the `Not yet verified` status when no eligible source-backed rule exists, including the link to the institution. Explain that the rule needs a retrieved source, archive hash, two independent reviewer approvals and passing official golden fixtures before the UI can say “Meets published minimum.”

## 1:15–2:00 — What-If

Open **What-If**. Change one or more demo marks or the subject code using a pre-reviewed test policy. Show “Hypothetical — not saved” and the before/after outcome. In a rule that requires Mathematics, demonstrate the explicit Mathematical Literacy warning and acknowledgement gate. Do not claim that an unsourced programme rule is a real university rule.

## 2:00–2:45 — Funding and deadlines

Open **Funding**. Demonstrate that draft, stale, past-deadline and incomplete-provenance opportunities do not become actionable matches. A valid “May be eligible” or “Possibly eligible — check” card requires sourced criteria, conditions, last-updated date and an open closing date or an explicitly published no-deadline state. The starter database has no verified funder offers, so the honest initial state may be empty.

## 2:45–3:30 — Vault, consent and privacy

Show the checklist and a test upload/download. Explain the AES-GCM envelope and that production depends on configuring and protecting `VAULT_MASTER_KEY`, migrating legacy rows and hardening SQL Server/backup storage. Show purpose-specific consent controls, export and delayed account-deletion request. Do not claim the guardian flag is a verified identity check.

## 3:30–4:15 — Verification admin

Open admin verification, upload a real official prospectus PDF, record page/year/date/conditions, submit a draft rule and demonstrate the independent sign-off flow using two distinct authorised accounts. Run the accuracy suite after importing official examples.

## 4:15–5:00 — Pilot dashboard and next evidence

Show the pilot dashboard and point out minimum-cell-size suppression for groups under five. With no approved participants, the dashboard is empty by design. End by identifying outstanding launch gates: official scoring examples, published funding criteria, approved guardian workflow, real Information Officer contact and a successful SQL Server/Node 24+ release verification.
