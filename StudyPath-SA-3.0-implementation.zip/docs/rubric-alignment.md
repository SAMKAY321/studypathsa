# Information Systems III rubric-alignment review

This checklist maps the project artefacts to the rubric supplied for the Information Systems III project. It is a preparation guide, not a prediction of the mark. Marking depends on the submitted schema, working live demo, and how clearly the group explains its decisions.

## Criteria and evidence

| Rubric criterion | Marks | Project evidence to show | Status / cautions |
|---|---:|---|---|
| ERD: entities, attributes, relationships and cardinalities | 35 | `docs/erd.md`, `docs/schema-data-dictionary.md`, `config/table-map.json`; show the ERD and trace representative joins into the SQL Server database | Uses the group-submitted ERD PDF and the supplied SQL Server DDL. Static source comparison confirms 30 tables, 128 columns and all 42 named FK relationships; cardinality notes now derive from FK nullability and unique constraints. A live SSMS database comparison is still required before claiming runtime verification. |
| Database: normalization | 10 | `docs/normalization-review.md`; explain 1NF, 2NF, 3NF with actual PKs, attributes and functional dependencies | Review notes include strengths and potential risks; final explanation must match actual schema and constraints. |
| Database: ERD/database alignment | 15 | `config/schema-contract.json`, `config/table-map.json`, `server/db/schema-compare.js`, `server/db/check.js`, `docs/schema-data-dictionary.md` | The supplied `table-map.json` matches the SQL script’s 30 tables / 128 columns / SQL types, and `schema-contract.json` lists 44 expected core objects (tables, views, functions, procedures and trigger). The readiness check confirms object and column presence; run it on the configured database to verify live state. |
| Database: SQL creation scripts, keys, constraints and relationships | 10 | The group's existing SQL Server DDL script; `database/security.sql` for additional application-security objects where used; ERD and data dictionary | The exact group SQL Server script is bundled under `database/source/` without modification; the submitted ERD PDF is preserved in `docs/source/`. `source-schema-audit.md` inventories the 42 FKs and key constraints. `database/security.sql` adds separate application-account/session objects only; it does not replace the academic database script. |
| User interface design and navigation | 5 | `public/` role pages and `public/assets/css/`; active navigation, responsive layouts, focus states, status feedback | Demonstrate at desktop size and a narrow/mobile viewport. Accessibility and visual checks should be carried out locally. |
| UI functionality and database integration | 20 | `server/full-api.js`, `server/storage.js`, `server/db/`, `shared/`, `tests/full-app.test.js`, `docs/application-workflows.md` | Use the four-role end-to-end demo below. Automated tests in this environment do not prove a live connection to the user's SQL Server; demonstrate real persistence in the actual configured environment. |
| Presentation: all group members participate | 5 | `docs/presentation-and-demo.md` | Adapt the suggested speaking split to the actual group. Each member should be able to explain their own contribution and the system end to end. |

## High-weight focus

The rubric allocates 60 marks to ERD plus database design/alignment/script evidence, 20 to application/database integration, and only 5 to visual UI design. Prioritize correctness of entity attributes and cardinalities, alignment to the actual database script, and a stable persisted workflow over adding more decorative interface elements.

## Before submission

- [ ] The submitted ERD includes all relevant entities, attributes, primary keys, relationships, and cardinalities.
- [ ] Every relationship shown in the ERD source mapping is reconciled to the 42 FK declarations in the supplied DDL; a live `npm run db:check` and workflow smoke test remain to verify the current server instance.
- [ ] Normalization explanations include keys and functional dependencies, not only definitions.
- [ ] The ERD, data dictionary, script and running app use the same table and column names.
- [ ] The existing SQL Server schema script is part of the final submission; no Oracle APEX export is presented as the database-creation script.
- [ ] `npm test` passes on the supported Node.js version, and `npm run db:check` plus real workflow smoke tests succeed on the configured SQL Server database.
- [ ] Every role is demonstrated without bypassing permission checks or inventing eligibility rules.
- [ ] All group members speak and can explain their actual contributions.

## Scope note

The app's intended runtime remains HTML/CSS/vanilla JavaScript served by Node.js/Express with SQL Server persistence. Oracle is not required to run the web app. This document does not instruct the team to migrate or rebuild the database.
