# Varsity Vault 2.0.5 — whole-application audit fixes

## Fixes included

- Added idempotent initialization for the two required application study-mode lookups (`Full-time`, `Part-time`). The supplied academic SQL script creates `STUDY_MODES` but does not insert rows. Startup adds only missing lookup values; it does not seed fictitious universities, schools, qualifications, learners, or applications.
- The Requirements page now displays a deliberate “Choose a study mode” placeholder and blocks submission with a clear explanation if study modes cannot be loaded/configured.
- Added shared ID normalization for server-side identifier comparisons so SQL Server integer values and numeric strings from browser/test data are handled consistently across role scoping, result verification, document access, status transitions, university-location joins and audit display.
- Empty result-save payloads are rejected rather than being interpreted as an instruction to delete every unverified result for a milestone.
- Added regression tests for cross-driver ID representation, idempotent study-mode initialization, the study-mode UI contract and the empty-results guard.

## Verification boundaries

- JavaScript syntax checks passed for all JavaScript source and test files.
- Standalone tests passed for core scoring, data contract, workflow, security configuration, UI theme, result drafts, ID normalization and reference-data initialization.
- The full integration test suite could not be completed in this build environment: `npm ci` timed out, leaving `express`, `jsdom`, and `nodemailer` incomplete. API lifecycle, browser DOM tests and mail delivery tests must be rerun after a successful `npm ci` using the supported Node.js version.
- No live connection to the user's SQL Server instance was available here, so the runtime lookup insert and complete four-role application workflow remain subject to a local smoke test.
