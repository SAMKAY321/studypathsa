# StudyPath SA build status — 3.0.0 implementation stage

**Build timestamp:** 26 October 2026. **Status: implementation in progress; not production-ready.** The application code, feature surfaces and handover docs have been expanded, but critical external evidence and environment-backed tests remain.

## Delivered in this working copy

- User-facing StudyPath SA branding; public cycle labels set to 2027; learner/public university catalogues are limited to WSU, UFH and UJ while pilot mode is active; admins retain all institutions with non-pilot entries labelled “Roadmap”. Internal package/database/schema names retained.
- Pilot flag configuration for WSU, UFH and UJ undergraduate only; postgraduate flag disabled.
- Separate StudyPathPilot database migrations and seed flags; original submitted academic SQL file not modified.
- Source ledger, evidence archive/hash validation, two-reviewer sign-off mechanism, programme/funding import templates, admin CSV dry-run diff/apply flows, duplicate-row checks, and no-op handling for unchanged imports. Changed programme evidence invalidates old approvals.
- Shared provenance serialization and freshness gate; server-side What-If endpoint; unsuitable-application acknowledgement guard.
- Credit-transfer guidance-only service and interface.
- Funding criteria match service, encrypted income-band profile and admin opportunity maintenance paths.
- AES-256-GCM envelope encryption/decryption, key rotation/re-wrap and legacy row migration utilities.
- Purpose-based consent, export/delete request interface/job, document download logging/no-store, checklists, deadline alerts, templates and reminder command.
- Competitor comparison scaffold with evidence-aware statuses; admin pilot workflow/dashboard/export with minimum-cell-size suppression.
- Security, data verification, pilot, comparator, handover and incident-response documents.

## Current automated checks

The focused test command is:

```powershell
node --test tests/studypath-trust.test.js tests/vault-crypto.test.js tests/studypath-operational.test.js tests/studypath-retention.test.js tests/security-log-hygiene.test.js tests/wsu-theme.test.js tests/local-assets.test.js
```

The test set covers provenance fail-closed behavior, freshness demotion, What-If validation/parity basics, Mathematics/Mathematical Literacy warning, funding criteria/actionability, LocalPilotStore consent idempotency, AES-GCM encrypt/decrypt/tamper/wrong-key/rotation/legacy handling, retention safety gates, log hygiene, wording lint, honest accuracy gating, pilot catalog scope, CSV-import safety and migration separation. See the current final validation record below.

`node --check` syntax checks have passed for several modified source files, but must be re-run at packaging for the full modified JavaScript file set. `scripts/wording-lint.js` passes. `scripts/accuracy.js` deliberately exits with code 2 because all three pilot golden fixtures contain zero sourced examples. This is a **blocked release gate**, not an accuracy pass.

## Runtime and environment limitations

- Available runtime is Node.js 22.16.0, below project engine `^24.15.0 || >=26.0.0`.
- Dependency installation did not complete, leaving Express/jsdom/Nodemailer/Prettier unavailable in this build environment. The whole original API/browser test suite and `npm run format:check` are not currently validated end to end.
- No live SQL Server 2019+ connection was available. The new T-SQL scripts, trigger behavior, transaction semantics, SQL adapter contracts, indexes, SQL Server encryption integration, performance target and rollback have not been verified against a live instance.
- No production browser automation/visual accessibility test was run for every new route at desktop/mobile widths.
- No real parent/guardian identity verification, licensed legal review, security audit or backup restore exercise was completed.

## Known production blockers

1. Official 2027 course-level rules and calculator worked outputs for each pilot institution, with source archives/content hash and two independent approvals.
2. Non-empty golden fixtures; `npm run accuracy` should pass after data has actually been verified.
3. Current funder criteria/deadlines/documents and independent verification; no current opportunity is seeded as verified.
4. Guardian identity verification flow and Information Officer/contact/retention policy approval.
5. Run `npm ci`, all tests, formatter and `npm run verify` on Node 24.15+ or 26+ in a working dependency environment.
6. Run migrations, re-run idempotency tests, rollback and security/performance smoke tests on a disposable SQL Server.
7. Confirm data subject export/delete cross-database reconciliation, production key custody/rotation and encrypted backup recovery.

See `docs/open-items.md`, `docs/security-and-popia.md` and `docs/incident-response.md`. No statement in this document means that a live database or production rollout was tested.

## Latest implementation validation (26 October 2026)

- Focused verification including trust, vault crypto, operations, retention, log hygiene, local assets, theme and operational source checks: **32 passed, 0 failed** on 26 October 2026.
- Full `npm test`: **69 passed, 3 test files failed to load** (72 tests total) because Express, jsdom and Nodemailer are missing from `node_modules` after repeated `npm ci --prefer-offline` timeout attempts. The npm output also warns that Node.js 22.16.0 is below both the package engine and several dependency engine ranges. The earlier stale UI inventory/year assertions have been updated to the three-institution 2027 scope.
- All JavaScript files under `server`, `shared`, `public/assets/js`, `scripts` and `tests` passed `node --check`; `node scripts/wording-lint.js` passed. `node scripts/accuracy.js` exits 2 with `blocked-unverified; 0/0 cases passed`, as expected without source-backed official golden examples.
- Public UI, pilot requirements-policy parity, source display and unsuitable-application acknowledgement changes are syntax/source-tested; end-to-end API route tests and visual browser checks remain blocked by dependencies. No live SQL Server tests were run.
