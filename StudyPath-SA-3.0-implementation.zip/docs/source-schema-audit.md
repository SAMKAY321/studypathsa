# Source schema audit — Varsity Vault

## Authoritative inputs

- Group ERD: `docs/source/Group 3 - Kagiso Mathabathe & Mantoa Moletsane VarsityVault ERD.pdf` (preserved unchanged).
- Database DDL: `database/source/unilink_script_improved.sql` (preserved byte-for-byte from the supplied upload).
- Application mapping: `config/table-map.json`.
- Startup object/column contract: `config/schema-contract.json`.

## Static reconciliation results

| Check | Result |
|---|---:|
| Base tables declared in DDL | 30 |
| Base table columns declared in DDL | 128 |
| Foreign-key constraints declared in DDL | 42 |
| Views declared in DDL | 8 |
| Scalar functions declared in DDL | 2 |
| Stored procedures declared in DDL | 3 |
| Triggers declared in DDL | 1 |
| Objects in `config/schema-contract.json` | 44 (30 tables + 8 views + 2 functions + 3 procedures + 1 trigger) |

A source-level comparison confirmed that all 30 table names, all 128 column names, and all declared SQL data types match `config/table-map.json`. The schema contract also lists the expected 30 tables, eight views, two functions, three stored procedures, and one trigger. The 42 FK declarations were mapped to the ERD relationships and the Mermaid cardinality markers were adjusted for FK nullability and single-column uniqueness.

## Declared objects in the SQL script

**Views:** `VIEW_SCHOOL_DIRECTORY`, `VIEW_UNIVERSITY_DIRECTORY`, `VIEW_USER_CONTEXT`, `VIEW_LEARNER_RESULTS_DETAIL`, `VIEW_LEARNER_SUBMISSION_CHECK`, `VIEW_APPLICATION_TIMELINE`, `VIEW_LEARNER_APPLICATIONS`, `VIEW_UNIVERSITY_APPLICATIONS`.

**Functions:** `fn_GetLearnerAps`, `fn_GetEligibility`.

**Stored procedures:** `usp_SubmitApplication`, `usp_ScreenApplication`, `usp_ReviewApplication`.

**Triggers:** `TRG_DOCUMENTS_LOCK_FINAL`.

## Foreign-key inventory

| Constraint | FK column | Referenced key | Cardinality notes | Delete action |
|---|---|---|---|---|
| `FK_SCHOOL_CITY` | `SCHOOLS.CITY_ID` | `CITIES.CITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_SCHOOL_PROVINCE` | `SCHOOLS.PROVINCE_ID` | `PROVINCES.PROVINCE_ID` | mandatory parent reference; parent can have many child rows | NO ACTION |
| `FK_UNI_PROVINCE` | `UNIVERSITIES.PROVINCE_ID` | `PROVINCES.PROVINCE_ID` | mandatory parent reference; parent can have many child rows | NO ACTION |
| `FK_QUAL_PROG` | `QUALIFICATIONS.PROGRAM_ID` | `PROGRAMS.PROGRAM_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_SUB_SCHOOL` | `SUBJECTS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_TEACHER_PERSON` | `TEACHERS.PERSON_ID` | `PERSONS.PERSON_ID` | nullable parent reference; unique child FK | CASCADE |
| `FK_TEACHER_SCHOOL` | `TEACHERS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_LEARNER_PERSON` | `LEARNERS.PERSON_ID` | `PERSONS.PERSON_ID` | nullable parent reference; unique child FK | CASCADE |
| `FK_LEARNER_SCHOOL` | `LEARNERS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_ITADMIN_PERSON` | `ITADMINS.PERSON_ID` | `PERSONS.PERSON_ID` | nullable parent reference; unique child FK | CASCADE |
| `FK_ITADMIN_SCHOOL` | `ITADMINS.SCHOOL_ID` | `SCHOOLS.SCHOOL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_PADDR_CITY` | `PERSON_ADDRESSES.CITY_ID` | `CITIES.CITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_PADDR_PERSON` | `PERSON_ADDRESSES.PERSON_ID` | `PERSONS.PERSON_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_PADDR_TYPE` | `PERSON_ADDRESSES.ADDRESS_TYPE_ID` | `ADDRESS_TYPES.ADDRESS_TYPE_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_UADDR_CITY` | `UNIVERSITY_ADDRESSES.CITY_ID` | `CITIES.CITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_UADDR_TYPE` | `UNIVERSITY_ADDRESSES.ADRRESS_TYPE_ID` | `ADDRESS_TYPES.ADDRESS_TYPE_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_UADDR_UNI` | `UNIVERSITY_ADDRESSES.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_REP_PERSON` | `UNIVERSITY_REPS.PERSON_ID` | `PERSONS.PERSON_ID` | mandatory parent reference; unique child FK | CASCADE |
| `FK_REP_UNI` | `UNIVERSITY_REPS.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | mandatory parent reference; parent can have many child rows | CASCADE |
| `FK_PROS_UNI` | `PROSPECTUSES.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_UNIQUAL_QUAL` | `UNI_QUALIFICATIONS.QUAL_ID` | `QUALIFICATIONS.QUAL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_UNIQUAL_UNI` | `UNI_QUALIFICATIONS.UNIVERSITY_ID` | `UNIVERSITIES.UNIVERSITY_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_QREQ_UNIQUAL` | `QUALIFICATION_REQUIREMENTS.UNI_QUAL_ID` | `UNI_QUALIFICATIONS.UNI_QUAL_ID` | mandatory parent reference; unique child FK | CASCADE |
| `FK_APPS_LEARNER` | `APPLICATIONS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_APPS_STUDYMODE` | `APPLICATIONS.STUDY_MODE_ID` | `STUDY_MODES.STUDY_MODE_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_APPS_TEACHER` | `APPLICATIONS.TEACHER_ID` | `TEACHERS.TEACHER_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_APPS_UNIQUAL` | `APPLICATIONS.UNI_QUAL_ID` | `UNI_QUALIFICATIONS.UNI_QUAL_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_APPS_STATUS` | `APPLICATIONS.STATUS_ID` | `APPLICATION_STATUSES.STATUS_ID` | mandatory parent reference; parent can have many child rows | NO ACTION |
| `FK_APPS_REVIEWER` | `APPLICATIONS.REVIEWED_BY_REP_ID` | `UNIVERSITY_REPS.REP_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_APPPROC_ACTION_FK` | `APPLICATION_PROCESSES.ACTION_ID` | `ACTIONS.ACTION_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_APPPROC_APPLICATION_FK` | `APPLICATION_PROCESSES.APPLICATION_ID` | `APPLICATIONS.APPLICATION_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_DOCS_VERSTATUS` | `DOCUMENTS.VERIFICATION_STATUS_ID` | `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_DOCS_VERTEACHER` | `DOCUMENTS.VERIFIED_BY_TEACHER_ID` | `TEACHERS.TEACHER_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_DOC_PERSON` | `DOCUMENTS.PERSON_ID` | `PERSONS.PERSON_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_DOC_TYPES` | `DOCUMENTS.DOCUMENT_TYPE_ID` | `DOCUMENT_TYPES.DOCUMENT_TYPE_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_LRESULTS_EXAMTYPE_FK` | `LEARNER_RESULTS.EXAM_TYPE_ID` | `EXAM_TYPES.EXAM_TYPE_ID` | mandatory parent reference; parent can have many child rows | CASCADE |
| `FK_LRESULTS_LEARNER_FK` | `LEARNER_RESULTS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | mandatory parent reference; parent can have many child rows | CASCADE |
| `FK_LRESULTS_SUBJECT_FK` | `LEARNER_RESULTS.SUBJECT_ID` | `SUBJECTS.SUBJECT_ID` | mandatory parent reference; parent can have many child rows | NO ACTION |
| `FK_LRESULTS_VERSTATUS` | `LEARNER_RESULTS.VERIFICATION_STATUS_ID` | `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_LRESULTS_VERTEACHER` | `LEARNER_RESULTS.VERIFIED_BY_TEACHER_ID` | `TEACHERS.TEACHER_ID` | nullable parent reference; parent can have many child rows | NO ACTION |
| `FK_LSUBJ_LEARNER` | `LEARNER_SUBJECTS.LEARNER_ID` | `LEARNERS.LEARNER_ID` | nullable parent reference; parent can have many child rows | CASCADE |
| `FK_LSUBJ_SUBJECT` | `LEARNER_SUBJECTS.SUBJECT_ID` | `SUBJECTS.SUBJECT_ID` | nullable parent reference; parent can have many child rows | NO ACTION |

## Schema details to preserve

- `UNIVERSITY_ADDRESSES.ADRRESS_TYPE_ID` uses the spelling in the submitted DDL; it is intentionally not silently renamed.
- The IT administrator identity key is `ITADMIN_IID`, not `ITADMIN_ID`.
- `SUBJECTS.SCHOOL_ID` allows NULL, which permits the national/shared subject catalogue seeded in the script.
- `QUALIFICATION_REQUIREMENTS.UNI_QUAL_ID` is `NOT NULL UNIQUE`, so the physical schema allows at most one requirements row per university offering.
- `APPLICATIONS` has the unique constraint on `(LEARNER_ID, UNI_QUAL_ID, ACADEMIC_YEAR)`; `LEARNER_SUBJECTS` has a unique pair on `(LEARNER_ID, SUBJECT_ID)`; `LEARNER_RESULTS` has a composite PK on `(LEARNER_ID, SUBJECT_ID, EXAM_TYPE_ID)`.
- `PERSONS.USERNAME` is enforced by a filtered unique index for non-NULL usernames; email, EMIS number and subject code are not declared unique by this script.
- Several date-like attributes are VARCHAR columns in the supplied DDL; the app preserves the exact contract rather than migrating those columns.

## Runtime boundary and remaining verification

The application-security tables used for accounts, sessions, audit, login attempts, recovery tokens and optional MFA are in the separately named `VarsityVaultSecurity` database created by `database/security.sql`. They are application support objects and are intentionally not added to the group’s core academic ERD or the 30-table count.

This report is a source-level comparison only. A live SQL Server instance was not available to this audit. Run `npm run db:check` on the configured machine, then carry out the learner → teacher → university representative → admin workflow with real persisted rows. A passing static comparison does not establish that SSMS successfully executed the DDL or that the running database has no drift.
