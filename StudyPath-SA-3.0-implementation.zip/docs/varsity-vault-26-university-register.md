# Varsity Vault — all 26 public universities

Planning register for the **2027 intake**, researched on **5 October 2026**.

**Coverage: 26/26 institutions. Production verification is incomplete.** This register covers scoring policies and their evidence status; it does not claim that every qualification, deadline or 2027 admission criterion has been imported. Older or undated policies are retained as review material and must be confirmed for 2027.

The submitted VARSITYVAULT2 database, ERD and generic SQL APS function remain unchanged. Institution and programme rules belong in separately versioned application configuration. HTML/CSS/JavaScript and the Node.js/Express backend remain the planned stack.

The review preview uses one fixed seven-subject NSC curriculum: isiXhosa HL, English FAL, Mathematics, Life Orientation, Accounting, Business Studies and Economics. It is not an arbitrary-subject or international-qualification calculator. Province coverage refers to primary campuses; UNISA is national.

This revision enables scoped sample arithmetic for all 26 institutions. It retains uncertainty gates for incomplete bands, conflicting policies and missing subjects. Scores do not establish programme eligibility. CPUT Methods 1 and 3 work with this sample; Method 2 requires Physical Sciences, which is absent.

## Coverage and evidence

| University                                       | Scoring scope                                            | Life Orientation                                                  | Evidence status                                                           |
| ------------------------------------------------ | -------------------------------------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------- |
| CPUT — Cape Peninsula University of Technology   | Percentage APS: Methods 1, 2 and 3                       | Excluded in every method                                          | CPUT-authored 2027 prospectus read from a mirrored copy                   |
| CUT — Central University of Technology           | AP: six academic ratings plus capped LO                  | Maximum 1; published minimum LO 50%                               | Current official policy; 2027 programme confirmation required             |
| DUT — Durban University of Technology            | Programme profile: English plus five ratings             | Excluded in Business Administration profile                       | Current programme page; 2027 confirmation required                        |
| MUT — Mangosuthu University of Technology        | Programme profile: six NSC subject ratings               | Excluded in ICT profile                                           | Current department policy; 2027 confirmation required                     |
| NMU — Nelson Mandela University                  | Applicant Score: six raw percentages                     | Excluded; school-quintile bonus requires verification             | 2024 scoring guide; 2027 selection guidance located                       |
| NWU — North-West University                      | Six subject ratings; 90% earns 8                         | Excluded                                                          | Official 2026 scoring ladder read; 2027 subject-count rule confirmed      |
| Rhodes — Rhodes University                       | Six percentages divided by 10                            | Excluded from score; minimum 50% for admission                    | Current prospectus labelled 2027; older entry page used for below-40 rule |
| SMU — Sefako Makgatho Health Sciences University | MBChB: seven-subject APS, separate preselection score    | Included in the MBChB seven-subject APS                           | Official Medicine equivalency table read; 2027 applicability pending      |
| SPU — Sol Plaatje University                     | Weighted APS with Maths and Home Language bonuses        | 0–4 points                                                        | 2026 prospectus; 2027 confirmation required                               |
| SU — Stellenbosch University                     | NSC average; faculty selection measures differ           | Excluded from the displayed average                               | 2027 admission booklet read                                               |
| TUT — Tshwane University of Technology           | NSC APS; level 1 subjects excluded                       | Excluded                                                          | 2027 first-year guide read                                                |
| UNISA — University of South Africa               | Six recognised 20-credit subjects                        | Excluded: 10-credit subject                                       | Current admissions page carries 2027 application information              |
| UCT — University of Cape Town                    | Base APS out of 600; faculty FPS / WPS separately        | Excluded from base academic score                                 | UCT-authored 2027 prospectus read from a mirrored copy                    |
| UFH — University of Fort Hare                    | Management & Commerce: NSC levels with capped LO         | Capped at level 4 in this faculty                                 | 2027 study guide read                                                     |
| UFS — University of the Free State               | AP: six academic ratings plus LO bonus                   | 1 point at 60% or higher; otherwise 0                             | 2027 prospectus scoring table retrieved in official search index          |
| UJ — University of Johannesburg                  | Best six NSC ratings including required subjects         | Excluded                                                          | Current APS FAQ and official programme page                               |
| UKZN — University of KwaZulu-Natal               | Six ratings; totals withheld if academic marks reach 90% | Excluded; may still be a programme prerequisite                   | 2027 prospectus conflict retained; consistent lower bands calculable      |
| UL — University of Limpopo                       | Six subjects; high-mark table needs confirmation         | Excluded                                                          | 2027 prospectus read; conflicting high-mark tables                        |
| UMP — University of Mpumalanga                   | Foundation Phase BEd: six ratings plus half LO           | Half of the NSC LO rating in this programme                       | Current programme page; 2027 confirmation required                        |
| UP — University of Pretoria                      | Six NSC 20-credit subject ratings                        | Excluded                                                          | 2027 programme requirements read                                          |
| UNIVEN — University of Venda                     | Percentage divided by 10; below 40% excluded             | Excluded                                                          | Current official scale and 2027 prospectus selection text indexed         |
| UWC — University of the Western Cape             | Seven subjects: weighted English and Mathematics         | 1–3 points, depending on achievement                              | Official calculator and English HL/FAL definition read                    |
| Wits — University of the Witwatersrand           | Weighted seven-subject APS                               | 0–4 points                                                        | Current official scoring table; BCom page explicitly names 2027           |
| UNIZULU — University of Zululand                 | Education: six relevant subjects on an eight-point scale | Excluded                                                          | Current Education policy; 2027 confirmation required                      |
| VUT — Vaal University of Technology              | Six ratings; verified academic bands 40–99%              | Excluded                                                          | VUT-authored 2027 sheet read from a mirrored copy                         |
| WSU — Walter Sisulu University                   | Commerce: two languages and four other subjects          | Excluded for these Commerce offerings; Education exception exists | 2027 admission brochure read                                              |

## Institution notes and sources

### CPUT — Cape Peninsula University of Technology

Method 1: six relevant percentages / 10. Method 2: double Mathematics and Physical Sciences, add English and the next best subject, then / 10. Method 3: double Mathematics and Accounting, add English and three other subjects, then / 10. Programme assignment and official distribution still require confirmation.

Source: [CPUT-authored 2027 prospectus read from a mirrored copy](https://cput.ac.za/study-at-cput/undergraduate/apply/step-1)

Additional evidence: [University-authored document, mirrored copy](https://assets.apply.org.za/u-files/Prospectuses/CPUT2027.pdf)

### CUT — Central University of Technology

Academic scale awards 8 at 90%. Marks below 30% are not defined in the published table; this preview withholds a score for those results.

Source: [Current official policy; 2027 programme confirmation required](https://www.cut.ac.za/admission-points-ap)

### DUT — Durban University of Technology

Verified scope: Diploma in Management Sciences: Business Administration. The published minimum is 25 with separate English, maths and subject conditions. Other programmes require their own policy.

Source: [Current programme page; 2027 confirmation required](https://www.dut.ac.za/course/diploma-in-management-sciences-business-administration/)

### MUT — Mangosuthu University of Technology

Scope: ICT. Marketing separately excludes subjects rated 1 or 2; do not reuse the ICT calculator for Marketing or other departments.

Source: [Current department policy; 2027 confirmation required](https://www.mut.ac.za/faculty-of-applied-and-health-sciences/department-of-information-and-communication-technology/)

### NMU — Nelson Mandela University

The base Applicant Score is out of 600. A published 7-point bonus depends on school quintile and LO achievement; no bonus is assumed from the seven marks alone. Required languages and subjects must remain in the selected six.

Source: [2024 scoring guide; 2027 selection guidance located](https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/MANDELA_Z-CARD-UNDERGRAD-PROGRAMME-2024-DIGITAL.pdf)

### NWU — North-West University

The official Grade 11 guide for 2026 supplies the complete 1–8 scoring ladder. The 2027 prospectus retains six subjects excluding LO. Arithmetic is available for review; confirm the complete ladder’s 2027 applicability before production eligibility.

Source: [Official 2026 scoring ladder read; 2027 subject-count rule confirmed](https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf)

Additional evidence: [Additional official scoring evidence](https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2024/2024-Grade-11-prospectus.pdf)

### Rhodes — Rhodes University

Include English and required programme subjects. The official entry page awards no points below 40%. Faculty offer bands, NBT and endorsement are separate checks.

Source: [Current prospectus labelled 2027; older entry page used for below-40 rule](https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf)

### SMU — Sefako Makgatho Health Sciences University

The MBChB NSC ladder uses 1–7 across seven subjects. Its preselection and ranking measures are separate. This Commerce subject set lacks Physical Sciences and Life Sciences; an APS total cannot assess MBChB eligibility.

Source: [Official Medicine equivalency table read; 2027 applicability pending](https://www.smu.ac.za/schools/medicine/medicine-undergraduate-admission-requirements/)

### SPU — Sol Plaatje University

Academic marks of 90% earn 8. Mathematics and any official Home Language earn +2 at 60% or +1 at 40–59%. English FAL does not receive the Home Language bonus.

Source: [2026 prospectus; 2027 confirmation required](https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf)

### SU — Stellenbosch University

The displayed six-subject average is only a baseline. Science doubles Mathematics in its selection average; Engineering combines Mathematics, Physical Sciences and six times the matric average. Programme criteria remain separate.

Source: [2027 admission booklet read](https://files.su.ac.za/public/undergraduate-maties/documents/2026-05/su-admissions-booklet-2027.pdf)

### TUT — Tshwane University of Technology

English, Mathematics or alternatives and programme subjects are compulsory as applicable. A subject below 30% contributes zero, rather than the usual NSC 1 point.

Source: [2027 first-year guide read](https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf)

### UNISA — University of South Africa

APS thresholds and English requirements depend on the qualification. Do not treat a score alone as an admission decision.

Source: [Current admissions page carries 2027 application information](https://unisa.ac.za/sites/corporate/default/Apply-for-admission/Undergraduate-qualifications/Qualifications/General-admission-requirements)

### UCT — University of Cape Town

Sum English plus five relevant subject percentages, excluding LO and AP subjects; marks below 40% contribute zero. Science FPS doubles Mathematics and an approved science subject; Health Sciences FPS adds three NBT scores. This preview displays base APS only, with programme eligibility unassessed.

Source: [UCT-authored 2027 prospectus read from a mirrored copy](https://uct.ac.za/students/prospective-students/undergraduate-prospectus)

Additional evidence: [University-authored document, mirrored copy](https://varsitytoolkit.com/uploads/documents/2027-uct-undergraduate-prospectus-1-april-2026.pdf)

### UFH — University of Fort Hare

This profile is restricted to Management & Commerce. The cap must not be applied to all other faculties without their own published policy.

Source: [2027 study guide read](https://www.ufh.ac.za/study-guide-2027)

### UFS — University of the Free State

Academic marks of 90% earn 8; below 30% contributes zero. Programme subject thresholds and selection conditions remain separate.

Source: [2027 prospectus scoring table retrieved in official search index](https://www.ufs.ac.za/docs/librariesprovider44/undergraduate/ufs---ug-prospectus-2027---jan.pdf?sfvrsn=f3a0f820_1)

### UJ — University of Johannesburg

The BEd example has a published 2026 closing date for this intake. Other qualifications require their own subject combinations and minima.

Source: [Current APS FAQ and official programme page](https://www.uj.ac.za/frequently-asked-questions)

### UKZN — University of KwaZulu-Natal

Calculate only academic marks below 90%, where the retrieved policies agree. The 2027 prospectus conflicts at 90–100%; the official 2026 brochure supports 8 in that band, while a faculty handbook differs. Do not infer which policy governs a 2027 programme.

Source: [2027 prospectus conflict retained; consistent lower bands calculable](https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf)

Additional evidence: [Additional official scoring evidence](https://studyatukzn.ukzn.ac.za/wp-content/uploads/2026/02/Study@UKZN-BROCHURE-2026.pdf)

### UL — University of Limpopo

The primary NSC table assigns 7 to 80–99%, while the conversion table lists 8 for NSC 90–100%. This preview calculates only when all academic marks are below 90%.

Source: [2027 prospectus read; conflicting high-mark tables](https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf)

### UMP — University of Mpumalanga

This is the published Foundation Phase BEd profile. Its compulsory subjects and electives must be checked. Other qualifications need independent profiles.

Source: [Current programme page; 2027 confirmation required](https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Education/School-of-Foundation-Phase-Teaching/Bachelor-of-Education-in-Foundation-Phase-Teaching)

### UP — University of Pretoria

Grade 11 and final NSC minima can differ: the published BA example uses APS 30 for application and APS 28 for final admission. Preserve the examination milestone.

Source: [2027 programme requirements read](https://www.up.ac.za/acsus/programmes/undergraduate/bachelor-of-arts-ba-3-year-programme/2027)

### UNIVEN — University of Venda

The 2027 source mentions seven highest subjects if more than seven were taken. This preview supports the ordinary seven-subject curriculum only; extra-subject selection requires explicit resolution.

Source: [Current official scale and 2027 prospectus selection text indexed](https://www.univen.ac.za/student-affairs/student-support-services/how-to-apply/general-information/)

### UWC — University of the Western Cape

English HL and FAL use the English column; the other language and electives use the other-subject column. Mathematics is weighted; Mathematical Literacy uses the other-subject column. LO contributes 0–3. Confirm programme thresholds for 2027.

Source: [Official calculator and English HL/FAL definition read](https://www.uwc.ac.za/admission-point-score-calculator/south-african-aps-calculator)

Additional evidence: [Additional official scoring evidence](https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-economic-and-management-sciences/undergraduate-application-process)

### Wits — University of the Witwatersrand

English and Mathematics receive +2 at 60% or higher. Academic marks below 40% score zero. Programme prerequisites, NBT where required and selection bands remain separate.

Source: [Current official scoring table; BCom page explicitly names 2027](https://www.wits.ac.za/undergraduate/entry-requirements/)

### UNIZULU — University of Zululand

The Education page awards 8 at 90%. It selects four prescribed and two recognised subjects. Do not assign the profile to every faculty without confirmation.

Source: [Current Education policy; 2027 confirmation required](https://www.education.unizulu.ac.za/undergraduate/)

### VUT — Vaal University of Technology

Six subjects excluding LO; 40–49% earns 3 through 90–99% earning 8. This preview withholds totals for academic marks below 40% or equal to 100% because the retrieved ladder does not define those bands. Programme thresholds remain separately verified.

Source: [VUT-authored 2027 sheet read from a mirrored copy](https://vut.ac.za/wp-content/uploads/2026/02/A4-flyer-double-sided.pdf)

Additional evidence: [University-authored document, mirrored copy](https://assets.apply.org.za/u-files/Prospectuses/VUT2027.pdf)

### WSU — Walter Sisulu University

Use English, another language and four relevant subjects. Academic marks of 90% earn 8. Foundation Phase BEd separately includes LO, so this Commerce profile must not be applied there.

Source: [2027 admission brochure read](https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf)

## Before production eligibility is enabled

- Confirm the exact 2027 programme, campus, study mode and application deadline. Never roll an older date forward by changing only its year.
- Record the source title, URL, publication year, verification date and programme scope. Store rule status separately from intake year.
- Configure programme thresholds, required subjects, English HL/FAL alternatives, Mathematics/Mathematical Literacy alternatives, endorsement, NBT, portfolio, test and ranking conditions where applicable.
- Confirm CPUT method assignments and official distribution of its 2027 prospectus; NWU’s 2027 ladder applicability; UKZN and UL conflicting high-mark bands; UWC’s 2027 programme thresholds; VUT’s undefined below-40 and 100% bands and source distribution; UCT faculty FPS/WPS inputs and official prospectus distribution; and SMU’s 2027 programme-specific selection measures.
- Confirm 2027 applicability for older or undated CUT, DUT, MUT, NMU, SPU, UNIZULU and UMP profiles. Confirm extra-subject selection for UNIVEN.
- For WSU, maintain separate Commerce and Education profiles because LO treatment differs. For UFH, restrict the capped-LO profile to Management & Commerce until other faculties are verified.
- For NMU, capture verified school quintile before granting any LO-related bonus.
- Treat Grade 11, Grade 12 mid-year/trial and final results as distinct milestones. UP and UJ demonstrate why their use cannot be assumed identical across universities.
- Display academic requirements, missing evidence and application-window status separately. Meeting listed minimums is not an admission offer.

## Preview validation

Passed JavaScript syntax, 26 unique institutions and their sample totals, 104 missing/out-of-range mark cases, CPUT method selection, weighted-subject boundaries and withheld totals for unresolved bands. Browser rendering and interaction have not been executed because no browser runtime is available. These checks validate scoped review arithmetic, not all admissions policies.

Sample totals are tied to the fixed curriculum above. CPUT Method 1 is 43.2 and Method 3 is 57.5; Method 2 is withheld. UCT base APS is 432; faculty FPS/WPS is not inferred. SMU's seven-subject APS is 41, but required science subjects are absent and MBChB eligibility is unassessed. UKZN and UL withhold totals if an academic mark reaches 90%; VUT withholds totals outside its retrieved 40–99% bands.

Institution list: [Universities South Africa — prospective students](https://usaf.ac.za/prospective-students/).
