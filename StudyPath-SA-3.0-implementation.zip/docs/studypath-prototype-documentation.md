# StudyPath SA — Prototype Documentation

**Version:** inherited application build 2.1.1; target release described by the StudyPath SA production build brief  
**Prepared:** 26 October 2026  
**Status:** W0 baseline and implementation plan. Planned features are identified separately from existing prototype behaviour.

## 1. Product overview

StudyPath SA is a South African academic-pathways prototype intended to help a learner organise their marks, explore institution-specific entry requirements, understand possible funding options and keep application documents/deadlines in one place. The production brief prioritises accuracy over breadth: the learner pilot is limited to undergraduate programmes at Walter Sisulu University (WSU), the University of Fort Hare (UFH) and the University of Johannesburg (UJ).

The inherited application already contains registration and email verification, login/recovery, role-based workspaces, results capture, document uploads, university/programme listings, programme-specific scoring configuration and an application workflow. Funding matching, household-income capture, What-If simulation, credit-transfer guidance, recommendation provenance, deadline reminders, encryption of uploaded documents, purpose-specific consent and pilot instrumentation are roadmap work rather than complete features in the supplied baseline.

## 2. User roles and journeys

### Learner

Create an account, maintain a profile, capture examination results, review programmes and available documents, submit an application and track the workflow. Planned additions are the stateless What-If simulator, sourced funding guidance, credit-transfer guidance, Vault checklist, deadline alerts, privacy/consent controls and data export/delete tools.

### Career-guidance teacher

Work only within the assigned school scope, find learners, review results and supporting documents, verify evidence and screen applications. Any future document access must also be covered by the applicable sharing consent.

### University representative

Maintain programmes and published requirements for the assigned institution, manage prospectuses, review screened applications/evidence and record workflow decisions. Representatives may propose data for verification; only authorised administrators should approve scoring policies.

### IT administrator

Maintain accounts, role assignments, school/university directories, programme requirements, security controls and audit history. The target release adds verification-ledger administration, funding maintenance, pilot metrics and data-governance tools.

## 3. Technical architecture

The browser is static HTML/CSS and vanilla JavaScript under `public/`. It calls the Express API in `server/`; it never connects directly to SQL Server. Shared scoring and workflow logic lives under `shared/`. The current code supports Microsoft SQL Server through `mssql` (including a Windows-auth option) and isolated local SQLite mode for tests/demo.

The academic database is `VARSITYVAULT2`, sourced from `database/source/unilink_script_improved.sql`. This source SQL and its 30-table academic schema are protected and must remain unchanged. Existing security/session support is separate in `VarsityVaultSecurity`. The target release adds a third, separate `StudyPathPilot` database with an `sp` schema for provenance, verification, funding, privacy, alerts, templates, pilot measurement and competitor evidence.

## 4. Trust and admissions accuracy

Each institution can calculate APS differently. The current scoring logic supports standard APS and staff-configured scoring rules including points bands/percentages, subject weights and exclusions, alternative required-subject groups, additional documents and application windows. Configuration is not proof that a rule is current or officially verified.

The target accuracy process requires a source title/URL, year/page reference, retrieval date, archived copy/content hash and two independent reviewer sign-offs for every verified programme rule. Golden fixtures must take expected APS and eligibility outcomes from institution-published worked examples or official calculators. Tests assert exact results, deterministic behaviour, subject-order invariance and documented scoring properties. Mismatches are reported, not hidden.

If a rule is missing, stale, conflicting or unverified, the platform must say it cannot confirm/calculate and link the learner to the institution. No interface, email, API or export may guarantee admission, a bursary, credit recognition or exemption. Recommendations require their source, last-updated/verified date and conditions.

## 5. Document Vault, privacy and POPIA

The inherited build stores uploaded documents in `DOCUMENTS.DOCUMENT_BLOB VARBINARY(MAX)`. The supplied build brief identifies that blob content as currently unencrypted at application level; this is a release risk, not a completed security control.

The target design encrypts each document before persistence using AES-256-GCM and a random per-document data key. A versioned envelope is stored in the existing blob column; the key-encryption master key is supplied outside the repository through a secret/environment source, with a key ID for rotation. A resumable, idempotent migration must support dry-run and counts-only logs. Household income is captured as a band by default and encrypted before storage.

Separate consent records are required for processing results, income/funding matching, sharing with a school/institution, pilot research and email reminders. Under-18 learners require recorded parent/guardian confirmation before income/document features unlock. The target also includes authenticated short-lived downloads, access logging, retention policy, privacy notice, export/delete requests, and operational guidance for encrypted SQL connections, TDE and backups. These controls must be tested and configured; documentation alone does not mean they are enabled.

## 6. Pilot scope and measurement

The target learner scope is undergraduate programmes at WSU, UFH and UJ. Other institution records stay in the register but are hidden from learner calculations/applications while flagged out. Postgraduate functionality stays disabled. The public-facing cycle labels now show the 2027 undergraduate pilot and learner-facing university catalogues are limited to WSU, UFH and UJ while pilot mode is active. The wider institution register remains available to administrators as a roadmap. Institution-specific rules themselves remain unverified until official sources, two independent sign-offs and golden accuracy fixtures are supplied.

The pilot should measure three outcomes: (1) time needed to research eligible courses before/after StudyPath; (2) unsuitable applications prevented by a subject-rule guard; and (3) deadline outcomes such as reminders opened and applications/uploads completed on time. Pilot activity is recorded only with research consent. Identity mapping is separately protected, exports are pseudonymous, and dashboard groups smaller than five are suppressed. Results must disclose sample size, self-selection and measurement limits.

## 7. Developer setup and current validation status

The repository is designed for Windows, PowerShell, VS Code and SSMS. The declared runtime requirement is Node.js 24.15+ in the 24.x line or Node.js 26+. Use a private `.env` file for secrets; do not commit it. Standard local commands are:

```powershell
npm ci
npm test
npm run format:check
npm run db:check
npm start
```

The W0 environment had Node.js 22.16.0, below the declared requirement. `npm ci` did not complete in two attempts. A test attempt reported 41 passing and three failing test-file loads because `express`, `jsdom` and `nodemailer` had incomplete package entry points. `npm run format:check` could not start because Prettier was not installed. A separate newly added branding test file passed both tests. No live SQL Server migration, TDE setup or live application smoke test was performed. These results are an incomplete baseline, not a clean release validation.

## 8. Roadmap and release gates

The build brief orders work as follows: W0 baseline/planning and rebrand; W1 narrow verified pilot data; W2 What-If; W3 credit-transfer guidance; W4 sourced funding matching; W5 document encryption/privacy/POPIA; W6 recommendation provenance; W7 checklist/alerts/templates; W8 competitor comparison; W9 pilot instrumentation; W10 quality/security/release engineering; W11 documentation and handover.

A release should not be called complete until dependencies install on the supported Node version; the existing tests still pass; golden accuracy, wording-lint, provenance and migration tests pass; the new verification/encryption/privacy flows are exercised; SQL migrations are idempotent on a real SQL Server test instance; formatting is clean; and keyboard/mobile/role-boundary smoke checks are recorded. The target `npm run verify` command consolidates the quality gates. Version 3.0.0 should be assigned only after the defined release criteria are met.

## 9. Open inputs

The team must provide official prospectus/calculator worked examples and current admission requirements for WSU, UFH and UJ; two independent verifiers; attributable funding criteria and deadlines; receiving-institution RPL/credit policies; approved Information Officer details and retention defaults; and a SQL Server test environment for migration/security validation. Anything unavailable remains unverified and is tracked in `docs/open-items.md`; it must not be replaced with guessed values.
