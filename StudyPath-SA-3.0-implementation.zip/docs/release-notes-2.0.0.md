# Varsity Vault 2.0.0 — full web application release

This release packages Varsity Vault as a web application for VS Code, HTML, CSS, browser JavaScript, Node.js/Express and Microsoft SQL Server. SQL Server remains the persistent system of record; browser code calls the application API and never connects directly to the database.

## Included

- Four role-scoped portals for learners, Career Guidance Teachers, University Representatives and IT Administrators.
- Multi-step application submission, results capture by milestone, evidence/document handling, verification gates, screening and final admission decisions.
- Programme requirement management, eligibility feedback, closing-date enforcement and dated application history.
- Session security, parameterized database access, email verification/recovery, login throttling, audit records and optional administrator MFA.
- Responsive branded UI, reusable frontend scripts/styles, Windows/VS Code launch helpers and automated tests.

The main academic database contract is preserved. The app does not auto-import records, fabricate university requirements, or run a schema migration against the academic database. A configured SQL Server instance and institution-verified application data are required for a real deployment.

## Validation in this build environment

- JavaScript syntax and static/unit tests that do not require third-party packages are run during packaging.
- Full API/interface tests require a complete dependency install under the supported Node.js runtime.
- Live SQL Server integration has not been executed in this packaging environment. Run `npm ci`, `npm test`, `npm run db:check` and smoke-test each portal in your own VS Code/SQL Server environment before production.
