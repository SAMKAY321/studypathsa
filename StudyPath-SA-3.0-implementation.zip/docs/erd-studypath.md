# StudyPathPilot ERD and data dictionary

The existing `VARSITYVAULT2` 30-table academic schema and `database/source/unilink_script_improved.sql` are preserved. New StudyPath SA operational data lives in the separate `StudyPathPilot` database under schema `sp`. Person IDs are soft references across databases; the application validates identity and scope and SQL Server cross-database foreign keys are not used for personal identity.

## Relationship overview

```mermaid
erDiagram
    Source ||--o{ RequirementProvenance : documents
    RequirementProvenance ||--o{ ScoringPolicyVerification : supports
    ScoringPolicyVerification ||--o{ VerificationSignoff : reviewed_by
    Funder ||--o{ FundingOpportunity : publishes
    FundingOpportunity ||--o{ FundingCriterion : has
    FundingOpportunity ||--o{ FundingDocumentRequirement : requires
    Consent }o--|| LearnerFinancialProfile : authorises
    PilotCohort ||--o{ PilotParticipant : enrols
    PilotParticipant ||--o{ PilotEvent : emits
    PilotParticipant ||--o{ PilotBaselineTask : completes
    PilotParticipant ||--o{ PilotSurvey : responds
    Competitor ||--o{ CompetitorFeature : compared_by
    CompetitorFeature ||--o{ CompetitorEvidence : evidenced_by
    PersonData ||--o{ DeadlineAlert : receives
    PersonData ||--o{ DataSubjectRequest : requests
    PersonData ||--o{ DocumentAccessLog : audits
```

`PersonData` is a conceptual label for the existing application person record, not a table created in StudyPathPilot.

## Table dictionary

| Table | Role and key data |
|---|---|
| `sp.MigrationLog` | Migration ID primary key, application timestamp and login. Tracks applied SQL migration files. |
| `sp.Source` | Authoritative source metadata: title, HTTPS URL, document year/page, retrieved date, content hash, archived copy path and source type. |
| `sp.RequirementProvenance` | Institution/programme requirements JSON, source, conditions, last-updated date and lifecycle status. Uniquely keyed by institution code + programme code. |
| `sp.ScoringPolicyVerification` | Intake-specific programme verification status, linked provenance and requirement JSON; two distinct approvals are required before verified. |
| `sp.VerificationSignoff` | Reviewer account/role, approve/reject decision, notes and timestamp; one signoff per reviewer per verification record. |
| `sp.Funder` | Funder name/type and source metadata/state. |
| `sp.FundingOpportunity` | Funding title, criteria reference, opening/closing dates, conditions, required docs, source and status. Closed/past/stale/unverified records are not actionable. |
| `sp.FundingCriterion` | Individual matching criterion by field/operator/value; one field criterion per opportunity in current design. |
| `sp.FundingDocumentRequirement` | Documents a funding opportunity requests, with links to checklist item metadata where available. |
| `sp.CreditTransferGuidance` | Receiving institution/programme guidance, published policy source, conditions, last update and verification state; guidance only, not a credit award. |
| `sp.Consent` | Person ID, purpose, version, grant/withdraw timestamps, age attestation and guardian-confirmation record. Person ID is a soft reference. |
| `sp.LearnerFinancialProfile` | One encrypted envelope per person containing income band and selected matching profile fields; separate key ID and update timestamps. |
| `sp.DocumentAccessLog` | Document/accessor IDs, purpose, role and access timestamp; no document content. |
| `sp.DataSubjectRequest` | Export/delete request lifecycle, schedule, cooling-off and outcome notes. |
| `sp.RetentionPolicy` | Configurable retention days and enable flag by record type. Values are defaults until approved by the Information Officer. |
| `sp.DeadlineAlert` | Person, item/channel, lead days, send status, due/created/sent times, mute and generic error metadata; unique alert key prevents duplicates. |
| `sp.DocumentTemplate` | Published template slug, title/summary, file path, last review and status. Files reside in `public/templates/`. |
| `sp.ChecklistItem` | Per-person programme/funding item, document label/type, status, due date and linked document ID. |
| `sp.PilotCohort` | Cohort label/date window/status. |
| `sp.PilotParticipant` | Cohort, person soft link, random pilot code, consented/withdrawn timestamps. |
| `sp.PilotEvent` | Participant, event type/time and minimised metadata JSON. Never store PII in metadata. |
| `sp.PilotBaselineTask` | Baseline/tool task times, duration, courses found and task type. |
| `sp.PilotSurvey` | Survey stage, score fields, perceived time saved, previous missed deadlines and free text. Review free text for accidental identifiers. |
| `sp.Competitor` | Competitor name/website/current review status. |
| `sp.CompetitorFeature` | Dated feature observation and verification status. |
| `sp.CompetitorEvidence` | Evidence URL/title/retrieval date tied to one feature record. |
| `sp.FeatureFlag` | Feature key, enabled flag, JSON value and update metadata. |

The executable table/column contract is `server/pilot-store.js` and the migration DDL under `database/migrations/`. The contract and each migration still require comparison against a live SQL Server instance before release. The figure above is a conceptual overview; use table definitions and foreign keys in the SQL migrations for precise physical constraints.
