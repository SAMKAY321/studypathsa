import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assessSubjects } from '../shared/scoring/subjects.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const institutions = ['wsu', 'ufh', 'uj'];
const validDate = (value) => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
const validSource = (source) => Boolean(source && typeof source.title === 'string' && source.title.trim() && /^https:\/\//i.test(source.url || '') && typeof source.pageRef === 'string' && source.pageRef.trim() && validDate(source.retrievedOn));
const summary = { generatedAt: new Date().toISOString(), status: 'blocked-unverified', institutions: [] };
let totalCases = 0, totalPassed = 0;
for (const institution of institutions) {
  const fixturePath = resolve(root, `tests/fixtures/golden/${institution}.json`);
  let fixture;
  try { fixture = JSON.parse(await readFile(fixturePath, 'utf8')); }
  catch { fixture = { institution, cases: [], verifiedExamplesSource: null }; }
  const topSourceValid = validSource(fixture.verifiedExamplesSource);
  const rows = [];
  for (const item of Array.isArray(fixture.cases) ? fixture.cases : []) {
    let actual, passed = false, error = null;
    try {
      actual = assessSubjects(item.subjects, item.policy ?? null, item.config ?? {});
      passed = actual.total === item.expected?.total && actual.eligible === item.expected?.eligible && actual.status === item.expected?.status;
    } catch (e) { error = String(e?.message || 'calculation error'); }
    const sourceValid = validSource(item.source) && typeof item.programmeCode === 'string' && item.programmeCode.trim();
    passed = passed && sourceValid;
    totalCases += 1;
    if (passed) totalPassed += 1;
    rows.push({ id: item.id || null, programmeCode: item.programmeCode || null, passed, sourceValid, expected: item.expected || null, actual: actual ? { total: actual.total, eligible: actual.eligible, status: actual.status } : null, error, source: item.source || null });
  }
  const groups = Object.groupBy ? Object.groupBy(rows, (r) => r.programmeCode || '(missing programme code)') : rows.reduce((acc, row) => { const key = row.programmeCode || '(missing programme code)'; (acc[key] ||= []).push(row); return acc; }, {});
  const programmeCoverage = Object.entries(groups).map(([programmeCode, cases]) => ({ programmeCode, cases: cases.length, passed: cases.filter((r) => r.passed).length, ready: cases.length >= 25 && cases.every((r) => r.passed) }));
  const allSourced = rows.length > 0 && topSourceValid && rows.every((r) => r.sourceValid);
  const releaseReady = rows.length > 0 && allSourced && programmeCoverage.length > 0 && programmeCoverage.every((group) => group.ready) && rows.every((r) => r.passed);
  summary.institutions.push({ institution, cases: rows.length, passed: rows.filter((r) => r.passed).length, passRate: rows.length ? rows.filter((r) => r.passed).length / rows.length : null, topSourceValid, allSourced, programmeCoverage, verifiedExamplesSource: fixture.verifiedExamplesSource || null, releaseReady, casesDetail: rows });
}
summary.totalCases = totalCases;
summary.totalPassed = totalPassed;
summary.passRate = totalCases ? totalPassed / totalCases : null;
summary.status = summary.institutions.every((item) => item.releaseReady) ? 'pass' : 'blocked-unverified';
const lines = [
  '# StudyPath SA scoring accuracy report', '',
  `Generated: ${summary.generatedAt}`, '',
  `**Overall status: ${summary.status}.** ${totalPassed}/${totalCases} golden cases passed.`, '',
  'An institution-level source is required, every case must identify its programme and source, exact expected outputs must match, and each programme must have at least 25 source-backed cases for the release gate. A missing fixture or source is not a pass. No 2027 requirements are inferred.', '',
  '| Institution | Golden cases | Passed | Pass rate | Programme coverage | Source | Release gate |', '|---|---:|---:|---:|---|---|---|',
  ...summary.institutions.map((item) => `| ${item.institution.toUpperCase()} | ${item.cases} | ${item.passed} | ${item.passRate === null ? 'N/A' : `${(item.passRate * 100).toFixed(1)}%`} | ${item.programmeCoverage.length ? item.programmeCoverage.map((g) => `${g.programmeCode}: ${g.passed}/${g.cases}${g.ready ? ' PASS' : ' BLOCKED (<25 or mismatch)'}`).join('; ') : 'Missing programme cases'} | ${item.allSourced ? 'Complete' : 'Missing source metadata'} | ${item.releaseReady ? 'PASS' : 'BLOCKED'} |`),
  '', '## Open discrepancies', '',
  ...summary.institutions.map((item) => {
    if (!item.cases) return `- **${item.institution.toUpperCase()}**: No official worked examples or calculator results imported. Admissions reviewers must provide rule sources, archived examples, page references, retrieval date and expected calculation results.`;
    return `- **${item.institution.toUpperCase()}**: ${item.cases - item.passed} failing or unsourced case(s); verify source metadata and the 25-case minimum for every programme: ${item.programmeCoverage.map((g) => `${g.programmeCode} (${g.passed}/${g.cases})`).join(', ')}.`;
  }),
  '', '## Interpretation', '',
  'A 100% rate is meaningful only for a non-empty, per-programme golden suite with official sources and at least 25 exact passing cases per programme. Empty suites are deliberately blocked, not reported as accurate. The status in this report is one of the server-side gates for enabling a programme.', '',
];
await mkdir(resolve(root, 'docs'), { recursive: true });
await writeFile(resolve(root, 'docs/accuracy-report.md'), lines.join('\n'));
console.log(`Accuracy report: ${summary.status}; ${totalPassed}/${totalCases} cases passed. Each programme needs 25 sourced exact cases; blocked is not a pass.`);
if (summary.status !== 'pass') process.exitCode = 2;
