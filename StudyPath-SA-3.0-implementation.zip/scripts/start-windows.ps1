$ErrorActionPreference = 'Stop'
if (-not (Test-Path '.env')) {
  throw 'Missing .env. Create it from .env.example and configure the SQL Server connection first.'
}
if (-not (Test-Path 'node_modules/express/package.json')) {
  throw 'Dependencies are not installed. Run .\scripts\setup-windows.ps1 first.'
}
$nodeVersion = (& node --version 2>$null)
if (-not $nodeVersion) { throw 'Node.js is not available in PATH.' }
$version = [version]($nodeVersion.TrimStart('v') -replace '-.*$', '')
if (($version.Major -lt 24) -or ($version.Major -eq 24 -and $version -lt [version]'24.15.0')) {
  throw "Detected Node.js $nodeVersion. Use Node.js 24.15+ or 26+ for this project."
}
npm run dev
