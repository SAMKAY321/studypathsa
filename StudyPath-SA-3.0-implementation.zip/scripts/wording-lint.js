import { readdir, readFile } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const targets = ['public', 'server', 'shared', 'emails'];
const forbidden = [
  ['you will get credits', /\byou will get credits\b/i],
  ['you will receive credits', /\byou will receive credits\b/i],
  ['guaranteed credit', /\bguaranteed credit\b/i],
  ['automatic credit', /\bautomatic credit\b/i],
  ['you qualify for exemption', /\byou qualify for exemption\b/i],
  ['guaranteed bursary', /\bguaranteed bursary\b/i],
  ['you will receive funding', /\byou will receive funding\b/i],
  ['you qualify for the bursary', /\byou qualify for the bursary\b/i],
  ['guaranteed admission', /\bguaranteed admission\b/i],
  ['you are guaranteed admission', /\byou are guaranteed admission\b/i],
  ['you will be admitted', /\byou will be admitted\b/i],
];
const eligible = new Set(['.js', '.html', '.mjs', '.txt', '.md', '.json', '.mjml']);
const findings = [];
async function walk(path) {
  let entries;
  try { entries = await readdir(path, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.data') continue;
    const full = resolve(path, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (eligible.has(entry.name.slice(entry.name.lastIndexOf('.')))) {
      const text = await readFile(full, 'utf8').catch(() => '');
      const lines = text.split(/\r?\n/);
      lines.forEach((line, index) => {
        // Text explaining a prohibition is allowed; the positive claim itself is not.
        const normalized = line.toLowerCase();
        if (normalized.includes('forbidden') || normalized.includes('must not say') || normalized.includes('do not say') || normalized.includes('wording-lint')) return;
        for (const [label, rule] of forbidden) if (rule.test(line)) findings.push(`${relative(root, full)}:${index + 1}: prohibited phrase (${label})`);
      });
    }
  }
}
for (const target of targets) await walk(resolve(root, target));
if (findings.length) {
  console.error('Wording lint failed:\n' + findings.join('\n'));
  process.exitCode = 1;
} else console.log('Wording lint passed. No prohibited certainty claims found in runtime content.');
