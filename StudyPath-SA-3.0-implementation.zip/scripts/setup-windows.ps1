$ErrorActionPreference = 'Stop'

$nodeVersion = (& node --version 2>$null)
if (-not $nodeVersion) {
  throw 'Node.js 24.15+ is required. Install Node.js, restart VS Code, and run this task again.'
}
$version = [version]($nodeVersion.TrimStart('v') -replace '-.*$', '')
if (($version.Major -lt 24) -or ($version.Major -eq 24 -and $version -lt [version]'24.15.0')) {
  throw "Detected Node.js $nodeVersion. Use Node.js 24.15+ or 26+ for this project."
}

if (-not (Test-Path '.env')) {
  Copy-Item '.env.example' '.env'
  Write-Host 'Created .env from .env.example. Edit the SQL Server and administrator settings before continuing.' -ForegroundColor Yellow
}

npm ci
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed. Review the npm output and retry.' }
Write-Host 'Dependencies installed. Configure .env for your SQL Server, then run npm run db:check.' -ForegroundColor Green
