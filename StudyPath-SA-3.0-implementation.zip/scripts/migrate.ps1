[CmdletBinding()]
param(
  [string]$Server = $env:DB_SERVER,
  [string]$Database = 'master',
  [string]$SqlcmdPath = 'sqlcmd',
  [switch]$WindowsAuth,
  [string]$Username = $env:DB_USER,
  [string]$Password = $env:DB_PASSWORD
)
$ErrorActionPreference = 'Stop'
if (-not $Server) { throw 'Supply -Server or set DB_SERVER.' }
$root = Split-Path -Parent $PSScriptRoot
$migrations = Get-ChildItem (Join-Path $root 'database/migrations') -Filter '*.sql' | Where-Object { $_.Name -ne '999_rollback.sql' } | Sort-Object Name
foreach ($migration in $migrations) {
  Write-Host ("[{0}] Running {1}" -f (Get-Date -Format 'HH:mm:ss'), $migration.Name) -ForegroundColor Cyan
  $args = @('-S', $Server, '-b', '-i', $migration.FullName)
  if ($WindowsAuth) { $args += '-E' }
  else {
    if (-not $Username -or -not $Password) { throw 'Supply -Username/-Password or configure DB_USER/DB_PASSWORD, or use -WindowsAuth.' }
    $args += @('-U', $Username, '-P', $Password)
  }
  & $SqlcmdPath @args
  if ($LASTEXITCODE -ne 0) { throw ("Migration failed: {0} (sqlcmd exit {1})" -f $migration.Name, $LASTEXITCODE) }
  Write-Host ("[OK] {0}" -f $migration.Name) -ForegroundColor Green
}
$seed = Join-Path $root 'database/seed/pilot-seed.sql'
Write-Host '[SEED] Applying pilot flags and explicitly unverified competitor placeholders' -ForegroundColor Cyan
$args = @('-S', $Server, '-b', '-i', $seed)
if ($WindowsAuth) { $args += '-E' } else { $args += @('-U', $Username, '-P', $Password) }
& $SqlcmdPath @args
if ($LASTEXITCODE -ne 0) { throw "Pilot seed failed (sqlcmd exit $LASTEXITCODE)." }
Write-Host 'StudyPathPilot migrations and seed completed.' -ForegroundColor Green
