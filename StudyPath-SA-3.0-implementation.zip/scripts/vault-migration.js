import { loadSqlDriver } from '../server/db/driver.js';
import { databaseConfig } from '../server/db/config.js';
import { encryptDocument, isEncryptedDocument, rewrapDocument } from '../server/vault-crypto.js';

const mode = process.argv.includes('--rotate') ? 'rotate' : 'encrypt';
const dryRun = process.argv.includes('--dry-run');
let pool;
try {
  if (!process.env.VAULT_MASTER_KEY) throw new Error('VAULT_MASTER_KEY is required.');
  const sql = await loadSqlDriver();
  pool = new sql.ConnectionPool(databaseConfig());
  pool.on('error', () => console.error('Vault migration SQL pool error.'));
  await pool.connect();
  let lastId = 0, scanned = 0, changed = 0, skipped = 0;
  while (true) {
    const read = await pool.request()
      .input('lastId', sql.Int, lastId)
      .query('SELECT TOP (100) DOCUMENT_ID,DOCUMENT_BLOB FROM dbo.DOCUMENTS WHERE DOCUMENT_ID>@lastId AND DOCUMENT_BLOB IS NOT NULL ORDER BY DOCUMENT_ID');
    if (!read.recordset.length) break;
    for (const row of read.recordset) {
      lastId = Number(row.DOCUMENT_ID); scanned += 1;
      const original = Buffer.from(row.DOCUMENT_BLOB);
      let output;
      if (mode === 'encrypt') {
        if (isEncryptedDocument(original)) { skipped += 1; continue; }
        output = encryptDocument(original);
      } else {
        if (!isEncryptedDocument(original)) { skipped += 1; continue; }
        output = rewrapDocument(original);
        if (output.equals(original)) { skipped += 1; continue; }
      }
      changed += 1;
      if (!dryRun) {
        const update = await pool.request()
          .input('id', sql.Int, row.DOCUMENT_ID)
          .input('original', sql.VarBinary(sql.MAX), original)
          .input('value', sql.VarBinary(sql.MAX), output)
          .query('UPDATE dbo.DOCUMENTS SET DOCUMENT_BLOB=@value WHERE DOCUMENT_ID=@id AND DOCUMENT_BLOB=@original');
        if (!update.rowsAffected[0]) throw new Error(`Document ${row.DOCUMENT_ID} changed concurrently; stop and retry.`);
      }
    }
  }
  console.log(JSON.stringify({ mode, dryRun, scanned, changed, skipped }, null, 2));
} catch (error) {
  console.error('Vault migration failed:', error.message);
  process.exitCode = 1;
} finally { if (pool) await pool.close(); }
