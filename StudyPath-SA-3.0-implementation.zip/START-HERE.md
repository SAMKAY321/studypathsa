# Upgrade to StudyPath SA 3.0.0 — Windows / PowerShell

This upgrade adds the StudyPathPilot operational database and new pilot services. It preserves the existing `VARSITYVAULT2` academic schema and internal identifiers. **Back up your app folder, `.env`, `.data`, academic database and security database first.**

## 1. Check the runtime and dependencies

Use Node.js 24.15+ (24.x) or Node.js 26+.

```powershell
node --version
npm ci
```

Do not continue to a live deployment if `npm ci` fails or you cannot run the full test/format suite. Keep the currently working `.env` and `.data` directories when extracting the project source.

## 2. Configure the environment

Review `.env.example`; preserve your current valid SQL/email/auth values. For production:

- `APP_MODE=sqlserver`.
- `DB_DATABASE` must be `VARSITYVAULT2` or omitted; the server fails closed on another value.
- Use TLS with certificate validation (`DB_TRUST_SERVER_CERTIFICATE=false`) and a least-privilege database identity.
- Configure `VAULT_MASTER_KEY` as base64 encoding of 32 cryptographically random bytes, set `VAULT_KEY_ID`, and protect previous key material during rotation. Store secrets outside source control and the web root.
- Keep `CLAMAV_ENABLED=false` unless a real scanner has been integrated, configured and tested.

The app's guardian-confirmation flag does not itself verify adult identity or the guardian relationship. Do not onboard minors with financial/document features until an approved verification process exists.

## 3. Run new database migrations

Run in a test SQL Server first. Then, when approved, use the project root in PowerShell:

```powershell
npm run db:migrate
npm run db:check
```

The migrations create/extend `StudyPathPilot`. They must not run the academic source script or modify the 30-table academic ERD. `db:check` reads schema metadata only. Check every script output and rerun the migration command in the disposable database to verify idempotency before moving on.

## 4. Run checks

```powershell
npm test
npm run format:check
npm run accuracy
npm run wording:lint
npm run verify
```

The accuracy command will remain blocked until the admissions verification team supplies official WSU/UFH/UJ 2027 rules and sourced worked examples/calculator outputs, the rules have two independent sign-offs and golden fixtures pass. A blocked accuracy report is an expected gate, not permission to launch recommendations.

## 5. Stage and test vault migration

After a protected backup, review what would be migrated:

```powershell
npm run vault:encrypt-existing -- --dry-run
```

Only execute the migration after confirming the key and recovery plan:

```powershell
npm run vault:encrypt-existing
```

For key rotation, configure the new active key and keep the old key in `VAULT_PREVIOUS_MASTER_KEYS` until all rows have been rewrapped and restore/decrypt tests pass:

```powershell
npm run vault:rotate-key
```

Do not run bulk migration or key rotation against live learner documents without a tested recovery route.

## 6. Start and schedule jobs

```powershell
npm start
```

After mail consent and scheduling have been tested, configure Windows Task Scheduler to run `npm run alerts:run` and `npm run privacy:process-deletions` at the approved cadence. Review failures and deletion partial outcomes; the academic and pilot DB operations are not a single cross-database transaction.

## 7. Before pilot launch

The product is not production-ready until all P0/P1 items in `docs/open-items.md` are resolved. This includes official 2027 programme evidence, two reviewers, non-empty golden fixtures, verified funder criteria, guardian verification for minors, approved privacy notice/Information Officer details, live SQL Server migration/idempotency validation, full tests/formatter and production vault/backup recovery checks.

Use `docs/demo-script.md` for an honest demo: show unverified states rather than inventing institutional thresholds. `docs/security-and-popia.md`, `docs/data-verification-process.md`, `docs/pilot-plan.md` and `docs/incident-response.md` cover the operational controls.

### Retention review

Run `npm run retention:run` for a read-only candidate report. Do not enable deletion until the Information Officer approves the policy and manifest workflow. Expiry and inactivity remain blocked without authoritative fields in the preserved academic schema.
