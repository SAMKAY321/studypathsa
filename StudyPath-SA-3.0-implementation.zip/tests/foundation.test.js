import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { databaseConfig } from '../server/db/config.js';
import { scoreReview, sampleMarks } from '../shared/scoring/review.js';
const policies = JSON.parse(
  readFileSync(new URL('../config/universities/2027/register.json', import.meta.url)),
);
const byId = (id) => policies.find((p) => p.id === id);
test('26 scoped review profiles retain verified arithmetic and deny eligibility', () => {
  assert.equal(policies.length, 26);
  assert.equal(new Set(policies.map((p) => p.id)).size, 26);
  const totals = {
    cput: 43.2,
    cut: 35,
    dut: 34,
    mut: 34,
    nmu: 432,
    nwu: 34,
    rhodes: 43.2,
    smu: 41,
    spu: 41,
    su: 72,
    tut: 34,
    unisa: 34,
    uct: 432,
    ufh: 38,
    ufs: 35,
    uj: 34,
    ukzn: 34,
    ul: 34,
    ump: 37.5,
    up: 34,
    univen: 43.2,
    uwc: 46,
    wits: 41,
    unizulu: 34,
    vut: 34,
    wsu: 34,
  };
  for (const [id, total] of Object.entries(totals)) {
    const result = scoreReview(sampleMarks, byId(id));
    assert.equal(result.total, total, id);
    assert.equal(result.eligibility, 'not_assessed');
    assert.equal(result.submissionEnabled, false);
    for (const invalid of [null, '', true, -1, 101, NaN, Infinity]) {
      const marks = [...sampleMarks];
      marks[1] = invalid;
      assert.equal(scoreReview(marks, byId(id)).total, null, id);
    }
  }
});
test('missing science, invalid methods and unresolved bands withhold a total', () => {
  assert.equal(scoreReview(sampleMarks, byId('cput'), 'method3').total, 57.5);
  assert.equal(scoreReview(sampleMarks, byId('cput'), 'method2').total, null);
  assert.equal(scoreReview(sampleMarks, byId('cput'), 'unknown').total, null);
  for (const id of ['ul', 'ukzn'])
    assert.equal(scoreReview([90, ...sampleMarks.slice(1)], byId(id)).total, null);
  for (const mark of [39, 100])
    assert.equal(scoreReview([mark, ...sampleMarks.slice(1)], byId('vut')).total, null);
  assert.equal(scoreReview(sampleMarks, { engine: 'unknown' }).total, null);
  assert.equal(scoreReview(sampleMarks.slice(1), byId('uj')).total, null);
});
test('database config validates port/instance and never defaults credentials', () => {
  assert.throws(() => databaseConfig({}), /DB_SERVER/);
  const env = { DB_SERVER: 'localhost', DB_USER: 'test', DB_PASSWORD: 'test' };
  const config = databaseConfig(env);
  assert.equal(config.database, 'VARSITYVAULT2');
  assert.equal(config.options.encrypt, true);
  assert.equal(config.options.trustServerCertificate, false);
  assert.throws(() => databaseConfig({ ...env, DB_PORT: 'abc' }), /DB_PORT/);
  assert.throws(
    () => databaseConfig({ ...env, DB_PORT: '1433', DB_INSTANCE: 'SQLEXPRESS' }),
    /either/,
  );
  assert.equal(
    databaseConfig({ ...env, DB_INSTANCE: 'SQLEXPRESS' }).options.instanceName,
    'SQLEXPRESS',
  );
  assert.throws(() => databaseConfig({ ...env, DB_DATABASE: 'Other' }), /submitted/);
});
