import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const publicRoot = join(projectRoot, 'public');

function filesBelow(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolute = join(directory, entry.name);
    return entry.isDirectory() ? filesBelow(absolute) : [absolute];
  });
}

function localTarget(sourceFile, rawValue, isRootRelative) {
  const value = rawValue.trim();
  if (
    !value ||
    value.startsWith('#') ||
    /^(?:https?:|mailto:|tel:|data:|javascript:|\/\/)/i.test(value)
  )
    return null;
  const path = value.split(/[?#]/, 1)[0];
  if (!path) return null;
  return isRootRelative || path.startsWith('/')
    ? join(publicRoot, path.replace(/^\/+/, ''))
    : resolve(dirname(sourceFile), path);
}

test('all local HTML and CSS resource references resolve inside public/', () => {
  const pages = filesBelow(publicRoot).filter((file) => file.endsWith('.html'));
  const stylesheets = filesBelow(publicRoot).filter((file) => file.endsWith('.css'));
  const missing = [];

  for (const page of pages) {
    const source = readFileSync(page, 'utf8');
    for (const [, attribute, value] of source.matchAll(/\b(href|src)\s*=\s*["']([^"']+)["']/gi)) {
      const target = localTarget(page, value, value.startsWith('/'));
      if (target && !existsSync(target))
        missing.push(`${relative(projectRoot, page)}: ${attribute}="${value}"`);
    }
  }

  for (const stylesheet of stylesheets) {
    const source = readFileSync(stylesheet, 'utf8');
    for (const [, value] of source.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/gi)) {
      const target = localTarget(stylesheet, value, value.trim().startsWith('/'));
      if (target && !existsSync(target))
        missing.push(`${relative(projectRoot, stylesheet)}: url(${value})`);
    }
  }

  assert.deepEqual(missing, [], `Unresolved local page/asset references:\n${missing.join('\n')}`);
  assert.equal(pages.length, 51, 'The app page inventory changed; review the audit count.');
  assert.equal(stylesheets.length, 4, 'The stylesheet inventory changed; review the audit count.');
});
