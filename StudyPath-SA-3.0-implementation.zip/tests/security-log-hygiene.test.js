import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { scrubSensitiveLogText } from '../server/log-scrub.js';

const root = resolve(new URL('..', import.meta.url).pathname);

test('server error log scrubber redacts emails, South African ID numbers, phone numbers and amounts', () => {
  const result = scrubSensitiveLogText('contact learner@example.org ID 8001015009087 phone 082 123 4567 household income R25,000 - R50,000');
  assert.doesNotMatch(result, /learner@example\.org|8001015009087|082 123 4567|R25,000|R50,000/i);
  assert.match(result, /redacted-email/);
  assert.match(result, /redacted-id-number/);
  assert.match(result, /redacted-phone/);
  assert.match(result, /redacted-amount/);
});

test('application errors use scrubbed messages and required response security headers', () => {
  const app = readFileSync(resolve(root, 'server/app.js'), 'utf8');
  assert.match(app, /scrubSensitiveLogText\(error\.message\)/);
  assert.match(app, /Permissions-Policy/);
  assert.match(app, /X-Content-Type-Options/);
  assert.match(app, /Content-Security-Policy/);
});
