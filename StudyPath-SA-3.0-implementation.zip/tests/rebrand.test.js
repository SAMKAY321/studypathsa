import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';

const root = path.resolve(import.meta.dirname, '..');

async function filesUnder(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const target = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...(await filesUnder(target)));
    else if (/\.(html|css|js|svg)$/i.test(entry.name)) files.push(target);
  }
  return files;
}

test('user-facing public assets use the StudyPath SA brand', async () => {
  const files = await filesUnder(path.join(root, 'public'));
  const oldBrandFiles = [];
  for (const file of files) {
    const content = await readFile(file, 'utf8');
    if (/Varsity\s?Vault/i.test(content)) oldBrandFiles.push(path.relative(root, file));
  }
  assert.deepEqual(oldBrandFiles, []);
});

test('account emails and authenticator labels use the StudyPath SA brand', async () => {
  const targets = [
    'server/account-email.js',
    'server/full-api.js',
    'server/mfa.js',
    'server/index.js',
  ];
  const matches = [];
  for (const file of targets) {
    const content = await readFile(path.join(root, file), 'utf8');
    if (/Varsity\s?Vault/i.test(content)) matches.push(file);
  }
  assert.deepEqual(matches, []);
});
