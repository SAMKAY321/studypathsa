import test from 'node:test';
import assert from 'node:assert/strict';
import { LocalStore } from '../server/storage.js';
import { ensureReferenceData } from '../server/reference-data.js';

test('missing study mode choices are seeded idempotently without replacing custom options', async () => {
  const store = new LocalStore(':memory:');
  try {
    const first = await ensureReferenceData(store);
    assert.deepEqual(first.inserted.sort(), ['Full-time', 'Part-time']);
    await store.insert('STUDY_MODES', { STUDY_MODE_NAME: 'Hybrid' });
    const second = await ensureReferenceData(store);
    assert.deepEqual(second.inserted, []);
    const names = (await store.list('STUDY_MODES')).map((row) => row.STUDY_MODE_NAME).sort();
    assert.deepEqual(names, ['Full-time', 'Hybrid', 'Part-time']);
  } finally {
    await store.close();
  }
});
