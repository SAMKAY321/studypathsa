import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { apsPoints, assessSubjects, curriculum } from '../shared/scoring/subjects.js';
const subjects = JSON.parse(
  readFileSync(new URL('../docs/submitted-subjects.json', import.meta.url)),
);
const rows = (marks = {}) =>
  ['ENGHL', 'AFRFAL', 'MATH', 'LO', 'PHSC', 'LFSC', 'GEOG'].map((code) => ({
    ...subjects.find((subject) => subject.SUBJECT_CODE === code),
    PERCENTAGE: marks[code] ?? 70,
  }));
test('standard APS uses the 1–7 NSC bands and excludes Life Orientation', () => {
  assert.deepEqual(
    [0, 29, 30, 39, 40, 49, 50, 59, 60, 69, 70, 79, 80, 100].map(apsPoints),
    [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7],
  );
  const record = rows({ LO: 100 });
  const result = assessSubjects(record, null, {});
  assert.equal(curriculum(record), true);
  assert.equal(result.total, 36);
  assert.equal(result.contributions.length, 6);
  assert.ok(
    result.contributions.every((subject) => subject.SUBJECT_CATEGORY !== 'LIFE_ORIENTATION'),
  );
  assert.equal(
    assessSubjects(record, null, {
      status: 'verified',
      intake: 2028,
      minScore: 36,
      source: 'https://university.example/requirements',
    }).eligible,
    true,
  );
});
test('curriculum and programme eligibility enforce the published data rules', () => {
  const data = rows();
  assert.equal(curriculum([...data, data[0]]), false);
  assert.equal(curriculum(data.slice(1)), false);
  assert.equal(curriculum(data.map((row) => ({ ...row, PERCENTAGE: 101 }))), false);
  const verified = {
    status: 'verified',
    intake: 2028,
    minScore: 35,
    minEnglish: 70,
    minMath: 70,
    source: 'https://university.example/requirements',
  };
  assert.equal(assessSubjects(data, null, verified).eligible, true);
  assert.equal(assessSubjects(data, null, { ...verified, minScore: 37 }).eligible, false);
  assert.equal(assessSubjects(data, null, { ...verified, minEnglish: 71 }).eligible, false);
  assert.equal(assessSubjects(data, null, { ...verified, minMath: 71 }).eligible, false);
  assert.equal(
    assessSubjects(data, null, { ...verified, intake: 2027 }).status,
    'Programme requirements pending verification',
  );
  assert.equal(
    assessSubjects(data, null, { ...verified, source: 'http://university.example' }).eligible,
    false,
  );
  const withExtra = [
    ...data,
    { ...subjects.find((row) => row.SUBJECT_CODE === 'ACCN'), PERCENTAGE: 100 },
  ];
  assert.equal(
    assessSubjects(withExtra, null, verified).total,
    37,
    'the six highest academic APS subjects are selected',
  );
});
