import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const ddl = readFileSync(
  new URL('../database/source/unilink_script_improved.sql', import.meta.url),
  'utf8',
);
const tableMap = JSON.parse(
  readFileSync(new URL('../config/table-map.json', import.meta.url), 'utf8'),
);
const schemaContract = JSON.parse(
  readFileSync(new URL('../config/schema-contract.json', import.meta.url), 'utf8'),
);

function parseDdlTables(text) {
  const parsed = {};
  for (const match of text.matchAll(/CREATE\s+TABLE\s+(\w+)\s*\((.*?)\);/gis)) {
    const table = match[1].toUpperCase();
    const columns = {};
    for (const line of match[2].split(/\r?\n/)) {
      const row = line.trim().replace(/,$/, '');
      if (!row || /^(CONSTRAINT\b|PRIMARY\s+KEY\b|UNIQUE\b|CHECK\s*\()/i.test(row)) continue;
      const column = row.match(
        /^([A-Za-z_][\w]*)\s+(INT|VARCHAR|NVARCHAR|VARBINARY|BIT|TINYINT|SMALLINT|DECIMAL|DATE)\s*(?:\(([^)]*)\))?/i,
      );
      if (!column) continue;
      const [, name, type, size] = column;
      columns[name.toUpperCase()] = {
        type: type.toUpperCase(),
        size: size ? size.toUpperCase().replace(/\s/g, '') : null,
      };
    }
    parsed[table] = columns;
  }
  return parsed;
}

test('submitted SQL Server DDL and the app column contract remain aligned', () => {
  const ddlTables = parseDdlTables(ddl);
  assert.equal(Object.keys(ddlTables).length, 30);
  assert.equal(Object.keys(tableMap).length, 30);
  let columnCount = 0;
  for (const [table, metadata] of Object.entries(tableMap)) {
    assert.ok(ddlTables[table], `DDL table missing: ${table}`);
    assert.deepEqual(
      Object.keys(ddlTables[table]).sort(),
      Object.keys(metadata.columns).sort(),
      `${table} column names`,
    );
    for (const [name, column] of Object.entries(metadata.columns)) {
      const actual = ddlTables[table][name];
      assert.equal(actual.type, column.type, `${table}.${name} SQL type`);
      const actualSize = actual.size;
      const expectedSize =
        column.size == null ? null : String(column.size).toUpperCase().replace(/\s/g, '');
      assert.equal(actualSize, expectedSize, `${table}.${name} SQL size`);
      columnCount++;
    }
  }
  assert.equal(columnCount, 128);
});

test('schema readiness contract accounts for all supplied SQL objects', () => {
  const objectNames = schemaContract.objects.map((o) => `${o.type}:${o.name.toUpperCase()}`);
  assert.equal(schemaContract.objects.length, 44);
  assert.equal(objectNames.filter((o) => o.startsWith('U:')).length, 30);
  assert.equal(objectNames.filter((o) => o.startsWith('V:')).length, 8);
  assert.equal(objectNames.filter((o) => o.startsWith('FN:')).length, 2);
  assert.equal(objectNames.filter((o) => o.startsWith('P:')).length, 3);
  assert.equal(objectNames.filter((o) => o.startsWith('TR:')).length, 1);
  for (const name of [
    'VIEW_SCHOOL_DIRECTORY',
    'VIEW_UNIVERSITY_DIRECTORY',
    'VIEW_USER_CONTEXT',
    'VIEW_LEARNER_RESULTS_DETAIL',
    'VIEW_LEARNER_SUBMISSION_CHECK',
    'VIEW_APPLICATION_TIMELINE',
    'VIEW_LEARNER_APPLICATIONS',
    'VIEW_UNIVERSITY_APPLICATIONS',
  ]) {
    assert.match(ddl, new RegExp(`CREATE\\s+VIEW\\s+${name}\\b`, 'i'));
  }
  for (const name of [
    'fn_GetLearnerAps',
    'fn_GetEligibility',
    'usp_SubmitApplication',
    'usp_ScreenApplication',
    'usp_ReviewApplication',
    'TRG_DOCUMENTS_LOCK_FINAL',
  ]) {
    assert.match(
      ddl,
      new RegExp(`CREATE\\s+(?:FUNCTION|PROCEDURE|TRIGGER)\\s+(?:dbo\\.)?${name}\\b`, 'i'),
    );
  }
  const fkMatches = [
    ...ddl.matchAll(
      /ALTER\s+TABLE\s+(\w+)\s+ADD\s+CONSTRAINT\s+\w+\s+FOREIGN\s+KEY\s*\(([^)]+)\)\s+REFERENCES\s+(\w+)\s*\(([^)]+)\)/gi,
    ),
  ];
  assert.equal(fkMatches.length, 42);
  const ddlPairs = new Set(fkMatches.map((m) => `${m[3].toUpperCase()}->${m[1].toUpperCase()}`));
  const erdPairs = new Set(
    [
      ...readFileSync(new URL('../docs/erd.md', import.meta.url), 'utf8').matchAll(
        /^\s{4}([A-Z_]+)\s+(?:\|\||o\|)--(?:o\{|o\|)\s+([A-Z_]+)\s+:/gm,
      ),
    ].map((m) => `${m[1]}->${m[2]}`),
  );
  assert.equal(erdPairs.size, 42);
  assert.deepEqual([...erdPairs].sort(), [...ddlPairs].sort());
});
