import test from 'node:test';
import assert from 'node:assert/strict';
import { attachSubjectsToResults } from '../shared/scoring/result-records.js';
import { assessSubjects, curriculum } from '../shared/scoring/subjects.js';

test('joins SQL result rows to subjects when IDs have different JS types', () => {
  const subjects = [
    {
      SUBJECT_ID: '1',
      SUBJECT_NAME: 'English Home Language',
      SUBJECT_CODE: 'ENGHL',
      SUBJECT_CATEGORY: 'HOME_LANGUAGE',
    },
    {
      SUBJECT_ID: 9,
      SUBJECT_NAME: 'isiZulu First Additional Language',
      SUBJECT_CODE: 'ZULFAL',
      SUBJECT_CATEGORY: 'FIRST_ADDITIONAL_LANGUAGE',
    },
    {
      SUBJECT_ID: '10',
      SUBJECT_NAME: 'Mathematics',
      SUBJECT_CODE: 'MATH',
      SUBJECT_CATEGORY: 'MATHEMATICS',
    },
    {
      SUBJECT_ID: 12,
      SUBJECT_NAME: 'Life Orientation',
      SUBJECT_CODE: 'LO',
      SUBJECT_CATEGORY: 'LIFE_ORIENTATION',
    },
    {
      SUBJECT_ID: '13',
      SUBJECT_NAME: 'Physical Sciences',
      SUBJECT_CODE: 'PHSC',
      SUBJECT_CATEGORY: 'ELECTIVE',
    },
    {
      SUBJECT_ID: 14,
      SUBJECT_NAME: 'Life Sciences',
      SUBJECT_CODE: 'LFSC',
      SUBJECT_CATEGORY: 'ELECTIVE',
    },
    {
      SUBJECT_ID: '18',
      SUBJECT_NAME: 'Geography',
      SUBJECT_CODE: 'GEOG',
      SUBJECT_CATEGORY: 'ELECTIVE',
    },
  ];
  const storedRows = [
    [1, 75],
    ['9', 86],
    [10, 54],
    ['12', 77],
    [13, 65],
    ['14', 69],
    [18, 71],
  ].map(([SUBJECT_ID, PERCENTAGE]) => ({ SUBJECT_ID, PERCENTAGE }));

  const hydrated = attachSubjectsToResults(storedRows, subjects);
  assert.equal(hydrated.length, 7);
  assert.equal(
    hydrated.every((row) => row.SUBJECT_NAME && row.SUBJECT_CODE && row.SUBJECT_CATEGORY),
    true,
  );
  assert.equal(curriculum(hydrated), true);
  const assessment = assessSubjects(hydrated, null, {});
  assert.equal(assessment.total, 33);
  assert.equal(assessment.contributions.length, 6);
  assert.ok(assessment.contributions.every((row) => row.SUBJECT_CATEGORY !== 'LIFE_ORIENTATION'));
});

test('keeps an explicit diagnostic label if a result has no catalogue subject', () => {
  const [row] = attachSubjectsToResults([{ SUBJECT_ID: 999, PERCENTAGE: 42 }], []);
  assert.equal(row.SUBJECT_NAME, 'Unknown subject (999)');
  assert.equal(row.PERCENTAGE, 42);
});
