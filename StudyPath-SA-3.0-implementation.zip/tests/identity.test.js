import test from 'node:test';
import assert from 'node:assert/strict';
import { sameId } from '../server/identity.js';

test('database identifiers compare safely across numeric and string driver representations', () => {
  assert.equal(sameId(4, '4'), true);
  assert.equal(sameId('004', 4), true);
  assert.equal(sameId(null, null), false);
  assert.equal(sameId(4, null), false);
  assert.equal(sameId('account-a', 'account-a'), true);
  assert.equal(sameId('account-a', 'account-b'), false);
});
