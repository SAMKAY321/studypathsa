import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);

test('wording lint passes across runtime source', () => {
  const result = spawnSync(process.execPath, ['scripts/wording-lint.js'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
});

test('accuracy report is honestly blocked when official golden examples are absent', () => {
  const result = spawnSync(process.execPath, ['scripts/accuracy.js'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 2, `${result.stdout}\n${result.stderr}`);
  const report = readFileSync(resolve(root, 'docs/accuracy-report.md'), 'utf8');
  assert.match(report, /blocked-unverified/i);
  assert.doesNotMatch(report, /Overall status:\s*100%|Pass rate[^\n]*100%/i);
});

test('pilot scope config excludes postgraduate and non-pilot universities', () => {
  const config = JSON.parse(readFileSync(resolve(root, 'config/pilot.json'), 'utf8'));
  assert.deepEqual(config.pilotInstitutions, ['wsu', 'ufh', 'uj']);
  assert.equal(config.postgraduateEnabled, false);
});

test('academic source schema file exists and no migration alters it', () => {
  const file = readFileSync(resolve(root, 'database/source/unilink_script_improved.sql'), 'utf8');
  assert.ok(file.includes('CREATE TABLE'));
  const migrations = ['001_create_studypath_database.sql','002_trust_and_verification.sql','003_funding.sql','004_credit_transfer.sql','005_privacy.sql','006_vault_alerts_templates.sql','007_pilot_and_competitors.sql','008_feature_flags_and_views.sql'];
  for (const migration of migrations) {
    const sql = readFileSync(resolve(root, 'database/migrations', migration), 'utf8');
    assert.match(sql, /StudyPathPilot/);
    assert.doesNotMatch(sql, /USE\s+VARSITYVAULT2/i);
  }
});

test('ClamAV upload scanner is optional unless explicitly enabled, and stream protocol frames include termination', async () => {
  const { scanBuffer, buildInstreamFrames } = await import('../server/clamav.js');
  assert.deepEqual(await scanBuffer(Buffer.from('safe test'), { CLAMAV_ENABLED: 'false' }), { enabled: false, clean: null });
  const frames = buildInstreamFrames(Buffer.from('abc'), 2);
  assert.equal(frames[0].toString('ascii'), 'zINSTREAM\0');
  assert.equal(frames[1].readUInt32BE(0), 2);
  assert.equal(frames[2].toString(), 'ab');
  assert.equal(frames[3].readUInt32BE(0), 1);
  assert.equal(frames[4].toString(), 'c');
  assert.equal(frames.at(-1).readUInt32BE(0), 0);
});


test('editing a programme rule invalidates old sign-offs and rejection blocks reactivation', () => {
  const api = readFileSync(resolve(root, 'server/full-api.js'), 'utf8');
  assert.match(api, /tx\.remove\('VerificationSignoff', \{ VerificationId: verification\.VerificationId \}\)/);
  assert.match(api, /signoffs\.some\(\(row\) => row\.Decision === 'reject'\)/);
});


test('learner catalogue is scoped to the three pilot institutions while administrators retain roadmap visibility', () => {
  const api = readFileSync(resolve(root, 'server/full-api.js'), 'utf8');
  const ui = readFileSync(resolve(root, 'public/assets/js/full.js'), 'utf8');
  assert.match(api, /scopedUniversities = pilotActive \? universities\.filter/);
  assert.match(api, /pilotActive && u\?\.role !== 'admin' && !\['wsu', 'ufh', 'uj'\]/);
  assert.match(ui, /\['Pilot scope'\]/);
  assert.match(ui, /\? '2027 pilot' : 'Roadmap'/);
});

test('programme and funding CSV imports preserve unchanged rows and do not reuse approvals after rule edits', () => {
  const api = readFileSync(resolve(root, 'server/full-api.js'), 'utf8');
  assert.match(api, /Rows marked unchanged will not be modified on apply/);
  assert.match(api, /change\.unchanged\) \{ out\.push/);
  assert.match(api, /evidence\/rule change invalidates the approvals tied to the previous evidence/);
  assert.match(api, /Unchanged rows were not modified/);
  assert.match(api, /CSV contains duplicate programme row/);
  assert.match(api, /Funding CSV contains duplicate opportunity/);
});

test('admin pages expose explicit CSV dry-run previews and separately confirmed draft imports', () => {
  const ui = readFileSync(resolve(root, 'public/assets/js/full.js'), 'utf8');
  assert.match(ui, /verification-import-form/);
  assert.match(ui, /apply-programme-import/);
  assert.match(ui, /funding-import-form/);
  assert.match(ui, /apply-funding-import/);
  assert.match(ui, /Apply these programme rows as drafts/);
  assert.match(ui, /Apply these funding rows as drafts/);
});


test('requirements and unsuitable-subject acknowledgement use the verified pilot policy end to end', () => {
  const api = readFileSync(resolve(root, 'server/full-api.js'), 'utf8');
  const ui = readFileSync(resolve(root, 'public/assets/js/full.js'), 'utf8');
  assert.match(api, /router\.get\(\s*'\/offerings\/:id\/requirements'/);
  assert.match(api, /const calculated = assessSubjects\(learnerResults, null, policy\)/);
  assert.match(api, /router\.post\('\/pilot\/unsuitable-acknowledgement'/);
  assert.match(api, /eligibleToApply: false/);
  assert.match(ui, /assessment\.pilotGuard\?\.acknowledgementRequired/);
  assert.match(ui, /acknowledgeUnsuitable: Boolean/);
  assert.match(ui, /Source and verification/);
});
