import test from 'node:test';
import assert from 'node:assert/strict';
import { databaseConfig } from '../server/db/config.js';
import { loadSqlDriver } from '../server/db/driver.js';
import { SqlStore } from '../server/storage.js';
const env = {
  DB_AUTH: 'windows',
  DB_SERVER: 'localhost',
  DB_INSTANCE: 'SQLEXPRESS',
  DB_PORT: '',
  DB_TRUST_SERVER_CERTIFICATE: 'true',
};
test('Windows config uses integrated credentials and preserves encryption and certificate options', () => {
  const c = databaseConfig({ ...env, DB_USER: 'ignored', DB_PASSWORD: 'ignored' });
  assert.equal(c.options.trustedConnection, true);
  assert.equal(c.user, undefined);
  assert.equal(c.password, undefined);
  assert.match(c.connectionString, /Server=localhost\\SQLEXPRESS;/);
  assert.match(
    c.connectionString,
    /Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes;/,
  );
  assert.doesNotMatch(c.connectionString, /ignored|Pwd=|Uid=/);
  assert.match(
    databaseConfig({ ...env, DB_TRUST_SERVER_CERTIFICATE: 'false' }).connectionString,
    /TrustServerCertificate=no;/,
  );
  assert.match(
    databaseConfig({ ...env, DB_INSTANCE: '', DB_PORT: '1433' }).connectionString,
    /Server=localhost,1433;/,
  );
  assert.throws(() => databaseConfig({ ...env, DB_PORT: '1433' }), /either/);
  assert.throws(() => databaseConfig({ ...env, DB_SERVER: 'localhost;Uid=other' }), /invalid/);
  assert.throws(() => databaseConfig({ ...env, DB_AUTH: 'invalid' }), /DB_AUTH/);
});
test('SQL transactions carry their selected driver into requests and parameter types', async () => {
  const seen = [];
  const transaction = {};
  const driver = {
    Transaction: class {
      constructor(pool) {
        assert.equal(pool, 'pool');
        return transaction;
      }
    },
    ISOLATION_LEVEL: { SERIALIZABLE: 4 },
    Request: class {
      constructor(t) {
        assert.equal(t, transaction);
        seen.push('request');
      }
    },
    Int: 'driver-int',
  };
  transaction.begin = async (level) => assert.equal(level, 4);
  transaction.commit = async () => seen.push('commit');
  transaction.rollback = async () => seen.push('rollback');
  const store = new SqlStore('pool', null, driver);
  await store.tx(async (db) => {
    db.request();
    const request = {
      input(name, type, value) {
        assert.equal(type, 'driver-int');
        assert.equal(value, 1);
      },
    };
    db.bind(request, 'PERSONS', { PERSON_ID: 1 }, 'p');
  });
  assert.deepEqual(seen, ['request', 'commit']);
});
test('SQL Server dashboard queue binds application status names as text', async () => {
  const seen = [];
  const pool = {
    request() {
      return {
        input(name, type, value) {
          seen.push({ name, type, value });
          return this;
        },
        async query(sql) {
          seen.push({ sql });
          return { recordset: sql.includes('COUNT(*) AS n') ? [{ n: 0 }] : [] };
        },
      };
    },
  };
  const driver = { Int: 'int', NVarChar: (size) => 'nvarchar(' + size + ')' };
  const store = new SqlStore(pool, null, driver);
  for (const [user, status, id] of [
    [{ role: 'teacher', schoolId: 7 }, 'Submitted', 7],
    [{ role: 'representative', universityId: 12 }, 'Screened by Career Teacher', 12],
  ]) {
    seen.length = 0;
    await store.dashboardApplications(user, { status });
    assert.equal(seen[0].name, 'd0');
    assert.equal(seen[0].type, 'int');
    assert.equal(seen[0].value, id);
    assert.equal(seen[1].type, 'nvarchar(100)');
    assert.equal(seen[1].value, status);
    assert.match(seen[2].sql, /S\.STATUS_NAME=@d1/);
    seen.length = 0;
    await store.dashboardApplicationCount(user, status);
    assert.equal(seen[1].type, 'nvarchar(100)');
    assert.equal(seen[1].value, status);
    assert.match(seen[2].sql, /S\.STATUS_NAME=@d1/);
  }
});
test('SQL Server learner milestone lookup uses a scoped typed query', async () => {
  const seen = [],
    pool = {
      request() {
        return {
          input(name, type, value) {
            seen.push({ name, type, value });
            return this;
          },
          async query(sql) {
            seen.push({ sql });
            return { recordset: [{ EXAM_TYPE_ID: 1 }] };
          },
        };
      },
    },
    driver = { Int: 'int' },
    store = new SqlStore(pool, null, driver);
  assert.deepEqual(await store.resultMilestones(42), ['1']);
  assert.deepEqual(seen[0], { name: 'learnerId', type: 'int', value: 42 });
  assert.match(
    seen[1].sql,
    /SELECT DISTINCT EXAM_TYPE_ID FROM \[dbo\]\.\[LEARNER_RESULTS\] WHERE LEARNER_ID=@learnerId/,
  );
});
test('SQL Server closing soon and admin queues only treat 2028 policies as current', async () => {
  const seen = [];
  const pool = {
    request() {
      return {
        input(name, type, value) {
          seen.push({ name, type, value });
          return this;
        },
        async query(sql) {
          seen.push({ sql });
          return { recordset: [] };
        },
      };
    },
  };
  const driver = { Int: 'int', Date: 'date', NVarChar: (size) => 'nvarchar(' + size + ')' },
    store = new SqlStore(pool, null, driver);
  await store.dashboardOfferings({ unverified: true });
  assert.match(seen.at(-1).sql, /\$\.intake/);
  assert.match(seen.at(-1).sql, /2028/);
  seen.length = 0;
  await store.dashboardOfferings({ closingFrom: '2028-01-01', closingTo: '2028-01-31' });
  assert.match(seen.at(-1).sql, /JSON_VALUE\(C\.PAYLOAD,'\$\.intake'\)='2028'/);
  assert.deepEqual(
    seen.slice(0, 2).map((v) => v.value),
    ['2028-01-01', '2028-01-31'],
  );
});
test(
  'Windows auth fails clearly on non-Windows rather than falling back to SQL credentials',
  { skip: process.platform === 'win32' },
  async () => {
    await assert.rejects(loadSqlDriver(env), /native Windows/);
  },
);

import { schemaCheckQueries, securityReadinessQuery } from '../server/db/schema-compare.js';
test('read-only database check verifies the persistent login-throttle table', () => {
  assert.match(
    securityReadinessQuery,
    /OBJECT_ID\(N'VarsityVaultSecurity\.dbo\.LoginAttempts', N'U'\)/,
  );
});
test('schema verification delegates identifier and type checks to SQL Server', () => {
  const expected = {
    objects: [
      { name: 'ACTIONS', type: 'U' },
      { name: 'VIEW_USER_CONTEXT', type: 'V' },
      { name: 'usp_SubmitApplication', type: 'P' },
    ],
    columns: [{ table: 'PERSONS', name: 'PERSON_ID' }],
  };
  const { objectChecks, columnChecks } = schemaCheckQueries(expected);
  assert.match(objectChecks, /OBJECT_ID\(N'dbo\.ACTIONS', N'U'\)/);
  assert.match(objectChecks, /OBJECT_ID\(N'dbo\.VIEW_USER_CONTEXT', N'V'\)/);
  assert.match(objectChecks, /OBJECT_ID\(N'dbo\.usp_SubmitApplication', N'P'\)/);
  assert.match(columnChecks, /COL_LENGTH\(N'dbo\.PERSONS', N'PERSON_ID'\)/);
  assert.throws(
    () =>
      schemaCheckQueries({
        objects: [{ name: "ACTIONS'; DROP DATABASE x--", type: 'U' }],
        columns: [],
      }),
    /Invalid SQL schema contract identifier/,
  );
});
