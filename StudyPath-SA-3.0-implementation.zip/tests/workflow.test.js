import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createReviewState,
  schoolLearners,
  institutionApplications,
  verifyReviewResults,
  verifyReviewDocument,
  transitionReview,
} from '../shared/review/workflow.js';
test('sample scope and workflow gates prevent skipped or repeated decisions', () => {
  const state = createReviewState();
  assert.equal(schoolLearners(state).length, 2);
  assert.equal(institutionApplications(state).length, 2);
  const teacher = { role: 'teacher', school: 'sample-school' },
    rep = { role: 'representative', university: 'wsu' };
  assert.throws(
    () => transitionReview(state, 'sample-a1', 'Screened by Career Teacher', teacher),
    /Verify/,
  );
  assert.throws(() => verifyReviewResults(state, 'sample-l2'), /do not match/);
  assert.throws(() => verifyReviewResults(state, 'sample-l3'), /outside/);
  assert.throws(() => verifyReviewDocument(state, 'sample-l3', 'sample-d1'), /outside/);
  assert.throws(
    () => transitionReview(state, 'sample-a1', 'Provisionally Accepted', rep),
    /screened/,
  );
  verifyReviewResults(state, 'sample-l1');
  verifyReviewDocument(state, 'sample-l1', 'sample-d1');
  verifyReviewDocument(state, 'sample-l1', 'sample-d2');
  transitionReview(state, 'sample-a1', 'Screened by Career Teacher', teacher);
  assert.throws(
    () => transitionReview(state, 'sample-a1', 'Screened by Career Teacher', teacher),
    /submitted/,
  );
  assert.throws(() => transitionReview(state, 'sample-a2', 'Rejected', rep), /institution/);
  assert.throws(() => transitionReview(state, 'sample-a1', 'Admitted', rep), /screened/);
  transitionReview(state, 'sample-a1', 'Provisionally Accepted', rep, '2026-10-05T09:00:00.000Z');
  assert.equal(state.applications[0].history.length, 3);
  assert.equal(state.applications[0].history[2].at, '2026-10-05T09:00:00.000Z');
  assert.throws(() => transitionReview(state, 'sample-a1', 'Rejected', rep), /screened/);
});
