import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateScoring,
  validateGroups,
  offeringAvailability,
} from '../shared/scoring/programme.js';
import { assessSubjects } from '../shared/scoring/subjects.js';
const codes = new Set(['ENGHL', 'AFRFAL', 'MATH', 'LO', 'PHSC', 'LFSC', 'GEOG']);
const scoring = {
  mode: 'RAW',
  count: 6,
  divisor: 6,
  floor: 0,
  label: 'Average',
  bands: [],
  exclude: ['LO'],
  overrides: [],
};
const categories = [
  'HOME_LANGUAGE',
  'FIRST_ADDITIONAL_LANGUAGE',
  'MATHEMATICS',
  'LIFE_ORIENTATION',
  'OTHER',
  'OTHER',
  'OTHER',
];
const records = [...codes].map((code, i) => ({
  SUBJECT_ID: i + 1,
  SUBJECT_CODE: code,
  SUBJECT_CATEGORY: categories[i],
  PERCENTAGE: 70,
}));
test('configured scoring is used by the live subject assessor', () => {
  const config = {
    scoring: validateScoring(scoring, codes),
    status: 'verified',
    intake: 2028,
    minScore: 65,
    source: 'https://example.edu',
    subjectGroups: validateGroups([{ group: 1, code: 'MATH', minimum: 60 }], codes),
  };
  const r = assessSubjects(records, null, config);
  assert.equal(r.total, 70);
  assert.equal(r.eligible, true);
  assert.equal(r.metric, 'Average');
  assert.equal(assessSubjects(records, null, { ...config, minScore: 71 }).eligible, false);
  assert.equal(
    assessSubjects(records, null, {
      ...config,
      subjectGroups: [{ group: 1, code: 'MATH', minimum: 80 }],
    }).eligible,
    false,
  );
  assert.equal(assessSubjects(records, null, { ...config, status: 'pending' }).eligible, false);
});
test('invalid configuration fails validation instead of yielding an eligible result', () => {
  assert.throws(
    () =>
      validateScoring(
        {
          ...scoring,
          mode: 'BANDS',
          bands: [
            [0, 60, 1],
            [50, 101, 2],
          ],
        },
        codes,
      ),
    /gaps or overlaps/,
  );
  assert.throws(() => validateScoring({ ...scoring, exclude: ['UNKNOWN'] }, codes), /directory/);
  assert.throws(
    () => validateGroups([{ group: 1, code: 'MATH', minimum: 101 }], codes),
    /requirement/,
  );
  assert.throws(() => validateScoring({ ...scoring, divisor: 0 }, codes), /divisor/);
});
test('application windows use South African closing time and deny inactive or future offerings', () => {
  const cfg = { status: 'verified', openingDate: '2028-01-01', closingTime: '23:59' };
  assert.equal(offeringAvailability(cfg, '2028-10-31', new Date('2028-10-31T21:58:59Z')), 'Open');
  assert.equal(offeringAvailability(cfg, '2028-10-31', new Date('2028-10-31T21:59:00Z')), 'Closed');
  assert.equal(
    offeringAvailability(cfg, '2028-10-31', new Date('2027-12-31T21:59:59Z')),
    'Not yet open',
  );
  assert.equal(offeringAvailability({ ...cfg, active: false }, '2028-10-31'), 'Inactive');
  assert.equal(
    offeringAvailability({ ...cfg, openingDate: '2028-02-30' }, '2028-10-31'),
    'Invalid dates',
  );
});

test('SQL Server Date objects and JSON date strings produce identical availability', () => {
  const config = { status: 'verified', openingDate: '2026-05-30', closingTime: '23:59' };
  const now = new Date('2026-10-26T19:00:00Z');
  for (const close of [
    new Date('2026-10-31T00:00:00.000Z'),
    '2026-10-31T00:00:00.000Z',
    '2026-10-31',
  ]) {
    assert.equal(offeringAvailability(config, close, now), 'Open');
    assert.equal(offeringAvailability(config, close, new Date('2026-10-31T21:59:00Z')), 'Closed');
  }
  assert.equal(offeringAvailability(config, new Date(NaN), now), 'Invalid dates');
  assert.equal(offeringAvailability(config, '2026-02-30', now), 'Invalid dates');
});
