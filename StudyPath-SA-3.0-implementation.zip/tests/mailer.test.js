import test from 'node:test';
import assert from 'node:assert/strict';
import { emailDeliveryReady } from '../server/mailer.js';

const keys = [
  'NODE_ENV',
  'EMAIL_MODE',
  'PUBLIC_APP_URL',
  'SMTP_HOST',
  'SMTP_PORT',
  'SMTP_FROM',
  'SMTP_USER',
  'SMTP_PASSWORD',
];
const original = Object.fromEntries(keys.map((key) => [key, process.env[key]]));
function configure(values) {
  for (const key of keys) {
    if (Object.hasOwn(values, key)) process.env[key] = values[key];
    else delete process.env[key];
  }
}
test('SMTP readiness requires a complete, paired authentication configuration', () => {
  try {
    configure({
      NODE_ENV: 'development',
      EMAIL_MODE: 'smtp',
      PUBLIC_APP_URL: 'http://127.0.0.1:3000',
      SMTP_HOST: 'smtp.example.test',
      SMTP_PORT: '587',
      SMTP_FROM: 'noreply@example.test',
    });
    assert.equal(emailDeliveryReady(), true, 'unauthenticated SMTP relays remain supported');
    process.env.SMTP_USER = 'user@example.test';
    assert.equal(emailDeliveryReady(), false, 'a username without a password is incomplete');
    process.env.SMTP_PASSWORD = 'secret';
    assert.equal(emailDeliveryReady(), true);
    delete process.env.SMTP_USER;
    assert.equal(emailDeliveryReady(), false, 'a password without a username is incomplete');
  } finally {
    for (const key of keys) {
      if (original[key] === undefined) delete process.env[key];
      else process.env[key] = original[key];
    }
  }
});
