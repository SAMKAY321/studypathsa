import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { LocalStore } from '../server/storage.js';
import { seedLocal, bootstrapAdmin } from '../server/seed.js';
import { emailVerificationMessage } from '../server/account-email.js';
import { createFullApplication } from '../server/app.js';
import { currentTotp, decryptSecret } from '../server/mfa.js';
import { checkPassword } from '../server/security.js';
import { recoverAdministrator } from '../server/recover-admin.js';
const password = 'Test-only-password-2028';
export async function fixture(path = ':memory:') {
  process.env.SECURITY_ENCRYPTION_KEY ||= 'a'.repeat(64);
  // Test-only vault key; never used by production configuration.
  process.env.VAULT_MASTER_KEY ||= Buffer.alloc(32, 11).toString('base64');
  process.env.VAULT_KEY_ID ||= 'test-v1';
  process.env.PUBLIC_APP_URL ||= 'http://127.0.0.1:3000';
  const db = new LocalStore(path);
  await db.tx(seedLocal);
  const sentEmails = [];
  const adminPerson = await bootstrapAdmin(db, { username: 'admin@example.test', password });
  sentEmails.push(
    await db.tx((tx) => emailVerificationMessage(tx, adminPerson.PERSON_ID, 'admin@example.test')),
  );
  const server = createFullApplication(db, {
    sendEmail: async (message) => {
      sentEmails.push(message);
    },
  }).listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = 'http://127.0.0.1:' + server.address().port;
  function client() {
    let cookie = '',
      csrf = '',
      futureMfaStep = 1;
    return {
      async call(path, method = 'GET', body, expected = 200, headers = {}) {
        const raw = Buffer.isBuffer(body);
        const response = await fetch(base + '/api' + path, {
          method,
          headers: {
            ...(cookie ? { Cookie: cookie } : {}),
            ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
            ...(body === undefined
              ? {}
              : { 'Content-Type': raw ? 'application/pdf' : 'application/json' }),
            ...headers,
          },
          ...(body === undefined ? {} : { body: raw ? body : JSON.stringify(body) }),
        });
        if (response.headers.get('set-cookie'))
          cookie = response.headers.get('set-cookie').split(';')[0];
        const out = response.headers.get('content-type')?.includes('application/json')
          ? await response.json()
          : Buffer.from(await response.arrayBuffer());
        if (response.status !== expected)
          throw Object.assign(new Error(JSON.stringify(out)), {
            status: response.status,
            data: out,
          });
        if (out.csrf) csrf = out.csrf;
        return out;
      },
      async login(username, loginPassword = password) {
        let out;
        try {
          out = await this.call('/auth/login', 'POST', { username, password: loginPassword });
        } catch (error) {
          if (error.status !== 403 || !/verify your email/i.test(error.data?.error || ''))
            throw error;
          await new Promise((resolve) => setTimeout(resolve, 20));
          const email = sentEmails.find(
            (item) => item.to === username && item.subject.includes('Verify your'),
          );
          if (!email) throw new Error('Test email verification message was not delivered.');
          const link = new URL(email.text.match(/https?:\/\/\S+/)[0]),
            token = link.searchParams.get('token');
          await this.call('/auth/email/verify', 'POST', { token });
          out = await this.call('/auth/login', 'POST', { username, password: loginPassword });
        }
        if (out.mfaRequired) {
          const account = (await db.list('security.Accounts', { USERNAME: username }))[0],
            factor = (await db.list('security.Mfa', { PERSON_ID: account.PERSON_ID }))[0],
            secret = decryptSecret(factor.SECRET_CIPHERTEXT),
            verified = await this.call('/auth/mfa/verify', 'POST', {
              code: currentTotp(secret, Date.now() + futureMfaStep++ * 30000),
            });
          out = verified;
        }
        return out;
      },
    };
  }
  return {
    db,
    server,
    base,
    client,
    sentEmails,
    async close() {
      await new Promise((r) => server.close(r));
      await db.close();
    },
  };
}
test('persisted four-role lifecycle, access boundaries, validation and audit', async () => {
  const temp = mkdtempSync(join(tmpdir(), 'vv-full-')),
    path = join(temp, 'app.sqlite'),
    f = await fixture(path);
  try {
    const anon = f.client(),
      admin = f.client(),
      learner = f.client(),
      teacher = f.client(),
      rep = f.client(),
      other = f.client();
    assert.equal((await anon.call('/health')).intake, 2028);
    await anon.call('/me', 'GET', undefined, 401);
    await admin.login('admin@example.test');
    const c = await admin.call('/catalog'),
      publicCatalog = await anon.call('/catalog');
    assert.equal(c.subjects.length, 20);
    assert.equal(c.universities.length, 26);
    assert.ok(c.studyModes.some((item) => item.STUDY_MODE_NAME === 'Full-time'));
    assert.ok(c.studyModes.some((item) => item.STUDY_MODE_NAME === 'Part-time'));
    assert.ok(!publicCatalog.schools.some((school) => school.EMIS_NUMBER === 'LOCAL-ONLY'));
    assert.ok(publicCatalog.schools.every((school) => !Object.hasOwn(school, 'EMIS_NUMBER')));
    const school = c.schools[0].SCHOOL_ID,
      uni = c.universities[0].UNIVERSITY_ID;
    for (const [email, role, schoolId, universityId] of [
      ['teacher@example.test', 'teacher', school, null],
      ['rep@example.test', 'representative', null, uni],
      ['other@example.test', 'learner', school, null],
    ])
      await admin.call('/admin/accounts', 'POST', {
        email,
        role,
        schoolId,
        universityId,
        firstName: role,
        lastName: 'Test',
        password,
      });
    await anon.call('/auth/register', 'POST', {
      email: 'learner@example.test',
      password,
      schoolId: school,
      firstName: 'Learner',
      lastName: 'Test',
      role: 'admin',
    });
    const me = await learner.login('learner@example.test');
    assert.equal(me.user.role, 'learner');
    await teacher.login('teacher@example.test');
    await rep.login('rep@example.test');
    await other.login('other@example.test');
    await learner.call('/admin/accounts', 'GET', undefined, 403);
    await learner.call('/me/profile', 'PUT', { firstName: 'Bad', lastName: 'Origin' }, 403, {
      Origin: 'https://attacker.test',
    });
    await learner.call('/me/profile', 'PUT', { firstName: 'Bad', lastName: 'CSRF' }, 403, {
      'X-CSRF-Token': 'wrong',
    });
    const rows = ['ENGHL', 'AFRFAL', 'MATH', 'LO', 'PHSC', 'LFSC', 'GEOG'].map((code) => ({
      subjectId: c.subjects.find((s) => s.SUBJECT_CODE === code).SUBJECT_ID,
      percentage: 70,
    }));
    await learner.call('/results', 'PUT', { examTypeId: c.examTypes[0].EXAM_TYPE_ID, rows });
    // An empty payload must never be interpreted as a request to erase a whole milestone.
    await learner.call(
      '/results',
      'PUT',
      { examTypeId: c.examTypes[0].EXAM_TYPE_ID, rows: [] },
      400,
    );
    assert.equal(
      (await learner.call('/results?examTypeId=' + c.examTypes[0].EXAM_TYPE_ID)).rows.length,
      7,
    );
    await assert.rejects(
      () =>
        learner.call('/results', 'PUT', {
          examTypeId: c.examTypes[0].EXAM_TYPE_ID,
          rows: [{ subjectId: 999999, percentage: 75 }],
        }),
      (error) => {
        assert.equal(error.status, 400);
        assert.match(error.data?.error || '', /not in the current subject catalogue/i);
        return true;
      },
    );
    await assert.rejects(
      () =>
        learner.call('/results', 'PUT', {
          examTypeId: c.examTypes[0].EXAM_TYPE_ID,
          rows: [{ subjectId: 999999, percentage: 75 }],
        }),
      (error) => {
        assert.equal(error.status, 400);
        assert.match(error.data?.error || '', /not in the current subject catalogue/i);
        return true;
      },
    );
    await learner.call(
      '/results',
      'PUT',
      {
        examTypeId: c.examTypes[0].EXAM_TYPE_ID,
        rows: [...rows, { subjectId: rows[0].subjectId, percentage: 50 }],
      },
      400,
    );
    assert.equal(
      (await learner.call('/results?examTypeId=' + c.examTypes[0].EXAM_TYPE_ID)).rows.length,
      7,
    );
    // Regression: saving a second time must update existing composite-key rows,
    // round-trip through the API, and not depend on deleting/recreating the set.
    const updatedRows = rows.map((row) => ({ ...row }));
    updatedRows.find(
      (row) => row.subjectId === c.subjects.find((s) => s.SUBJECT_CODE === 'MATH').SUBJECT_ID,
    ).percentage = 74;
    await learner.call('/results', 'PUT', {
      examTypeId: c.examTypes[0].EXAM_TYPE_ID,
      rows: updatedRows,
    });
    const reloaded = await learner.call('/results?examTypeId=' + c.examTypes[0].EXAM_TYPE_ID);
    assert.equal(reloaded.rows.length, 7);
    assert.equal(reloaded.rows.find((row) => row.SUBJECT_CODE === 'MATH').PERCENTAGE, 74);
    assert.deepEqual((await learner.call('/results/summary')).examTypeIds, [
      String(c.examTypes[0].EXAM_TYPE_ID),
    ]);
    assert.deepEqual((await other.call('/results/summary')).examTypeIds, []);
    await other.call('/results?learnerId=' + me.user.recordId + '&examTypeId=1');
    assert.equal((await other.call('/results?examTypeId=1')).rows.length, 0);
    const config = {
      universityId: uni,
      universityKey: 'cput',
      intake: 2028,
      name: 'Test-only BSc',
      program: 'Test fixture',
      closingDate: '2028-12-31',
      minScore: 35,
      minEnglish: 50,
      minMath: 50,
      source: 'https://cput.ac.za/',
      requiredCodes: ['MATH', 'PHSC'],
      subjectMinimums: { PHSC: 60 },
      verified: true,
    };
    await admin.call(
      '/admin/offerings',
      'POST',
      { ...config, subjectMinimums: { NOPE: 100 } },
      400,
    );
    const offering = await admin.call('/admin/offerings', 'POST', config);
    const offer = offering.offeringId;
    assert.equal(
      (await learner.call('/offerings/' + offer + '/requirements?examTypeId=1')).eligible,
      true,
    );
    const storedOffering = (await admin.call('/offerings')).offerings.find(
      (item) => String(item.UNI_QUAL_ID) === String(offer),
    );
    assert.equal(storedOffering.program, 'Test fixture');
    await learner.call('/applications', 'POST', { offeringId: offer, studyModeId: 1 }, 409);
    const pdf = Buffer.from('%PDF-1.4\nTest-only fixture\n%%EOF');
    await learner.call('/documents', 'POST', pdf, 409, {
      'X-Document-Type': '4',
      'X-File-Name': 'final.pdf',
    });
    for (const type of c.documentTypes.filter((t) => t.IS_MANDATORY))
      await learner.call('/documents', 'POST', pdf, 200, {
        'X-Document-Type': String(type.DOCUMENT_TYPE_ID),
        'X-File-Name': 'test.pdf',
      });
    await learner.call('/documents', 'POST', Buffer.from('not a PDF'), 400, {
      'X-Document-Type': '1',
    });
    const docs = (await learner.call('/documents')).documents;
    assert.equal(docs.length, 2);
    assert.ok(!('DOCUMENT_BLOB' in docs[0]));
    await other.call('/documents/' + docs[0].DOCUMENT_ID + '/download', 'GET', undefined, 403);
    const app = (await learner.call('/applications', 'POST', { offeringId: offer, studyModeId: 1 }))
      .application;
    await learner.call('/applications', 'POST', { offeringId: offer, studyModeId: 1 }, 409);
    const learnerSummary = await learner.call('/dashboard/summary');
    assert.equal(learnerSummary.applicationCount, 1);
    assert.equal(
      learnerSummary.applications[0].offering.university,
      c.universities[0].UNIVERSITY_NAME,
    );
    assert.equal(learnerSummary.counts.results, 7);
    assert.equal(learnerSummary.counts.documents, 2);
    const teacherSummary = await teacher.call('/dashboard/summary');
    assert.equal(teacherSummary.counts.awaitingScreening, 1);
    assert.equal(teacherSummary.actionQueue[0].id, app.APPLICATION_ID);
    const repSummary = await rep.call('/dashboard/summary');
    assert.equal(repSummary.applicationCount, 1);
    assert.equal(repSummary.counts.awaitingReview, 0);
    assert.equal(repSummary.actionQueue.length, 0);
    const adminSummary = await admin.call('/dashboard/summary');
    assert.equal(adminSummary.counts.offerings, 1);
    assert.equal(adminSummary.actionQueue.length, 0);
    const publicConfig = await anon.call('/public-config');
    assert.ok(publicConfig.supportEmail === null || typeof publicConfig.supportEmail === 'string');
    await teacher.call(
      '/applications/' + app.APPLICATION_ID + '/transition',
      'POST',
      { status: 'Screened by Career Teacher' },
      409,
    );
    await rep.call('/applications/' + app.APPLICATION_ID + '/evidence', 'GET', undefined, 403);
    await teacher.call(
      '/teacher/verify',
      'POST',
      { learnerId: me.user.recordId, examTypeId: 1, decision: 'nonsense' },
      400,
    );
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      examTypeId: 1,
      decision: 'Verified',
    });
    for (const d of docs)
      await teacher.call('/teacher/verify', 'POST', {
        learnerId: me.user.recordId,
        documentId: d.DOCUMENT_ID,
        decision: 'Verified',
      });
    await learner.call('/results', 'PUT', { examTypeId: 1, rows }, 409);
    await teacher.call('/applications/' + app.APPLICATION_ID + '/transition', 'POST', {
      status: 'Screened by Career Teacher',
    });
    assert.equal(
      (await rep.call('/applications/' + app.APPLICATION_ID + '/evidence')).exams[0].rows.length,
      7,
    );
    await rep.call(
      '/applications/' + app.APPLICATION_ID + '/transition',
      'POST',
      { status: 'Admitted' },
      409,
    ); // A screening decision must not allow subsequently rejected evidence through admission.
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      examTypeId: 1,
      decision: 'Rejected',
    });
    await rep.call(
      '/applications/' + app.APPLICATION_ID + '/transition',
      'POST',
      { status: 'Provisionally Accepted' },
      409,
    );
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      examTypeId: 1,
      decision: 'Verified',
    });
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      documentId: docs[0].DOCUMENT_ID,
      decision: 'Rejected',
    });
    await rep.call(
      '/applications/' + app.APPLICATION_ID + '/transition',
      'POST',
      { status: 'Provisionally Accepted' },
      409,
    );
    assert.equal(
      (await learner.call('/applications/' + app.APPLICATION_ID + '/timeline')).timeline.length,
      2,
    );
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      documentId: docs[0].DOCUMENT_ID,
      decision: 'Verified',
    });
    await rep.call('/applications/' + app.APPLICATION_ID + '/transition', 'POST', {
      status: 'Provisionally Accepted',
    });
    await rep.call(
      '/applications/' + app.APPLICATION_ID + '/transition',
      'POST',
      { status: 'Final Matric Verified' },
      409,
    );
    await learner.call('/results', 'PUT', { examTypeId: 3, rows });
    await learner.call('/documents', 'POST', pdf, 200, {
      'X-Document-Type': '4',
      'X-File-Name': 'final.pdf',
    });
    const final = (await learner.call('/documents')).documents.find(
      (d) => d.DOCUMENT_TYPE_ID === 4,
    );
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      examTypeId: 3,
      decision: 'Verified',
    });
    await teacher.call('/teacher/verify', 'POST', {
      learnerId: me.user.recordId,
      documentId: final.DOCUMENT_ID,
      decision: 'Verified',
    });
    await rep.call('/applications/' + app.APPLICATION_ID + '/transition', 'POST', {
      status: 'Final Matric Verified',
    });
    await rep.call('/applications/' + app.APPLICATION_ID + '/transition', 'POST', {
      status: 'Admitted',
    });
    assert.equal(
      (await learner.call('/applications/' + app.APPLICATION_ID + '/timeline')).timeline.length,
      5,
    );
    assert.equal((await learner.call('/applications')).applications[0].status, 'Admitted');
    const audit = (await admin.call('/admin/audit')).events;
    assert.ok(audit.length > 20);
    assert.ok(audit.some((event) => event.actor === 'System Administrator'));
    assert.ok(audit.every((event) => !Object.hasOwn(event, 'PERSON_ID')));
    // School and institution boundaries are enforced on server requests.
    await admin.call(
      '/admin/directories/schools',
      'POST',
      { SCHOOL_NAME: 'Missing location', EMIS_NUMBER: 'MISS' },
      400,
    );
    await admin.call(
      '/admin/directories/universities',
      'POST',
      { UNIVERSITY_NAME: 'Missing location', WEBSITE: 'https://example.test', PROVINCE_ID: 1 },
      400,
    );
    const otherSchool = (
      await admin.call('/admin/directories/schools', 'POST', {
        SCHOOL_NAME: 'Other School',
        EMIS_NUMBER: 'TEST2',
        CITY_ID: 1,
        PROVINCE_ID: 1,
      })
    ).row.SCHOOL_ID;
    for (const [email, role, schoolId, universityId] of [
      ['outside-teacher@example.test', 'teacher', otherSchool, null],
      ['outside-rep@example.test', 'representative', null, c.universities[1].UNIVERSITY_ID],
    ]) {
      await admin.call('/admin/accounts', 'POST', {
        email,
        role,
        schoolId,
        universityId,
        firstName: 'Outside',
        lastName: 'Test',
        password,
      });
      const cl = f.client();
      await cl.login(email);
      assert.equal((await cl.call('/applications')).applications.length, 0);
      await cl.call('/applications/' + app.APPLICATION_ID + '/timeline', 'GET', undefined, 403);
      await cl.call('/documents/' + docs[0].DOCUMENT_ID + '/download', 'GET', undefined, 403);
    }
    await admin.call(
      '/admin/directories/schools',
      'POST',
      { SCHOOL_NAME: 'Bad School', EMIS_NUMBER: 'TEST3', CITY_ID: 999, PROVINCE_ID: 1 },
      404,
    );
    const account = (await admin.call('/admin/accounts')).accounts.find(
      (a) => a.user.username === 'other@example.test',
    );
    await admin.call('/admin/accounts/' + account.accountId + '/disable', 'POST', {});
    await other.call('/me', 'GET', undefined, 401);
    await learner.call('/auth/logout', 'POST', {});
    await learner.call('/me', 'GET', undefined, 401);
  } finally {
    await f.close();
  }
  const reopened = new LocalStore(path);
  assert.equal((await reopened.list('APPLICATIONS')).length, 1);
  assert.equal((await reopened.list('DOCUMENTS')).length, 3);
  await reopened.close();
  rmSync(temp, { recursive: true });
});

test('learner result reads do not overlap requests on a SQL Server transaction', async () => {
  const f = await fixture();
  try {
    const learner = f.client();
    await learner.call('/auth/register', 'POST', {
      email: 'serial-results@example.test',
      password,
      schoolId: 1,
      firstName: 'Serial',
      lastName: 'Results',
    });
    await learner.login('serial-results@example.test');
    const list = f.db.list.bind(f.db);
    let active = 0,
      maximum = 0;
    f.db.list = async (table, where) => {
      if (!['LEARNER_RESULTS', 'SUBJECTS'].includes(table)) return list(table, where);
      active++;
      maximum = Math.max(maximum, active);
      await new Promise((resolve) => setTimeout(resolve, 5));
      try {
        return await list(table, where);
      } finally {
        active--;
      }
    };
    await learner.call('/results?examTypeId=1');
    assert.equal(maximum, 1);
  } finally {
    await f.close();
  }
});

test('management edits, existing-person sign-in, password changes and expired offerings', async () => {
  const f = await fixture();
  try {
    const admin = f.client();
    await admin.login('admin@example.test');
    await admin.call('/admin/directories/cities/1', 'PATCH', {
      CITY_NAME: 'Updated Development City',
    });
    assert.equal((await admin.call('/catalog')).cities[0].CITY_NAME, 'Updated Development City');
    const directory = await admin.call('/catalog'),
      university = directory.universities[0];
    await admin.call('/admin/directories/universities/' + university.UNIVERSITY_ID, 'PATCH', {
      UNIVERSITY_NAME: university.UNIVERSITY_NAME,
      WEBSITE: university.WEBSITE,
      PROVINCE_ID: university.PROVINCE_ID,
      CITY_ID: 1,
      STREET_NAME: 'Main campus',
    });
    const mapped = (await admin.call('/admin/directories/universities')).rows.find(
      (row) => row.UNIVERSITY_ID === university.UNIVERSITY_ID,
    );
    assert.equal(mapped.CITY_ID, 1);
    assert.equal(mapped.STREET_NAME, 'Main campus');
    const publicUniversities = await f.client().call('/universities');
    assert.equal(publicUniversities.universities[0].city, 'Updated Development City');
    assert.equal(
      publicUniversities.universities[0].province,
      directory.provinces.find((row) => row.PROVINCE_ID === university.PROVINCE_ID).PROVINCE_NAME,
    );
    assert.ok(!Object.hasOwn(publicUniversities.universities[0], 'UNIVERSITY_ID'));
    const p = await f.db.tx(async (db) => {
      const person = await db.insert('PERSONS', {
        FIRST_NAME: 'Existing',
        LAST_NAME: 'Teacher',
        EMAIL: 'existing@example.test',
        USERNAME: 'existing',
        PHONE_NUMBER: null,
        SA_ID_NUMBER: null,
      });
      await db.insert('TEACHERS', {
        PERSON_ID: person.PERSON_ID,
        SCHOOL_ID: 1,
        DEPARTMENT: 'Career',
        DESIGNATION: 'Teacher',
      });
      return person;
    });
    assert.equal((await admin.call('/admin/unlinked')).people.length, 1);
    await admin.call('/admin/accounts/link', 'POST', {
      personId: p.PERSON_ID,
      email: 'existing@example.test',
      password,
    });
    const linked = f.client();
    assert.equal((await linked.login('existing@example.test')).user.role, 'teacher');
    await linked.call(
      '/me/password',
      'POST',
      { currentPassword: 'wrong', newPassword: 'Changed-test-password-2028' },
      400,
    );
    await linked.call('/me/password', 'POST', {
      currentPassword: password,
      newPassword: 'Changed-test-password-2028',
    });
    await linked.call('/me', 'GET', undefined, 401);
    await linked.call('/auth/login', 'POST', { username: 'existing@example.test', password }, 401);
    await linked.call('/auth/login', 'POST', {
      username: 'existing@example.test',
      password: 'Changed-test-password-2028',
    });
    const config = {
      universityId: 1,
      universityKey: 'cput',
      intake: 2028,
      name: 'Management test only',
      program: 'Test',
      closingDate: '2028-10-31',
      minScore: 35,
      minEnglish: 50,
      minMath: 50,
      source: 'https://cput.ac.za/',
      requiredCodes: ['MATH'],
      verified: false,
    };
    await admin.call('/admin/offerings', 'POST', { ...config, intake: 2027 }, 400);
    await admin.call('/admin/offerings', 'POST', { ...config, minScore: 43 }, 400);
    const o = await admin.call('/admin/offerings', 'POST', config);
    await admin.call('/admin/offerings/' + o.offeringId, 'PATCH', {
      ...config,
      minScore: 39,
      finalMinScore: 36,
      verified: true,
    });
    let offering = (await admin.call('/offerings')).offerings[0];
    assert.equal(offering.config.minScore, 39);
    assert.equal(offering.config.finalMinScore, 36);
    assert.equal(offering.config.scoringMethod, 'standard-aps-6');
    await admin.call(
      '/admin/offerings/' + o.offeringId,
      'PATCH',
      { ...config, closingDate: '2028-02-30' },
      400,
    );
    const learner = f.client();
    await learner.call('/auth/register', 'POST', {
      email: 'closed@example.test',
      password,
      firstName: 'Closed',
      lastName: 'Test',
      schoolId: 1,
    });
    await learner.login('closed@example.test');
    const catalog = await learner.call('/catalog'),
      rows = ['ENGHL', 'AFRFAL', 'MATH', 'LO', 'PHSC', 'LFSC', 'GEOG'].map((code) => ({
        subjectId: catalog.subjects.find((s) => s.SUBJECT_CODE === code).SUBJECT_ID,
        percentage: 70,
      }));
    await learner.call('/results', 'PUT', { examTypeId: 1, rows });
    await admin.call('/admin/offerings/' + o.offeringId, 'PATCH', {
      ...config,
      closingDate: '2026-01-01',
      verified: true,
    });
    const out = await learner.call(
      '/applications',
      'POST',
      { offeringId: o.offeringId, studyModeId: 1 },
      409,
    );
    assert.match(out.error, /closed/);
  } finally {
    await f.close();
  }
});

test('account restoration requires an administrator and fresh login; linked login names stay accurate', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      learner = f.client();
    await admin.login('admin@example.test');
    await admin.call(
      '/admin/accounts',
      'POST',
      {
        email: 'invalid',
        password,
        role: 'learner',
        schoolId: 1,
        firstName: 'Invalid',
        lastName: 'Account',
      },
      400,
    );
    assert.equal((await f.db.list('PERSONS')).length, 1);
    await learner.call('/auth/register', 'POST', {
      email: 'restore@example.test',
      password,
      schoolId: 1,
      firstName: 'Restore',
      lastName: 'Test',
    });
    const me = await learner.login('restore@example.test');
    const account = (await admin.call('/admin/accounts')).accounts.find(
      (a) => a.user.personId === me.user.personId,
    );
    await learner.call('/admin/accounts/' + account.accountId + '/enable', 'POST', {}, 403);
    await admin.call('/admin/accounts/' + account.accountId + '/disable', 'POST', {});
    await learner.call('/auth/login', 'POST', { username: 'restore@example.test', password }, 401);
    await admin.call('/admin/accounts/' + account.accountId + '/enable', 'POST', {});
    await learner.call('/me', 'GET', undefined, 401);
    await learner.login('restore@example.test');
    assert.equal((await learner.call('/me')).user.personId, me.user.personId);
    assert.ok((await admin.call('/admin/audit')).events.some((e) => e.EVENT === 'account.enable'));
    const catalog = await learner.call('/catalog'),
      subject = catalog.subjects[0].SUBJECT_ID;
    await learner.call(
      '/results',
      'PUT',
      {
        examTypeId: 1,
        rows: [
          { subjectId: subject, percentage: 70 },
          { subjectId: String(subject), percentage: 60 },
        ],
      },
      400,
    );
    assert.equal((await learner.call('/results?examTypeId=1')).rows.length, 0);
    const person = await f.db.tx(async (db) => {
      const p = await db.insert('PERSONS', {
        FIRST_NAME: 'Linked',
        LAST_NAME: 'Teacher',
        EMAIL: 'old@example.test',
        USERNAME: 'oldname',
      });
      await db.insert('TEACHERS', { PERSON_ID: p.PERSON_ID, SCHOOL_ID: 1 });
      return p;
    });
    await admin.call('/admin/accounts/link', 'POST', {
      personId: person.PERSON_ID,
      email: 'new-login@example.test',
      password,
    });
    assert.equal(
      (await admin.call('/admin/accounts')).accounts.find(
        (a) => a.user.personId === person.PERSON_ID,
      ).username,
      'new-login@example.test',
    );
  } finally {
    await f.close();
  }
});

test('email verification, generic password recovery, one-use tokens and session revocation', async () => {
  const f = await fixture();
  try {
    const learner = f.client(),
      anon = f.client();
    await learner.call('/auth/register', 'POST', {
      email: 'recovery@example.test',
      password,
      schoolId: 1,
      firstName: 'Recovery',
      lastName: 'Test',
    });
    const blocked = await learner.call(
      '/auth/login',
      'POST',
      { username: 'recovery@example.test', password },
      403,
    );
    assert.match(blocked.error, /verify your email/i);
    await new Promise((resolve) => setTimeout(resolve, 20));
    const verificationEmail = f.sentEmails.find(
      (message) =>
        message.to === 'recovery@example.test' && message.subject.includes('Verify your'),
    );
    const verificationToken = new URL(
      verificationEmail.text.match(/https?:\/\/\S+/)[0],
    ).searchParams.get('token');
    const storedVerification = (
      await f.db.list('security.AccountTokens', { PURPOSE: 'email-verification' })
    )[0];
    assert.notEqual(storedVerification.TOKEN_HASH, verificationToken);
    assert.equal(storedVerification.TOKEN_HASH.length, 64);
    await anon.call('/auth/email/verify', 'POST', { token: verificationToken });
    await anon.call('/auth/email/verify', 'POST', { token: verificationToken }, 400);
    await learner.login('recovery@example.test');
    assert.equal((await learner.call('/me')).user.email, 'recovery@example.test');
    const unknown = await anon.call(
        '/auth/password-reset',
        'POST',
        { email: 'not-present@example.test' },
        202,
      ),
      known = await anon.call(
        '/auth/password-reset',
        'POST',
        { email: 'recovery@example.test' },
        202,
      );
    assert.equal(unknown.message, known.message);
    await new Promise((resolve) => setTimeout(resolve, 20));
    const resetEmail = f.sentEmails.find(
      (message) =>
        message.to === 'recovery@example.test' && message.subject.startsWith('Reset your'),
    );
    const resetToken = new URL(resetEmail.text.match(/https?:\/\/\S+/)[0]).searchParams.get(
        'token',
      ),
      storedReset = (await f.db.list('security.AccountTokens', { PURPOSE: 'password-reset' }))[0];
    assert.notEqual(storedReset.TOKEN_HASH, resetToken);
    await anon.call('/auth/password-reset/complete', 'POST', {
      token: resetToken,
      password: 'New-Account-password-2028',
      confirmPassword: 'New-Account-password-2028',
    });
    await learner.call('/me', 'GET', undefined, 401);
    await anon.call(
      '/auth/password-reset/complete',
      'POST',
      {
        token: resetToken,
        password: 'Another-new-password-2028',
        confirmPassword: 'Another-new-password-2028',
      },
      400,
    );
    await anon.call('/auth/login', 'POST', { username: 'recovery@example.test', password }, 401);
    await anon.call('/auth/login', 'POST', {
      username: 'recovery@example.test',
      password: 'New-Account-password-2028',
    });
  } finally {
    await f.close();
  }
});

test('legacy accounts without verification records are blocked and receive a verification email', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      anon = f.client();
    await admin.login('admin@example.test');
    await admin.call('/admin/accounts', 'POST', {
      email: 'legacy-teacher@example.test',
      role: 'teacher',
      schoolId: 1,
      firstName: 'Legacy',
      lastName: 'Teacher',
      password,
    });
    const account = (
      await f.db.list('security.Accounts', { USERNAME: 'legacy-teacher@example.test' })
    )[0];
    await f.db.remove('security.EmailVerifications', { PERSON_ID: account.PERSON_ID });
    const blocked = await anon.call(
      '/auth/login',
      'POST',
      { username: account.USERNAME, password },
      403,
    );
    assert.match(blocked.error, /verify your email/i);
    await new Promise((resolve) => setTimeout(resolve, 20));
    const message = f.sentEmails.findLast(
      (item) => item.to === account.USERNAME && item.subject.includes('Verify your'),
    );
    assert.ok(message);
    const token = new URL(message.text.match(/https?:\/\/\S+/)[0]).searchParams.get('token');
    await anon.call('/auth/email/verify', 'POST', { token });
    assert.equal(
      (await admin.call('/admin/accounts')).accounts.find(
        (item) => item.accountId === account.ACCOUNT_ID,
      ).emailVerified,
      true,
    );
    assert.equal(
      (await anon.call('/auth/login', 'POST', { username: account.USERNAME, password })).user.role,
      'teacher',
    );
  } finally {
    await f.close();
  }
});

test('administrator account invites and triggered password resets use verified one-time links', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      anon = f.client();
    await admin.login('admin@example.test');
    await admin.call('/admin/accounts', 'POST', {
      email: 'new-staff@example.test',
      role: 'teacher',
      schoolId: 1,
      firstName: 'New',
      lastName: 'Staff',
    });
    await new Promise((resolve) => setTimeout(resolve, 20));
    const invite = f.sentEmails.find(
      (message) => message.to === 'new-staff@example.test' && message.subject.includes('account'),
    );
    const invitationToken = new URL(invite.text.match(/https?:\/\/\S+/)[0]).searchParams.get(
      'token',
    );
    await anon.call('/auth/password-reset/complete', 'POST', {
      token: invitationToken,
      password: 'Staff-setup-password-2028',
      confirmPassword: 'Staff-setup-password-2028',
    });
    const staff = f.client();
    assert.equal(
      (await staff.login('new-staff@example.test', 'Staff-setup-password-2028')).user.role,
      'teacher',
    );
    const account = (await admin.call('/admin/accounts')).accounts.find(
      (item) => item.username === 'new-staff@example.test',
    );
    await admin.call('/admin/accounts/' + account.accountId + '/password-reset', 'POST', {});
    await new Promise((resolve) => setTimeout(resolve, 20));
    const reset = f.sentEmails.find(
      (message) =>
        message.to === 'new-staff@example.test' &&
        message.subject.startsWith('Password reset requested'),
    );
    const resetToken = new URL(reset.text.match(/https?:\/\/\S+/)[0]).searchParams.get('token');
    await anon.call('/auth/password-reset/complete', 'POST', {
      token: resetToken,
      password: 'Staff-new-password-2028',
      confirmPassword: 'Staff-new-password-2028',
    });
    await staff.call('/me', 'GET', undefined, 401);
    await anon.call('/auth/login', 'POST', {
      username: 'new-staff@example.test',
      password: 'Staff-new-password-2028',
    });
  } finally {
    await f.close();
  }
});

test('administrator MFA is optional; enabled factors require codes and retain audited recovery', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      anon = f.client(),
      initialEmail = f.sentEmails.find(
        (message) => message.to === 'admin@example.test' && message.subject.includes('Verify your'),
      ),
      initialToken = new URL(initialEmail.text.match(/https?:\/\/\S+/)[0]).searchParams.get(
        'token',
      );
    await anon.call('/auth/email/verify', 'POST', { token: initialToken });
    const login = await admin.call('/auth/login', 'POST', {
      username: 'admin@example.test',
      password,
    });
    assert.equal(login.user.role, 'admin');
    assert.equal(login.mfaSetupRequired, undefined);
    await admin.call('/admin/accounts');
    const setup = await admin.call('/me/mfa/setup', 'POST', { currentPassword: password }),
      factor = (await f.db.list('security.Mfa', { PERSON_ID: 1 }))[0];
    assert.ok(!factor.SECRET_CIPHERTEXT.includes(setup.secret));
    const confirmed = await admin.call('/me/mfa/confirm', 'POST', {
        code: currentTotp(setup.secret),
      }),
      savedFactor = (await f.db.list('security.Mfa', { PERSON_ID: 1 }))[0];
    assert.equal(confirmed.recoveryCodes.length, 10);
    assert.ok(!savedFactor.RECOVERY_HASHES.includes(confirmed.recoveryCodes[0]));
    assert.ok((await admin.call('/admin/accounts')).accounts.length >= 1);
    const challenge = f.client(),
      required = await challenge.call('/auth/login', 'POST', {
        username: 'admin@example.test',
        password,
      });
    assert.equal(required.mfaRequired, true);
    await challenge.call('/auth/mfa/verify', 'POST', { code: '000000' }, 401);
    const valid = await challenge.call('/auth/mfa/verify', 'POST', {
      code: confirmed.recoveryCodes[0],
    });
    assert.equal(valid.user.role, 'admin');
    const codes = (await f.db.list('security.Mfa', { PERSON_ID: 1 }))[0].RECOVERY_HASHES;
    assert.ok(!codes.includes(confirmed.recoveryCodes[0]));
    const recovery = await f.db.tx((db) =>
      recoverAdministrator(db, 'admin@example.test', 'Local database operator'),
    );
    assert.ok(recovery.temporaryPassword.length >= 24);
    assert.ok(
      await checkPassword(
        recovery.temporaryPassword,
        (await f.db.list('security.Accounts', { USERNAME: 'admin@example.test' }))[0].PASSWORD_HASH,
      ),
    );
    assert.equal((await f.db.list('security.Mfa', { PERSON_ID: 1 })).length, 0);
    assert.equal((await f.db.list('security.Sessions', { PERSON_ID: 1 })).length, 0);
    assert.ok(
      (await f.db.list('security.Audit')).some(
        (event) =>
          event.EVENT === 'account.operator_recovery' &&
          JSON.parse(event.DETAIL).operator === 'Local database operator',
      ),
    );
  } finally {
    await f.close();
  }
});

test('failed sign-ins use a persisted per-name and per-IP throttle with generic unknown-user timing', async () => {
  const temp = mkdtempSync(join(tmpdir(), 'vv-login-throttle-')),
    path = join(temp, 'app.sqlite'),
    f = await fixture(path);
  try {
    const anon = f.client();
    for (let i = 0; i < 9; i++)
      await anon.call(
        '/auth/login',
        'POST',
        { username: 'not-a-real-user@example.test', password },
        401,
      );
    await anon.call(
      '/auth/login',
      'POST',
      { username: 'not-a-real-user@example.test', password },
      429,
    );
    await anon.call(
      '/auth/login',
      'POST',
      { username: 'not-a-real-user@example.test', password },
      429,
    );
    const rows = await f.db.list('security.LoginAttempts');
    assert.equal(rows.length, 1);
    assert.equal(rows[0].FAILURES, 10);
    assert.ok(rows[0].BLOCKED_UNTIL);
    assert.doesNotMatch(rows[0].ATTEMPT_KEY, /not-a-real-user|127\.0\.0\.1/);
  } finally {
    await f.close();
  }
  const reopened = new LocalStore(path),
    rows = await reopened.list('security.LoginAttempts');
  assert.equal(rows.length, 1);
  assert.equal(rows[0].FAILURES, 10);
  await reopened.close();
  rmSync(temp, { recursive: true });
});

test('explicit proxy trust accepts a hop count and rejects blanket trust', async () => {
  const original = process.env.TRUST_PROXY;
  const db = new LocalStore(':memory:');
  try {
    process.env.TRUST_PROXY = '1';
    const app = createFullApplication(db);
    assert.equal(app.get('trust proxy'), 1);
    process.env.TRUST_PROXY = 'true';
    assert.throws(() => createFullApplication(db), /TRUST_PROXY/);
  } finally {
    await db.close();
    if (original === undefined) delete process.env.TRUST_PROXY;
    else process.env.TRUST_PROXY = original;
  }
});

test('representative manages assigned offerings and cannot read or mutate another university offering', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      rep = f.client();
    await admin.login('admin@example.test');
    const catalog = await admin.call('/catalog');
    const own = catalog.universities[0].UNIVERSITY_ID;
    const outside = catalog.universities[1].UNIVERSITY_ID;
    await admin.call('/admin/accounts', 'POST', {
      email: 'scoped-rep@example.test',
      role: 'representative',
      universityId: own,
      firstName: 'Scoped',
      lastName: 'Representative',
      password,
    });
    await rep.login('scoped-rep@example.test');
    const config = {
      universityId: own,
      intake: 2028,
      name: 'Scoped offering',
      program: 'Test',
      closingDate: '2028-10-31',
      minScore: 28,
      source: 'https://example.edu/',
      verified: false,
    };
    const other = await admin.call('/admin/offerings', 'POST', {
      ...config,
      universityId: outside,
    });
    const created = await rep.call('/representative/offerings', 'POST', config);
    await rep.call('/representative/offerings/' + created.offeringId, 'PATCH', {
      ...config,
      minScore: 30,
    });
    const listing = (await rep.call('/offerings')).offerings;
    assert.ok(listing.every((o) => o.UNIVERSITY_ID === own));
    assert.equal(listing.find((o) => o.UNI_QUAL_ID === created.offeringId).config.minScore, 30);
    await rep.call('/representative/offerings', 'POST', { ...config, universityId: outside }, 403);
    await rep.call('/representative/offerings/' + other.offeringId, 'PATCH', config, 403);
    await rep.call('/admin/offerings/' + other.offeringId, 'PATCH', config, 403);
    const after = (await admin.call('/offerings')).offerings.find(
      (o) => o.UNI_QUAL_ID === other.offeringId,
    );
    assert.equal(after.config.minScore, 28);
  } finally {
    await f.close();
  }
});

test('custom programme scoring persists and drives live eligibility with existing tables', async () => {
  const f = await fixture();
  try {
    const admin = f.client(),
      learner = f.client();
    await admin.login('admin@example.test');
    const c = await admin.call('/catalog');
    await admin.call('/admin/accounts', 'POST', {
      email: 'configured@example.test',
      role: 'learner',
      schoolId: c.schools[0].SCHOOL_ID,
      firstName: 'Configured',
      lastName: 'Learner',
      password,
    });
    await learner.login('configured@example.test');
    const codes = ['ENGHL', 'AFRFAL', 'MATH', 'LO', 'PHSC', 'LFSC', 'GEOG'];
    await learner.call('/results', 'PUT', {
      examTypeId: c.examTypes.find((e) => e.EXAM_TYPE_NAME === 'Grade 11 Final').EXAM_TYPE_ID,
      rows: codes.map((code) => ({
        subjectId: Number(c.subjects.find((s) => s.SUBJECT_CODE === code).SUBJECT_ID),
        percentage: 70,
      })),
    });
    const config = {
      universityId: c.universities[0].UNIVERSITY_ID,
      intake: 2028,
      name: 'Configured score integration fixture',
      program: 'Test',
      closingDate: '2028-10-31',
      minScore: 400,
      source: 'https://example.edu',
      verified: true,
      scoring: {
        mode: 'RAW',
        count: 6,
        divisor: 1,
        floor: 0,
        label: 'Percentage total',
        bands: [],
        exclude: ['LO'],
        overrides: [],
      },
      subjectGroups: [{ group: 1, code: 'MATH', minimum: 60 }],
      closingTime: '23:59',
    };
    const created = await admin.call('/admin/offerings', 'POST', config);
    const path =
      '/offerings/' +
      created.offeringId +
      '/requirements?examTypeId=' +
      c.examTypes.find((e) => e.EXAM_TYPE_NAME === 'Grade 11 Final').EXAM_TYPE_ID;
    let check = await learner.call(path);
    assert.equal(check.total, 420);
    assert.equal(check.eligible, true);
    assert.equal(check.offering.availability, 'Open');
    await admin.call('/admin/offerings/' + created.offeringId, 'PATCH', {
      ...config,
      minScore: 430,
    });
    check = await learner.call(path);
    assert.equal(check.eligible, false);
    await admin.call('/admin/offerings/' + created.offeringId, 'PATCH', {
      ...config,
      active: false,
    });
    check = await learner.call(path);
    assert.equal(check.offering.availability, 'Inactive');
    await learner.call(
      '/applications',
      'POST',
      { offeringId: created.offeringId, studyModeId: c.studyModes[0].STUDY_MODE_ID },
      409,
    );
    await admin.call(
      '/admin/offerings/' + created.offeringId,
      'PATCH',
      {
        ...config,
        scoring: {
          ...config.scoring,
          mode: 'BANDS',
          bands: [
            [0, 50, 1],
            [49, 101, 7],
          ],
        },
      },
      400,
    );
    check = await learner.call(path);
    assert.equal(
      check.offering.config.active,
      false,
      'Failed edit leaves stored configuration intact',
    );
  } finally {
    await f.close();
  }
});
