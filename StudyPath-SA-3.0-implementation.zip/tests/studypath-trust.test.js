import test from 'node:test';
import assert from 'node:assert/strict';
import { withProvenance, hasCompleteProvenance } from '../shared/trust/provenance.js';
import { compareFundingCriteria, isFundingOpportunityActionable } from '../shared/funding/matcher.js';
import { validateHypotheticalMarks, runWhatIf, unsuitableApplicationReason } from '../shared/scoring/what-if.js';
import { LocalPilotStore } from '../server/pilot-store.js';

const sourceProvenance = {
  source: { title: 'Official 2027 source', url: 'https://example.edu.za/prospectus-2027.pdf', year: 2027, pageRef: 'p. 12' },
  lastUpdated: '2026-10-01', conditions: ['Selection and final results checks apply'], status: 'verified', lastVerifiedByRole: 'admin',
};

test('provenance fails closed if source, date or conditions are missing', () => {
  for (const bad of [{}, { ...sourceProvenance, source: null }, { ...sourceProvenance, lastUpdated: 'not-date' }, { ...sourceProvenance, conditions: [] }]) {
    const result = withProvenance({ label: 'Meets published minimum' }, bad, { now: new Date('2026-10-26T00:00:00Z') });
    assert.equal(result.kind, 'cannot-confirm');
    assert.equal(result.recommendation, null);
  }
});

test('provenance returns verified only when record is status verified and fresh', () => {
  const current = withProvenance({ label: 'Meets published minimum' }, sourceProvenance, { now: new Date('2026-10-26T00:00:00Z') });
  assert.equal(current.kind, 'recommendation');
  assert.equal(hasCompleteProvenance(current), true);
  const stale = withProvenance({ label: 'Meets published minimum' }, { ...sourceProvenance, lastUpdated: '2025-01-01' }, { now: new Date('2026-10-26T00:00:00Z') });
  assert.equal(stale.kind, 'guidance');
  assert.equal(stale.provenance.stale, true);
  assert.equal(stale.recommendation, null);
});

test('provenance rejects future dates, invalid calendar dates and missing source page references', () => {
  const future = withProvenance({ label: 'Meets published minimum' }, { ...sourceProvenance, lastUpdated: '2027-01-01' }, { now: new Date('2026-10-26T00:00:00Z') });
  assert.equal(future.kind, 'cannot-confirm');
  const impossible = withProvenance({ label: 'Meets published minimum' }, { ...sourceProvenance, lastUpdated: '2026-02-31' }, { now: new Date('2026-10-26T00:00:00Z') });
  assert.equal(impossible.kind, 'cannot-confirm');
  const noPage = withProvenance({ label: 'Meets published minimum' }, { ...sourceProvenance, source: { ...sourceProvenance.source, pageRef: '' } }, { now: new Date('2026-10-26T00:00:00Z') });
  assert.equal(noPage.kind, 'cannot-confirm');
});

test('hypothetical marks validate percentages and duplicate subject codes', () => {
  assert.throws(() => validateHypotheticalMarks([{ SUBJECT_CODE: 'MATH', SUBJECT_CATEGORY: 'MATHEMATICS', PERCENTAGE: 101 }]));
  assert.throws(() => validateHypotheticalMarks([
    { SUBJECT_CODE: 'math', SUBJECT_CATEGORY: 'MATHEMATICS', PERCENTAGE: 50 },
    { SUBJECT_CODE: 'MATH', SUBJECT_CATEGORY: 'MATHEMATICS', PERCENTAGE: 60 },
  ]));
  const rows = [
    { SUBJECT_CODE: 'ENGHL', SUBJECT_CATEGORY: 'LANGUAGE', PERCENTAGE: 60 },
    { SUBJECT_CODE: 'MATH', SUBJECT_CATEGORY: 'MATHEMATICS', PERCENTAGE: 60 },
    { SUBJECT_CODE: 'PHSC', SUBJECT_CATEGORY: 'SUBJECT', PERCENTAGE: 60 },
  ];
  const result = runWhatIf(rows, rows.map((row) => row.SUBJECT_CODE === 'MATH' ? { ...row, PERCENTAGE: 80 } : row), null, {});
  assert.equal(result.saved, false);
  assert.equal(result.label, 'Hypothetical — not saved');
  assert.equal(result.after.total >= result.before.total, true);
});

test('unsuitable-application guard explains Mathematical Literacy mismatch', () => {
  const reason = unsuitableApplicationReason([
    { SUBJECT_CODE: 'MATHLIT', SUBJECT_CATEGORY: 'MATHEMATICAL_LITERACY', PERCENTAGE: 80 },
  ], { requiresMathematics: true });
  assert.match(reason, /requires Mathematics/i);
  assert.equal(unsuitableApplicationReason([
    { SUBJECT_CODE: 'MATH', SUBJECT_CATEGORY: 'MATHEMATICS', PERCENTAGE: 80 },
  ], { requiresMathematics: true }), null);
});

test('funding labels unknown criteria as possibly eligible and excludes stale/closed opportunities', () => {
  assert.equal(compareFundingCriteria([{ field: 'province', operator: 'eq', value: 'Gauteng' }], {}).label, 'Possibly eligible — check');
  assert.equal(compareFundingCriteria([{ field: 'province', operator: 'eq', value: 'Gauteng' }], { province: 'Eastern Cape' }).label, 'Does not match on known criteria');
  const base = { Status: 'verified', SourceTitle: 'Funder rules', SourceUrl: 'https://funder.example.org/rules', LastUpdatedOn: '2026-10-01', Conditions: 'subject to funder checks', ApplicationCloses: '2026-11-01' };
  assert.equal(isFundingOpportunityActionable(base, '2026-10-26'), true);
  assert.equal(isFundingOpportunityActionable({ ...base, LastUpdatedOn: '2026-01-01' }, '2026-10-26'), false);
  assert.equal(isFundingOpportunityActionable({ ...base, ApplicationCloses: '2026-10-25' }, '2026-10-26'), false);
  assert.equal(isFundingOpportunityActionable({ ...base, Status: 'draft' }, '2026-10-26'), false);
});

test('local StudyPathPilot store uses scoped parameterized CRUD and prevents duplicate consent rows', async () => {
  const store = new LocalPilotStore(':memory:');
  try {
    await store.insert('Consent', { PersonId: 10, Purpose: 'funding-matching', PolicyVersion: 'v1', Granted: 1, GrantedAt: '2026-10-26T00:00:00Z' });
    assert.equal((await store.list('Consent', { PersonId: 10, Purpose: 'funding-matching' })).length, 1);
    await assert.rejects(() => store.insert('Consent', { PersonId: 10, Purpose: 'funding-matching', PolicyVersion: 'v1', Granted: 1 }));
    assert.equal(await store.update('Consent', { PersonId: 10, Purpose: 'funding-matching', PolicyVersion: 'v1' }, { Granted: 0, WithdrawnAt: '2026-10-26T01:00:00Z' }), 1);
    assert.equal((await store.list('Consent', { PersonId: 10 }))[0].Granted, 0);
  } finally { await store.close(); }
});
