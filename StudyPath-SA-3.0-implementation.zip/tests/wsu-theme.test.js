import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(project, 'public');
const themePath = path.join(publicDir, 'assets/css/wsu-theme.css');

function htmlFiles(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? htmlFiles(target) : target.endsWith('.html') ? [target] : [];
  });
}

test('every public screen loads the shared WSU-inspired visual system', () => {
  const pages = htmlFiles(publicDir);
  assert.equal(
    pages.length,
    51,
    'update the expected count when adding or removing a public route',
  );
  for (const page of pages) {
    const html = readFileSync(page, 'utf8');
    assert.match(
      html,
      /\/assets\/css\/app\.css/,
      `${path.relative(publicDir, page)} keeps the app stylesheet`,
    );
    assert.match(
      html,
      /\/assets\/css\/wsu-theme\.css\?v=2\.0\.0/,
      `${path.relative(publicDir, page)} gets the refreshed theme`,
    );
    assert.doesNotMatch(
      html,
      /class="review-strip"/,
      `${path.relative(publicDir, page)} omits the database status strip`,
    );
    assert.match(
      html,
      /2027 entry|2027 university entry|2027 UNIVERSITY ENTRY|2027 Admissions|2027 UNDERGRADUATE PILOT|2027 PILOT/i,
      `${path.relative(publicDir, page)} carries the 2027 pilot entry label`,
    );
    assert.match(
      html,
      /inter-latin-variable\.woff2/,
      `${path.relative(publicDir, page)} preloads the self-hosted font`,
    );
  }
});

test('account security pages use POST-confirmed links and make administrator MFA optional', () => {
  const login = readFileSync(path.join(publicDir, 'login.html'), 'utf8');
  assert.match(
    readFileSync(path.join(publicDir, 'assets/js/full.js'), 'utf8'),
    /account-recovery\.html/,
  );
  assert.match(
    readFileSync(path.join(publicDir, 'assets/js/full.js'), 'utf8'),
    /Forgot password or need an email verification link/,
  );
  assert.match(readFileSync(path.join(publicDir, 'verify-email.html'), 'utf8'), /verify-email\.js/);
  assert.match(
    readFileSync(path.join(publicDir, 'reset-password.html'), 'utf8'),
    /name="confirmPassword"/,
  );
  assert.match(readFileSync(path.join(publicDir, 'mfa-setup.html'), 'utf8'), /mfa-setup\.js/);
  assert.match(readFileSync(path.join(publicDir, 'mfa-setup.html'), 'utf8'), /optional/i);
  assert.doesNotMatch(
    readFileSync(path.join(publicDir, 'assets/js/full.js'), 'utf8'),
    /mfaSetupRequired/,
  );
  assert.match(
    readFileSync(path.join(publicDir, 'mfa-challenge.html'), 'utf8'),
    /mfa-challenge\.js/,
  );
  assert.match(
    readFileSync(path.join(publicDir, 'assets/js/verify-email.js'), 'utf8'),
    /method:\s*'POST'/,
  );
});

test('the shared theme covers all four role portals and the common page components', () => {
  const theme = readFileSync(themePath, 'utf8');
  const font = path.join(publicDir, 'assets/fonts/inter-latin-variable.woff2');
  const fontLicense = path.join(publicDir, 'assets/fonts/OFL-Inter.txt');
  assert.ok(readFileSync(font).byteLength > 1000, 'self-hosted Inter font is bundled');
  assert.match(readFileSync(fontLicense, 'utf8'), /SIL OPEN FONT LICENSE/);
  for (const role of ['learner', 'teacher', 'representative', 'admin']) {
    const overview = path.join(publicDir, role, 'overview.html');
    assert.ok(
      readFileSync(overview, 'utf8').includes('wsu-theme.css'),
      `${role} dashboard loads the refreshed theme`,
    );
  }
  for (const selector of [
    '.sidebar',
    '.welcome-panel',
    '.stat-card',
    '.journey-grid',
    '.action-queue',
    '.page-footer',
    '.help-page',
    '.panel',
    '.table-wrap',
    '.fields',
    '.auth-card',
  ]) {
    assert.ok(theme.includes(selector), `theme includes ${selector}`);
  }
  assert.match(theme, /prefers-reduced-motion/);
  assert.match(theme, /max-width: 700px/);
  assert.match(theme, /\.nav-open \.sidebar/);
  assert.match(theme, /#551516/);
  assert.match(theme.toLowerCase(), /ochre oxide/);
  assert.match(theme, /font-weight: 100 900/);
  assert.match(theme, /scroll-snap-type: x mandatory/);
  assert.match(theme, /#574f48/);
  assert.match(
    theme,
    /background: var\(--brand-accent\)/,
    'the portal header uses the oxide accent',
  );
  assert.match(
    theme,
    /\.sidebar\s*\{\s*background: #fffefa/,
    'the portal navigation uses the warm light surface',
  );
});

test('learner dashboard preserves the 2027 pilot admissions badge and provides actionable next steps', () => {
  const source = readFileSync(path.join(publicDir, 'assets/js/full.js'), 'utf8');
  assert.match(source, /aria-label="\$\{intakeYear\} admissions"/);
  assert.match(source, /api\/dashboard\/summary/);
  assert.doesNotMatch(source, /Promise\.all\(catalog\.examTypes/);
  for (const action of [
    '/learner/results.html',
    '/learner/universities.html',
    '/learner/requirements.html',
    '/learner/applications.html',
  ]) {
    assert.ok(source.includes(action), `learner journey links to ${action}`);
  }
  assert.match(source, /Your application story starts here/);
  assert.match(source, /Help &amp; guidance/);
  assert.doesNotMatch(source, /26 university profiles/);
  const landing = readFileSync(path.join(publicDir, 'index.html'), 'utf8');
  assert.match(landing, /3 pilot institutions/);
});

test('inner pages use 2027 entry hierarchy and keep the mobile hero clear', () => {
  const source = readFileSync(path.join(publicDir, 'assets/js/full.js'), 'utf8');
  const theme = readFileSync(themePath, 'utf8');
  assert.match(source, /2027 UNIVERSITY ENTRY|\$\{intakeYear\} UNIVERSITY ENTRY/);
  assert.match(source, /requirements-review/);
  assert.match(source, /APS points/);
  assert.match(source, /Life Orientation is excluded/);
  assert.match(
    theme,
    /@media \(max-width: 700px\) \{\s*\.welcome-panel\s*\{\s*background: linear-gradient/,
  );
  assert.match(theme, /\.requirements-review \.review-meta p \{[^}]*font-size: 14px/);
});
