import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const fullJs = readFileSync(new URL('../public/assets/js/full.js', import.meta.url), 'utf8');

test('application review never shows an empty study-mode control without explanation', () => {
  assert.match(fullJs, /Choose a study mode/);
  assert.match(fullJs, /Study modes are not configured/);
  assert.match(fullJs, /Applications cannot be submitted until a\s+study mode\s+is available/);
  assert.match(fullJs, /Number\.isInteger\(studyModeId\)/);
});
