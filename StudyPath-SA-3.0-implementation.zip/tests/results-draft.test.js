import test from 'node:test';
import assert from 'node:assert/strict';
import { reconcileResultDraftRows } from '../shared/scoring/results-draft.js';

test('reconciles stale IDENTITY subject IDs by stable subject code', () => {
  const catalog = [
    {
      SUBJECT_ID: 101,
      SUBJECT_NAME: 'English Home Language',
      SUBJECT_CODE: 'ENGHL',
      SCHOOL_ID: null,
    },
    { SUBJECT_ID: 105, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', SCHOOL_ID: null },
  ];
  const result = reconcileResultDraftRows(
    [
      { SUBJECT_ID: 1, SUBJECT_NAME: 'Old ID label', SUBJECT_CODE: 'ENGHL', PERCENTAGE: 75 },
      { SUBJECT_ID: 2, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', PERCENTAGE: 54 },
    ],
    catalog,
    8,
  );
  assert.deepEqual(result.unresolved, []);
  assert.deepEqual(
    result.rows.map((row) => [row.SUBJECT_ID, row.SUBJECT_NAME, row.PERCENTAGE]),
    [
      [101, 'English Home Language', 75],
      [105, 'Mathematics', 54],
    ],
  );
});

test('reconciles drafts by normalized subject name when code is absent', () => {
  const result = reconcileResultDraftRows(
    [{ SUBJECT_ID: 2, SUBJECT_NAME: '  MATHEMATICS ', PERCENTAGE: '54' }],
    [{ SUBJECT_ID: 55, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', SCHOOL_ID: null }],
    8,
  );
  assert.deepEqual(result.unresolved, []);
  assert.equal(result.rows[0].SUBJECT_ID, 55);
  assert.equal(result.rows[0].PERCENTAGE, 54);
});

test('preserves unresolved draft marks and identifies subject for re-addition', () => {
  const result = reconcileResultDraftRows(
    [{ SUBJECT_ID: 24, SUBJECT_NAME: 'Old elective', PERCENTAGE: 69 }],
    [{ SUBJECT_ID: 1, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', SCHOOL_ID: null }],
    8,
  );
  assert.deepEqual(result.unresolved, ['Old elective']);
  assert.equal(result.rows[0].PERCENTAGE, 69);
  assert.match(result.rows[0].__subjectResolutionError, /remove and re-add/);
});

test('does not remap a subject that belongs to a different school', () => {
  const result = reconcileResultDraftRows(
    [
      {
        SUBJECT_ID: 2,
        SUBJECT_NAME: 'School-only elective',
        SUBJECT_CODE: 'ELEC1',
        PERCENTAGE: 69,
      },
    ],
    [{ SUBJECT_ID: 8, SUBJECT_NAME: 'School-only elective', SUBJECT_CODE: 'ELEC1', SCHOOL_ID: 88 }],
    7,
  );
  assert.deepEqual(result.unresolved, ['School-only elective']);
});

test('does not permit two stale draft rows to map to the same subject', () => {
  const result = reconcileResultDraftRows(
    [
      { SUBJECT_ID: 2, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', PERCENTAGE: 60 },
      { SUBJECT_ID: 7, SUBJECT_NAME: 'Maths (old label)', SUBJECT_CODE: 'MATH', PERCENTAGE: 70 },
    ],
    [{ SUBJECT_ID: 55, SUBJECT_NAME: 'Mathematics', SUBJECT_CODE: 'MATH', SCHOOL_ID: null }],
    8,
  );
  assert.equal(result.rows[0].SUBJECT_ID, 55);
  assert.equal(
    result.rows[1].__subjectResolutionError,
    'Duplicate or invalid subject — remove and re-add',
  );
  assert.equal(result.unresolved.length, 1);
});
