import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptDocument, decryptDocument, isEncryptedDocument, rewrapDocument, validateVaultKey } from '../server/vault-crypto.js';
const k1 = Buffer.alloc(32, 17).toString('base64');
const k2 = Buffer.alloc(32, 29).toString('base64');
const env1 = { VAULT_MASTER_KEY: k1, VAULT_KEY_ID: 'test-v1' };
const env2 = { VAULT_MASTER_KEY: k2, VAULT_KEY_ID: 'test-v2', VAULT_PREVIOUS_MASTER_KEYS: JSON.stringify({ 'test-v1': k1 }) };

test('vault validates a base64 32-byte key and encrypts with a versioned envelope', () => {
  assert.equal(validateVaultKey(env1), true);
  assert.throws(() => validateVaultKey({ VAULT_MASTER_KEY: Buffer.alloc(12, 1).toString('base64') }));
  const text = Buffer.from('private report card text');
  const encrypted = encryptDocument(text, env1);
  assert.equal(isEncryptedDocument(encrypted), true);
  assert.notEqual(encrypted.includes(text), true);
  assert.deepEqual(decryptDocument(encrypted, env1), text);
});

test('vault uses authenticated encryption; tampering and wrong keys fail closed', () => {
  const encrypted = encryptDocument(Buffer.from('tamper test'), env1);
  const altered = Buffer.from(encrypted); altered[altered.length - 1] ^= 1;
  assert.throws(() => decryptDocument(altered, env1));
  assert.throws(() => decryptDocument(encrypted, { VAULT_MASTER_KEY: k2, VAULT_KEY_ID: 'wrong-id' }));
});

test('key rotation rewraps the per-document data key without changing plaintext', () => {
  const input = Buffer.from('document data that must survive rotation');
  const encrypted = encryptDocument(input, env1);
  const rewrapped = rewrapDocument(encrypted, env2);
  assert.equal(isEncryptedDocument(rewrapped), true);
  assert.deepEqual(decryptDocument(rewrapped, env2), input);
  assert.deepEqual(decryptDocument(encrypted, env2), input, 'old key remains available during staged rotation');
});

test('legacy plaintext rows are detected for migration rather than silently altered', () => {
  const legacy = Buffer.from('%PDF-legacy-content');
  assert.equal(isEncryptedDocument(legacy), false);
  assert.deepEqual(decryptDocument(legacy, env1), legacy);
  assert.deepEqual(rewrapDocument(legacy, env2), legacy);
});
