import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  evaluateConfiguredScoring as score,
  evaluateAdmissionRoutes as routes,
} from '../shared/scoring/policy-engine.js';
const policies = JSON.parse(
  readFileSync(
    new URL(
      './fixtures/admission-reference/reviewed-policy-reference/policies.json',
      import.meta.url,
    ),
  ),
);
const basic = {
  version: 1,
  qualification: 'NSC',
  status: 'READY',
  mode: 'BANDS',
  count: 2,
  divisor: 1,
  floor: 0,
  bands: [
    [0, 30, 1],
    [30, 40, 2],
    [40, 50, 3],
    [50, 60, 4],
    [60, 70, 5],
    [70, 80, 6],
    [80, 101, 7],
  ],
  exclude: ['LO'],
  overrides: [],
  groups: [],
  bonuses: [],
  requirements: 'SELECTED',
  label: 'APS',
};
test('Configured scoring chooses the best valid combination, including required groups', () => {
  const marks = [
    { code: 'ENGHL', mark: 50 },
    { code: 'MATH', mark: 80 },
    { code: 'PHSC', mark: 90 },
  ];
  assert.equal(score(basic, marks).score, 14);
  const r = score(basic, marks, [{ group: 1, code: 'ENGHL', minimum: 50 }]);
  assert.equal(r.score, 11);
  assert.ok(r.selected.some((m) => m.code === 'ENGHL'));
  assert.equal(
    score(basic, marks, [{ group: 1, code: 'ENGHL', minimum: 60 }]).status,
    'NO_VALID_SELECTION',
  );
});
test('Configured scoring preserves raw percentages, weights, divisor and LO context bonuses', () => {
  const cfg = {
    ...basic,
    mode: 'RAW',
    divisor: 10,
    overrides: [{ codes: ['MATH'], weight: 2 }],
    bonuses: [{ subject: 'LO', minimum: 60, points: 2, quintiles: [1, 2] }],
  };
  const marks = [
    { code: 'ENGHL', mark: 60 },
    { code: 'MATH', mark: 80 },
    { code: 'LO', mark: 70 },
  ];
  assert.equal(score(cfg, marks).status, 'CONTEXT_REQUIRED');
  assert.equal(score(cfg, marks, [], 1).score, 24);
  assert.equal(score(cfg, marks, [], 5).score, 22);
});
test('Configured scoring rejects duplicates, overlapping bands and unreviewed policies', () => {
  assert.equal(
    score(basic, [
      { code: 'MATH', mark: 80 },
      { code: ' math ', mark: 60 },
    ]).status,
    'INPUT_ERROR',
  );
  assert.equal(
    score(
      {
        ...basic,
        bands: [
          [0, 101, 7],
          [0, 50, 1],
        ],
      },
      [
        { code: 'A', mark: 40 },
        { code: 'B', mark: 70 },
      ],
    ).status,
    'CONFIG_ERROR',
  );
  assert.equal(score({ ...basic, status: 'REVIEW' }, []).status, 'REVIEW_REQUIRED');
});
test('all 53 reviewed scoring configurations parse and evaluate without configuration errors', () => {
  const codes = ['ENGHL', 'AFRFAL', 'MATH', 'PHSC', 'LFSC', 'GEOG', 'LO'];
  for (const p of policies) {
    const result = score(
      p.RULE_CONFIG,
      codes.map((code, id) => ({ code, id, mark: 80 })),
      [],
      3,
    );
    assert.notEqual(result.status, 'CONFIG_ERROR', p.POLICY_NAME + ': ' + result.message);
    if (p.RULE_CONFIG.status !== 'READY') assert.equal(result.status, 'REVIEW_REQUIRED');
  }
});
test('admission routes apply alternative thresholds, stage restrictions and additional points', () => {
  const cfg = {
    version: 1,
    accepted_exam_types: ['Grade 11 Final'],
    routes: [
      { label: 'Maths', minimum_score: 28, groups: [{ codes: ['MATH'], count: 1, minimum: 50 }] },
      {
        label: 'Maths literacy',
        minimum_score: 30,
        groups: [{ codes: ['MLIT'], count: 1, minimum: 60 }],
      },
    ],
  };
  assert.equal(routes(cfg, [{ code: 'MLIT', mark: 70 }], 28, 'Grade 11 Final').required_score, 30);
  assert.equal(
    routes(cfg, [{ code: 'MATH', mark: 60 }], 28, 'Trial').status,
    'RESULT_STAGE_NOT_ALLOWED',
  );
  assert.equal(routes(cfg, [{ code: 'MATH', mark: 40 }], 28, 'Grade 11 Final').status, 'NO_ROUTE');
  const group = {
    version: 1,
    routes: [
      {
        label: 'Additional',
        minimum_score: 28,
        groups: [{ count: 2, minimum: 40, minimum_points: 10 }],
      },
    ],
  };
  assert.equal(
    routes(
      group,
      [
        { code: 'A', mark: 60 },
        { code: 'B', mark: 60 },
      ],
      28,
    ).status,
    'OK',
  );
  assert.equal(
    routes(
      group,
      [
        { code: 'A', mark: 40 },
        { code: 'B', mark: 40 },
      ],
      28,
    ).status,
    'NO_ROUTE',
  );
});
