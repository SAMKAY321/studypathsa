import test from 'node:test';
import assert from 'node:assert/strict';
import { retentionCutoff, collectRejectedDocumentCandidates, validateRetentionManifest } from '../shared/trust/retention.js';

test('retention cutoff validates period and anchors to UTC date', () => {
  assert.equal(retentionCutoff('2026-10-26T12:00:00Z', 365), '2025-10-26');
  assert.throws(() => retentionCutoff('bad date', 365));
  assert.throws(() => retentionCutoff('2026-10-26', 0));
});

test('only old explicitly rejected documents are candidates; upload age is not treated as expiry', () => {
  const statuses = [{ VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' }, { VERIFICATION_STATUS_ID: 2, VERIFICATION_STATUS_NAME: 'Rejected' }];
  const docs = [
    { DOCUMENT_ID: 1, PERSON_ID: 8, UPLOAD_DATE: '2025-01-01', VERIFICATION_STATUS_ID: 2 },
    { DOCUMENT_ID: 2, PERSON_ID: 8, UPLOAD_DATE: '2026-10-01', VERIFICATION_STATUS_ID: 2 },
    { DOCUMENT_ID: 3, PERSON_ID: 9, UPLOAD_DATE: '2024-01-01', VERIFICATION_STATUS_ID: 1 },
    { DOCUMENT_ID: 4, PERSON_ID: 9, UPLOAD_DATE: 'not a date', VERIFICATION_STATUS_ID: 2 },
  ];
  assert.deepEqual(collectRejectedDocumentCandidates({ documents: docs, statuses, retentionDays: 365, asOf: '2026-10-26T00:00:00Z' }).map((row) => row.documentId), [1]);
});

test('retention application requires two distinct approvers and a current eligible manifest', () => {
  const candidates = [{ documentId: 1, personId: 8, uploadDate: '2025-01-01', cutoff: '2025-10-26' }];
  const manifest = [{ documentId: 1, reason: 'rejected-document', approvedBy1: 'reviewer-a', approvedBy2: 'reviewer-b', approvedAt: '2026-10-20T12:00:00Z', notes: 'Approved under published retention policy' }];
  assert.equal(validateRetentionManifest(manifest, candidates, '2026-10-26T00:00:00Z').length, 1);
  assert.throws(() => validateRetentionManifest([{ ...manifest[0], approvedBy2: 'reviewer-a' }], candidates, '2026-10-26T00:00:00Z'), /two distinct approver/i);
  assert.throws(() => validateRetentionManifest([{ ...manifest[0], documentId: 2 }], candidates, '2026-10-26T00:00:00Z'), /not an old, rejected document/i);
});
