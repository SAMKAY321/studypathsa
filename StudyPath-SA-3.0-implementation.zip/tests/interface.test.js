import { reconcileResultDraftRows } from '../shared/scoring/results-draft.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';
import { scoreReview, subjects, sampleMarks } from '../shared/scoring/review.js';
import * as workflow from '../shared/review/workflow.js';
const root = new URL('../', import.meta.url);
const policies = JSON.parse(readFileSync(new URL('config/universities/2027/register.json', root)));
const controller = readFileSync(new URL('public/assets/js/review.js', root), 'utf8').replace(
  /^import .*;\n/gm,
  '',
);
const portalController = readFileSync(new URL('public/assets/js/portals.js', root), 'utf8')
  .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
  .replace('export function renderPortal', 'function renderPortal');
const renderPortal = new Function(
  ...Object.keys(workflow),
  portalController + '\nreturn renderPortal;',
)(...Object.values(workflow));
const iconSource = readFileSync(new URL('public/assets/icons/lucide.min.js', root), 'utf8');
async function page(path, stored) {
  const dom = new JSDOM(readFileSync(new URL('public/' + path, root), 'utf8'), {
    url: 'http://localhost/' + path,
    runScripts: 'outside-only',
  });
  if (stored) dom.window.sessionStorage.setItem('vv-portal-review', stored);
  dom.window.eval(iconSource);
  const api = async (path) =>
    path === '/api/health' ? { demoMode: true } : { universities: policies };
  new Function(
    'api',
    'scoreReview',
    'subjects',
    'sampleMarks',
    'renderPortal',
    'document',
    'window',
    'location',
    'sessionStorage',
    controller,
  )(
    api,
    scoreReview,
    subjects,
    sampleMarks,
    renderPortal,
    dom.window.document,
    dom.window,
    dom.window.location,
    dom.window.sessionStorage,
  );
  await new Promise((resolve) => setImmediate(resolve));
  return dom;
}
function change(dom, id, value) {
  const el = dom.window.document.getElementById(id);
  el.value = value;
  el.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
}
async function liveDashboard(role, summary, progress = {}) {
  const dom = new JSDOM(readFileSync(new URL('public/' + role + '/overview.html', root), 'utf8'), {
      url: 'http://localhost/' + role + '/overview.html',
      runScripts: 'outside-only',
    }),
    calls = [];
  const personId = 42;
  dom.window.lucide = { createIcons() {} };
  if (Object.keys(progress).length)
    dom.window.localStorage.setItem('vv-pathway-' + personId, JSON.stringify(progress));
  dom.window.api = async (path) => {
    calls.push(path);
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return { user: { role, personId, firstName: 'Test', lastName: 'User' }, csrf: 'test-token' };
    if (path === '/api/catalog')
      return {
        examTypes: [],
        schools: [],
        universities: [],
        subjects: [],
        documentTypes: [],
        verificationStatuses: [],
        studyModes: [],
        provinces: [],
        cities: [],
      };
    if (path === '/api/dashboard/summary') return summary;
    throw new Error('Unexpected request: ' + path);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
  await dom.window.startTest();
  return { dom, calls };
}
async function livePortal(path, role, handler, storage = {}) {
  const sourcePath = path.split('?')[0],
    dom = new JSDOM(readFileSync(new URL('public/' + sourcePath, root), 'utf8'), {
      url: 'http://localhost/' + path,
      runScripts: 'outside-only',
    }),
    calls = [];
  dom.window.lucide = { createIcons() {} };
  dom.window.assessSubjects = () => ({
    metric: 'Institution score',
    total: 90,
    contributions: [],
    status: 'Meets listed minimums',
    issues: [],
    eligible: true,
  });
  for (const [key, value] of Object.entries(storage)) dom.window.localStorage.setItem(key, value);
  const api = async (path, options = {}) => {
    calls.push({ path, options });
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: {
          role,
          personId: 42,
          firstName: 'Test',
          lastName: 'User',
          schoolId: 5,
          universityId: 3,
        },
        csrf: 'csrf-test',
      };
    return handler(path, options, calls);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  dom.window.reconcileResultDraftRows = reconcileResultDraftRows;
  dom.window.api = api;
  dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
  try {
    await dom.window.startTest();
    return { dom, calls };
  } catch (error) {
    dom.window.close();
    throw error;
  }
}
const tick = () => new Promise((resolve) => setImmediate(resolve));
const storageSnapshot = (window) =>
  Object.fromEntries(
    Array.from({ length: window.localStorage.length }, (_, index) => {
      const key = window.localStorage.key(index);
      return [key, window.localStorage.getItem(key)];
    }),
  );
test('requirements page loads all institutions, changes scoring and handles missing science', async () => {
  const dom = await page('learner/requirements.html');
  const d = dom.window.document;
  assert.equal(d.querySelectorAll('#university option').length, 26);
  assert.match(d.querySelector('#score').textContent, /34/);
  assert.equal(d.querySelectorAll('#breakdown tr').length, 7);
  assert.ok(d.querySelector('nav a[href="/learner/requirements.html"][aria-current="page"]'));
  assert.ok(d.querySelector('.brand svg'));
  change(dom, 'university', 'uwc');
  assert.match(d.querySelector('#score').textContent, /46/);
  change(dom, 'university', 'cput');
  change(dom, 'method', 'method3');
  assert.match(d.querySelector('#score').textContent, /57.5/);
  change(dom, 'method', 'method2');
  assert.equal(d.querySelector('#score').textContent, 'Not calculated');
  assert.match(d.querySelector('#reason').textContent, /Physical Sciences/);
  change(dom, 'exam', 'final');
  assert.equal(d.querySelector('#score').textContent, 'Not calculated');
  assert.ok(d.querySelector('button[disabled]'));
  dom.window.close();
});
test('directory filters and direct requirement links retain institution IDs', async () => {
  const dom = await page('learner/universities.html');
  const d = dom.window.document;
  assert.equal(d.querySelectorAll('#directory tr').length, 26);
  change(dom, 'province', 'Northern Cape');
  assert.match(d.querySelector('#count').textContent, /1 of 26/);
  change(dom, 'province', 'all');
  change(dom, 'university', 'uwc');
  assert.equal(d.querySelectorAll('#directory tr').length, 1);
  assert.match(d.querySelector('#directory a').href, /university=uwc/);
  dom.window.close();
});
test('sample marks save to the selected milestone without database writes', async () => {
  const dom = await page('learner/results.html');
  const d = dom.window.document;
  const input = d.querySelector('#mark-2');
  input.value = '55';
  input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
  assert.match(d.querySelector('#live-score').textContent, /33/);
  d.querySelector('#results-form').dispatchEvent(
    new dom.window.Event('submit', { bubbles: true, cancelable: true }),
  );
  assert.equal(JSON.parse(dom.window.sessionStorage.getItem('vv-review-grade11'))[2], 55);
  assert.match(d.querySelector('#feedback').textContent, /No SQL Server records/);
  change(dom, 'university', 'cput');
  change(dom, 'method', 'method2');
  assert.equal(d.querySelector('#live-score').textContent, 'Not calculated');
  dom.window.close();
});
test('all four portal dashboards use the supplied structure and labelled sample data', async () => {
  for (const role of ['learner', 'teacher', 'representative', 'admin']) {
    const dom = await page(role + '/overview.html');
    const d = dom.window.document;
    assert.ok(d.querySelector('.portal-header'));
    assert.ok(d.querySelector('.welcome-panel'));
    assert.ok(d.querySelector('.dashboard-stats'));
    assert.match(
      d.querySelector('main').textContent,
      /sample|Sample|Demonstration|demonstration|Review/,
    );
    assert.ok(d.querySelector('nav a[href="/' + role + '/profile.html"]'));
    dom.window.close();
  }
});

test('learner pathway marks completion and selects step three without skipping it', async () => {
  const { dom, calls } = await liveDashboard(
    'learner',
    {
      applications: [],
      applicationCount: 0,
      actionQueue: [],
      counts: { results: 7, documents: 0 },
    },
    { resultsReady: true, explored: true },
  );
  const d = dom.window.document,
    steps = [...d.querySelectorAll('.journey-card')];
  assert.equal(steps.length, 4);
  assert.ok(steps[0].classList.contains('is-complete'));
  assert.ok(steps[1].classList.contains('is-complete'));
  assert.ok(steps[2].classList.contains('is-current'));
  assert.equal(steps[2].getAttribute('aria-current'), 'step');
  assert.ok(!steps[3].classList.contains('is-current'));
  assert.match(steps[0].textContent, /Done/);
  assert.match(steps[1].textContent, /Done/);
  assert.match(steps[2].textContent, /Next step/);
  assert.match(steps[3].querySelector('.journey-action').textContent, /Find a programme to apply/);
  assert.equal(
    steps[3].querySelector('.journey-action').getAttribute('href'),
    '/learner/requirements.html',
  );
  assert.equal(d.querySelector('.welcome-cta').getAttribute('href'), '/learner/requirements.html');
  assert.deepEqual(
    calls.filter((path) => path === '/api/dashboard/summary'),
    ['/api/dashboard/summary'],
  );
  assert.ok(!calls.some((path) => path.startsWith('/api/results?')));
  dom.window.close();
});

test('browser visit flags cannot advance the learner journey before results exist', async () => {
  const { dom } = await liveDashboard(
    'learner',
    {
      applications: [],
      applicationCount: 0,
      actionQueue: [],
      counts: { results: 0, documents: 0 },
    },
    { explored: true, requirementsReviewed: true },
  );
  const d = dom.window.document,
    steps = [...d.querySelectorAll('.journey-card')];
  assert.equal(
    d.querySelector('.journey-progress-count').textContent.trim(),
    '0 of 4 steps complete',
  );
  assert.ok(steps[0].classList.contains('is-current'));
  assert.ok(steps.slice(1, 3).every((step) => !step.classList.contains('is-complete')));
  assert.match(
    d.querySelector('#journey-title').parentElement.textContent,
    /remembered in this browser/,
  );
  dom.window.close();
});

test('visits from before results are cleared when the learner first has results', async () => {
  const { dom } = await liveDashboard(
    'learner',
    {
      applications: [],
      applicationCount: 0,
      actionQueue: [],
      counts: { results: 7, documents: 0 },
    },
    { explored: true, requirementsReviewed: true },
  );
  const steps = [...dom.window.document.querySelectorAll('.journey-card')];
  assert.equal(
    dom.window.document.querySelector('.journey-progress-count').textContent.trim(),
    '1 of 4 steps complete',
  );
  assert.ok(steps[0].classList.contains('is-complete'));
  assert.ok(steps[1].classList.contains('is-current'));
  assert.ok(steps.slice(1, 3).every((step) => !step.classList.contains('is-complete')));
  const progress = JSON.parse(dom.window.localStorage.getItem('vv-pathway-42'));
  assert.equal(progress.resultsReady, true);
  assert.equal(progress.explored, undefined);
  dom.window.close();
});

test('staff dashboards show oldest-first role queues instead of bare count cards', async () => {
  const queue = [
    {
      id: 1,
      title: 'Sample learner A',
      detail: 'Qualification A',
      context: 'University A',
      status: 'Submitted',
      date: '2026-09-01',
      href: '/portal/applications.html',
      label: 'Review',
    },
    {
      id: 2,
      title: 'Sample learner B',
      detail: 'Qualification B',
      context: 'University B',
      status: 'Submitted',
      date: '2026-09-12',
      href: '/portal/applications.html',
      label: 'Review',
    },
  ];
  for (const [role, counts] of [
    ['teacher', { learners: 4 }],
    ['representative', { awaitingReview: 2 }],
    ['admin', { accounts: 3, universities: 26, offerings: 2 }],
  ]) {
    const { dom } = await liveDashboard(role, {
      applications: [],
      applicationCount: 2,
      actionQueue: queue,
      counts,
    });
    const d = dom.window.document;
    assert.ok(d.querySelector('.action-queue'));
    assert.equal(d.querySelectorAll('.queue-list li').length, 2);
    assert.match(d.querySelector('.queue-list li:first-child').textContent, /Sample learner A/);
    assert.ok(d.querySelector('.welcome-cta'));
    assert.equal(d.querySelector('.dashboard-stats'), null);
    dom.window.close();
  }
  const { dom } = await liveDashboard('admin', {
    applications: [],
    applicationCount: 0,
    actionQueue: [],
    counts: { accounts: 1, universities: 1, offerings: 0 },
  });
  assert.match(dom.window.document.querySelector('.role-metrics').textContent, /1\s*user account/);
  assert.doesNotMatch(
    dom.window.document.querySelector('.role-metrics').textContent,
    /1\s*user accounts/,
  );
  assert.match(dom.window.document.querySelector('.queue-empty').textContent, /setup checklist/);
  dom.window.close();
});

test('learner deadline strip only appears for real supplied closing dates', async () => {
  const { dom } = await liveDashboard('learner', {
    applications: [],
    applicationCount: 0,
    actionQueue: [],
    counts: { results: 0, documents: 0 },
    closingSoon: [
      {
        id: 8,
        title: 'Bachelor of Science',
        university: 'Eastern Cape University',
        date: '2026-10-25',
      },
    ],
  });
  const strip = dom.window.document.querySelector('.closing-soon');
  assert.ok(strip);
  assert.match(strip.textContent, /Bachelor of Science/);
  assert.match(strip.querySelector('a').href, /offeringId=8/);
  dom.window.close();
});

test('learner shell appears while portal catalog data is still loading', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/learner/universities.html', root), 'utf8'), {
    url: 'http://localhost/learner/universities.html',
    runScripts: 'outside-only',
  });
  let releaseCatalog;
  const pendingCatalog = new Promise((resolve) => {
    releaseCatalog = resolve;
  });
  dom.window.lucide = { createIcons() {} };
  dom.window.api = async (path) => {
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: { role: 'learner', personId: 42, firstName: 'Test', lastName: 'User' },
        csrf: 'test-token',
      };
    if (path === '/api/catalog') return pendingCatalog;
    if (path === '/api/offerings') return { offerings: [] };
    throw new Error('Unexpected request: ' + path);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  try {
    dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
    const started = dom.window.startTest();
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(
      dom.window.document.querySelector('#navigation a[aria-current="page"]').textContent.trim(),
      'Universities',
    );
    assert.equal(
      dom.window.document.querySelector('.portal-account').textContent.trim(),
      'Sign out',
    );
    assert.equal(
      dom.window.document.querySelector('main h1').textContent,
      'Loading your workspace',
    );
    releaseCatalog({
      schools: [],
      universities: [],
      subjects: [],
      examTypes: [],
      documentTypes: [],
      verificationStatuses: [],
      studyModes: [],
      provinces: [],
      cities: [],
    });
    await started;
    assert.equal(dom.window.document.querySelector('main h1').textContent, 'Universities');
  } finally {
    dom.window.close();
  }
});
test('sample teacher verification flows into representative decisions and learner history', async () => {
  let dom = await page('teacher/results.html');
  let d = dom.window.document;
  d.querySelector('[data-verify-results="sample-l2"]').click();
  assert.match(d.querySelector('#portal-feedback').textContent, /do not match/);
  d.querySelector('[data-verify-results="sample-l1"]').click();
  let stored = dom.window.sessionStorage.getItem('vv-portal-review');
  dom.window.close();
  dom = await page('teacher/documents.html', stored);
  d = dom.window.document;
  for (const id of ['sample-d1', 'sample-d2'])
    d.querySelector('[data-verify-doc="' + id + '"]').click();
  stored = dom.window.sessionStorage.getItem('vv-portal-review');
  dom.window.close();
  dom = await page('teacher/applications.html', stored);
  d = dom.window.document;
  assert.doesNotMatch(d.querySelector('main').textContent, /Sample Learner Three/);
  d.querySelector('[data-screen="sample-a1"]').click();
  stored = dom.window.sessionStorage.getItem('vv-portal-review');
  dom.window.close();
  dom = await page('representative/decisions.html', stored);
  d = dom.window.document;
  assert.doesNotMatch(d.querySelector('main').textContent, /Sample Learner Two/);
  d.querySelector('[data-decision="sample-a1"][data-target="Provisionally Accepted"]').click();
  stored = dom.window.sessionStorage.getItem('vv-portal-review');
  dom.window.close();
  dom = await page('learner/applications.html', stored);
  d = dom.window.document;
  assert.match(d.querySelector('main').textContent, /Provisionally Accepted/);
  assert.equal(d.querySelectorAll('.timeline li').length, 3);
  dom.window.close();
});

test('live account page shows the sign-in username and restores disabled access', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/admin/accounts.html', root), 'utf8'), {
    url: 'http://localhost/admin/accounts.html',
    runScripts: 'outside-only',
  });
  let disabled = true;
  const calls = [];
  const api = async (path, options = {}) => {
    calls.push([path, options.method]);
    if (path === '/api/health') return { mode: 'local' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: { role: 'admin', personId: 1, firstName: 'Admin', lastName: 'Test' },
        csrf: 'test-csrf',
      };
    if (path === '/api/catalog') return { schools: [], universities: [] };
    if (path === '/api/admin/unlinked') return { people: [] };
    if (path === '/api/admin/accounts')
      return {
        accounts: [
          {
            accountId: 'test-account',
            username: 'actual-login@example.test',
            disabled,
            user: {
              personId: 2,
              username: 'legacy-name',
              role: 'teacher',
              firstName: 'Test',
              lastName: 'Teacher',
            },
          },
        ],
      };
    if (path === '/api/admin/accounts/test-account/enable') {
      assert.equal(options.headers['X-CSRF-Token'], 'test-csrf');
      disabled = false;
      return { message: 'Account restored. The user must sign in again.' };
    }
    if (path === '/api/admin/accounts/test-account/disable' && options.method === 'POST') {
      disabled = true;
      return { message: 'Account disabled.' };
    }
    if (path === '/api/admin/accounts/test-account/password-reset' && options.method === 'POST')
      return { message: 'Password reset link sent.' };
    throw new Error('Unexpected API request: ' + path);
  };
  try {
    const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
      .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
      .replace('export async function startFullApp', 'async function startFullApp');
    dom.window.testApi = api;
    dom.window.eval('const api=window.testApi;\n' + source + '\nwindow.startTest=startFullApp;');
    await dom.window.startTest();
    assert.match(
      dom.window.document.querySelector('main').textContent,
      /actual-login@example.test/,
    );
    assert.doesNotMatch(dom.window.document.querySelector('main').textContent, /legacy-name/);
    dom.window.document.querySelector('[data-account-action="enable"]').click();
    await new Promise((r) => setImmediate(r));
    assert.ok(calls.some(([path, method]) => path.endsWith('/enable') && method === 'POST'));
    assert.ok(dom.window.document.querySelector('[data-account-action="disable"]'));
    assert.ok(dom.window.document.querySelector('[data-account-password-reset="test-account"]'));
    assert.doesNotMatch(
      dom.window.document.querySelector('#account').textContent,
      /Initial password/,
    );
    assert.match(dom.window.document.querySelector('#feedback').textContent, /Account restored/);
    dom.window.document.querySelector('[data-account-password-reset="test-account"]').click();
    await new Promise((r) => setImmediate(r));
    assert.ok(
      calls.some(([path, method]) => path.endsWith('/password-reset') && method === 'POST'),
    );
    assert.match(
      dom.window.document.querySelector('#feedback').textContent,
      /Password reset link sent/,
    );
    dom.window.document.querySelector('[data-account-action="disable"]').click();
    await new Promise((r) => setImmediate(r));
    assert.ok(calls.some(([path, method]) => path.endsWith('/disable') && method === 'POST'));
    assert.ok(dom.window.document.querySelector('[data-account-action="enable"]'));
  } finally {
    dom.window.close();
  }
});

test('sign-in screen uses the branded split layout and accessible account tabs', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/login.html', root), 'utf8'), {
    url: 'http://localhost/login.html',
    runScripts: 'outside-only',
  });
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  const calls = [];
  dom.window.api = async (path) => {
    calls.push(path);
    if (path === '/api/health') return { mode: 'sqlserver' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/catalog') return { schools: [{ SCHOOL_ID: 1, SCHOOL_NAME: 'Test School' }] };
    if (path === '/api/auth/login' || path === '/api/auth/register')
      throw new Error('Expected test rejection.');
    throw new Error('Unexpected request: ' + path);
  };
  dom.window.lucide = { createIcons() {} };
  try {
    dom.window.eval(source + '\nwindow.startTest=startFullApp;');
    await dom.window.startTest();
    const d = dom.window.document;
    assert.ok(d.body.classList.contains('is-auth'));
    assert.ok(d.querySelector('.auth-layout .auth-story'));
    assert.ok(d.querySelector('.auth-layout .auth-card'));
    assert.ok(d.querySelector('.auth-story-cta'));
    assert.equal(d.querySelector('.auth-brand').getAttribute('href'), '/');
    assert.equal(d.querySelector('.auth-mobile-brand').getAttribute('href'), '/');
    assert.equal(d.querySelector('.portal-header').hidden, true);
    assert.equal(d.querySelector('#auth-tab-login').getAttribute('aria-selected'), 'true');
    assert.equal(d.querySelector('#auth-register-panel').hidden, true);
    assert.ok(d.querySelector('#login input[name="username"]'));
    assert.ok(d.querySelector('#register select[name="schoolId"]'));
    assert.equal(d.querySelector('#login button').type, 'submit');
    assert.equal(d.querySelector('#register button').type, 'submit');
    d.querySelector('#auth-create-account').click();
    assert.equal(d.querySelector('#auth-login-panel').hidden, true);
    assert.equal(d.querySelector('#auth-register-panel').hidden, false);
    assert.equal(d.querySelector('#auth-tab-register').getAttribute('aria-selected'), 'true');
    d.querySelector('#register').dispatchEvent(
      new dom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await new Promise((r) => setImmediate(r));
    assert.equal(d.querySelector('#register button').disabled, false);
    assert.ok(calls.includes('/api/auth/register'));
    d.querySelector('#auth-tab-login').click();
    assert.equal(d.querySelector('#auth-login-panel').hidden, false);
    assert.equal(d.querySelector('#auth-tab-login').getAttribute('aria-selected'), 'true');
    d.querySelector('#login').dispatchEvent(
      new dom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await new Promise((r) => setImmediate(r));
    assert.equal(d.querySelector('#login button').disabled, false);
    assert.ok(calls.includes('/api/auth/login'));
    assert.deepEqual(calls, [
      '/api/health',
      '/api/public-config',
      '/api/catalog',
      '/api/auth/register',
      '/api/auth/login',
    ]);
  } finally {
    dom.window.close();
  }
});

test('local-only development school is not offered as a real learner registration choice', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/login.html', root), 'utf8'), {
    url: 'http://localhost/login.html',
    runScripts: 'outside-only',
    pretendToBeVisual: true,
  });
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  dom.window.api = async (path) => {
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/catalog')
      return {
        schools: [
          { SCHOOL_ID: 1, SCHOOL_NAME: 'Development Secondary School', EMIS_NUMBER: 'LOCAL-ONLY' },
        ],
      };
    throw new Error('Unexpected request: ' + path);
  };
  dom.window.lucide = { createIcons() {} };
  try {
    dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
    await dom.window.startTest();
    dom.window.document.querySelector('#auth-tab-register').click();
    const d = dom.window.document;
    assert.equal(d.querySelectorAll('#register [name="schoolId"] option').length, 1);
    assert.equal(d.querySelector('#register button').disabled, true);
    assert.match(
      d.querySelector('#auth-register-panel .form-help').textContent,
      /No schools are configured/,
    );
    assert.doesNotMatch(d.querySelector('#register').textContent, /Development Secondary School/);
  } finally {
    dom.window.close();
  }
});

test('profile and audit screens show readable names and summaries instead of internal database IDs', async () => {
  const catalog = {
    schools: [{ SCHOOL_ID: 5, SCHOOL_NAME: 'Mthatha Secondary' }],
    universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Walter Sisulu University' }],
    cities: [],
    provinces: [],
    subjects: [],
    examTypes: [],
    documentTypes: [],
    verificationStatuses: [],
    studyModes: [],
  };
  const profile = await livePortal('learner/profile.html', 'learner', async (path) => {
    if (path === '/api/catalog') return catalog;
    if (path === '/api/me/profile')
      return {
        person: {
          FIRST_NAME: 'Test',
          LAST_NAME: 'User',
          PHONE_NUMBER: null,
          EMAIL: 'test@example.test',
        },
      };
    throw new Error('Unexpected request: ' + path);
  });
  try {
    assert.match(
      profile.dom.window.document.querySelector('main').textContent,
      /Mthatha Secondary/,
    );
    assert.doesNotMatch(profile.dom.window.document.querySelector('main').textContent, /School 5/);
  } finally {
    profile.dom.window.close();
  }
  const audit = await livePortal('admin/audit.html', 'admin', async (path) => {
    if (path === '/api/catalog') return catalog;
    if (path === '/api/admin/audit')
      return {
        events: [
          {
            CREATED_AT: '2026-10-12T12:00:00.000Z',
            actor: 'Kagiso Mathabathe',
            EVENT: 'account.create',
            DETAIL: '{"personId":23,"role":"teacher","invitation":true}',
          },
        ],
      };
    throw new Error('Unexpected request: ' + path);
  });
  try {
    const text = audit.dom.window.document.querySelector('main').textContent;
    assert.match(text, /Kagiso Mathabathe/);
    assert.match(text, /role: teacher/);
    assert.match(text, /invitation: yes/);
    assert.doesNotMatch(text, /personId|Actor person ID|\b23\b/);
  } finally {
    audit.dom.window.close();
  }
});

test('learner university directory searches mapped locations and links configured programmes', async () => {
  const catalog = {
    schools: [],
    universities: [
      {
        UNIVERSITY_ID: '31',
        UNIVERSITY_NAME: 'Western Cape University',
        PROVINCE_ID: '2',
        CITY_ID: '4',
      },
      {
        UNIVERSITY_ID: '32',
        UNIVERSITY_NAME: 'New University from database',
        PROVINCE_ID: '2',
        CITY_ID: null,
      },
    ],
    cities: [{ CITY_ID: '4', CITY_NAME: 'Cape Town' }],
    provinces: [{ PROVINCE_ID: '2', PROVINCE_NAME: 'Western Cape' }],
    subjects: [],
    examTypes: [],
    documentTypes: [],
    verificationStatuses: [],
    studyModes: [],
  };
  const offering = {
    UNI_QUAL_ID: '99',
    UNIVERSITY_ID: '31',
    university: 'Western Cape University',
    qualification: 'Bachelor of Science',
    program: 'Science',
    APPLICATION_CLOSING_DATE: '2028-09-30',
    config: { intake: 2028, status: 'verified', source: 'https://example.test', minScore: 30 },
  };
  const page = await livePortal('learner/universities.html', 'learner', async (path) => {
    if (path === '/api/catalog') return catalog;
    if (path === '/api/offerings') return { offerings: [offering] };
    throw new Error('Unexpected request: ' + path);
  });
  try {
    const d = page.dom.window.document,
      text = d.querySelector('#directory-grid').textContent;
    assert.match(text, /Western Cape University/);
    assert.match(text, /Cape Town/);
    assert.match(text, /Bachelor of Science/);
    assert.match(text, /Check requirements/);
    assert.match(text, /Location not recorded/);
    assert.doesNotMatch(text, /UNIVERSITY_ID|Historical 2027|Scoring profile/);
    assert.equal(
      d.querySelector('#directory-grid a').getAttribute('href'),
      '/learner/requirements.html?offeringId=99',
    );
    d.querySelector('#search').value = 'cape town';
    d.querySelector('#search').dispatchEvent(new page.dom.window.Event('input', { bubbles: true }));
    assert.equal(d.querySelectorAll('#directory-grid tbody tr').length, 1);
  } finally {
    page.dom.window.close();
  }
});

test('directory Edit loads SQL string IDs and submits an update; policy review stays separate', async () => {
  const directoryDom = new JSDOM(
      readFileSync(new URL('public/admin/directories.html', root), 'utf8'),
      { url: 'http://localhost/admin/directories.html', runScripts: 'outside-only' },
    ),
    calls = [];
  directoryDom.window.lucide = { createIcons() {} };
  const catalog = {
    schools: [{ SCHOOL_ID: 7, SCHOOL_NAME: 'Existing School' }],
    universities: [],
    cities: [{ CITY_ID: 4, CITY_NAME: 'Mthatha' }],
    provinces: [{ PROVINCE_ID: 2, PROVINCE_NAME: 'Eastern Cape' }],
    subjects: [],
    examTypes: [],
    studyModes: [],
    documentTypes: [],
    verificationStatuses: [],
  };
  const api = async (path, options = {}) => {
    calls.push([path, options]);
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: { role: 'admin', personId: 1, firstName: 'Admin', lastName: 'User' },
        csrf: 'test-csrf',
      };
    if (path === '/api/catalog') return catalog;
    if (path === '/api/admin/directories/schools')
      return {
        rows: [
          {
            SCHOOL_ID: '12',
            SCHOOL_NAME: 'Old Name',
            EMIS_NUMBER: 'EMIS12',
            CITY_ID: 4,
            PROVINCE_ID: 2,
          },
        ],
      };
    if (path === '/api/admin/directories/schools/12' && options.method === 'PATCH')
      return { message: 'School updated.' };
    throw new Error('Unexpected request: ' + path);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  try {
    directoryDom.window.api = api;
    directoryDom.window.eval(
      'const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;',
    );
    await directoryDom.window.startTest();
    const d = directoryDom.window.document,
      edit = d.querySelector('[data-directory-edit="12"]');
    assert.ok(edit, 'directory row exposes its Edit action');
    edit.click();
    assert.equal(d.querySelector('[name="SCHOOL_NAME"]').value, 'Old Name');
    assert.equal(d.querySelector('[name="EMIS_NUMBER"]').value, 'EMIS12');
    assert.equal(d.querySelector('#directory-submit').textContent, 'Update record');
    assert.equal(d.querySelector('#directory-cancel').hidden, false);
    assert.match(d.querySelector('#managed-directory').textContent, /Mthatha/);
    assert.match(d.querySelector('#managed-directory').textContent, /Eastern Cape/);
    assert.doesNotMatch(d.querySelector('#managed-directory').textContent, /CITY_ID|PROVINCE_ID/);
    d.querySelector('[name="SCHOOL_NAME"]').value = 'Updated School';
    d.querySelector('#directory-form').dispatchEvent(
      new directoryDom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await new Promise((resolve) => setImmediate(resolve));
    const update = calls.find(
      ([path, options]) =>
        path === '/api/admin/directories/schools/12' && options.method === 'PATCH',
    );
    assert.ok(update, 'Edit submits a PATCH to the matching string ID');
    assert.deepEqual(JSON.parse(update[1].body), {
      SCHOOL_NAME: 'Updated School',
      EMIS_NUMBER: 'EMIS12',
      CITY_ID: 4,
      PROVINCE_ID: 2,
    });
    assert.match(d.querySelector('#feedback').textContent, /School updated/);
  } finally {
    directoryDom.window.close();
  }
  const policyDom = new JSDOM(readFileSync(new URL('public/admin/policies.html', root), 'utf8'), {
    url: 'http://localhost/admin/policies.html',
    runScripts: 'outside-only',
  });
  policyDom.window.lucide = { createIcons() {} };
  policyDom.window.api = async (path) => {
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: { role: 'admin', personId: 1, firstName: 'Admin', lastName: 'User' },
        csrf: 'test-csrf',
      };
    if (path === '/api/catalog')
      return {
        schools: [],
        universities: [],
        cities: [],
        provinces: [],
        subjects: [],
        examTypes: [],
        studyModes: [],
        documentTypes: [],
        verificationStatuses: [],
      };
    if (path === '/api/offerings') return { offerings: [] };
    throw new Error('Unexpected policies API request: ' + path);
  };
  try {
    policyDom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
    await policyDom.window.startTest();
    assert.match(
      policyDom.window.document.querySelector('main h1').textContent,
      /Programme requirements/,
    );
    assert.equal(policyDom.window.document.querySelector('#directory-form'), null);
    assert.match(policyDom.window.document.querySelector('main').textContent, /No records yet/);
  } finally {
    policyDom.window.close();
  }
});

test('programme Edit loads SQL string IDs, supports cancel and saves changes', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/admin/offerings.html', root), 'utf8'), {
      url: 'http://localhost/admin/offerings.html',
      runScripts: 'outside-only',
    }),
    calls = [];
  dom.window.lucide = { createIcons() {} };
  const catalog = {
      schools: [],
      universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
      cities: [],
      provinces: [],
      subjects: [],
      examTypes: [],
      studyModes: [],
      documentTypes: [],
      verificationStatuses: [],
    },
    policy = policies[0];
  const offering = {
    UNI_QUAL_ID: '17',
    UNIVERSITY_ID: 3,
    university: 'Eastern Cape University',
    qualification: 'Bachelor of Science',
    program: 'Natural Sciences',
    APPLICATION_CLOSING_DATE: '2028-01-31',
    config: {
      universityKey: policy.id,
      intake: 2028,
      status: 'verified',
      source: 'https://example.test/admissions',
      minScore: 34,
      finalMinScore: null,
      minEnglish: 50,
      minMath: 60,
      requiredCodes: ['MATH'],
      subjectMinimums: {},
      method: 'method1',
      notes: 'Source reviewed.',
    },
  };
  const api = async (path, options = {}) => {
    calls.push([path, options]);
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/me')
      return {
        user: { role: 'admin', personId: 1, firstName: 'Admin', lastName: 'User' },
        csrf: 'test-csrf',
      };
    if (path === '/api/catalog') return catalog;
    if (path === '/api/offerings') return { offerings: [offering] };
    if (path === '/api/admin/offerings/17' && options.method === 'PATCH')
      return { message: 'Offering saved.' };
    throw new Error('Unexpected request: ' + path);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  dom.window.reconcileResultDraftRows = reconcileResultDraftRows;
  dom.window.api = api;
  try {
    dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
    await dom.window.startTest();
    const d = dom.window.document;
    assert.match(d.querySelector('#main').textContent, /Natural Sciences/);
    d.querySelector('[data-edit-offering="17"]').click();
    assert.equal(d.querySelector('[name="name"]').value, 'Bachelor of Science');
    assert.equal(d.querySelector('[name="program"]').value, 'Natural Sciences');
    assert.equal(d.querySelector('[name="minScore"]').value, '34');
    assert.equal(d.querySelector('#offering-submit').textContent, 'Update offering');
    d.querySelector('#offering-cancel').click();
    assert.equal(d.querySelector('#offering-submit').textContent, 'Save offering');
    assert.equal(d.querySelector('[name="name"]').readOnly, false);
    d.querySelector('[data-edit-offering="17"]').click();
    d.querySelector('[name="minScore"]').value = '35';
    d.querySelector('#offering-form').dispatchEvent(
      new dom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await new Promise((resolve) => setImmediate(resolve));
    const update = calls.find(
      ([path, options]) => path === '/api/admin/offerings/17' && options.method === 'PATCH',
    );
    assert.ok(update, 'the edit action targets a string offering ID');
    assert.equal(JSON.parse(update[1].body).minScore, 35);
    assert.match(d.querySelector('#feedback').textContent, /Programme offering saved/);
  } finally {
    dom.window.close();
  }
});

test('learner Results buttons add, edit, remove and save subjects to the selected exam milestone', async () => {
  const subjects = [
    {
      SUBJECT_ID: '11',
      SUBJECT_NAME: 'Mathematics',
      SUBJECT_CODE: 'MATH',
      SUBJECT_CATEGORY: 'MATHEMATICS',
      SCHOOL_ID: '5',
    },
    {
      SUBJECT_ID: '12',
      SUBJECT_NAME: 'English',
      SUBJECT_CODE: 'ENG',
      SUBJECT_CATEGORY: 'FIRST_ADDITIONAL_LANGUAGE',
      SCHOOL_ID: '5',
    },
  ];
  let stored = [];
  const { dom, calls } = await livePortal(
    'learner/results.html',
    'learner',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [],
          subjects,
          examTypes: [{ EXAM_TYPE_ID: 2, EXAM_TYPE_NAME: 'Grade 12 Trial' }],
          documentTypes: [],
          verificationStatuses: [
            { VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' },
          ],
          studyModes: [],
          provinces: [],
          cities: [],
        };

      if (path === '/api/results?examTypeId=2') return { rows: stored };
      if (path === '/api/results' && options.method === 'PUT') {
        stored = JSON.parse(options.body).rows.map((row) => ({
          ...subjects.find((s) => String(s.SUBJECT_ID) === String(row.subjectId)),
          PERCENTAGE: row.percentage,
          VERIFICATION_STATUS_ID: 1,
        }));
        return { message: 'Results saved for teacher verification.' };
      }
      throw new Error('Unexpected request: ' + path);
    },
  );
  try {
    const d = dom.window.document;
    assert.ok(d.querySelector('#add'));
    assert.ok(d.querySelector('#save-results'));
    d.querySelector('#subject').value = '11';
    d.querySelector('#add').click();
    assert.equal(d.querySelectorAll('[data-mark]').length, 1);
    assert.match(d.querySelector('#result-grid').textContent, /Mathematics/);
    d.querySelector('[data-mark="0"]').value = '76.5';
    d.querySelector('[data-mark="0"]').dispatchEvent(
      new dom.window.Event('input', { bubbles: true }),
    );
    d.querySelector('#subject').value = '12';
    d.querySelector('#add').click();
    assert.equal(d.querySelectorAll('[data-mark]').length, 2);
    d.querySelector('[data-mark="1"]').value = '81';
    d.querySelector('[data-mark="1"]').dispatchEvent(
      new dom.window.Event('input', { bubbles: true }),
    );
    d.querySelector('#save-results').click();
    await tick();
    await tick();
    const save = calls.find(
      (call) => call.path === '/api/results' && call.options.method === 'PUT',
    );
    assert.ok(save, 'Save results sends the API update');
    assert.deepEqual(JSON.parse(save.options.body), {
      examTypeId: 2,
      rows: [
        { subjectId: 11, percentage: 76.5 },
        { subjectId: 12, percentage: 81 },
      ],
    });
    assert.match(d.querySelector('#feedback').textContent, /Results saved/);
    assert.equal(d.querySelectorAll('#result-grid tbody tr').length, 2);
    d.querySelector('[data-remove="0"]').click();
    assert.equal(d.querySelectorAll('[data-mark]').length, 1);
    assert.match(d.querySelector('#result-grid').textContent, /English/);
  } finally {
    dom.window.close();
  }
});

test('learner result drafts and selected exam survive Results → Subjects → Results navigation', async () => {
  const subjects = [
      {
        SUBJECT_ID: '11',
        SUBJECT_NAME: 'Mathematics',
        SUBJECT_CODE: 'MATH',
        SUBJECT_CATEGORY: 'MATHEMATICS',
        SCHOOL_ID: 5,
      },
      {
        SUBJECT_ID: '12',
        SUBJECT_NAME: 'English',
        SUBJECT_CODE: 'ENG',
        SUBJECT_CATEGORY: 'FIRST_ADDITIONAL_LANGUAGE',
        SCHOOL_ID: 5,
      },
    ],
    examTypes = [
      { EXAM_TYPE_ID: 1, EXAM_TYPE_NAME: 'Grade 11' },
      { EXAM_TYPE_ID: 22, EXAM_TYPE_NAME: 'Trial Examinations' },
    ];
  let savedRows = [],
    enrolled = [];
  const catalog = {
    schools: [],
    universities: [],
    subjects,
    examTypes,
    documentTypes: [],
    verificationStatuses: [{ VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' }],
    studyModes: [],
    provinces: [],
    cities: [],
  };
  const apiFor = async (path, options) => {
    if (path === '/api/catalog') return catalog;
    if (path === '/api/results' && options.method === 'PUT') {
      const body = JSON.parse(options.body);
      savedRows = body.rows.map((row) => ({
        ...subjects.find((subject) => String(subject.SUBJECT_ID) === String(row.subjectId)),
        PERCENTAGE: row.percentage,
        VERIFICATION_STATUS_ID: 1,
      }));
      enrolled = savedRows.map((row) => ({ SUBJECT_ID: row.SUBJECT_ID }));
      return { message: 'Results saved for teacher verification.' };
    }
    if (path === '/api/results?examTypeId=22')
      return {
        rows: savedRows.map((row) => ({ ...row })),
        enrolled: enrolled.map((row) => ({ ...row })),
      };
    throw new Error('Unexpected request: ' + path);
  };
  let storage = { 'vv-results-exam-42': '22' };
  let result = await livePortal('learner/results.html', 'learner', apiFor, storage);
  try {
    const d = result.dom.window.document;
    assert.equal(d.querySelector('#exam').value, '22');
    d.querySelector('#subject').value = '11';
    d.querySelector('#add').click();
    const mark = d.querySelector('[data-mark="0"]');
    mark.value = '73.5';
    mark.dispatchEvent(new result.dom.window.Event('input', { bubbles: true }));
    storage = storageSnapshot(result.dom.window);
    assert.deepEqual(
      JSON.parse(storage['vv-results-draft-42-22']).map((row) => [row.SUBJECT_ID, row.PERCENTAGE]),
      [['11', 73.5]],
    );
    assert.equal(savedRows.length, 0);
  } finally {
    result.dom.window.close();
  }
  const subjectPage = await livePortal('learner/subjects.html', 'learner', apiFor, storage);
  try {
    const d = subjectPage.dom.window.document;
    assert.match(d.querySelector('main').textContent, /Mathematics/);
    assert.match(d.querySelector('main').textContent, /Draft · not saved/);
    assert.match(d.querySelector('main').textContent, /Trial Examinations/);
    assert.match(
      d.querySelector('main a.inline-link[href*="results.html"]').getAttribute('href'),
      /examTypeId=22/,
    );
  } finally {
    subjectPage.dom.window.close();
  }
  result = await livePortal('learner/results.html', 'learner', apiFor, storage);
  try {
    const w = result.dom.window,
      d = w.document;
    assert.equal(d.querySelector('#exam').value, '22');
    assert.equal(d.querySelector('[data-mark="0"]').value, '73.5');
    assert.match(
      d.querySelector('#feedback').textContent,
      /unsaved (?:changes|marks) were restored/,
    );
    d.querySelector('#save-results').click();
    await tick();
    await tick();
    assert.deepEqual(
      savedRows.map((row) => [row.SUBJECT_ID, row.PERCENTAGE]),
      [['11', 73.5]],
    );
    assert.equal(w.localStorage.getItem('vv-results-draft-42-22'), null);
    storage = storageSnapshot(w);
  } finally {
    result.dom.window.close();
  }
  const savedSubjects = await livePortal('learner/subjects.html', 'learner', apiFor, storage);
  try {
    const d = savedSubjects.dom.window.document;
    assert.match(d.querySelector('main').textContent, /Mathematics/);
    assert.match(d.querySelector('main').textContent, /73.5%/);
    assert.match(d.querySelector('main').textContent, /Saved for this milestone/);
    assert.doesNotMatch(d.querySelector('main').textContent, /Draft · not saved/);
  } finally {
    savedSubjects.dom.window.close();
  }
  const staleDraft = { ...storage, 'vv-results-draft-42-22': JSON.stringify(savedRows) },
    reconciled = await livePortal('learner/subjects.html', 'learner', apiFor, staleDraft);
  try {
    const d = reconciled.dom.window.document;
    assert.match(d.querySelector('main').textContent, /Saved for this milestone/);
    assert.doesNotMatch(d.querySelector('main').textContent, /Draft · not saved/);
    assert.equal(reconciled.dom.window.localStorage.getItem('vv-results-draft-42-22'), null);
  } finally {
    reconciled.dom.window.close();
  }
  const reopened = await livePortal('learner/results.html', 'learner', apiFor, staleDraft);
  try {
    const d = reopened.dom.window.document;
    assert.equal(d.querySelector('[data-mark="0"]').value, '73.5');
    assert.doesNotMatch(
      d.querySelector('#feedback').textContent,
      /unsaved (?:changes|marks) were restored/,
    );
    assert.equal(reopened.dom.window.localStorage.getItem('vv-results-draft-42-22'), null);
  } finally {
    reopened.dom.window.close();
  }
});

test('result save retains and clearly reports a draft until the server confirms it', async () => {
  const subject = {
    SUBJECT_ID: 11,
    SUBJECT_NAME: 'Mathematics',
    SUBJECT_CODE: 'MATH',
    SUBJECT_CATEGORY: 'MATHEMATICS',
    SCHOOL_ID: 5,
  };
  const page = await livePortal('learner/results.html', 'learner', async (path, options) => {
    if (path === '/api/catalog')
      return {
        schools: [],
        universities: [],
        subjects: [subject],
        examTypes: [{ EXAM_TYPE_ID: 8, EXAM_TYPE_NAME: 'Trial' }],
        documentTypes: [],
        verificationStatuses: [],
        studyModes: [],
        provinces: [],
        cities: [],
      };
    if (path === '/api/results?examTypeId=8') return { rows: [], enrolled: [] };
    if (path === '/api/results' && options.method === 'PUT') return { message: 'Results saved.' };
    throw new Error('Unexpected request: ' + path);
  });
  try {
    const w = page.dom.window,
      d = w.document;
    d.querySelector('#subject').value = '11';
    d.querySelector('#add').click();
    d.querySelector('[data-mark="0"]').value = '82';
    d.querySelector('[data-mark="0"]').dispatchEvent(new w.Event('input', { bubbles: true }));
    d.querySelector('#save-results').click();
    await tick();
    await tick();
    assert.match(
      d.querySelector('#feedback').textContent,
      /(?:save could not be confirmed|server did not confirm)/,
    );
    assert.ok(w.localStorage.getItem('vv-results-draft-42-8'));
    assert.equal(d.querySelector('#save-results').disabled, false);
  } finally {
    page.dom.window.close();
  }
});

test('teacher Results buttons verify or reject the currently selected learner and exam', async () => {
  const decisions = [];
  const { dom, calls } = await livePortal(
    'teacher/results.html',
    'teacher',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [],
          subjects: [],
          examTypes: [{ EXAM_TYPE_ID: 4, EXAM_TYPE_NAME: 'Final NSC' }],
          documentTypes: [],
          verificationStatuses: [
            { VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' },
          ],
          studyModes: [],
          provinces: [],
          cities: [],
        };

      if (path === '/api/teacher/learners')
        return { learners: [{ LEARNER_ID: 9, name: 'Learner Example' }] };
      if (path === '/api/results?examTypeId=4&learnerId=9')
        return {
          rows: [
            {
              SUBJECT_ID: 11,
              SUBJECT_NAME: 'Mathematics',
              PERCENTAGE: 76,
              VERIFICATION_STATUS_ID: 1,
            },
          ],
        };
      if (path === '/api/teacher/verify' && options.method === 'POST') {
        decisions.push(JSON.parse(options.body));
        return { message: 'Result review recorded.' };
      }
      throw new Error('Unexpected request: ' + path);
    },
  );
  try {
    const d = dom.window.document;
    d.querySelector('#verify').click();
    await tick();
    d.querySelector('#reject').click();
    await tick();
    assert.deepEqual(decisions, [
      { learnerId: 9, examTypeId: 4, decision: 'Verified' },
      { learnerId: 9, examTypeId: 4, decision: 'Rejected' },
    ]);
    assert.equal(calls.filter((c) => c.path === '/api/teacher/verify').length, 2);
  } finally {
    dom.window.close();
  }
});

test('teacher document review and representative decision buttons send scoped actions', async () => {
  const documentActions = [];
  let appStatus = 'Screened by Career Teacher';
  const appCalls = [];
  const teacher = await livePortal('teacher/documents.html', 'teacher', async (path, options) => {
    if (path === '/api/catalog')
      return {
        schools: [],
        universities: [],
        subjects: [],
        examTypes: [],
        documentTypes: [],
        verificationStatuses: [{ VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' }],
        studyModes: [],
        provinces: [],
        cities: [],
      };
    if (path === '/api/teacher/learners')
      return { learners: [{ LEARNER_ID: 9, name: 'Learner Example' }] };
    if (path === '/api/documents?learnerId=9')
      return {
        documents: [
          {
            DOCUMENT_ID: 31,
            DOCUMENT_NAME: 'ID document.pdf',
            UPLOAD_DATE: '2026-10-01',
            VERIFICATION_STATUS_ID: 1,
          },
        ],
      };
    if (path === '/api/teacher/verify' && options.method === 'POST') {
      documentActions.push(JSON.parse(options.body));
      return { message: 'Document review recorded.' };
    }
    throw new Error('Unexpected teacher request: ' + path);
  });
  try {
    const d = teacher.dom.window.document;
    d.querySelector('[data-doc="31"]').click();
    await tick();
    d.querySelector('[data-reject="31"]').click();
    await tick();
    assert.deepEqual(documentActions, [
      { learnerId: 9, documentId: 31, decision: 'Verified' },
      { learnerId: 9, documentId: 31, decision: 'Rejected' },
    ]);
  } finally {
    teacher.dom.window.close();
  }
  const representative = await livePortal(
    'representative/decisions.html',
    'representative',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
          subjects: [],
          examTypes: [],
          documentTypes: [],
          verificationStatuses: [],
          studyModes: [],
          provinces: [],
          cities: [],
        };

      if (path === '/api/applications')
        return {
          applications: [
            {
              APPLICATION_ID: 81,
              LEARNER_ID: 9,
              learnerName: 'Learner Example',
              offering: { qualification: 'BSc', university: 'Eastern Cape University' },
              ACADEMIC_YEAR: 2028,
              status: appStatus,
            },
          ],
        };
      if (path === '/api/applications/81/transition' && options.method === 'POST') {
        appCalls.push(JSON.parse(options.body));
        appStatus = JSON.parse(options.body).status;
        return { message: 'Decision saved.' };
      }
      if (path === '/api/applications/81/timeline')
        return { timeline: [{ status: appStatus, ACTION_DATE: '2026-10-11' }] };
      if (path === '/api/applications/81/evidence') return { exams: [], documents: [] };
      throw new Error('Unexpected representative request: ' + path);
    },
  );
  try {
    const w = representative.dom.window,
      d = w.document;
    w.prompt = () => 'Reviewed';
    d.querySelector('[data-transition="81"]').click();
    await tick();
    await tick();
    assert.deepEqual(appCalls, [{ status: 'Provisionally Accepted', notes: 'Reviewed' }]);
    assert.match(d.querySelector('main').textContent, /Provisionally Accepted/);
    d.querySelector('[data-history="81"]').click();
    await tick();
    assert.match(d.querySelector('#detail').textContent, /Application Timeline/);
    d.querySelector('[data-files="9"]').click();
    await tick();
    assert.match(d.querySelector('#detail').textContent, /Applicant Evidence/);
  } finally {
    representative.dom.window.close();
  }
});

test('learner requirement, document and application controls reach their matching APIs', async () => {
  const calls = [];
  const offering = {
    UNI_QUAL_ID: '17',
    UNIVERSITY_ID: '3',
    university: 'Eastern Cape University',
    qualification: 'Bachelor of Science',
    APPLICATION_CLOSING_DATE: '2028-01-31',
    config: {
      universityKey: policies[0].id,
      intake: 2028,
      status: 'verified',
      source: 'https://example.test/programme',
      minScore: 34,
      finalMinScore: null,
      minEnglish: null,
      minMath: null,
      requiredCodes: [],
      subjectMinimums: {},
      method: 'method1',
      notes: 'Reviewed.',
    },
  };
  const learner = await livePortal(
    'learner/requirements.html',
    'learner',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
          subjects: [],
          examTypes: [
            { EXAM_TYPE_ID: 1, EXAM_TYPE_NAME: 'Grade 11 Final' },
            { EXAM_TYPE_ID: 2, EXAM_TYPE_NAME: 'Final NSC' },
          ],
          documentTypes: [
            { DOCUMENT_TYPE_ID: 1, DOCUMENT_TYPE_NAME: 'Identity document', IS_MANDATORY: 1 },
          ],
          verificationStatuses: [
            { VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' },
          ],
          studyModes: [{ STUDY_MODE_ID: 1, STUDY_MODE_NAME: 'Full time' }],
          provinces: [],
          cities: [],
        };
      if (path === '/api/offerings') return { offerings: [offering] };
      if (path === '/api/results/summary') return { examTypeIds: ['2'] };
      if (path === '/api/documents')
        return { documents: [{ DOCUMENT_TYPE_ID: 1, DOCUMENT_NAME: 'Identity document' }] };
      if (path === '/api/applications' && options.method !== 'POST') return { applications: [] };
      if (path === '/api/results?examTypeId=2') return { rows: [] };
      if (path === '/api/results?examTypeId=1') return { rows: [] };
      if (path === '/api/offerings/17/requirements?examTypeId=2')
        return {
          metric: 'Institution score',
          total: 90,
          contributions: [],
          status: 'Meets listed minimums',
          issues: [],
          eligible: true,
        };
      if (path === '/api/offerings/17/requirements?examTypeId=1')
        return {
          metric: 'Institution score',
          total: 90,
          contributions: [],
          status: 'Meets listed minimums',
          issues: [],
          eligible: true,
        };
      if (path === '/api/applications' && options.method === 'POST') {
        calls.push({ path, body: JSON.parse(options.body) });
        return { message: 'Application submitted.' };
      }
      throw new Error('Unexpected requirement request: ' + path);
    },
  );
  try {
    const d = learner.dom.window.document;
    assert.ok(d.querySelector('#offering'), d.querySelector('main').textContent);
    d.querySelector('#offering').value = '17';
    d.querySelector('#offering').dispatchEvent(
      new learner.dom.window.Event('change', { bubbles: true }),
    );
    await tick();
    assert.equal(d.querySelector('#apply'), null);
    d.querySelector('#review-grade11').click();
    await tick();
    assert.equal(d.querySelector('#exam').value, '1');
    assert.ok(d.querySelector('#apply'));
    assert.match(d.querySelector('.apply-panel').textContent, /submit your application here/i);
    assert.match(d.querySelector('.apply-panel').textContent, /Identity document uploaded/i);
    assert.equal(d.querySelector('#wizard-context').hidden, false);
    d.querySelector('#wizard-next').click();
    assert.equal(d.querySelector('#wizard-programme').hidden, false);
    d.querySelector('#wizard-next').click();
    assert.equal(d.querySelector('#requirements-content').hidden, false);
    d.querySelector('#wizard-back').click();
    assert.equal(d.querySelector('#offering').value, '17');
    d.querySelector('#wizard-next').click();
    d.querySelector('#apply').click();
    await tick();
    assert.equal(calls.length, 0);
    assert.match(d.querySelector('#feedback').textContent, /Confirm/);
    d.querySelector('#application-confirm').checked = true;
    d.querySelector('#study-mode').value = '1';
    d.querySelector('#apply').click();
    await tick();
    assert.equal(d.querySelector('#apply'), null);
    assert.deepEqual(calls[0], {
      path: '/api/applications',
      body: { offeringId: 17, studyModeId: 1 },
    });
    assert.match(d.querySelector('#feedback').textContent, /Application submitted/);
  } finally {
    learner.dom.window.close();
  }
  const uploaded = [];
  const docs = await livePortal('learner/documents.html', 'learner', async (path, options) => {
    if (path === '/api/catalog')
      return {
        schools: [],
        universities: [],
        subjects: [],
        examTypes: [],
        documentTypes: [{ DOCUMENT_TYPE_ID: 1, DOCUMENT_TYPE_NAME: 'Identity document' }],
        verificationStatuses: [{ VERIFICATION_STATUS_ID: 1, VERIFICATION_STATUS_NAME: 'Pending' }],
        studyModes: [],
        provinces: [],
        cities: [],
      };
    if (path === '/api/documents' && options.method !== 'POST') return { documents: [] };
    if (path === '/api/documents' && options.method === 'POST') {
      uploaded.push(options);
      return { message: 'Document uploaded.' };
    }
    throw new Error('Unexpected document request: ' + path);
  });
  try {
    const w = docs.dom.window,
      d = w.document,
      file = new w.File(['%PDF-1.4 test'], 'identity.pdf', { type: 'application/pdf' });
    Object.defineProperty(d.querySelector('[name="file"]'), 'files', { value: [file] });
    d.querySelector('#upload').dispatchEvent(
      new w.Event('submit', { bubbles: true, cancelable: true }),
    );
    await tick();
    await tick();
    assert.equal(uploaded.length, 1);
    assert.equal(uploaded[0].headers['X-Document-Type'], '1');
    assert.equal(uploaded[0].headers['X-File-Name'], 'identity.pdf');
    assert.match(d.querySelector('#feedback').textContent, /Document uploaded/);
  } finally {
    docs.dom.window.close();
  }
});

test('requirements compares saved marks to a string-ID offering and defaults to the latest saved milestone', async () => {
  const calls = [],
    offering = {
      UNI_QUAL_ID: '17',
      UNIVERSITY_ID: '3',
      university: 'Eastern Cape University',
      qualification: 'Bachelor of Science',
      APPLICATION_CLOSING_DATE: '2028-01-31',
      config: {
        intake: 2028,
        status: 'verified',
        source: 'https://example.test/programme',
        minScore: 34,
        minEnglish: null,
        minMath: null,
        requiredCodes: [],
        subjectMinimums: {},
        notes: 'Reviewed.',
      },
    };
  const learner = await livePortal(
    'learner/requirements.html?offeringId=17',
    'learner',
    async (path) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
          subjects: [],
          examTypes: [
            { EXAM_TYPE_ID: 1, EXAM_TYPE_NAME: 'Grade 11 Final' },
            { EXAM_TYPE_ID: 3, EXAM_TYPE_NAME: 'Grade 12 Final (NSC)' },
          ],
          documentTypes: [],
          verificationStatuses: [],
          studyModes: [],
          provinces: [],
          cities: [],
        };
      if (path === '/api/offerings') return { offerings: [offering] };
      if (path === '/api/results/summary') return { examTypeIds: ['1'] };
      if (path === '/api/results?examTypeId=1') return { rows: [] };
      if (path === '/api/offerings/17/requirements?examTypeId=1') {
        calls.push(path);
        return {
          metric: 'APS (1–7; maximum 42)',
          total: 34,
          contributions: [],
          status: 'Below listed requirements',
          issues: ['Below minimum APS of 36.'],
          eligible: false,
        };
      }
      throw new Error('Unexpected requirements request: ' + path);
    },
  );
  try {
    const d = learner.dom.window.document;
    assert.ok(d.querySelector('#exam'), d.querySelector('#main').textContent);
    assert.equal(d.querySelector('#exam').value, '1');
    assert.equal(d.querySelector('#offering').value, '17');
    assert.deepEqual(calls, ['/api/offerings/17/requirements?examTypeId=1']);
    assert.match(d.querySelector('#requirements-content').textContent, /34/);
    assert.match(d.querySelector('#requirements-content').textContent, /Below minimum APS of 36/);
    assert.doesNotMatch(
      d.querySelector('#requirements-content').textContent,
      /No programme is listed/,
    );
  } finally {
    learner.dom.window.close();
  }
});

test('representative prospectus upload button sends the selected PDF', async () => {
  const uploads = [];
  const rep = await livePortal(
    'representative/prospectuses.html',
    'representative',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
          subjects: [],
          examTypes: [],
          documentTypes: [],
          verificationStatuses: [],
          studyModes: [],
          provinces: [],
          cities: [],
        };
      if (path === '/api/prospectuses' && options.method !== 'POST') return { prospectuses: [] };
      if (path === '/api/prospectuses' && options.method === 'POST') {
        uploads.push(options);
        return { message: 'Uploaded' };
      }
      throw new Error('Unexpected prospectus request: ' + path);
    },
  );
  try {
    const w = rep.dom.window,
      d = w.document,
      file = new w.File(['%PDF-1.4 brochure'], 'prospectus.pdf', { type: 'application/pdf' });
    Object.defineProperty(d.querySelector('[name="file"]'), 'files', { value: [file] });
    d.querySelector('#prospectus-upload').dispatchEvent(
      new w.Event('submit', { bubbles: true, cancelable: true }),
    );
    await tick();
    await tick();
    assert.equal(uploads.length, 1);
    assert.equal(uploads[0].headers['X-File-Name'], 'prospectus.pdf');
    assert.match(d.querySelector('#feedback').textContent, /Prospectus uploaded/);
  } finally {
    rep.dom.window.close();
  }
});

test('administrator account create and link controls submit role-scoped details', async () => {
  const created = [],
    linked = [];
  let accounts = [],
    unlinked = [{ personId: 88, firstName: 'Legacy', lastName: 'Teacher', role: 'teacher' }];
  const admin = await livePortal('admin/accounts.html', 'admin', async (path, options) => {
    if (path === '/api/catalog')
      return {
        schools: [{ SCHOOL_ID: 5, SCHOOL_NAME: 'Example School' }],
        universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Eastern Cape University' }],
        subjects: [],
        examTypes: [],
        documentTypes: [],
        verificationStatuses: [],
        studyModes: [],
        provinces: [],
        cities: [],
      };
    if (path === '/api/admin/accounts' && options.method !== 'POST') return { accounts };
    if (path === '/api/admin/unlinked') return { people: unlinked };
    if (path === '/api/admin/accounts' && options.method === 'POST') {
      const body = JSON.parse(options.body);
      created.push(body);
      accounts = [
        {
          accountId: 'new-account',
          username: body.email,
          disabled: false,
          emailVerified: false,
          user: {
            personId: 99,
            username: body.email,
            role: body.role,
            firstName: body.firstName,
            lastName: body.lastName,
          },
        },
      ];
      return { message: 'Account created.' };
    }
    if (path === '/api/admin/accounts/link' && options.method === 'POST') {
      const body = JSON.parse(options.body);
      linked.push(body);
      unlinked = [];
      accounts.push({
        accountId: 'linked-account',
        username: body.email,
        disabled: false,
        emailVerified: false,
        user: {
          personId: 88,
          username: body.email,
          role: 'teacher',
          firstName: 'Legacy',
          lastName: 'Teacher',
        },
      });
      return { message: 'Sign-in enabled.' };
    }
    throw new Error('Unexpected admin account request: ' + path);
  });
  try {
    const d = admin.dom.window.document;
    for (const [name, value] of Object.entries({
      firstName: 'New',
      lastName: 'Learner',
      email: 'new@example.test',
      role: 'learner',
      schoolId: '5',
      universityId: '',
    }))
      d.querySelector(`#account [name="${name}"]`).value = value;
    d.querySelector('#account').dispatchEvent(
      new admin.dom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await tick();
    await tick();
    assert.deepEqual(created, [
      {
        firstName: 'New',
        lastName: 'Learner',
        email: 'new@example.test',
        role: 'learner',
        schoolId: 5,
        universityId: null,
      },
    ]);
    assert.ok(d.querySelector('#link-account'));
    d.querySelector('#link-account [name="email"]').value = 'legacy@example.test';
    d.querySelector('#link-account').dispatchEvent(
      new admin.dom.window.Event('submit', { bubbles: true, cancelable: true }),
    );
    await tick();
    await tick();
    assert.deepEqual(linked, [{ personId: 88, email: 'legacy@example.test' }]);
    assert.equal(d.querySelector('#link-account'), null);
  } finally {
    admin.dom.window.close();
  }
});

test('public landing page has working registration and navigation links without running the portal app', () => {
  const html = readFileSync(new URL('public/index.html', root), 'utf8');
  const dom = new JSDOM(html, { url: 'http://localhost/', runScripts: 'outside-only' }),
    d = dom.window.document;
  assert.equal(d.querySelector('body').dataset.page, undefined);
  assert.equal(d.querySelector('script[type="module"]'), null);
  assert.equal(
    d.querySelector('.landing-primary').getAttribute('href'),
    '/login.html#auth-tab-register',
  );
  assert.equal(d.querySelector('.landing-signin').getAttribute('href'), '/login.html');
  assert.ok(d.querySelector('#how-it-works'));
  assert.ok(d.querySelector('#pathways'));
  assert.match(d.querySelector('main').textContent, /2027 ADMISSIONS/);
  assert.equal(d.querySelectorAll('a[href="#"]').length, 0);
  dom.window.close();
});

test('landing page registration link opens the learner registration tab', async () => {
  const dom = new JSDOM(readFileSync(new URL('public/login.html', root), 'utf8'), {
    url: 'http://localhost/login.html#auth-tab-register',
    runScripts: 'outside-only',
  });
  dom.window.lucide = { createIcons() {} };
  dom.window.api = async (path) => {
    if (path === '/api/health') return { status: 'ok' };
    if (path === '/api/public-config') return { supportEmail: null };
    if (path === '/api/catalog') return { schools: [{ SCHOOL_ID: 1, SCHOOL_NAME: 'Test School' }] };
    throw new Error('Unexpected request: ' + path);
  };
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8')
    .replace(/^import\b[\s\S]*?;\r?\n/gm, '')
    .replace('export async function startFullApp', 'async function startFullApp');
  try {
    dom.window.eval('const api=window.api;\n' + source + '\nwindow.startTest=startFullApp;');
    await dom.window.startTest();
    assert.equal(
      dom.window.document.querySelector('#auth-tab-register').getAttribute('aria-selected'),
      'true',
    );
    assert.equal(dom.window.document.querySelector('#auth-register-panel').hidden, false);
  } finally {
    dom.window.close();
  }
});

test('help page icons and configured support link load through a CSP-safe script', async () => {
  const html = readFileSync(new URL('public/help.html', root), 'utf8'),
    source = readFileSync(new URL('public/assets/js/help.js', root), 'utf8');
  assert.match(html, /<script src="\/assets\/js\/help\.js" defer><\/script>/);
  assert.doesNotMatch(html, /<script>[^<]/);
  const dom = new JSDOM(html, { url: 'http://localhost/help.html', runScripts: 'outside-only' });
  dom.window.eval(iconSource);
  dom.window.fetch = async () => ({
    ok: true,
    json: async () => ({ supportEmail: 'help@example.test' }),
  });
  dom.window.eval(source);
  dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded'));
  await new Promise((resolve) => setImmediate(resolve));
  assert.ok(dom.window.document.querySelector('.help-card-icon svg'));
  const contact = dom.window.document.querySelector('[data-support-email]');
  assert.equal(contact.textContent, 'help@example.test');
  assert.equal(contact.href, 'mailto:help@example.test');
  dom.window.close();
});

test('My Applications offers a submission entry point with and without existing applications', async () => {
  for (const existing of [false, true]) {
    const { dom } = await livePortal('learner/applications.html', 'learner', async (path) => {
      if (path === '/api/catalog') return {};
      if (path === '/api/applications')
        return {
          applications: existing
            ? [
                {
                  APPLICATION_ID: 7,
                  learnerName: 'Test User',
                  offering: { qualification: 'BSc', university: 'Test University' },
                  ACADEMIC_YEAR: 2028,
                  status: 'Submitted',
                },
              ]
            : [],
        };
      throw new Error('Unexpected request: ' + path);
    });
    try {
      const button = dom.window.document.querySelector('#start-application');
      assert.ok(button);
      assert.equal(button.getAttribute('href'), '/learner/requirements.html');
      assert.equal(button.textContent.trim(), 'Start an application');
      assert.match(
        dom.window.document.querySelector('#start-application-title').textContent,
        existing ? /another programme/ : /first application/,
      );
    } finally {
      dom.window.close();
    }
  }
});

test('all live portals group each destination once and retain an active dashboard', async () => {
  for (const role of ['learner', 'teacher', 'representative', 'admin']) {
    const { dom } = await liveDashboard(role, {
      applications: [],
      applicationCount: 0,
      actionQueue: [],
      counts: { results: 0, documents: 0, accounts: 0, universities: 0, offerings: 0 },
    });
    const navigation = dom.window.document.querySelector('#navigation');
    const links = [...navigation.querySelectorAll('a')];
    assert.ok(navigation.querySelectorAll('section[aria-labelledby]').length >= 3);
    assert.equal(new Set(links.map((a) => a.href)).size, links.length);
    assert.equal(navigation.querySelectorAll('[aria-current="page"]').length, 1);
    assert.ok(links.every((a) => a.getAttribute('href').startsWith('/' + role + '/')));
    assert.ok(links.some((a) => a.textContent.trim() === 'My Profile'));
  }
});

test('pending actions reject duplicate clicks and become usable after failure', async () => {
  const source = readFileSync(new URL('public/assets/js/full.js', root), 'utf8');
  const guardSource = source.slice(
    source.indexOf('const pendingActions'),
    source.indexOf('async function upload'),
  );
  const messages = [];
  const guard = new Function('feedback', 'location', guardSource + '\nreturn guard;')(
    (message) => messages.push(message),
    { assign() {} },
  );
  const dom = new JSDOM('<button>Save</button>');
  const button = dom.window.document.querySelector('button');
  let finish,
    calls = 0,
    prevented = false;
  const handler = guard(async () => {
    calls++;
    await new Promise((resolve) => {
      finish = resolve;
    });
    throw new Error('Please try again.');
  });
  const event = {
    currentTarget: button,
    preventDefault() {
      prevented = true;
    },
  };
  const pending = handler(event);
  assert.equal(button.disabled, true);
  await handler(event);
  assert.equal(calls, 1);
  assert.equal(prevented, true);
  finish();
  await pending;
  assert.equal(button.disabled, false);
  assert.equal(button.hasAttribute('aria-busy'), false);
  assert.deepEqual(messages, ['Please try again.']);
});

test('programme editor restores custom scoring and submits rule, document and window settings', async () => {
  const rows = [
    {
      UNI_QUAL_ID: 7,
      UNIVERSITY_ID: 3,
      qualification: 'Applied Science',
      program: 'Degree',
      APPLICATION_CLOSING_DATE: '2028-10-31',
      config: {
        status: 'verified',
        intake: 2028,
        minScore: 65,
        source: 'https://example.edu',
        notes: 'Reviewed requirements',
        openingDate: '2028-01-01',
        closingTime: '17:00',
        active: true,
        requiredDocumentIds: [1],
        subjectGroups: [{ group: 1, code: 'MATH', minimum: 50 }],
        scoring: {
          mode: 'RAW',
          count: 6,
          divisor: 6,
          floor: 0,
          label: 'Average',
          bands: [],
          exclude: ['LO'],
          overrides: [{ codes: ['MATH'], weight: 2 }],
        },
      },
    },
  ];
  let saved;
  const { dom } = await livePortal(
    'representative/offerings.html',
    'representative',
    async (path, options) => {
      if (path === '/api/catalog')
        return {
          schools: [],
          universities: [{ UNIVERSITY_ID: 3, UNIVERSITY_NAME: 'Assigned university' }],
          subjects: [
            { SUBJECT_ID: 1, SUBJECT_CODE: 'MATH', SUBJECT_NAME: 'Mathematics' },
            { SUBJECT_ID: 2, SUBJECT_CODE: 'LO', SUBJECT_NAME: 'Life Orientation' },
          ],
          examTypes: [],
          documentTypes: [{ DOCUMENT_TYPE_ID: 1, DOCUMENT_TYPE_NAME: 'Identity document' }],
          verificationStatuses: [],
          studyModes: [],
          provinces: [],
          cities: [],
        };
      if (path === '/api/offerings') return { offerings: rows };
      if (path === '/api/representative/offerings/7' && options.method === 'PATCH') {
        saved = JSON.parse(options.body);
        return { message: 'Saved' };
      }
      throw new Error('Unexpected request ' + path);
    },
  );
  try {
    const d = dom.window.document;
    d.querySelector('[data-edit-offering]').click();
    const form = d.querySelector('#offering-form');
    assert.equal(d.querySelector('#custom-scoring').hidden, false);
    assert.equal(form.elements.scoringMode.value, 'RAW');
    assert.equal(form.elements.closingTime.value, '17:00');
    form.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    await tick();
    assert.equal(saved.scoring.divisor, 6);
    assert.deepEqual(saved.scoring.exclude, ['LO']);
    assert.deepEqual(saved.scoring.overrides, [{ codes: ['MATH'], weight: 2 }]);
    assert.deepEqual(saved.subjectGroups, [{ group: 1, code: 'MATH', minimum: 50 }]);
    assert.deepEqual(saved.requiredDocumentIds, [1]);
    assert.equal(saved.openingDate, '2028-01-01');
    assert.equal(saved.closingTime, '17:00');
  } finally {
    dom.window.close();
  }
});
