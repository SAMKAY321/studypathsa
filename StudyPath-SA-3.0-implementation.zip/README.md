# StudyPath SA 3.0.0 — verified undergraduate pathways (implementation stage)

StudyPath SA extends the existing Varsity Vault application while preserving its HTML/CSS/vanilla JavaScript frontend, Express API, shared scoring modules and SQL Server academic schema. The pilot target is **2027 undergraduate applications at Walter Sisulu University (WSU), University of Fort Hare (UFH) and University of Johannesburg (UJ)**. Postgraduate matching is disabled. Internal package/database names remain where changing them would break the existing install.

> **Release status:** implementation in progress, not production-certified. Programme scoring golden fixtures are intentionally empty pending official 2027 sources and two independent approvals. Funding records are not seeded as verified. See `docs/build-status.md` and `docs/open-items.md` before using real personal data.

## Architecture

- `public/` — learner/admin screens, accessible page scripts and reusable styles.
- `server/` — Express API, existing authentication/session/role scopes, SQL Server adapters, new pilot routes, privacy/deletion and alert jobs.
- `shared/` — scoring, What-If validation, funding matcher and shared provenance/disclaimer logic.
- `config/pilot.json` — explicit pilot institutions and feature flags.
- `database/source/unilink_script_improved.sql` — submitted `VARSITYVAULT2` academic SQL, preserved unchanged.
- `database/migrations/001…008_*.sql` — separate `StudyPathPilot` operational database; `999_rollback.sql` is a guarded pilot rollback and never drops `VARSITYVAULT2`.
- `database/import/` — programme and funding CSV templates.
- `database/hardening/tde.sql` — optional SSMS TDE starting point, requires sysadmin review.
- `server/vault-crypto.js` — AES-256-GCM envelope encryption for uploaded documents and encrypted financial-profile payloads.
- `docs/` — accuracy, verification, security, privacy, incident response, pilot, competitor, schema and handover docs.

## Key implementation gates

- All scoring and funding recommendations are server-produced and source-gated. Without source, updated date, conditions, fresh status and required verification, the app must show a guidance or unverified state rather than imply eligibility.
- The verification ledger requires an archived source/hash and two distinct reviewer accounts before programme rules become verified.
- Hypothetical What-If marks are stateless and labelled “Hypothetical — not saved”.
- Funding matches use the profile fields the learner provided, labels “May be eligible”, “Possibly eligible — check” and “Does not match on known criteria”, and do not guarantee funding.
- Credit-transfer messaging is guidance only; the institution decides.
- The vault requires `VAULT_MASTER_KEY`, `VAULT_KEY_ID` and a tested migration/rotation procedure in production.
- The current guardian flag records a confirmation but does not verify parent/guardian identity. Do not onboard minors for a live pilot until the approved workflow exists.

## Setup on Windows / PowerShell

Use Node.js **24.15+ in the 24.x line, or Node.js 26+**. The currently tested implementation environment was Node 22.16.0 and incomplete dependencies, so run the full verification before rollout.

1. Back up the working folder, `.env`, `.data` and databases. Do not overwrite the submitted academic SQL file with a different script.
2. Extract the update over the existing application source while retaining your `.env` and private `.data` directory.
3. Install locked dependencies:

```powershell
npm ci
```

4. Prepare `.env` from `.env.example`. Keep all secrets out of the repo and frontend. Set `APP_MODE=sqlserver`, correct SQL Server connection details and the protected vault key before any production document upload. Configure `VAULT_MASTER_KEY` as base64-encoded 32 random bytes and a unique `VAULT_KEY_ID`; use a secret store on the server in production.
5. Run the numbered migrations on a reviewed SQL Server instance. From PowerShell:

```powershell
npm run db:migrate
npm run db:check
```

`db:migrate` uses `scripts/migrate.ps1` and `sqlcmd`; review the script and permissions before execution. Migrations `001`–`008` target `StudyPathPilot`, not `VARSITYVAULT2`. Do not run the original academic script again on an existing install. `999_rollback.sql` drops only objects in `StudyPathPilot` and should only be used after a deliberate backup/review.

6. Review the environment and run tests/formatter/accuracy/wording lint:

```powershell
npm test
npm run format:check
npm run accuracy
npm run wording:lint
npm run verify
```

`npm run accuracy` will intentionally return a non-zero blocked status until official programme examples exist. Do not suppress it or create made-up fixture expectations to get green CI.

7. Before production, follow `docs/security-and-popia.md`, `docs/data-verification-process.md`, `docs/pilot-plan.md` and `docs/incident-response.md`. Verify current official sources, build golden fixtures, approve guardian workflow and retention settings, test SQL migrations/rollback and perform a backup restore drill.

## Operations

```powershell
npm start
npm run alerts:run
npm run privacy:process-deletions
npm run vault:encrypt-existing -- --dry-run
npm run vault:encrypt-existing
npm run vault:rotate-key
```

Run reminders and deletion jobs using Windows Task Scheduler only after mail consent, time zone, idempotency and retention settings have been tested in staging. `vault:encrypt-existing` can mutate every legacy document row; take a protected backup and complete dry-run/recovery checks before live execution.

## Workstream and status documents

- `docs/studypath-implementation-plan.md` — W0-W11 file plan/order/risk gates.
- `docs/baseline.md` — observed environment and dependency/test limits.
- `docs/build-status.md` — delivered features vs validation boundary.
- `docs/accuracy-report.md` and `tests/fixtures/golden/` — sourced scoring verification; empty fixtures mean no verified programme scoring claims.
- `docs/data-verification-process.md` — evidence and reviewer SOP.
- `docs/security-and-popia.md`, `docs/incident-response.md` — operational security requirements and boundaries.
- `docs/pilot-plan.md` — research measures and limits.
- `docs/competitor-analysis.md` and `docs/competitor-verification-checklist.md` — dated source review and open claims.
- `docs/demo-script.md` — five-minute judge demonstration without fabricated admissions outcomes.

## Important limitations

This implementation work has not been tested against a live SQL Server, has not completed full `npm ci`/test/format checks in the current environment, and is not legal/security certification. Verify all source data and operational details with accountable staff. Keep local SQLite mode for isolated development/demo only, not production learner records.

## Retention review (dry-run by default)

`npm run retention:run` reports old, explicitly rejected documents and explains why expiry/inactivity candidates cannot safely be inferred from the preserved academic schema. Deletion requires two distinct approvers in a per-document JSON manifest and explicit `RETENTION_DELETION_ENABLED=true`; see `docs/security-and-popia.md`.
