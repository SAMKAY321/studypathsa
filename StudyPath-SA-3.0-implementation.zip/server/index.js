import { createFullApplication } from './app.js';
import { LocalStore, SqlStore } from './storage.js';
import { seedLocal } from './seed.js';
import { emailDeliveryReady } from './mailer.js';
import { ensureReferenceData } from './reference-data.js';
import { openPilotStore } from './pilot-store.js';
import { seedPilotStore } from './seed-pilot.js';
import { validateVaultKey } from './vault-crypto.js';
const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be 1–65535.');
const host = process.env.HOST || '127.0.0.1';
const mode = process.env.APP_MODE || 'sqlserver';
if (!['local', 'sqlserver'].includes(mode)) throw new Error('APP_MODE must be local or sqlserver.');
if (
  ['true', 'false'].includes(
    String(process.env.TRUST_PROXY || '')
      .trim()
      .toLowerCase(),
  )
)
  throw new Error(
    'TRUST_PROXY must identify trusted proxy addresses or hop count, not true/false.',
  );
if (mode === 'local' && !['127.0.0.1', 'localhost', '::1'].includes(host))
  throw new Error('Local development mode must bind to loopback.');
if (
  process.env.NODE_ENV === 'production' &&
  (mode !== 'sqlserver' || process.env.COOKIE_SECURE !== 'true')
)
  throw new Error('Production requires SQL Server and secure HTTPS cookies.');
if (process.env.NODE_ENV === 'production' && !emailDeliveryReady())
  throw new Error(
    'Production requires a valid HTTPS PUBLIC_APP_URL and complete EMAIL_MODE=smtp settings for account verification and password recovery.',
  );
if (
  process.env.NODE_ENV === 'production' &&
  !/^[a-f0-9]{64}$/i.test(String(process.env.SECURITY_ENCRYPTION_KEY || ''))
)
  throw new Error('Production requires a 32-byte SECURITY_ENCRYPTION_KEY for administrator MFA.');
const store =
  mode === 'sqlserver'
    ? await SqlStore.open()
    : new LocalStore(process.env.LOCAL_DATABASE || '.data/varsity-vault.sqlite');
if (mode === 'local') await store.tx(seedLocal);
if (process.env.NODE_ENV === 'production') validateVaultKey();
const pilotStore = await openPilotStore({ mode, path: process.env.PILOT_LOCAL_DATABASE || '.data/studypath-pilot.sqlite' });
await seedPilotStore(pilotStore);
const referenceData = await ensureReferenceData(store);
if (referenceData.inserted.length)
  console.log('Added missing application lookup values:', referenceData.inserted.join(', '));
const server = createFullApplication(store, { pilotStore }).listen(port, host, () =>
  console.log(`StudyPath SA (${mode}): http://${host}:${port}/`),
);
for (const signal of ['SIGINT', 'SIGTERM'])
  process.on(signal, () =>
    server.close(async () => {
      await store.close();
      await pilotStore.close();
      process.exit(0);
    }),
  );
