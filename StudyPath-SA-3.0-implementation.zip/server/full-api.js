import {
  validateScoring,
  validateGroups,
  offeringAvailability,
} from '../shared/scoring/programme.js';
import { randomUUID, createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve as resolvePath, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sameId } from './identity.js';
import express from 'express';
import packageInfo from '../package.json' with { type: 'json' };
import { passwordHash, checkPassword, token, digest, userContext, audit } from './security.js';
import { accountLink, emailDeliveryReady, sendAccountEmail } from './mailer.js';
import {
  accountInvitationMessage,
  emailVerificationMessage,
  issueAccountToken,
} from './account-email.js';
import {
  decryptSecret,
  encryptSecret,
  encryptionKey,
  makeRecoveryCodes,
  newTotpSecret,
  provisioningUri,
  verifyTotp,
} from './mfa.js';
import { assessSubjects, curriculum } from '../shared/scoring/subjects.js';
import { attachSubjectsToResults } from '../shared/scoring/result-records.js';
import pilotConfig from '../config/pilot.json' with { type: 'json' };
import { runWhatIf, unsuitableApplicationReason, validateHypotheticalMarks } from '../shared/scoring/what-if.js';
import { withProvenance } from '../shared/trust/provenance.js';
import { DISCLAIMERS } from '../shared/trust/disclaimers.js';
import { compareFundingCriteria, isFundingOpportunityActionable } from '../shared/funding/matcher.js';
import { encryptDocument, decryptDocument, isEncryptedDocument } from './vault-crypto.js';
import { scanBuffer } from './clamav.js';
const bad = (message, status = 400) => Object.assign(new Error(message), { status });
const id = (x) => {
  const n = Number(x);
  if (!Number.isInteger(n) || n < 1) throw bad('Invalid record identifier.');
  return n;
};
const text = (x, max = 100) => {
  if (typeof x !== 'string' || !x.trim() || x.length > max)
    throw bad('A required text field is missing or too long.');
  return x.trim();
};
const now = () => new Date().toISOString();
const date = () => now().slice(0, 19);
const today = () =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
const one = async (db, t, w) => {
  const r = (await db.list(t, w))[0];
  if (!r) throw bad('Record not found.', 404);
  return r;
};
const role = (u, ...roles) => {
  if (!roles.includes(u.role)) throw bad('This account cannot perform that action.', 403);
};
const statusId = async (db, name) =>
  (await one(db, 'APPLICATION_STATUSES', { STATUS_NAME: name })).STATUS_ID;
const verificationId = async (db, name) =>
  (await one(db, 'VERIFICATION_STATUSES', { VERIFICATION_STATUS_NAME: name }))
    .VERIFICATION_STATUS_ID;
async function results(db, learnerId, examId) {
  const rows = await db.list('LEARNER_RESULTS', { LEARNER_ID: learnerId, EXAM_TYPE_ID: examId });
  const subjects = await db.list('SUBJECTS');
  return attachSubjectsToResults(rows, subjects);
}
async function scopedLearner(db, u, learnerId) {
  const learner = await one(db, 'LEARNERS', { LEARNER_ID: learnerId });
  if (
    (u.role === 'learner' && !sameId(learner.LEARNER_ID, u.recordId)) ||
    (u.role === 'teacher' && !sameId(learner.SCHOOL_ID, u.schoolId)) ||
    !['learner', 'teacher', 'admin'].includes(u.role)
  )
    throw bad('Learner is outside your access scope.', 403);
  return learner;
}
async function scopeApp(db, u, applicationId) {
  const a = await one(db, 'APPLICATIONS', { APPLICATION_ID: applicationId }),
    l = await one(db, 'LEARNERS', { LEARNER_ID: a.LEARNER_ID }),
    o = await one(db, 'UNI_QUALIFICATIONS', { UNI_QUAL_ID: a.UNI_QUAL_ID });
  if (
    (u.role === 'learner' && !sameId(a.LEARNER_ID, u.recordId)) ||
    (u.role === 'teacher' && !sameId(l.SCHOOL_ID, u.schoolId)) ||
    (u.role === 'representative' && !sameId(o.UNIVERSITY_ID, u.universityId))
  )
    throw bad('Application is outside your access scope.', 403);
  return a;
}
async function offering(db, offeringId) {
  const o = await one(db, 'UNI_QUALIFICATIONS', { UNI_QUAL_ID: offeringId }),
    university = await one(db, 'UNIVERSITIES', { UNIVERSITY_ID: o.UNIVERSITY_ID }),
    qualification = await one(db, 'QUALIFICATIONS', { QUAL_ID: o.QUAL_ID }),
    program = await one(db, 'PROGRAMS', { PROGRAM_ID: qualification.PROGRAM_ID });
  const row = (await db.list('security.Policies', { UNI_QUAL_ID: offeringId }))[0];
  const legacy = (await db.list('QUALIFICATION_REQUIREMENTS', { UNI_QUAL_ID: offeringId }))[0];
  const config = {
    ...(legacy
      ? {
          minScore: legacy.MIN_APS_SCORE,
          minEnglish: legacy.MIN_ENG_SCORE,
          minMath: legacy.MIN_MATH_SCORE,
          notes: legacy.NOTES,
          status: 'pending',
        }
      : {}),
    ...(row ? JSON.parse(row.PAYLOAD) : {}),
  };
  return {
    ...o,
    university: university.UNIVERSITY_NAME,
    qualification: qualification.QUAL_NAME,
    program: program.PROGRAM_NAME,
    config,
    availability: offeringAvailability(config, o.APPLICATION_CLOSING_DATE),
  };
}
function dashboardApplication(row) {
  const config = {
    ...(row.LEGACY_MIN_APS_SCORE != null
      ? {
          minScore: row.LEGACY_MIN_APS_SCORE,
          minMath: row.LEGACY_MIN_MATH_SCORE,
          minEnglish: row.LEGACY_MIN_ENG_SCORE,
          notes: row.LEGACY_NOTES,
          status: 'pending',
        }
      : {}),
    ...(row.POLICY_PAYLOAD ? JSON.parse(row.POLICY_PAYLOAD) : {}),
  };
  return {
    ...row,
    status: row.APPLICATION_STATUS,
    learnerName: row.LEARNER_FIRST_NAME + ' ' + row.LEARNER_LAST_NAME,
    learnerId: row.LEARNER_ID,
    offering: {
      UNI_QUAL_ID: row.UNI_QUAL_ID,
      UNIVERSITY_ID: row.OFFERING_UNIVERSITY_ID,
      APPLICATION_CLOSING_DATE: row.OFFERING_CLOSING_DATE,
      qualification: row.OFFERING_QUALIFICATION,
      university: row.OFFERING_UNIVERSITY,
      config,
    },
  };
}
async function assessment(db, u, offerId, examId) {
  const o = await offering(db, offerId),
    exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_ID: examId });
  const config = { ...o.config };
  if (exam.EXAM_TYPE_NAME === 'Grade 12 Final (NSC)' && config.finalMinScore != null)
    config.minScore = config.finalMinScore;
  return {
    ...assessSubjects(await results(db, u.recordId, examId), o.policy, config),
    offering: o,
  };
}
async function history(db, a, target, u) {
  const action = await one(db, 'ACTIONS', { ACTION_NAME: target });
  await db.insert('APPLICATION_PROCESSES', {
    APPLICATION_ID: a.APPLICATION_ID,
    ACTION_ID: action.ACTION_ID,
    ACTION_DATE: date(),
  });
  await audit(db, u.personId, 'application.' + target, { applicationId: a.APPLICATION_ID });
}
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const genericResetMessage =
  'If the address belongs to an active account, instructions will be sent shortly.';
export function fullApi(store, { secureCookies = false, sendEmail = sendAccountEmail, pilotStore = null } = {}) {
  const router = express.Router();
  const whatIfLimits = new Map();
  const enforceWhatIfRateLimit = (personId) => {
    const nowMs = Date.now(), key = String(personId);
    for (const [id, bucket] of whatIfLimits) if (nowMs - bucket.started > 120000) whatIfLimits.delete(id);
    const prior = whatIfLimits.get(key) || { started: nowMs, count: 0 };
    if (nowMs - prior.started >= 60000) { prior.started = nowMs; prior.count = 0; }
    prior.count += 1;
    whatIfLimits.set(key, prior);
    if (prior.count > 30) throw bad('Too many What-If requests. Please retry in a minute.', 429);
  };
  const cookie = 'vv_session',
    challengeCookie = 'vv_mfa_challenge';
  const dummyPasswordHash =
    'vv-timing-salt-2026:b72899f1546691f625d7cde1685862b301ca091f519c8703cbb61e9d95e236ec66129956ec2959d6d7fc2edefb8131de559b7f2f09be1493103a974b4fd83d63';
  const readToken = (req) =>
    String(req.headers.cookie || '')
      .split(';')
      .map((s) => s.trim())
      .find((s) => s.startsWith(cookie + '='))
      ?.slice(cookie.length + 1);
  const setCookie = (res, value, clear = false) =>
    res.setHeader(
      'Set-Cookie',
      `${cookie}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${clear ? 0 : 28800}${secureCookies ? '; Secure' : ''}`,
    );
  const readChallenge = (req) =>
    String(req.headers.cookie || '')
      .split(';')
      .map((s) => s.trim())
      .find((s) => s.startsWith(challengeCookie + '='))
      ?.slice(challengeCookie.length + 1);
  const setChallengeCookie = (res, value, clear = false) =>
    res.setHeader(
      'Set-Cookie',
      `${challengeCookie}=${value}; Path=/api/auth/mfa; HttpOnly; SameSite=Strict; Max-Age=${clear ? 0 : 600}${secureCookies ? '; Secure' : ''}`,
    );
  const issueSession = async (db, personId, res) => {
    const secret = token(),
      csrf = token();
    await db.insert('security.Sessions', {
      TOKEN_HASH: digest(secret),
      PERSON_ID: personId,
      CSRF: csrf,
      EXPIRES: new Date(Date.now() + 28800000).toISOString(),
    });
    setCookie(res, secret);
    return { csrf };
  };
  const queueEmail = (to, subject, text) => {
    const message = typeof to === 'object' && to ? to : { to, subject, text };
    return { __afterCommit: () => sendEmail(message) };
  };
  const issueToken = issueAccountToken;
  const requestAllowed = async (db, req, scope, identifier) => {
    const timestamp = Date.now(),
      windowMs = 900000;
    let allowed = true;
    for (const value of ['ip:' + req.ip, 'key:' + digest(identifier)]) {
      const key = digest('account-flow|' + scope + '|' + value),
        prior = (await db.list('security.LoginAttempts', { ATTEMPT_KEY: key }))[0],
        active = prior && Date.now() - Date.parse(prior.WINDOW_START) < windowMs;
      if (prior?.BLOCKED_UNTIL && Date.parse(prior.BLOCKED_UNTIL) > timestamp) {
        allowed = false;
        continue;
      }
      const failures = (active ? Number(prior.FAILURES) : 0) + 1,
        windowStart = active ? prior.WINDOW_START : new Date(timestamp).toISOString(),
        blockedUntil = failures > 5 ? new Date(timestamp + windowMs).toISOString() : '';
      const row = { FAILURES: failures, WINDOW_START: windowStart, BLOCKED_UNTIL: blockedUntil };
      if (prior) await db.update('security.LoginAttempts', { ATTEMPT_KEY: key }, row);
      else await db.insert('security.LoginAttempts', { ATTEMPT_KEY: key, ...row });
      if (failures > 5) allowed = false;
    }
    return allowed;
  };
  const clearRequestLimit = async (db, req, scope, identifier) => {
    for (const value of ['ip:' + req.ip, 'key:' + digest(identifier)])
      await db.remove('security.LoginAttempts', {
        ATTEMPT_KEY: digest('account-flow|' + scope + '|' + value),
      });
  };
  const emailAvailable = sendEmail !== sendAccountEmail || emailDeliveryReady();
  const inviteAccount = async (db, personId, email) => {
    if (!emailAvailable)
      throw bad('Email delivery is not configured. Contact the application administrator.', 503);
    return queueEmail(await accountInvitationMessage(db, personId, email));
  };
  const verifyAccountEmail = async (db, personId, email) => {
    if (!emailAvailable)
      throw bad('Email delivery is not configured. Contact the application administrator.', 503);
    return queueEmail(await emailVerificationMessage(db, personId, email));
  };
  const activeInvitation = async (db, personId) =>
    (
      await db.list('security.AccountTokens', {
        PERSON_ID: personId,
        PURPOSE: 'account-invitation',
      })
    ).some((item) => item.EXPIRES > now());
  const wrap =
    (fn, { publicRoute = false, minimumDuration = 0 } = {}) =>
    async (req, res, next) => {
      const started = Date.now();
      try {
        let afterCommit = null;
        const output = await store.tx(async (db) => {
          let u = null,
            session = null;
          const secret = readToken(req);
          if (secret) {
            session = (await db.list('security.Sessions', { TOKEN_HASH: digest(secret) }))[0];
            if (session && session.EXPIRES > now()) {
              const account = (
                await db.list('security.Accounts', { PERSON_ID: session.PERSON_ID })
              )[0];
              if (account && !account.DISABLED) u = await userContext(db, session.PERSON_ID);
            }
          }
          if (!publicRoute && !u) throw bad('Please sign in.', 401);
          if (!['GET', 'HEAD'].includes(req.method)) {
            const origin = req.get('origin');
            if (origin && origin !== `${req.protocol}://${req.get('host')}`)
              throw bad('Cross-site request refused.', 403);
            if (!publicRoute && (!session || req.get('x-csrf-token') !== session.CSRF))
              throw bad('Refresh the page before changing data.', 403);
          }
          const value = await fn(db, u, req, res, session);
          if (value?.__afterCommit) {
            afterCommit = value.__afterCommit;
            const { __afterCommit, ...body } = value;
            return body;
          }
          return value;
        });
        if (afterCommit)
          setImmediate(() =>
            Promise.resolve()
              .then(afterCommit)
              .catch((error) =>
                console.error('Account email delivery failed:', error.code || error.name),
              ),
          );
        const remaining = minimumDuration - (Date.now() - started);
        if (remaining > 0) await new Promise((resolve) => setTimeout(resolve, remaining));
        if (output !== undefined && !res.headersSent) {
          if (Number.isInteger(output.__httpStatus)) {
            const { __httpStatus, ...body } = output;
            res.status(__httpStatus).json(body);
          } else res.json(output);
        }
      } catch (error) {
        next(error);
      }
    };
  router.get('/health', (req, res) =>
    res.json({
      status: 'ok',
      version: packageInfo.version,
      mode: store.mode,
      authentication: 'enabled',
      database: store.mode === 'sqlserver' ? 'SQL Server' : 'local development SQLite',
      intake: process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true' ? 2027 : 2028,
      demoMode: false,
      writesEnabled: true,
    }),
  );
  router.get('/public-config', (req, res) => {
    const email = (process.env.SUPPORT_EMAIL || '').trim();
    res.json({
      supportEmail: emailPattern.test(email) && email.length <= 254 ? email : null,
      emailEnabled: emailAvailable,
      intakeYear: process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true' ? 2027 : 2028,
      pilotMode: process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true',
    });
  });
  router.get(
    '/universities',
    wrap(
      async (db) => {
        const universities = await db.list('UNIVERSITIES'),
          provinces = await db.list('PROVINCES'),
          cities = await db.list('CITIES'),
          addresses = await db.list('UNIVERSITY_ADDRESSES');
        const pilotActive = process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true';
        const scopedUniversities = pilotActive ? universities.filter((item) => ['wsu', 'ufh', 'uj'].includes(institutionCodeFor(item.UNIVERSITY_NAME))) : universities;
        return {
          intake: pilotActive ? 2027 : 2028,
          count: scopedUniversities.length,
          universities: scopedUniversities.map((u) => {
            const address = addresses.find((a) => sameId(a.UNIVERSITY_ID, u.UNIVERSITY_ID));
            return {
              name: u.UNIVERSITY_NAME,
              city: cities.find((c) => sameId(c.CITY_ID, address?.CITY_ID))?.CITY_NAME ?? null,
              province:
                provinces.find((p) => sameId(p.PROVINCE_ID, u.PROVINCE_ID))?.PROVINCE_NAME ?? null,
            };
          }),
        };
      },
      { publicRoute: true },
    ),
  );
  router.get(
    '/catalog',
    wrap(
      async (db, u) => {
        const allSchools = await db.list('SCHOOLS'),
          schools =
            u?.role === 'admin'
              ? allSchools.map((s) => ({
                  ...s,
                  SCHOOL_NAME:
                    s.EMIS_NUMBER === 'LOCAL-ONLY'
                      ? s.SCHOOL_NAME + ' (local setup only)'
                      : s.SCHOOL_NAME,
                }))
              : allSchools
                  .filter((s) => s.EMIS_NUMBER !== 'LOCAL-ONLY')
                  .map(({ SCHOOL_ID, SCHOOL_NAME }) => ({ SCHOOL_ID, SCHOOL_NAME })),
          universities = await db.list('UNIVERSITIES'),
          subjects = await db.list('SUBJECTS'),
          examTypes = await db.list('EXAM_TYPES'),
          documentTypes = await db.list('DOCUMENT_TYPES'),
          verificationStatuses = await db.list('VERIFICATION_STATUSES'),
          studyModes = await db.list('STUDY_MODES'),
          provinces = await db.list('PROVINCES'),
          cities = await db.list('CITIES'),
          addresses = await db.list('UNIVERSITY_ADDRESSES');
        return {
          schools,
          universities: universities
            .filter((item) => {
              const pilotActive = process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true';
              if (pilotActive && u?.role !== 'admin' && !['wsu', 'ufh', 'uj'].includes(institutionCodeFor(item.UNIVERSITY_NAME))) return false;
              return u?.role !== 'representative' || String(item.UNIVERSITY_ID) === String(u.universityId);
            })
            .map((u) => {
              const address = addresses.find((a) => sameId(a.UNIVERSITY_ID, u.UNIVERSITY_ID));
              return {
                ...u,
                CITY_ID: address?.CITY_ID ?? null,
                STREET_NAME: address?.STREET_NAME ?? null,
              };
            }),
          subjects,
          examTypes,
          documentTypes,
          verificationStatuses,
          studyModes,
          provinces,
          cities,
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/auth/login',
    wrap(
      async (db, u, req, res) => {
        const username = text(req.body.username, 100).toLowerCase(),
          key = digest(req.ip + '|' + username),
          timestamp = Date.now(),
          windowMs = 900000;
        const prior = (await db.list('security.LoginAttempts', { ATTEMPT_KEY: key }))[0];
        if (prior?.BLOCKED_UNTIL && Date.parse(prior.BLOCKED_UNTIL) > timestamp)
          return {
            __httpStatus: 429,
            error: 'Too many sign-in attempts. Try again in 15 minutes.',
          };
        const account = (await db.list('security.Accounts', { USERNAME: username }))[0];
        const valid = await checkPassword(
          req.body.password,
          account?.PASSWORD_HASH || dummyPasswordHash,
        );
        if (!valid || !account || account.DISABLED) {
          const active =
              prior &&
              Number.isFinite(Date.parse(prior.WINDOW_START)) &&
              timestamp - Date.parse(prior.WINDOW_START) < windowMs,
            failures = (active ? Number(prior.FAILURES) : 0) + 1,
            windowStart = active ? prior.WINDOW_START : new Date(timestamp).toISOString(),
            blockedUntil = failures >= 10 ? new Date(timestamp + windowMs).toISOString() : '';
          if (prior)
            await db.update(
              'security.LoginAttempts',
              { ATTEMPT_KEY: key },
              { FAILURES: failures, WINDOW_START: windowStart, BLOCKED_UNTIL: blockedUntil },
            );
          else
            await db.insert('security.LoginAttempts', {
              ATTEMPT_KEY: key,
              FAILURES: failures,
              WINDOW_START: windowStart,
              BLOCKED_UNTIL: blockedUntil,
            });
          return {
            __httpStatus: failures >= 10 ? 429 : 401,
            error:
              failures >= 10
                ? 'Too many sign-in attempts. Try again in 15 minutes.'
                : 'Incorrect username or password.',
          };
        }
        const context = await userContext(db, account.PERSON_ID);
        if (!context) throw bad('The account needs a single assigned role.', 403);
        if (prior) await db.remove('security.LoginAttempts', { ATTEMPT_KEY: key });
        const verification = (
          await db.list('security.EmailVerifications', { PERSON_ID: account.PERSON_ID })
        )[0];
        if (!verification || !verification.VERIFIED_AT) {
          if (!verification && emailAvailable)
            return {
              ...(await verifyAccountEmail(db, account.PERSON_ID, account.USERNAME)),
              __httpStatus: 403,
              error:
                'Verify your email address before signing in. A verification link has been sent.',
            };
          if (!verification)
            throw bad(
              'Email delivery is not configured. Contact the application administrator to verify your account.',
              503,
            );
          return {
            __httpStatus: 403,
            error:
              'Verify your email address before signing in. You can request a new verification link.',
          };
        }
        const old = readToken(req);
        if (old) await db.remove('security.Sessions', { TOKEN_HASH: digest(old) });
        if (context.role === 'admin') {
          const factor = (await db.list('security.Mfa', { PERSON_ID: account.PERSON_ID }))[0];
          if (factor?.ENABLED) {
            for (const previous of await db.list('security.MfaChallenges', {
              PERSON_ID: account.PERSON_ID,
            }))
              await db.remove('security.MfaChallenges', { TOKEN_HASH: previous.TOKEN_HASH });
            const challenge = token();
            await db.insert('security.MfaChallenges', {
              TOKEN_HASH: digest(challenge),
              PERSON_ID: account.PERSON_ID,
              EXPIRES: new Date(Date.now() + 600000).toISOString(),
              FAILURES: 0,
            });
            setChallengeCookie(res, challenge);
            return { mfaRequired: true };
          }
          if (factor) await db.remove('security.Mfa', { PERSON_ID: account.PERSON_ID });
          const { csrf } = await issueSession(db, account.PERSON_ID, res);
          await audit(db, account.PERSON_ID, 'login.password', { role: 'admin' });
          return { user: context, csrf };
        }
        const { csrf } = await issueSession(db, account.PERSON_ID, res);
        await audit(db, account.PERSON_ID, 'login', {});
        return { user: context, csrf };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/auth/register',
    wrap(
      async (db, u, req) => {
        const b = req.body,
          username = text(b.email, 100).toLowerCase();
        if (!emailPattern.test(username)) throw bad('Enter a valid email address.');
        if (!emailAvailable)
          throw bad(
            'Email delivery is not configured. Contact the application administrator.',
            503,
          );
        if ((await db.list('security.Accounts', { USERNAME: username })).length)
          throw bad('An account already uses that email.', 409);
        const school = await one(db, 'SCHOOLS', { SCHOOL_ID: id(b.schoolId) }),
          hash = await passwordHash(b.password);
        const p = await db.insert('PERSONS', {
          FIRST_NAME: text(b.firstName),
          LAST_NAME: text(b.lastName),
          EMAIL: username,
          USERNAME: username,
          PHONE_NUMBER: null,
          SA_ID_NUMBER: null,
        });
        await db.insert('LEARNERS', { PERSON_ID: p.PERSON_ID, SCHOOL_ID: school.SCHOOL_ID });
        await db.insert('security.Accounts', {
          ACCOUNT_ID: randomUUID(),
          PERSON_ID: p.PERSON_ID,
          USERNAME: username,
          PASSWORD_HASH: hash,
          DISABLED: 0,
        });
        await audit(db, p.PERSON_ID, 'register', {});
        return {
          ...(await verifyAccountEmail(db, p.PERSON_ID, username)),
          message: 'Account created. Check your email to verify the address before signing in.',
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/auth/email/resend',
    wrap(
      async (db, u, req) => {
        const username = String(req.body.email || '')
          .trim()
          .toLowerCase();
        if (emailPattern.test(username) && (await requestAllowed(db, req, 'verify', username))) {
          const account = (await db.list('security.Accounts', { USERNAME: username }))[0],
            verification =
              account &&
              (await db.list('security.EmailVerifications', { PERSON_ID: account.PERSON_ID }))[0];
          if (account && !account.DISABLED && (!verification || !verification.VERIFIED_AT)) {
            const message = await ((await activeInvitation(db, account.PERSON_ID))
              ? accountInvitationMessage(db, account.PERSON_ID, username)
              : emailVerificationMessage(db, account.PERSON_ID, username));
            return {
              ...queueEmail(message),
              message: 'If the address needs verification, a link will be sent shortly.',
            };
          }
        }
        return { message: 'If the address needs verification, a link will be sent shortly.' };
      },
      { publicRoute: true, minimumDuration: 250 },
    ),
  );
  router.post(
    '/auth/email/verify',
    wrap(
      async (db, u, req) => {
        const raw = text(req.body.token, 200),
          stored = (
            await db.list('security.AccountTokens', {
              TOKEN_HASH: digest(raw),
              PURPOSE: 'email-verification',
            })
          )[0];
        if (!stored || stored.EXPIRES <= now())
          throw bad('This verification link is invalid or expired. Request another link.', 400);
        const verification = (
          await db.list('security.EmailVerifications', { PERSON_ID: stored.PERSON_ID })
        )[0];
        if (verification)
          await db.update(
            'security.EmailVerifications',
            { PERSON_ID: stored.PERSON_ID },
            { VERIFIED_AT: now() },
          );
        else
          await db.insert('security.EmailVerifications', {
            PERSON_ID: stored.PERSON_ID,
            VERIFIED_AT: now(),
          });
        await db.remove('security.AccountTokens', { TOKEN_HASH: stored.TOKEN_HASH });
        await audit(db, stored.PERSON_ID, 'email.verify', {});
        return { message: 'Email verified. You can now sign in.' };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/auth/password-reset',
    wrap(
      async (db, u, req) => {
        const email = String(req.body.email || '')
          .trim()
          .toLowerCase();
        if (emailPattern.test(email) && (await requestAllowed(db, req, 'password-reset', email))) {
          const account = (await db.list('security.Accounts', { USERNAME: email }))[0];
          if (account && !account.DISABLED) {
            const verified = (
              await db.list('security.EmailVerifications', { PERSON_ID: account.PERSON_ID })
            )[0];
            if (!verified || !verified.VERIFIED_AT) {
              if (emailAvailable) {
                const message = await ((await activeInvitation(db, account.PERSON_ID))
                  ? accountInvitationMessage(db, account.PERSON_ID, email)
                  : emailVerificationMessage(db, account.PERSON_ID, email));
                return { ...queueEmail(message), __httpStatus: 202, message: genericResetMessage };
              }
            } else {
              const raw = await issueToken(db, account.PERSON_ID, 'password-reset', 20);
              return {
                ...queueEmail(
                  email,
                  'Reset your StudyPath SA password',
                  `A password reset was requested for your account. This link expires in 20 minutes and can be used once:\n\n${accountLink('/reset-password.html', raw)}\n\nIf you did not request this, ignore this message. Your password has not changed.`,
                ),
                __httpStatus: 202,
                message: genericResetMessage,
              };
            }
          }
        }
        return { __httpStatus: 202, message: genericResetMessage };
      },
      { publicRoute: true, minimumDuration: 250 },
    ),
  );
  router.post(
    '/auth/password-reset/complete',
    wrap(
      async (db, u, req) => {
        const raw = text(req.body.token, 200),
          password = req.body.password;
        if (password !== req.body.confirmPassword) throw bad('The passwords do not match.');
        const tokenHash = digest(raw),
          stored = (await db.list('security.AccountTokens', { TOKEN_HASH: tokenHash }))[0];
        if (
          !stored ||
          !['password-reset', 'account-invitation'].includes(stored.PURPOSE) ||
          stored.EXPIRES <= now()
        )
          throw bad('This reset or invitation link is invalid or expired. Request a new one.', 400);
        const account = (await db.list('security.Accounts', { PERSON_ID: stored.PERSON_ID }))[0];
        if (!account || account.DISABLED)
          throw bad('This reset or invitation link is invalid or expired. Request a new one.', 400);
        const hash = await passwordHash(password);
        await db.update(
          'security.Accounts',
          { PERSON_ID: stored.PERSON_ID },
          { PASSWORD_HASH: hash },
        );
        if (stored.PURPOSE === 'account-invitation') {
          const verified = (
            await db.list('security.EmailVerifications', { PERSON_ID: stored.PERSON_ID })
          )[0];
          if (verified)
            await db.update(
              'security.EmailVerifications',
              { PERSON_ID: stored.PERSON_ID },
              { VERIFIED_AT: now() },
            );
          else
            await db.insert('security.EmailVerifications', {
              PERSON_ID: stored.PERSON_ID,
              VERIFIED_AT: now(),
            });
        }
        for (const item of await db.list('security.AccountTokens', { PERSON_ID: stored.PERSON_ID }))
          await db.remove('security.AccountTokens', { TOKEN_HASH: item.TOKEN_HASH });
        for (const session of await db.list('security.Sessions', { PERSON_ID: stored.PERSON_ID }))
          await db.remove('security.Sessions', { TOKEN_HASH: session.TOKEN_HASH });
        await audit(
          db,
          stored.PERSON_ID,
          stored.PURPOSE === 'account-invitation'
            ? 'account.invitation.accepted'
            : 'password.reset',
          {},
        );
        return {
          message:
            stored.PURPOSE === 'account-invitation'
              ? 'Password set and email verified. Sign in to continue.'
              : 'Password reset. Sign in with your new password.',
        };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/auth/mfa/verify',
    wrap(
      async (db, u, req, res) => {
        const challenge = readChallenge(req),
          record =
            challenge &&
            (await db.list('security.MfaChallenges', { TOKEN_HASH: digest(challenge) }))[0],
          factor = record && (await db.list('security.Mfa', { PERSON_ID: record.PERSON_ID }))[0];
        if (!record || record.EXPIRES <= now() || !factor?.ENABLED) {
          setChallengeCookie(res, '', true);
          throw bad('The sign-in challenge expired. Sign in again.', 401);
        }
        if (!(await requestAllowed(db, req, 'mfa', String(record.PERSON_ID))))
          return {
            __httpStatus: 429,
            error: 'Too many verification attempts. Sign in again later.',
          };
        const supplied = String(req.body.code || '')
          .replace(/[ -]/g, '')
          .toLowerCase();
        let validStep = null,
          recoveryHashes = JSON.parse(factor.RECOVERY_HASHES || '[]'),
          recoveryIndex = -1;
        if (/^\d{6}$/.test(supplied)) {
          const secret = decryptSecret(factor.SECRET_CIPHERTEXT);
          validStep = verifyTotp(secret, supplied, factor.LAST_STEP);
        } else recoveryIndex = recoveryHashes.indexOf(digest(supplied));
        if (validStep === null && recoveryIndex < 0) {
          const failures = Number(record.FAILURES) + 1;
          if (failures >= 5) {
            await db.remove('security.MfaChallenges', { TOKEN_HASH: record.TOKEN_HASH });
            setChallengeCookie(res, '', true);
          } else
            await db.update(
              'security.MfaChallenges',
              { TOKEN_HASH: record.TOKEN_HASH },
              { FAILURES: failures },
            );
          return { __httpStatus: 401, error: 'That verification code is not valid.' };
        }
        if (validStep !== null)
          await db.update(
            'security.Mfa',
            { PERSON_ID: record.PERSON_ID },
            { LAST_STEP: validStep },
          );
        else {
          recoveryHashes.splice(recoveryIndex, 1);
          await db.update(
            'security.Mfa',
            { PERSON_ID: record.PERSON_ID },
            { RECOVERY_HASHES: JSON.stringify(recoveryHashes) },
          );
        }
        await db.remove('security.MfaChallenges', { TOKEN_HASH: record.TOKEN_HASH });
        await clearRequestLimit(db, req, 'mfa', String(record.PERSON_ID));
        setChallengeCookie(res, '', true);
        const context = await userContext(db, record.PERSON_ID),
          { csrf } = await issueSession(db, record.PERSON_ID, res);
        await audit(db, record.PERSON_ID, 'login.mfa', {
          method: validStep === null ? 'recovery-code' : 'totp',
        });
        return { user: context, csrf };
      },
      { publicRoute: true },
    ),
  );
  router.post(
    '/me/mfa/setup',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      try {
        encryptionKey();
      } catch {
        throw bad(
          'Configure SECURITY_ENCRYPTION_KEY and restart before setting up administrator MFA.',
          503,
        );
      }
      const account = await one(db, 'security.Accounts', { PERSON_ID: u.personId });
      if (!(await checkPassword(req.body.currentPassword, account.PASSWORD_HASH)))
        throw bad('Current password is incorrect.', 400);
      const current = (await db.list('security.Mfa', { PERSON_ID: u.personId }))[0];
      if (current?.ENABLED) throw bad('Administrator MFA is already enabled.', 409);
      const secret = newTotpSecret(),
        payload = {
          PERSON_ID: u.personId,
          SECRET_CIPHERTEXT: encryptSecret(secret),
          RECOVERY_HASHES: '[]',
          ENABLED: 0,
          LAST_STEP: null,
          SETUP_FAILURES: 0,
        };
      if (current) await db.update('security.Mfa', { PERSON_ID: u.personId }, payload);
      else await db.insert('security.Mfa', payload);
      await audit(db, u.personId, 'admin.mfa.setup.started', {});
      return { secret, provisioningUri: provisioningUri(secret, account.USERNAME) };
    }),
  );
  router.post(
    '/me/mfa/confirm',
    wrap(async (db, u, req, res) => {
      role(u, 'admin');
      if (!(await requestAllowed(db, req, 'mfa-setup', String(u.personId))))
        throw bad('Too many verification attempts. Start setup again later.', 429);
      const factor = (await db.list('security.Mfa', { PERSON_ID: u.personId }))[0];
      if (!factor || factor.ENABLED) throw bad('Start administrator MFA setup first.', 409);
      const secret = decryptSecret(factor.SECRET_CIPHERTEXT),
        step = verifyTotp(secret, req.body.code);
      if (step === null) {
        const failures = Number(factor.SETUP_FAILURES || 0) + 1;
        if (failures >= 5) {
          await db.remove('security.Mfa', { PERSON_ID: u.personId });
          await audit(db, u.personId, 'admin.mfa.setup.locked', {});
        } else
          await db.update('security.Mfa', { PERSON_ID: u.personId }, { SETUP_FAILURES: failures });
        throw bad(
          failures >= 5
            ? 'Too many incorrect codes. Start MFA setup again.'
            : 'Enter the current six-digit code from your authenticator app.',
          400,
        );
      }
      const recovery = makeRecoveryCodes();
      await db.update(
        'security.Mfa',
        { PERSON_ID: u.personId },
        {
          ENABLED: 1,
          LAST_STEP: step,
          RECOVERY_HASHES: JSON.stringify(recovery.hashes),
          SETUP_FAILURES: 0,
        },
      );
      await clearRequestLimit(db, req, 'mfa-setup', String(u.personId));
      for (const session of await db.list('security.Sessions', { PERSON_ID: u.personId }))
        await db.remove('security.Sessions', { TOKEN_HASH: session.TOKEN_HASH });
      const { csrf } = await issueSession(db, u.personId, res);
      await audit(db, u.personId, 'admin.mfa.enabled', { recoveryCodes: recovery.codes.length });
      return {
        message:
          'Administrator MFA enabled. Save these recovery codes now; they will not be shown again.',
        recoveryCodes: recovery.codes,
        csrf,
      };
    }),
  );
  router.get(
    '/me',
    wrap(async (db, u, req, res, session) => {
      if (u.role === 'admin') {
        const factor = (await db.list('security.Mfa', { PERSON_ID: u.personId }))[0];
        if (factor && !factor.ENABLED) await db.remove('security.Mfa', { PERSON_ID: u.personId });
      }
      return { user: u, csrf: session.CSRF, mode: store.mode };
    }),
  );
  router.post(
    '/auth/logout',
    wrap(async (db, u, req, res) => {
      await db.remove('security.Sessions', { TOKEN_HASH: digest(readToken(req)) });
      setCookie(res, '', true);
      return { message: 'Signed out.' };
    }),
  );
  router.post(
    '/me/password',
    wrap(async (db, u, req, res) => {
      const a = await one(db, 'security.Accounts', { PERSON_ID: u.personId });
      if (!(await checkPassword(req.body.currentPassword, a.PASSWORD_HASH)))
        throw bad('Current password is incorrect.', 400);
      await db.update(
        'security.Accounts',
        { PERSON_ID: u.personId },
        { PASSWORD_HASH: await passwordHash(req.body.newPassword) },
      );
      for (const session of await db.list('security.Sessions', { PERSON_ID: u.personId }))
        await db.remove('security.Sessions', { TOKEN_HASH: session.TOKEN_HASH });
      await audit(db, u.personId, 'password.change', {});
      setCookie(res, '', true);
      return { message: 'Password changed. Sign in again.' };
    }),
  );
  router.put(
    '/me/profile',
    wrap(async (db, u, req) => {
      const b = req.body;
      await db.update(
        'PERSONS',
        { PERSON_ID: u.personId },
        {
          FIRST_NAME: text(b.firstName),
          LAST_NAME: text(b.lastName),
          PHONE_NUMBER: b.phone ? text(b.phone, 10) : null,
        },
      );
      await audit(db, u.personId, 'profile.update', {});
      return { message: 'Profile saved.' };
    }),
  );
  router.get(
    '/me/profile',
    wrap(async (db, u) => ({
      user: u,
      person: await one(db, 'PERSONS', { PERSON_ID: u.personId }),
    })),
  );
  router.get(
    '/results',
    wrap(async (db, u, req) => {
      role(u, 'learner', 'teacher', 'admin');
      const learnerId = u.role === 'learner' ? u.recordId : id(req.query.learnerId);
      await scopedLearner(db, u, learnerId);
      return {
        rows: await results(db, learnerId, id(req.query.examTypeId)),
        enrolled: await db.list('LEARNER_SUBJECTS', { LEARNER_ID: learnerId }),
      };
    }),
  );
  router.get(
    '/results/summary',
    wrap(async (db, u) => {
      role(u, 'learner');
      return { examTypeIds: await db.resultMilestones(u.recordId) };
    }),
  );
  router.put(
    '/results',
    wrap(async (db, u, req) => {
      role(u, 'learner');
      const exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_ID: id(req.body.examTypeId) });
      const rows = req.body.rows;
      if (
        !Array.isArray(rows) ||
        rows.length < 1 ||
        rows.length > 30 ||
        new Set(rows.map((r) => id(r?.subjectId))).size !== rows.length
      )
        throw bad('Add at least one subject and use unique subject rows, maximum 30.');
      const existing = await db.list('LEARNER_RESULTS', {
          LEARNER_ID: u.recordId,
          EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
        }),
        verified = await verificationId(db, 'Verified');
      if (existing.some((r) => sameId(r.VERIFICATION_STATUS_ID, verified)))
        throw bad(
          'Verified marks are locked. Ask your teacher to reject/unlock the affected result first.',
          409,
        );
      const subjects = await db.list('SUBJECTS');
      const pending = await verificationId(db, 'Pending');
      for (const row of rows) {
        const subjectId = id(row?.subjectId),
          subject = subjects.find((s) => Number(s.SUBJECT_ID) === subjectId);
        if (!subject)
          throw bad(
            `Subject ID ${subjectId} is not in the current subject catalogue. Refresh the Results page and re-add that subject from the current list.`,
          );
        if (subject.SCHOOL_ID != null && Number(subject.SCHOOL_ID) !== Number(u.schoolId))
          throw bad(`“${subject.SUBJECT_NAME}” is not available to your school.`);
        if (
          typeof row.percentage !== 'number' ||
          !Number.isFinite(row.percentage) ||
          row.percentage < 0 ||
          row.percentage > 100
        )
          throw bad(`Enter a percentage from 0 to 100 for “${subject.SUBJECT_NAME}”.`);
      }
      // Reconcile the submitted milestone in-place instead of deleting the whole
      // result set first. This preserves unrelated rows and gives SQL Server a
      // straightforward update/insert path under the surrounding transaction.
      const submittedIds = new Set(rows.map((row) => id(row.subjectId)));
      for (const saved of existing) {
        if (![...submittedIds].some((submittedId) => sameId(submittedId, saved.SUBJECT_ID))) {
          await db.remove('LEARNER_RESULTS', {
            LEARNER_ID: u.recordId,
            SUBJECT_ID: saved.SUBJECT_ID,
            EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
          });
        }
      }
      for (const row of rows) {
        const subjectId = id(row.subjectId);
        const key = {
          LEARNER_ID: u.recordId,
          SUBJECT_ID: subjectId,
          EXAM_TYPE_ID: exam.EXAM_TYPE_ID,
        };
        const values = {
          PERCENTAGE: row.percentage,
          VERIFICATION_STATUS_ID: pending,
          VERIFIED_BY_TEACHER_ID: null,
          VERIFIED_DATE: null,
        };
        if (existing.some((saved) => sameId(saved.SUBJECT_ID, subjectId))) {
          await db.update('LEARNER_RESULTS', key, values);
        } else {
          await db.insert('LEARNER_RESULTS', { ...key, ...values });
        }
        const enrolled = await db.list('LEARNER_SUBJECTS', {
          LEARNER_ID: u.recordId,
          SUBJECT_ID: subjectId,
        });
        if (!enrolled.length)
          await db.insert('LEARNER_SUBJECTS', {
            LEARNER_ID: u.recordId,
            SUBJECT_ID: subjectId,
            ENROLLMENT_DATE: date().slice(0, 10),
          });
      }
      await audit(db, u.personId, 'results.save', {
        examTypeId: exam.EXAM_TYPE_ID,
        count: rows.length,
      });
      return { message: 'Results saved for teacher verification.' };
    }),
  );
  router.get(
    '/offerings',
    wrap(async (db, u) => {
      const all = [];
      const pilotMode = process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true';
      for (const row of await db.list(
        'UNI_QUALIFICATIONS',
        u.role === 'representative' ? { UNIVERSITY_ID: u.universityId } : {},
      )) {
        const item = await offering(db, row.UNI_QUAL_ID);
        if (pilotMode && u.role === 'learner') {
          const code = institutionCodeFor(item.university);
          if (!code || !pilotCodes.has(code)) continue;
          // The authoritative recommendation ledger is the only learner calculation source in pilot mode.
          const matching = pilotStore ? await verifiedPilotRuleFor(item.university, item.qualification) : null;
          if (!matching) continue;
        }
        all.push(item);
      }
      return { offerings: all };
    }),
  );
  router.get(
    '/offerings/:id/requirements',
    wrap(async (db, u, req) => {
      role(u, 'learner');
      const offeringId = id(req.params.id);
      if (pilotModeActive()) {
        const current = await offering(db, offeringId);
        const rule = await verifiedPilotRuleFor(current.university, current.qualification);
        if (!rule) return {
          status: 'not-yet-verified', eligible: false, total: null, metric: 'Programme eligibility',
          contributions: [], issues: ['This programme is not currently verified with passing source-backed golden cases in StudyPath SA.'],
          disclaimer: DISCLAIMERS.eligibility,
        };
        const exams = await db.list('EXAM_TYPES');
        const exam = req.query.examTypeId
          ? await one(db, 'EXAM_TYPES', { EXAM_TYPE_ID: id(req.query.examTypeId) })
          : exams.find((item) => /Grade 11 Final/i.test(item.EXAM_TYPE_NAME)) || exams[0];
        if (!exam) throw bad('An exam type must be configured before eligibility can be calculated.', 409);
        const policy = {
          ...parsedJson(rule.verification.RequirementJson, {}),
          status: 'verified', intake: 2027, allowPilotYear: true, source: rule.source.SourceUrl,
        };
        const learnerResults = await results(db, u.recordId, exam.EXAM_TYPE_ID);
        const calculated = assessSubjects(learnerResults, null, policy);
        const guardReason = /Grade 11 Final/i.test(exam.EXAM_TYPE_NAME) ? unsuitableApplicationReason(learnerResults, policy) : null;
        return {
          ...calculated,
          offering: { ...current, config: policy },
          pilotGuard: guardReason ? { reason: guardReason, acknowledgementRequired: true } : null,
          provenance: {
            source: { title: rule.source.SourceTitle, url: rule.source.SourceUrl, year: Number(rule.source.DocumentYear), pageRef: rule.source.PageRef || null },
            lastUpdated: rule.provenance.LastUpdatedOn,
            lastVerifiedByRole: 'admin',
            conditions: parseConditions(rule.provenance.Conditions),
            status: rule.provenance.Status,
            staleAfterDays: pilotConfig.freshnessDays.programme,
          },
          disclaimer: DISCLAIMERS.eligibility,
        };
      }
      return assessment(db, u, offeringId, id(req.query.examTypeId));
    }),
  );

  router.post('/pilot/unsuitable-acknowledgement', wrap(async (db, u, req) => {
    role(u, 'learner');
    if (!pilotModeActive()) throw bad('This acknowledgement workflow is available only in the active pilot.', 409);
    const offerId = id(req.body.offeringId);
    const current = await offering(db, offerId);
    const rule = await verifiedPilotRuleFor(current.university, current.qualification);
    if (!rule) throw bad('The programme cannot be assessed until its source-backed rule and golden accuracy gate are verified.', 409);
    const exam = (await db.list('EXAM_TYPES')).find((item) => /Grade 11 Final/i.test(item.EXAM_TYPE_NAME));
    if (!exam) throw bad('Grade 11 Final results are not configured.', 409);
    const policy = { ...parsedJson(rule.verification.RequirementJson, {}), status: 'verified', intake: 2027, allowPilotYear: true, source: rule.source.SourceUrl };
    const learnerResults = await results(db, u.recordId, exam.EXAM_TYPE_ID);
    const reason = unsuitableApplicationReason(learnerResults, policy);
    if (!reason) throw bad('No unsuitable-subject warning applies to the current results.', 409);
    const institutionCode = institutionCodeFor(current.university) || 'outside-pilot';
    const programmeCode = String(current.qualification || '').slice(0, 100);
    const participant = await researchParticipant(u);
    if (participant) {
      const pilotDb = requirePilot();
      const priorAcknowledgements = await pilotDb.list('PilotEvent', { ParticipantId: participant.ParticipantId, EventType: 'application-acknowledged' });
      const alreadyRecorded = priorAcknowledgements.some((event) => {
        const metadata = parsedJson(event.MetadataJson, {});
        return metadata.institutionCode === institutionCode && metadata.programmeCode === programmeCode && metadata.reasonCode === 'subject-requirement' && metadata.outcome === 'acknowledged-before-review';
      });
      if (!alreadyRecorded) await recordPilotEvent(u, 'application-acknowledged', {
        institutionCode, programmeCode, reasonCode: 'subject-requirement', outcome: 'acknowledged-before-review',
      });
    }
    await audit(db, u.personId, 'application.unsuitable-acknowledgement-reviewed', { offeringId: offerId, reasonCode: 'subject-requirement' });
    return { acknowledged: true, eligibleToApply: false, reason, message: 'Acknowledgement recorded. It does not override the institution’s published requirements or make an ineligible application eligible.' };
  }));
  router.get(
    '/documents',
    wrap(async (db, u, req) => {
      let personId = u.personId;
      if (req.query.learnerId) {
        const l = await scopedLearner(db, u, id(req.query.learnerId));
        personId = l.PERSON_ID;
        if (['teacher', 'representative'].includes(u.role) && pilotStore && !(await pilotConsent({ personId }, 'share-with-school')))
          throw bad('The learner has not granted current consent to share documents with a school or institution.', 403);
      }
      const docs = await db.list('DOCUMENTS', { PERSON_ID: personId });
      return { documents: docs.map(({ DOCUMENT_BLOB, ...d }) => d) };
    }),
  );
  router.post(
    '/documents',
    express.raw({ type: ['application/pdf', 'image/png', 'image/jpeg'], limit: '6mb' }),
    wrap(async (db, u, req) => {
      role(u, 'learner');
      if (pilotStore && !(await pilotConsent(u, 'document-processing')))
        throw bad('Document processing consent and age/guardian attestation are required before Vault uploads are enabled.', 403);
      const type = await one(db, 'DOCUMENT_TYPES', {
        DOCUMENT_TYPE_ID: id(req.get('x-document-type')),
      });
      if (!Buffer.isBuffer(req.body) || !req.body.length)
        throw bad('Upload a PDF, PNG or JPEG, up to 6 MB.');
      const data = req.body,
        mime = req.get('content-type').split(';')[0];
      if (!(
        (mime === 'application/pdf' && data.subarray(0, 5).toString() === '%PDF-') ||
        (mime === 'image/png' &&
          data.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ||
        (mime === 'image/jpeg' && data[0] === 255 && data[1] === 216 && data[2] === 255)
      ))
        throw bad('The file signature does not match its type.');
      const apps = await db.list('APPLICATIONS', { LEARNER_ID: u.recordId }),
        statuses = await db.list('APPLICATION_STATUSES');
      if (
        type.IS_LOCKED_UNTIL_FINAL &&
        !apps.some((a) =>
          ['Provisionally Accepted', 'Final Matric Verified', 'Admitted', 'Offer Revoked'].includes(
            statuses.find((s) => sameId(s.STATUS_ID, a.STATUS_ID))?.STATUS_NAME,
          ),
        )
      )
        throw bad('Final NSC uploads unlock after provisional acceptance.', 409);
      try { await scanBuffer(data); }
      catch (error) { throw bad(error.status === 422 ? error.message : 'Upload scanning is unavailable; the file was not stored. Contact the administrator.', error.status || 503); }
      const name = decodeURIComponent(req.get('x-file-name') || 'upload')
        .replace(/[^a-zA-Z0-9._ -]/g, '_')
        .slice(0, 200);
      const pending = await verificationId(db, 'Pending');
      await db.insert('DOCUMENTS', {
        DOCUMENT_NAME: type.DOCUMENT_TYPE_NAME,
        DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
        UPLOAD_DATE: date(),
        PERSON_ID: u.personId,
        FILE_NAME: name,
        MIME_TYPE: mime,
        DOCUMENT_BLOB: encryptDocument(data),
        VERIFICATION_STATUS_ID: pending,
        VERIFIED_BY_TEACHER_ID: null,
        VERIFIED_DATE: null,
      });
      await audit(db, u.personId, 'document.upload', {
        typeId: type.DOCUMENT_TYPE_ID,
        bytes: data.length,
      });
      return { message: 'Document uploaded.' };
    }),
  );
  router.get(
    '/documents/:id/download',
    wrap(async (db, u, req, res) => {
      const d = await one(db, 'DOCUMENTS', { DOCUMENT_ID: id(req.params.id) });
      let allowed = sameId(d.PERSON_ID, u.personId) || u.role === 'admin';
      const l = (await db.list('LEARNERS', { PERSON_ID: d.PERSON_ID }))[0];
      if (l && u.role === 'teacher') allowed = sameId(l.SCHOOL_ID, u.schoolId);
      if (l && u.role === 'representative') {
        const apps = await db.list('APPLICATIONS', { LEARNER_ID: l.LEARNER_ID });
        for (const a of apps) {
          const o = await offering(db, a.UNI_QUAL_ID);
          if (
            sameId(o.UNIVERSITY_ID, u.universityId) &&
            !sameId(a.STATUS_ID, await statusId(db, 'Submitted'))
          )
            allowed = true;
        }
      }
      if (!allowed) throw bad('Document is outside your scope.', 403);
      if (['teacher', 'representative'].includes(u.role) && !sameId(d.PERSON_ID, u.personId) && pilotStore && !(await pilotConsent({ personId: d.PERSON_ID }, 'share-with-school')))
        throw bad('The learner has not granted current consent to share documents with a school or institution.', 403);
      const blob = Buffer.from(d.DOCUMENT_BLOB);
      const content = decryptDocument(blob);
      if (pilotStore) {
        const purpose = sameId(d.PERSON_ID, u.personId) ? 'learner download' : 'authorised review';
        await pilotStore.insert('DocumentAccessLog', { PersonId: d.PERSON_ID, DocumentId: d.DOCUMENT_ID, AccessedByPersonId: u.personId, Purpose: purpose, Role: u.role });
      }
      res
        .type(d.MIME_TYPE)
        .set('Cache-Control', 'no-store')
        .set('Content-Disposition', 'attachment; filename="' + d.FILE_NAME.replace(/["\r\n]/g, '_') + '"')
        .send(content);
    }),
  );
  router.get(
    '/applications',
    wrap(async (db, u) => ({
      applications: (await db.allApplications(u)).map(dashboardApplication),
    })),
  );
  router.get(
    '/dashboard/summary',
    wrap(async (db, u) => {
      const summary = {
        applications: [],
        applicationCount: 0,
        actionQueue: [],
        closingSoon: [],
        counts: {},
      };
      const appAction = (application, href, label) => ({
        id: application.APPLICATION_ID,
        title: application.learnerName,
        detail: application.offering.qualification,
        context: application.offering.university,
        status: application.status,
        date: application.APPLICATION_DATE,
        href,
        label,
      });
      if (u.role === 'learner') {
        const applications = await db.dashboardApplications(u, { limit: 8, order: 'DESC' });
        summary.applications = applications.map(dashboardApplication);
        summary.applicationCount = Number(applications[0]?.TOTAL_COUNT || 0);
        summary.counts.results = await db.count('LEARNER_RESULTS', { LEARNER_ID: u.recordId });
        summary.counts.documents = await db.count('DOCUMENTS', { PERSON_ID: u.personId });
        const dateLimit = new Date(Date.now() + 30 * 86400000),
          closingFrom = today(),
          closingTo = new Intl.DateTimeFormat('en-CA', {
            timeZone: 'Africa/Johannesburg',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
          }).format(dateLimit);
        summary.closingSoon = (
          await db.dashboardOfferings({ closingFrom, closingTo, limit: 4 })
        ).map((row) => ({
          id: row.UNI_QUAL_ID,
          title: row.QUAL_NAME,
          university: row.UNIVERSITY_NAME,
          date: row.APPLICATION_CLOSING_DATE,
        }));
      } else if (u.role === 'teacher') {
        const queue = await db.dashboardApplications(u, {
          status: 'Submitted',
          limit: 8,
          order: 'ASC',
        });
        summary.actionQueue = queue.map((a) =>
          appAction(dashboardApplication(a), '/teacher/applications.html', 'Screen application'),
        );
        summary.counts.awaitingScreening = Number(queue[0]?.TOTAL_COUNT || 0);
        summary.counts.learners = await db.count('LEARNERS', { SCHOOL_ID: u.schoolId });
      } else if (u.role === 'representative') {
        const queue = await db.dashboardApplications(u, {
          status: 'Screened by Career Teacher',
          limit: 8,
          order: 'ASC',
        });
        summary.actionQueue = queue.map((a) =>
          appAction(dashboardApplication(a), '/representative/decisions.html', 'Review decision'),
        );
        summary.counts.awaitingReview = Number(queue[0]?.TOTAL_COUNT || 0);
        summary.applicationCount = await db.dashboardApplicationCount(u);
      } else if (u.role === 'admin') {
        summary.counts.accounts = await db.count('security.Accounts');
        summary.counts.universities = await db.count('UNIVERSITIES');
        summary.counts.offerings = await db.count('UNI_QUALIFICATIONS');
        const queue = await db.dashboardOfferings({ unverified: true, limit: 8 });
        summary.actionQueue = queue.map((item) => ({
          id: item.UNI_QUAL_ID,
          title: item.QUAL_NAME,
          detail: item.UNIVERSITY_NAME,
          context:
            item.POLICY_STATUS === 'pending'
              ? 'Needs source verification'
              : 'Review 2028 source and deadline',
          status: item.POLICY_STATUS,
          date: item.APPLICATION_CLOSING_DATE,
          href: '/admin/offerings.html',
          label: 'Review requirements',
        }));
      }
      return summary;
    }),
  );
  router.post(
    '/applications',
    wrap(async (db, u, req) => {
      role(u, 'learner');
      const offerId = id(req.body.offeringId),
        studyMode = await one(db, 'STUDY_MODES', { STUDY_MODE_ID: id(req.body.studyModeId) }),
        exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_NAME: 'Grade 11 Final' });
      const offer = await offering(db, offerId);
      const pilotActive = pilotModeActive();
      const verifiedRule = pilotActive ? await verifiedPilotRuleFor(offer.university, offer.qualification) : null;
      if (pilotActive && !verifiedRule) throw bad('Applications are disabled for this programme until the 2027 rule has provenance, two independent approvals and passing golden accuracy cases.', 409);
      const applicationYear = pilotActive ? 2027 : 2028;
      const check = await assessment(db, u, offerId, exam.EXAM_TYPE_ID);
      const currentSubjects = await results(db, u.recordId, exam.EXAM_TYPE_ID);
      if (pilotActive) {
        const pilotPolicy = { ...parsedJson(verifiedRule.verification.RequirementJson, {}), status: 'verified', intake: 2027, allowPilotYear: true, source: verifiedRule.source.SourceUrl };
        check.offering.config = pilotPolicy;
        const officialAssessment = assessSubjects(currentSubjects, null, pilotPolicy);
        check.eligible = officialAssessment.eligible;
        check.status = officialAssessment.status;
        check.issues = officialAssessment.issues || [];
        check.score = officialAssessment.total;
      }
      const unsuitableReason = unsuitableApplicationReason(currentSubjects, check.offering.config);
      if (unsuitableReason && req.body.acknowledgeUnsuitable !== true) {
        throw bad(`${unsuitableReason} Explicit acknowledgement is required before this application can proceed.`, 409);
      }
      if (unsuitableReason && req.body.acknowledgeUnsuitable === true) {
        await recordPilotEvent(u, 'application-acknowledged', {
          institutionCode: institutionCodeFor(check.offering.university) || 'outside-pilot',
          programmeCode: String(check.offering.qualification || '').slice(0, 100),
          reasonCode: 'subject-requirement', outcome: 'acknowledged',
        }).catch(() => false);
        await audit(db, u.personId, 'application.unsuitable-acknowledged', {
          offeringId: offerId, reasonCode: 'subject-requirement',
        });
      }
      if (!check.eligible) throw bad(check.status + ': ' + check.issues.join(' '), 409);
      const closes = check.offering.APPLICATION_CLOSING_DATE;
      if (offeringAvailability(check.offering.config, closes) !== 'Open')
        throw bad('This offering is closed or its deadline is unverified.', 409);
      if (
        (
          await db.list('APPLICATIONS', {
            LEARNER_ID: u.recordId,
            UNI_QUAL_ID: offerId,
            ACADEMIC_YEAR: applicationYear,
          })
        ).length
      )
        throw bad('You already applied for this qualification in the selected intake.', 409);
      for (const type of (await db.list('DOCUMENT_TYPES')).filter(
        (t) =>
          t.IS_MANDATORY ||
          check.offering.config.requiredDocumentIds?.includes(Number(t.DOCUMENT_TYPE_ID)),
      )) {
        const docs = await db.list('DOCUMENTS', {
          PERSON_ID: u.personId,
          DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
        });
        if (!docs.some((d) => d.DOCUMENT_BLOB?.length))
          throw bad('Upload ' + type.DOCUMENT_TYPE_NAME + ' before submitting.', 409);
      }
      const a = await db.insert('APPLICATIONS', {
        APPLICATION_DATE: date(),
        ACADEMIC_YEAR: applicationYear,
        STUDY_MODE_ID: studyMode.STUDY_MODE_ID,
        UNI_QUAL_ID: offerId,
        LEARNER_ID: u.recordId,
        TEACHER_ID: null,
        STATUS_ID: await statusId(db, 'Submitted'),
        REVIEWED_BY_REP_ID: null,
        REVIEW_DATE: null,
        REVIEW_NOTES: null,
      });
      await history(db, a, 'Submitted', u);
      return { application: a, message: `Application submitted for teacher screening (${applicationYear} intake).` };
    }),
  );
  router.get(
    '/applications/:id/timeline',
    wrap(async (db, u, req) => {
      const a = await scopeApp(db, u, id(req.params.id)),
        actions = await db.list('ACTIONS');
      return {
        timeline: (await db.list('APPLICATION_PROCESSES', { APPLICATION_ID: a.APPLICATION_ID }))
          .sort((x, y) => x.APP_PROC_ID - y.APP_PROC_ID)
          .map((r) => ({
            ...r,
            status: actions.find((v) => sameId(v.ACTION_ID, r.ACTION_ID))?.ACTION_NAME,
          })),
      };
    }),
  );
  router.get(
    '/applications/:id/evidence',
    wrap(async (db, u, req) => {
      role(u, 'representative', 'teacher', 'admin');
      const a = await scopeApp(db, u, id(req.params.id));
      if (u.role === 'representative' && sameId(a.STATUS_ID, await statusId(db, 'Submitted')))
        throw bad('Teacher screening is required before evidence review.', 403);
      const learner = await one(db, 'LEARNERS', { LEARNER_ID: a.LEARNER_ID }),
        exams = [];
      for (const ex of await db.list('EXAM_TYPES'))
        exams.push({
          name: ex.EXAM_TYPE_NAME,
          rows: await results(db, learner.LEARNER_ID, ex.EXAM_TYPE_ID),
        });
      return {
        exams,
        documents: (await db.list('DOCUMENTS', { PERSON_ID: learner.PERSON_ID })).map(
          ({ DOCUMENT_BLOB, ...d }) => d,
        ),
      };
    }),
  );
  router.get(
    '/teacher/learners',
    wrap(async (db, u) => {
      role(u, 'teacher');
      const out = [];
      for (const l of await db.list('LEARNERS', { SCHOOL_ID: u.schoolId })) {
        const p = await one(db, 'PERSONS', { PERSON_ID: l.PERSON_ID });
        out.push({ ...l, name: p.FIRST_NAME + ' ' + p.LAST_NAME, email: p.EMAIL });
      }
      return { learners: out };
    }),
  );
  router.post(
    '/teacher/verify',
    wrap(async (db, u, req) => {
      role(u, 'teacher');
      if (!['Verified', 'Rejected'].includes(req.body.decision))
        throw bad('Choose Verified or Rejected.');
      const l = await scopedLearner(db, u, id(req.body.learnerId)),
        verified = await verificationId(
          db,
          req.body.decision === 'Rejected' ? 'Rejected' : 'Verified',
        );
      if (req.body.documentId) {
        const d = await one(db, 'DOCUMENTS', { DOCUMENT_ID: id(req.body.documentId) });
        if (!sameId(d.PERSON_ID, l.PERSON_ID))
          throw bad('Document does not belong to this learner.', 403);
        await db.update(
          'DOCUMENTS',
          { DOCUMENT_ID: d.DOCUMENT_ID },
          {
            VERIFICATION_STATUS_ID: verified,
            VERIFIED_BY_TEACHER_ID: u.recordId,
            VERIFIED_DATE: date(),
          },
        );
      } else {
        const examId = id(req.body.examTypeId),
          rows = await results(db, l.LEARNER_ID, examId);
        if (!curriculum(rows)) throw bad('The learner curriculum is incomplete.');
        await db.update(
          'LEARNER_RESULTS',
          { LEARNER_ID: l.LEARNER_ID, EXAM_TYPE_ID: examId },
          {
            VERIFICATION_STATUS_ID: verified,
            VERIFIED_BY_TEACHER_ID: u.recordId,
            VERIFIED_DATE: date(),
          },
        );
      }
      await audit(db, u.personId, 'teacher.verify', req.body);
      return { message: 'Verification recorded.' };
    }),
  );
  router.post(
    '/applications/:id/transition',
    wrap(async (db, u, req) => {
      const a = await scopeApp(db, u, id(req.params.id)),
        target = req.body.status,
        statuses = await db.list('APPLICATION_STATUSES'),
        current = statuses.find((s) => sameId(s.STATUS_ID, a.STATUS_ID))?.STATUS_NAME,
        l = await one(db, 'LEARNERS', { LEARNER_ID: a.LEARNER_ID }),
        verified = await verificationId(db, 'Verified'),
        programme = await offering(db, a.UNI_QUAL_ID);
      if (target === 'Screened by Career Teacher') {
        role(u, 'teacher');
        if (current !== 'Submitted') throw bad('Only submitted applications can be screened.', 409);
        const exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_NAME: 'Grade 11 Final' }),
          rows = await results(db, a.LEARNER_ID, exam.EXAM_TYPE_ID);
        if (!curriculum(rows) || rows.some((r) => !sameId(r.VERIFICATION_STATUS_ID, verified)))
          throw bad('Verify the complete Grade 11 results first.', 409);
        for (const type of (await db.list('DOCUMENT_TYPES')).filter(
          (t) =>
            t.IS_MANDATORY ||
            programme.config.requiredDocumentIds?.includes(Number(t.DOCUMENT_TYPE_ID)),
        )) {
          if (
            !(
              await db.list('DOCUMENTS', {
                PERSON_ID: l.PERSON_ID,
                DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
              })
            ).some((d) => sameId(d.VERIFICATION_STATUS_ID, verified))
          )
            throw bad('Verify mandatory documents first.', 409);
        }
        await db.update(
          'APPLICATIONS',
          { APPLICATION_ID: a.APPLICATION_ID },
          { TEACHER_ID: u.recordId },
        );
      } else {
        role(u, 'representative');
        const allowed = {
          'Screened by Career Teacher': ['Provisionally Accepted', 'Rejected'],
          'Provisionally Accepted': ['Final Matric Verified'],
          'Final Matric Verified': ['Admitted', 'Offer Revoked'],
        };
        if (!allowed[current]?.includes(target))
          throw bad('This transition is not available from ' + current + '.', 409);
        if (target === 'Provisionally Accepted') {
          const exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_NAME: 'Grade 11 Final' }),
            rows = await results(db, a.LEARNER_ID, exam.EXAM_TYPE_ID);
          if (!curriculum(rows) || rows.some((r) => !sameId(r.VERIFICATION_STATUS_ID, verified)))
            throw bad(
              'Grade 11 results must still be verified before provisional acceptance.',
              409,
            );
          for (const type of (await db.list('DOCUMENT_TYPES')).filter(
            (t) =>
              t.IS_MANDATORY ||
              programme.config.requiredDocumentIds?.includes(Number(t.DOCUMENT_TYPE_ID)),
          ))
            if (
              !(
                await db.list('DOCUMENTS', {
                  PERSON_ID: l.PERSON_ID,
                  DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
                })
              ).some((d) => sameId(d.VERIFICATION_STATUS_ID, verified) && d.DOCUMENT_BLOB?.length)
            )
              throw bad(
                'Mandatory documents must still be verified before provisional acceptance.',
                409,
              );
          const check = await assessment(
            db,
            { ...u, recordId: a.LEARNER_ID },
            a.UNI_QUAL_ID,
            exam.EXAM_TYPE_ID,
          );
          if (!check.eligible)
            throw bad('Grade 11 results do not meet the currently configured requirements.', 409);
        }
        if (['Final Matric Verified', 'Admitted'].includes(target)) {
          const exam = await one(db, 'EXAM_TYPES', { EXAM_TYPE_NAME: 'Grade 12 Final (NSC)' }),
            rows = await results(db, a.LEARNER_ID, exam.EXAM_TYPE_ID),
            type = await one(db, 'DOCUMENT_TYPES', { DOCUMENT_TYPE_NAME: 'Final NSC Certificate' });
          if (
            !curriculum(rows) ||
            rows.some((r) => !sameId(r.VERIFICATION_STATUS_ID, verified)) ||
            !(
              await db.list('DOCUMENTS', {
                PERSON_ID: l.PERSON_ID,
                DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
              })
            ).some((d) => sameId(d.VERIFICATION_STATUS_ID, verified))
          )
            throw bad('Verified final NSC results and certificate are required.', 409);
          const check = await assessment(
            db,
            { ...u, recordId: a.LEARNER_ID },
            a.UNI_QUAL_ID,
            exam.EXAM_TYPE_ID,
          );
          if (target === 'Admitted' && !check.eligible)
            throw bad('Final results do not meet the configured requirements.', 409);
        }
        await db.update(
          'APPLICATIONS',
          { APPLICATION_ID: a.APPLICATION_ID },
          {
            REVIEWED_BY_REP_ID: u.recordId,
            REVIEW_DATE: date(),
            REVIEW_NOTES: typeof req.body.notes === 'string' ? req.body.notes.slice(0, 400) : null,
          },
        );
      }
      await db.update(
        'APPLICATIONS',
        { APPLICATION_ID: a.APPLICATION_ID },
        { STATUS_ID: await statusId(db, target) },
      );
      await history(db, a, target, u);
      return { message: 'Application moved to ' + target + '.' };
    }),
  );
  router.post(
    '/admin/accounts',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      if (!emailAvailable)
        throw bad('Email delivery is not configured. Contact the application administrator.', 503);
      const b = req.body,
        username = text(b.email, 100).toLowerCase();
      if (!emailPattern.test(username)) throw bad('Enter a valid email address.');
      if (!['learner', 'teacher', 'representative', 'admin'].includes(b.role))
        throw bad('Choose a valid role.');
      let school = null,
        university = null;
      if (['learner', 'teacher'].includes(b.role))
        school = await one(db, 'SCHOOLS', { SCHOOL_ID: id(b.schoolId) });
      if (b.role === 'representative')
        university = await one(db, 'UNIVERSITIES', { UNIVERSITY_ID: id(b.universityId) });
      if ((await db.list('security.Accounts', { USERNAME: username })).length)
        throw bad('An account already uses that email.', 409);
      const p = await db.insert('PERSONS', {
          FIRST_NAME: text(b.firstName),
          LAST_NAME: text(b.lastName),
          EMAIL: username,
          USERNAME: username,
          PHONE_NUMBER: null,
          SA_ID_NUMBER: null,
        }),
        table = {
          learner: 'LEARNERS',
          teacher: 'TEACHERS',
          representative: 'UNIVERSITY_REPS',
          admin: 'ITADMINS',
        }[b.role];
      await db.insert(table, {
        PERSON_ID: p.PERSON_ID,
        ...(b.role === 'representative'
          ? { UNIVERSITY_ID: university.UNIVERSITY_ID }
          : { SCHOOL_ID: school?.SCHOOL_ID ?? null }),
        ...(b.role === 'teacher'
          ? { DEPARTMENT: 'Career Guidance', DESIGNATION: 'Career Guidance Teacher' }
          : {}),
      });
      const invited = typeof b.password !== 'string' || !b.password,
        initialPassword = invited ? token() : b.password;
      await db.insert('security.Accounts', {
        ACCOUNT_ID: randomUUID(),
        PERSON_ID: p.PERSON_ID,
        USERNAME: username,
        PASSWORD_HASH: await passwordHash(initialPassword),
        DISABLED: 0,
      });
      await audit(db, u.personId, 'account.create', {
        personId: p.PERSON_ID,
        role: b.role,
        invitation: invited,
      });
      return {
        ...(await (invited
          ? inviteAccount(db, p.PERSON_ID, username)
          : verifyAccountEmail(db, p.PERSON_ID, username))),
        message: invited
          ? 'Account created. A secure setup link was emailed to the user.'
          : 'Account created. A verification link was emailed to the user.',
      };
    }),
  );
  router.get(
    '/admin/unlinked',
    wrap(async (db, u) => {
      role(u, 'admin');
      const linked = new Set((await db.list('security.Accounts')).map((a) => a.PERSON_ID)),
        people = [];
      for (const p of await db.list('PERSONS'))
        if (!linked.has(p.PERSON_ID)) {
          const context = await userContext(db, p.PERSON_ID);
          if (context) people.push(context);
        }
      return { people };
    }),
  );
  router.post(
    '/admin/accounts/link',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      if (!emailAvailable)
        throw bad('Email delivery is not configured. Contact the application administrator.', 503);
      const personId = id(req.body.personId),
        context = await userContext(db, personId);
      if (!context) throw bad('The existing person must have exactly one assigned role.');
      if ((await db.list('security.Accounts', { PERSON_ID: personId })).length)
        throw bad('This person already has an account.', 409);
      const username = text(req.body.email, 100).toLowerCase();
      if (!emailPattern.test(username)) throw bad('Enter a valid email.');
      if ((await db.list('security.Accounts', { USERNAME: username })).length)
        throw bad('That login already exists.', 409);
      const invited = typeof req.body.password !== 'string' || !req.body.password;
      await db.insert('security.Accounts', {
        ACCOUNT_ID: randomUUID(),
        PERSON_ID: personId,
        USERNAME: username,
        PASSWORD_HASH: await passwordHash(invited ? token() : req.body.password),
        DISABLED: 0,
      });
      await audit(db, u.personId, 'account.link', { personId, invitation: invited });
      return {
        ...(await (invited
          ? inviteAccount(db, personId, username)
          : verifyAccountEmail(db, personId, username))),
        message: invited
          ? 'Existing person linked. A secure setup link was emailed to the user.'
          : 'Existing person linked. A verification link was emailed to the user.',
      };
    }),
  );
  router.get(
    '/admin/accounts',
    wrap(async (db, u) => {
      role(u, 'admin');
      const out = [];
      for (const a of await db.list('security.Accounts')) {
        const verification = (
          await db.list('security.EmailVerifications', { PERSON_ID: a.PERSON_ID })
        )[0];
        out.push({
          accountId: a.ACCOUNT_ID,
          username: a.USERNAME,
          disabled: a.DISABLED,
          emailVerified: Boolean(verification?.VERIFIED_AT),
          accountSetupPending: await activeInvitation(db, a.PERSON_ID),
          user: await userContext(db, a.PERSON_ID),
        });
      }
      return { accounts: out };
    }),
  );
  router.post(
    '/admin/accounts/:id/password-reset',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      if (!emailAvailable)
        throw bad('Email delivery is not configured. Contact the application administrator.', 503);
      const account = await one(db, 'security.Accounts', { ACCOUNT_ID: req.params.id });
      if (sameId(account.PERSON_ID, u.personId))
        throw bad('Use the self-service password recovery page for your own account.', 400);
      if (account.DISABLED) throw bad('Restore the account before requesting recovery.', 409);
      const verification = (
          await db.list('security.EmailVerifications', { PERSON_ID: account.PERSON_ID })
        )[0],
        invitation = await activeInvitation(db, account.PERSON_ID),
        person = await one(db, 'PERSONS', { PERSON_ID: account.PERSON_ID }),
        email = String(person.EMAIL || account.USERNAME).toLowerCase();
      if (!verification || !verification.VERIFIED_AT) {
        const message = await (invitation
          ? accountInvitationMessage(db, account.PERSON_ID, email)
          : emailVerificationMessage(db, account.PERSON_ID, email));
        await audit(
          db,
          u.personId,
          invitation ? 'account.invitation.resent' : 'email.verification.resent',
          { personId: account.PERSON_ID },
        );
        return {
          ...queueEmail(message),
          message: invitation
            ? 'Account setup link sent to the account email.'
            : 'Email verification link sent to the account email.',
        };
      }
      const raw = await issueToken(db, account.PERSON_ID, 'password-reset', 20);
      await audit(db, u.personId, 'password.reset.requested', { personId: account.PERSON_ID });
      return {
        ...queueEmail(
          email,
          'Password reset requested by your StudyPath SA administrator',
          `An administrator requested account access instructions. This link expires in 20 minutes and can only be used once:\n\n${accountLink('/reset-password.html', raw)}\n\nIf you did not expect this, contact your institution administrator.`,
        ),
        message: 'Password reset instructions sent to the verified account email.',
      };
    }),
  );
  router.post(
    '/admin/accounts/:id/disable',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const a = await one(db, 'security.Accounts', { ACCOUNT_ID: req.params.id });
      if (sameId(a.PERSON_ID, u.personId)) throw bad('You cannot disable your own account.');
      await db.update('security.Accounts', { ACCOUNT_ID: a.ACCOUNT_ID }, { DISABLED: 1 });
      for (const s of await db.list('security.Sessions', { PERSON_ID: a.PERSON_ID }))
        await db.remove('security.Sessions', { TOKEN_HASH: s.TOKEN_HASH });
      await audit(db, u.personId, 'account.disable', { personId: a.PERSON_ID });
      return { message: 'Account disabled.' };
    }),
  );
  router.post(
    '/admin/accounts/:id/enable',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const a = await one(db, 'security.Accounts', { ACCOUNT_ID: req.params.id });
      if (!(await userContext(db, a.PERSON_ID)))
        throw bad('Assign exactly one valid role before restoring this account.', 409);
      await db.update('security.Accounts', { ACCOUNT_ID: a.ACCOUNT_ID }, { DISABLED: 0 });
      for (const session of await db.list('security.Sessions', { PERSON_ID: a.PERSON_ID }))
        await db.remove('security.Sessions', { TOKEN_HASH: session.TOKEN_HASH });
      await audit(db, u.personId, 'account.enable', { personId: a.PERSON_ID });
      return { message: 'Account restored. The user must sign in again.' };
    }),
  );
  router.get(
    '/admin/audit',
    wrap(async (db, u) => {
      role(u, 'admin');
      const people = new Map(
        (await db.list('PERSONS')).map((person) => [
          String(person.PERSON_ID),
          [person.FIRST_NAME, person.LAST_NAME].filter(Boolean).join(' '),
        ]),
      );
      const events = (await db.list('security.Audit'))
        .sort((a, b) => b.CREATED_AT.localeCompare(a.CREATED_AT))
        .slice(0, 200)
        .map(({ PERSON_ID, ...event }) => ({
          ...event,
          actor: people.get(String(PERSON_ID)) || 'System',
        }));
      return { events };
    }),
  );
  const saveOffering = wrap(async (db, u, req) => {
    role(u, 'admin', 'representative');
    if (u.role === 'representative' && String(req.body.universityId) !== String(u.universityId))
      throw bad('You can manage offerings only for your assigned university.', 403);
    if (req.params.id && u.role === 'representative') {
      const existing = await one(db, 'UNI_QUALIFICATIONS', { UNI_QUAL_ID: id(req.params.id) });
      if (String(existing.UNIVERSITY_ID) !== String(u.universityId))
        throw bad('This offering belongs to another university.', 403);
    }
    const b = req.body,
      university = await one(db, 'UNIVERSITIES', { UNIVERSITY_ID: id(b.universityId) });
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(b.closingDate) ||
      Number.isNaN(Date.parse(b.closingDate)) ||
      new Date(b.closingDate).toISOString().slice(0, 10) !== b.closingDate ||
      b.intake !== 2028
    )
      throw bad('Use a valid closing date and the 2028 intake.');
    if (
      !Number.isInteger(b.minScore) ||
      b.minScore < 0 ||
      b.minScore > (b.scoring ? 32767 : 42) ||
      (!b.scoring && !Number.isInteger(b.minScore))
    )
      throw bad(
        'Use a whole-number minimum: 0–42 for standard APS, or 0–32767 for a custom score.',
      );
    if (!/^https:\/\//.test(b.source || '')) throw bad('Add an official HTTPS source URL.');
    if (
      b.finalMinScore != null &&
      (!Number.isFinite(b.finalMinScore) ||
        b.finalMinScore < 0 ||
        b.finalMinScore > (b.scoring ? 32767 : 42) ||
        (!b.scoring && !Number.isInteger(b.finalMinScore)))
    )
      throw bad('Final APS must be a whole number between 0 and 42.');
    for (const k of ['minEnglish', 'minMath'])
      if (b[k] != null && (typeof b[k] !== 'number' || b[k] < 0 || b[k] > 100))
        throw bad('Subject minimums must be 0–100.');
    const known = new Set((await db.list('SUBJECTS')).map((s) => s.SUBJECT_CODE));
    if (
      b.requiredCodes !== undefined &&
      (!Array.isArray(b.requiredCodes) ||
        b.requiredCodes.length > 6 ||
        b.requiredCodes.some((c) => !known.has(c)))
    )
      throw bad('Use at most six known required subject codes.');
    if (
      b.subjectMinimums !== undefined &&
      (!b.subjectMinimums ||
        typeof b.subjectMinimums !== 'object' ||
        Array.isArray(b.subjectMinimums) ||
        Object.entries(b.subjectMinimums).some(
          ([c, v]) =>
            !known.has(c) || typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 100,
        ))
    )
      throw bad('Use known subject codes with numeric percentage minimums from 0–100.');
    let scoring, subjectGroups;
    try {
      scoring = validateScoring(b.scoring, known);
      subjectGroups = validateGroups(b.subjectGroups, known);
    } catch (error) {
      throw bad(error.message);
    }
    const requiredDocumentIds = b.requiredDocumentIds ?? [];
    const types = await db.list('DOCUMENT_TYPES');
    if (
      !Array.isArray(requiredDocumentIds) ||
      requiredDocumentIds.some(
        (value) =>
          !types.some((t) => Number(t.DOCUMENT_TYPE_ID) === value && !t.IS_LOCKED_UNTIL_FINAL),
      )
    )
      throw bad(
        'Choose existing submission document types; final certificates cannot be required before a provisional offer.',
      );
    if (
      b.openingDate &&
      (!/^\d{4}-\d{2}-\d{2}$/.test(b.openingDate) ||
        Number.isNaN(Date.parse(b.openingDate)) ||
        new Date(b.openingDate).toISOString().slice(0, 10) !== b.openingDate ||
        b.openingDate > b.closingDate)
    )
      throw bad('Opening date must be valid and on or before the closing date.');
    if (b.closingTime && !/^([01]\d|2[0-3]):[0-5]\d$/.test(b.closingTime))
      throw bad('Closing time must use HH:MM.');
    let o;
    if (req.params.id) {
      o = await one(db, 'UNI_QUALIFICATIONS', { UNI_QUAL_ID: id(req.params.id) });
      if (!sameId(o.UNIVERSITY_ID, university.UNIVERSITY_ID))
        throw bad('An offering cannot be transferred to a different university.');
      await db.update(
        'UNI_QUALIFICATIONS',
        { UNI_QUAL_ID: o.UNI_QUAL_ID },
        { APPLICATION_CLOSING_DATE: b.closingDate },
      );
    } else {
      const program = await db.insert('PROGRAMS', {
          PROGRAM_NAME: text(b.program || 'Undergraduate'),
        }),
        qualification = await db.insert('QUALIFICATIONS', {
          QUAL_NAME: text(b.name, 150),
          PROGRAM_ID: program.PROGRAM_ID,
        });
      o = await db.insert('UNI_QUALIFICATIONS', {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
        QUAL_ID: qualification.QUAL_ID,
        APPLICATION_CLOSING_DATE: b.closingDate,
      });
    }
    const config = {
      intake: 2028,
      status: b.verified === true ? 'verified' : 'pending',
      source: b.source,
      minScore: b.minScore,
      finalMinScore: b.finalMinScore ?? null,
      minEnglish: b.minEnglish ?? null,
      minMath: b.minMath ?? null,
      requiredCodes: Array.isArray(b.requiredCodes) ? b.requiredCodes : [],
      subjectMinimums: b.subjectMinimums || {},
      scoring,
      subjectGroups,
      requiredDocumentIds: [...new Set(requiredDocumentIds)],
      openingDate: b.openingDate || null,
      closingTime: b.closingTime || '23:59',
      active: b.active !== false,
      scoringMethod: scoring ? 'configured' : 'standard-aps-6',
      notes: text(b.notes || 'Check the university source for full selection conditions.', 400),
    };
    if ((await db.list('security.Policies', { UNI_QUAL_ID: o.UNI_QUAL_ID })).length)
      await db.update(
        'security.Policies',
        { UNI_QUAL_ID: o.UNI_QUAL_ID },
        { PAYLOAD: JSON.stringify(config) },
      );
    else
      await db.insert('security.Policies', {
        UNI_QUAL_ID: o.UNI_QUAL_ID,
        PAYLOAD: JSON.stringify(config),
      });
    const data = {
      MIN_APS_SCORE: config.minScore,
      MIN_ENG_SCORE: config.minEnglish,
      MIN_MATH_SCORE: config.minMath,
      NOTES: config.notes,
    };
    if ((await db.list('QUALIFICATION_REQUIREMENTS', { UNI_QUAL_ID: o.UNI_QUAL_ID })).length)
      await db.update('QUALIFICATION_REQUIREMENTS', { UNI_QUAL_ID: o.UNI_QUAL_ID }, data);
    else await db.insert('QUALIFICATION_REQUIREMENTS', { UNI_QUAL_ID: o.UNI_QUAL_ID, ...data });
    await audit(db, u.personId, req.params.id ? 'offering.update' : 'offering.create', {
      offeringId: o.UNI_QUAL_ID,
      config,
    });
    return { message: 'Offering saved.', offeringId: o.UNI_QUAL_ID };
  });
  router.post('/admin/offerings', saveOffering);
  router.patch('/admin/offerings/:id', saveOffering);
  router.post('/representative/offerings', saveOffering);
  router.patch('/representative/offerings/:id', saveOffering);
  const directoryTables = {
    schools: 'SCHOOLS',
    universities: 'UNIVERSITIES',
    cities: 'CITIES',
    provinces: 'PROVINCES',
    subjects: 'SUBJECTS',
    exams: 'EXAM_TYPES',
    studyModes: 'STUDY_MODES',
  };
  router.get(
    '/admin/directories/:type',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const t = directoryTables[req.params.type];
      if (!t) throw bad('Unknown directory.');
      const rows = await db.list(t);
      if (t === 'UNIVERSITIES') {
        const addresses = await db.list('UNIVERSITY_ADDRESSES');
        return {
          rows: rows.map((row) => {
            const address = addresses.find((a) => sameId(a.UNIVERSITY_ID, row.UNIVERSITY_ID));
            return {
              ...row,
              CITY_ID: address?.CITY_ID ?? null,
              STREET_NAME: address?.STREET_NAME ?? null,
            };
          }),
        };
      }
      return { rows };
    }),
  );
  const saveDirectory = wrap(async (db, u, req) => {
    role(u, 'admin');
    const t = directoryTables[req.params.type];
    if (!t) throw bad('Unknown directory.');
    const allowed = {
      schools: ['SCHOOL_NAME', 'EMIS_NUMBER', 'CITY_ID', 'PROVINCE_ID'],
      universities: ['UNIVERSITY_NAME', 'WEBSITE', 'PROVINCE_ID', 'CITY_ID', 'STREET_NAME'],
      cities: ['CITY_NAME'],
      provinces: ['PROVINCE_NAME'],
      subjects: ['SUBJECT_NAME', 'SUBJECT_CODE', 'SCHOOL_ID', 'SUBJECT_CATEGORY'],
      exams: ['EXAM_TYPE_NAME'],
      studyModes: ['STUDY_MODE_NAME'],
    }[req.params.type];
    const data = {};
    for (const k of allowed) {
      const v = req.body[k];
      if (v !== undefined)
        data[k] = k.endsWith('_ID')
          ? v === null
            ? null
            : id(v)
          : text(v, k === 'WEBSITE' ? 255 : k === 'STREET_NAME' ? 150 : 150);
    }
    if (!Object.keys(data).length) throw bad('Enter directory fields.');
    for (const [column, target] of [
      ['CITY_ID', 'CITIES'],
      ['PROVINCE_ID', 'PROVINCES'],
      ['SCHOOL_ID', 'SCHOOLS'],
    ])
      if (data[column] != null) await one(db, target, { [column]: data[column] });
    if (
      t === 'SUBJECTS' &&
      ![
        'HOME_LANGUAGE',
        'FIRST_ADDITIONAL_LANGUAGE',
        'MATHEMATICS',
        'MATHEMATICAL_LITERACY',
        'LIFE_ORIENTATION',
        'ELECTIVE',
      ].includes(data.SUBJECT_CATEGORY)
    )
      throw bad('Choose a valid NSC category.');
    for (const column of allowed.filter((c) => !c.endsWith('_ID')))
      if (data[column] === undefined) throw bad('Enter ' + column + '.');
    if (t === 'SCHOOLS' && (!data.CITY_ID || !data.PROVINCE_ID))
      throw bad('Assign the school to a city and province.');
    if (t === 'UNIVERSITIES' && (!data.CITY_ID || !data.PROVINCE_ID || !data.STREET_NAME))
      throw bad('Add the university’s campus location, city and province.');
    let row;
    if (req.params.id) {
      const primary = {
          SCHOOLS: 'SCHOOL_ID',
          UNIVERSITIES: 'UNIVERSITY_ID',
          CITIES: 'CITY_ID',
          PROVINCES: 'PROVINCE_ID',
          SUBJECTS: 'SUBJECT_ID',
          EXAM_TYPES: 'EXAM_TYPE_ID',
          STUDY_MODES: 'STUDY_MODE_ID',
        }[t],
        where = { [primary]: id(req.params.id) };
      await one(db, t, where);
      const values = { ...data };
      if (t === 'UNIVERSITIES') {
        delete values.CITY_ID;
        delete values.STREET_NAME;
      }
      await db.update(t, where, values);
      row = { ...where, ...values };
    } else {
      const values = { ...data };
      if (t === 'UNIVERSITIES') {
        delete values.CITY_ID;
        delete values.STREET_NAME;
      }
      row = await db.insert(t, values);
    }
    if (t === 'UNIVERSITIES') {
      let addressType =
        (await db.list('ADDRESS_TYPES')).find((a) => /campus|main/i.test(a.ADDRESS_TYPE_NAME)) ||
        (await db.list('ADDRESS_TYPES'))[0];
      if (!addressType)
        addressType = await db.insert('ADDRESS_TYPES', { ADDRESS_TYPE_NAME: 'Campus' });
      const uniId = row.UNIVERSITY_ID,
        existing = (await db.list('UNIVERSITY_ADDRESSES', { UNIVERSITY_ID: uniId }))[0],
        address = {
          UNIVERSITY_ID: uniId,
          ADRRESS_TYPE_ID: addressType.ADDRESS_TYPE_ID,
          STREET_NAME: data.STREET_NAME,
          CITY_ID: data.CITY_ID,
        };
      if (existing)
        await db.update('UNIVERSITY_ADDRESSES', { ADDRESS_ID: existing.ADDRESS_ID }, address);
      else await db.insert('UNIVERSITY_ADDRESSES', address);
      row = { ...row, CITY_ID: data.CITY_ID, STREET_NAME: data.STREET_NAME };
    }
    await audit(db, u.personId, req.params.id ? 'directory.update' : 'directory.create', {
      table: t,
    });
    return { row };
  });
  router.post('/admin/directories/:type', saveDirectory);
  router.patch('/admin/directories/:type/:id', saveDirectory);
  router.get(
    '/prospectuses',
    wrap(async (db, u) => ({
      prospectuses: (await db.list('PROSPECTUSES')).map(({ PROSPECTUS_FILE, ...p }) => p),
    })),
  );
  router.post(
    '/prospectuses',
    express.raw({ type: 'application/pdf', limit: '6mb' }),
    wrap(async (db, u, req) => {
      role(u, 'representative');
      if (!Buffer.isBuffer(req.body) || req.body.subarray(0, 5).toString() !== '%PDF-')
        throw bad('Upload a PDF prospectus.');
      await db.insert('PROSPECTUSES', {
        UNIVERSITY_ID: u.universityId,
        PROSPECTUS_FILE: req.body,
        PROSPECTUS_FILENAME: decodeURIComponent(req.get('x-file-name') || 'prospectus.pdf')
          .replace(/[^a-zA-Z0-9._ -]/g, '_')
          .slice(0, 200),
        PROSPECTUS_MIMETYPE: 'application/pdf',
        PROSPECTUS_DATE: date(),
      });
      await audit(db, u.personId, 'prospectus.upload', {});
      return { message: 'Prospectus uploaded.' };
    }),
  );
  router.get(
    '/prospectuses/:id/download',
    wrap(async (db, u, req, res) => {
      const p = await one(db, 'PROSPECTUSES', { PROSPECTUS_ID: id(req.params.id) });
      res
        .type('application/pdf')
        .set(
          'Content-Disposition',
          'attachment; filename="' + p.PROSPECTUS_FILENAME.replace(/["\r\n]/g, '_') + '"',
        )
        .send(Buffer.from(p.PROSPECTUS_FILE));
    }),
  );
  const requirePilot = () => {
    if (!pilotStore) throw bad('StudyPathPilot storage is not configured. Apply database/migrations and restart.', 503);
    return pilotStore;
  };
  const pilotCodes = new Set(pilotConfig.pilotInstitutions);
  const pilotNames = { wsu: 'Walter Sisulu University', ufh: 'University of Fort Hare', uj: 'University of Johannesburg' };
  const institutionCodeFor = (name) => {
    const value = String(name || '').toLowerCase().replace(/[^a-z]/g, '');
    if (value.includes('waltersisulu') || value === 'wsu') return 'wsu';
    if (value.includes('fort hare'.replace(/\s/g, '')) || value.includes('universityofforthare') || value === 'ufh') return 'ufh';
    if (value.includes('universityofjohannesburg') || value === 'uj') return 'uj';
    return null;
  };
  const parsedJson = (value, fallback = null) => {
    if (value == null || value === '') return fallback;
    if (typeof value !== 'string') return value;
    try { return JSON.parse(value); } catch { return fallback; }
  };
  const canonicalJson = (value) => {
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
    if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
    return JSON.stringify(value);
  };
  const dateOnly = (value) => {
    if (!value) return '';
    const parsed = value instanceof Date ? value : new Date(value);
    return Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : String(value).slice(0, 10);
  };
  const pilotConsent = async (u, purpose) => {
    const p = requirePilot();
    const rows = await p.list('Consent', { PersonId: u.personId, Purpose: purpose, PolicyVersion: 'sp-privacy-v1' });
    return rows.find((row) => row.Granted && !row.WithdrawnAt && (row.AgeAttested || row.GuardianConfirmed)) || null;
  };
  const researchParticipant = async (u) => {
    const p = requirePilot();
    if (!(await pilotConsent(u, 'pilot-research'))) return null;
    return (await p.list('PilotParticipant', { PersonId: u.personId })).find((row) => !row.WithdrawnAt) || null;
  };
  const recordPilotEvent = async (u, eventType, metadata = {}) => {
    const p = requirePilot();
    const participant = await researchParticipant(u);
    if (!participant) return false;
    const allowed = new Set(['research-time-start', 'research-time-stop', 'whatif-guard', 'application-acknowledged', 'deadline-opened', 'document-uploaded', 'application-submitted', 'funding-opened']);
    if (!allowed.has(eventType)) return false;
    const clean = {};
    for (const key of ['institutionCode', 'programmeCode', 'reasonCode', 'outcome', 'seconds', 'count', 'itemType']) {
      const value = metadata[key];
      if (typeof value === 'string' && value.length <= 120) clean[key] = value;
      else if (Number.isFinite(value)) clean[key] = value;
      else if (typeof value === 'boolean') clean[key] = value;
    }
    await p.insert('PilotEvent', { ParticipantId: participant.ParticipantId, EventType: eventType, MetadataJson: JSON.stringify(clean) });
    return true;
  };
  const sourceFor = async (p, provenance) => {
    const src = (await p.list('Source', { SourceId: provenance.SourceId }))[0];
    return src ? { title: src.SourceTitle, url: src.SourceUrl, year: Number(src.DocumentYear), pageRef: src.PageRef || null } : null;
  };
  const parseConditions = (value) => {
    const parsed = parsedJson(value, []);
    if (Array.isArray(parsed)) return parsed;
    if (typeof parsed === 'string' && parsed.trim()) return [parsed.trim()];
    return [];
  };

  // Source provenance and sign-offs are required but not enough: current official golden cases must also pass.
  const goldenAccuracyGate = async (institutionCode, programmeCode) => {
    try {
      const fixturePath = fileURLToPath(new URL(`../tests/fixtures/golden/${institutionCode}.json`, import.meta.url));
      const fixture = JSON.parse(await readFile(fixturePath, 'utf8'));
      const source = fixture.verifiedExamplesSource;
      const validDate = (value) => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
      if (fixture.institution !== institutionCode || !source?.title || !/^https:\/\//i.test(source.url || '') || !source.pageRef || !validDate(source.retrievedOn))
        return { ready: false, cases: 0, reason: 'Institution-level official golden source metadata is incomplete.' };
      const cases = (Array.isArray(fixture.cases) ? fixture.cases : []).filter((item) => String(item.programmeCode || '').toLowerCase() === String(programmeCode).toLowerCase());
      if (cases.length < 25) return { ready: false, cases: cases.length, reason: 'At least 25 source-backed golden cases for this programme are required before it can be enabled.' };
      for (const item of cases) {
        if (!item.source?.title || !/^https:\/\//i.test(item.source.url || '') || !item.source.pageRef || !validDate(item.source.retrievedOn) || !Array.isArray(item.subjects) || !item.expected)
          return { ready: false, cases: cases.length, reason: 'One or more golden cases are missing official source metadata or expected outputs.' };
        const actual = assessSubjects(item.subjects, item.policy ?? null, item.config ?? {});
        if (actual.total !== item.expected.total || actual.eligible !== item.expected.eligible || actual.status !== item.expected.status)
          return { ready: false, cases: cases.length, reason: 'One or more exact golden outputs do not match the scoring engine.' };
      }
      return { ready: true, cases: cases.length, reason: null };
    } catch {
      return { ready: false, cases: 0, reason: 'The institution golden fixture is unavailable or invalid.' };
    }
  };
  const pilotModeActive = () => process.env.NODE_ENV === 'production' || process.env.STUDYPATH_PILOT_MODE === 'true';
  const comparableProgrammeCode = (value) => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const verifiedPilotRuleFor = async (institutionName, programmeName) => {
    const p = requirePilot();
    const institutionCode = institutionCodeFor(institutionName);
    if (!institutionCode || !pilotCodes.has(institutionCode)) return null;
    const candidates = (await p.list('ScoringPolicyVerification')).filter((item) => item.InstitutionCode === institutionCode && Number(item.IntakeYear) === 2027 && item.VerificationStatus === 'verified' && item.Enabled && comparableProgrammeCode(item.ProgrammeCode) === comparableProgrammeCode(programmeName));
    for (const candidate of candidates) {
      const gate = await goldenAccuracyGate(institutionCode, candidate.ProgrammeCode);
      if (!gate.ready) continue;
      const provenance = candidate.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: candidate.ProvenanceId }))[0] : null;
      const source = provenance ? (await p.list('Source', { SourceId: provenance.SourceId }))[0] : null;
      const evidence = provenance && source ? withProvenance({ label: 'Meets published minimum' }, { source: { title: source.SourceTitle, url: source.SourceUrl, year: Number(source.DocumentYear), pageRef: source.PageRef }, lastUpdated: provenance.LastUpdatedOn, conditions: parseConditions(provenance.Conditions), status: provenance.Status }, { freshnessDays: pilotConfig.freshnessDays.programme }) : null;
      if (evidence?.kind === 'recommendation') return { institutionCode, verification: candidate, accuracy: gate, provenance, source };
    }
    return null;
  };

  router.get('/pilot/config', (req, res) => res.json({
    product: pilotConfig.product,
    release: pilotConfig.release,
    intakeYear: 2027,
    pilotInstitutions: pilotConfig.pilotInstitutions.map((code) => ({ code, name: pilotNames[code] })),
    postgraduateEnabled: false,
    creditTransferEnabled: pilotConfig.creditTransferEnabled,
    bursaryMatchingEnabled: pilotConfig.bursaryMatchingEnabled,
    researchInstrumentationEnabled: pilotConfig.researchInstrumentationEnabled,
    disclaimers: { eligibility: DISCLAIMERS.eligibility, funding: DISCLAIMERS.funding, creditTransfer: DISCLAIMERS.creditTransfer, hypothetical: DISCLAIMERS.hypothetical, accuracy: DISCLAIMERS.accuracy },
  }));

  router.get('/pilot/recommendations', wrap(async (db, u, req) => {
    role(u, 'learner');
    const p = requirePilot();
    const exam = req.query.examTypeId ? await one(db, 'EXAM_TYPES', { EXAM_TYPE_ID: id(req.query.examTypeId) }) : (await db.list('EXAM_TYPES')).find((row) => /Grade 11 Final/i.test(row.EXAM_TYPE_NAME));
    const learnerResults = exam ? await results(db, u.recordId, exam.EXAM_TYPE_ID) : [];
    const verifications = (await p.list('ScoringPolicyVerification')).filter((row) => pilotCodes.has(row.InstitutionCode));
    const recommendations = [];
    for (const code of pilotConfig.pilotInstitutions) {
      const entries = verifications.filter((row) => row.InstitutionCode === code && Number(row.IntakeYear) === 2027);
      if (!entries.length) recommendations.push({ institutionCode: code, institution: pilotNames[code], programmeCode: null, label: 'Not yet verified', status: 'draft', reason: 'No source-backed programme rule has been submitted to the verification ledger.', source: null, lastUpdated: null, conditions: [], disclaimer: DISCLAIMERS.eligibility });
      for (const item of entries) {
        const prov = item.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: item.ProvenanceId }))[0] : null;
        const src = prov ? await sourceFor(p, prov) : null;
        const facts = prov && src ? withProvenance({ label: 'Meets published minimum' }, { source: src, lastUpdated: prov.LastUpdatedOn, conditions: parseConditions(prov.Conditions), status: prov.Status, lastVerifiedByRole: item.VerificationStatus === 'verified' ? 'admin' : null }, { freshnessDays: pilotConfig.freshnessDays.programme }) : { kind: 'cannot-confirm', label: 'Not yet verified', recommendation: null, provenance: null, reason: 'Source, last-updated date or conditions are missing.' };
        const accuracy = item.VerificationStatus === 'verified' && item.Enabled ? await goldenAccuracyGate(code, item.ProgrammeCode) : { ready: false, cases: 0, reason: 'The programme has not passed the accuracy gate.' };
        if (item.VerificationStatus === 'verified' && item.Enabled && !accuracy.ready) {
          facts.kind = 'guidance'; facts.label = 'Not yet verified'; facts.recommendation = null; facts.reason = accuracy.reason;
          if (facts.provenance) facts.provenance = { ...facts.provenance, status: 'draft' };
        }
        let result = null;
        if (item.VerificationStatus === 'verified' && item.Enabled && accuracy.ready && facts.kind === 'recommendation' && exam) {
          const conf = parsedJson(item.RequirementJson, {});
          result = assessSubjects(learnerResults, null, { ...conf, status: 'verified', intake: 2027, allowPilotYear: true, source: src.url });
          facts.label = result.eligible ? 'Meets published minimum' : result.status;
        } else facts.label = facts.label === 'Cannot confirm — see institution' ? 'Not yet verified' : facts.label;
        recommendations.push({ institutionCode: code, institution: pilotNames[code], programmeCode: item.ProgrammeCode, label: facts.label, status: facts.provenance?.status || (accuracy.ready ? item.VerificationStatus : 'draft') || 'draft', score: result?.total ?? null, metric: result?.metric ?? null, issues: result?.issues ?? [], source: facts.provenance?.source || null, lastUpdated: facts.provenance?.lastUpdated || null, conditions: facts.provenance?.conditions || [], stale: Boolean(facts.provenance?.stale), reason: facts.reason || (facts.provenance?.freshnessNotice ?? null), disclaimer: DISCLAIMERS.eligibility, why: result ? { scoringPolicy: item.ProgrammeCode, selectedSubjects: result.contributions.map((subject) => subject.SUBJECT_CODE), inputExam: exam.EXAM_TYPE_NAME } : null });
      }
    }
    return { intake: 2027, verifiedCount: recommendations.filter((row) => row.label === 'Meets published minimum').length, recommendations, disclaimer: DISCLAIMERS.eligibility };
  }));

  router.post('/whatif', wrap(async (db, u, req) => {
    role(u, 'learner');
    enforceWhatIfRateLimit(u.personId);
    const offerId = id(req.body.offeringId), examId = id(req.body.examTypeId);
    const currentOffering = await offering(db, offerId);
    if (pilotModeActive()) {
      const rule = await verifiedPilotRuleFor(currentOffering.university, currentOffering.qualification);
      if (!rule) throw bad('What-If is available only for programmes with complete provenance, two approvals and passing source-backed golden cases.', 409);
      currentOffering.config = parsedJson(rule.verification.RequirementJson, {});
    }
    const original = await results(db, u.recordId, examId);
    const catalog = await db.list('SUBJECTS');
    const submitted = validateHypotheticalMarks((req.body.subjects || []).map((row) => {
      const code = String(row.subjectCode || row.SUBJECT_CODE || '').trim().toUpperCase();
      const subject = catalog.find((s) => String(s.SUBJECT_CODE).toUpperCase() === code);
      if (!subject) throw bad('A hypothetical subject is not in the existing subject catalogue.');
      return { ...subject, PERCENTAGE: Number(row.percentage ?? row.PERCENTAGE) };
    }));
    if (!submitted.length) throw bad('Provide the hypothetical subject marks.');
    const base = original.map((row) => ({ ...row, SUBJECT_CODE: String(row.SUBJECT_CODE).toUpperCase() }));
    const outcome = runWhatIf(base, submitted, null, currentOffering.config);
    const guard = unsuitableApplicationReason(submitted, currentOffering.config);
    outcome.guard = guard ? { reason: guard, acknowledgementRequired: true } : null;
    outcome.offering = { id: currentOffering.UNI_QUAL_ID, institution: currentOffering.university, programme: currentOffering.qualification };
    outcome.disclaimer = DISCLAIMERS.hypothetical;
    if (guard) await recordPilotEvent(u, 'whatif-guard', { institutionCode: institutionCodeFor(currentOffering.university), programmeCode: String(currentOffering.qualification).slice(0, 120), reasonCode: 'subject-requirement' });
    return outcome;
  }));

  router.post('/admin/verification/evidence', express.raw({ type: 'application/pdf', limit: '10mb' }), wrap(async (db, u, req) => {
    role(u, 'admin', 'representative');
    if (!Buffer.isBuffer(req.body) || req.body.length < 5 || req.body.subarray(0, 5).toString() !== '%PDF-') throw bad('Upload a valid PDF prospectus or official scoring document (maximum 10 MB).');
    try { await scanBuffer(req.body); }
    catch (error) { throw bad(error.status === 422 ? error.message : 'Evidence scanning is unavailable; the file was not archived.', error.status || 503); }
    const hash = createHash('sha256').update(req.body).digest('hex');
    const dir = fileURLToPath(new URL('../.data/evidence/', import.meta.url));
    await mkdir(dir, { recursive: true });
    const filename = `${hash.slice(0, 16)}-${randomUUID()}.pdf`;
    await writeFile(resolvePath(dir, filename), req.body, { flag: 'wx', mode: 0o600 });
    return { contentHash: hash, archivedCopyPath: `evidence/${filename}`, bytes: req.body.length, message: 'Evidence archived locally. Confirm the source URL, page and year before proposing a rule.' };
  }));

  const parseCsv = (input) => {
    if (typeof input !== 'string' || input.length > 2_000_000) throw bad('CSV input is missing or too large (maximum 2 MB).');
    const rows = []; let row = [], cell = '', quoted = false;
    for (let i = 0; i < input.length; i += 1) {
      const c = input[i];
      if (quoted) {
        if (c === '"' && input[i + 1] === '"') { cell += '"'; i += 1; }
        else if (c === '"') quoted = false;
        else cell += c;
      } else if (c === '"' && !cell) quoted = true;
      else if (c === ',') { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && input[i + 1] === '\n') i += 1;
        row.push(cell); cell = '';
        if (row.some((value) => value.trim())) rows.push(row);
        row = [];
      } else cell += c;
    }
    if (quoted) throw bad('CSV has an unclosed quoted field.');
    if (cell.length || row.length) { row.push(cell); if (row.some((value) => value.trim())) rows.push(row); }
    if (!rows.length) return [];
    const headers = rows.shift().map((value, index) => (index === 0 ? value.replace(/^\uFEFF/, '') : value).trim());
    if (new Set(headers).size !== headers.length || headers.some((header) => !header)) throw bad('CSV column headers must be non-empty and unique.');
    return rows.map((values) => {
      if (values.length !== headers.length) throw bad('Each CSV row must have the same number of fields as the header.');
      return Object.fromEntries(headers.map((header, index) => [header, values[index].trim()]));
    });
  };

  router.post('/pilot/whatif', wrap(async (db, u, req) => {
    role(u, 'learner');
    enforceWhatIfRateLimit(u.personId);
    const p = requirePilot(), institutionCode = String(req.body.institutionCode || '').toLowerCase(), programmeCode = String(req.body.programmeCode || '').toLowerCase();
    if (!pilotCodes.has(institutionCode)) throw bad('Choose WSU, UFH or UJ.');
    const verification = (await p.list('ScoringPolicyVerification', { InstitutionCode: institutionCode, ProgrammeCode: programmeCode, IntakeYear: 2027 })).find((row) => row.VerificationStatus === 'verified' && row.Enabled);
    if (!verification) throw bad('This programme is not yet verified for the pilot, so a reliable What-If result cannot be calculated.', 409);
    const prov = verification.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: verification.ProvenanceId }))[0] : null;
    const src = prov ? (await p.list('Source', { SourceId: prov.SourceId }))[0] : null;
    const verified = prov && src ? withProvenance({}, { source: { title: src.SourceTitle, url: src.SourceUrl, year: Number(src.DocumentYear), pageRef: src.PageRef }, lastUpdated: prov.LastUpdatedOn, conditions: parseConditions(prov.Conditions), status: prov.Status }, { freshnessDays: pilotConfig.freshnessDays.programme }) : null;
    if (verified?.kind !== 'recommendation') throw bad('This programme source is stale or incomplete. Verify it with the institution.', 409);
    const accuracy = await goldenAccuracyGate(institutionCode, programmeCode);
    if (!accuracy.ready) throw bad(`What-If is unavailable until the exact source-backed golden suite passes: ${accuracy.reason}`, 409);
    const exam = req.body.examTypeId ? await one(db, 'EXAM_TYPES', { EXAM_TYPE_ID: id(req.body.examTypeId) }) : (await db.list('EXAM_TYPES')).find((row) => /Grade 11 Final/i.test(row.EXAM_TYPE_NAME));
    if (!exam) throw bad('A Grade 11 final result set is required for the What-If simulator.', 409);
    const original = await results(db, u.recordId, exam.EXAM_TYPE_ID);
    if (!original.length) throw bad('Save your marks first, then return to the What-If simulator.', 409);
    const catalog = await db.list('SUBJECTS');
    const hypothetical = original.map((row) => ({ ...row, SUBJECT_CODE: String(row.SUBJECT_CODE).toUpperCase() }));
    const changes = Array.isArray(req.body.changes) ? req.body.changes : [];
    if (changes.length > 20) throw bad('Change no more than 20 subjects at a time.');
    for (const change of changes) {
      if (change.fromSubjectCode) {
        const from = String(change.fromSubjectCode).toUpperCase(), to = String(change.toSubjectCode || '').toUpperCase();
        const index = hypothetical.findIndex((row) => row.SUBJECT_CODE === from);
        if (index < 0) throw bad(`Subject ${from} is not in your saved profile.`);
        const replacement = catalog.find((row) => String(row.SUBJECT_CODE).toUpperCase() === to);
        if (!replacement) throw bad('Replacement subject is not in the current subject catalogue.');
        const mark = change.percentage == null ? hypothetical[index].PERCENTAGE : Number(change.percentage);
        if (!Number.isFinite(mark) || mark < 0 || mark > 100) throw bad('Hypothetical marks must be percentages from 0 to 100.');
        hypothetical.splice(index, 1, { ...replacement, PERCENTAGE: mark });
      } else {
        const code = String(change.subjectCode || '').toUpperCase(), index = hypothetical.findIndex((row) => row.SUBJECT_CODE === code);
        const mark = Number(change.percentage);
        if (index < 0) throw bad(`Subject ${code || '(blank)'} is not in your saved profile.`);
        if (!Number.isFinite(mark) || mark < 0 || mark > 100) throw bad('Hypothetical marks must be percentages from 0 to 100.');
        hypothetical[index] = { ...hypothetical[index], PERCENTAGE: mark };
      }
    }
    const config = { ...parsedJson(verification.RequirementJson, {}), status: 'verified', intake: 2027, allowPilotYear: true, source: src.SourceUrl };
    const result = runWhatIf(original, hypothetical, null, config);
    const guard = unsuitableApplicationReason(hypothetical, config);
    result.guard = guard ? { reason: guard, acknowledgementRequired: true } : null;
    result.programme = { institutionCode, institution: pilotNames[institutionCode], programmeCode };
    result.provenance = { source: { title: src.SourceTitle, url: src.SourceUrl, year: Number(src.DocumentYear), pageRef: src.PageRef }, lastUpdated: prov.LastUpdatedOn, conditions: parseConditions(prov.Conditions) };
    if (guard) await recordPilotEvent(u, 'whatif-guard', { institutionCode, programmeCode, reasonCode: 'subject-requirement' });
    return result;
  }));

  router.post('/admin/import/pilot-programmes', wrap(async (db, u, req) => {
    role(u, 'admin');
    const p = requirePilot(), rows = parseCsv(req.body.csv), dryRun = req.body.dryRun !== false;
    const expected = ['InstitutionCode','ProgrammeCode','ProgrammeName','IntakeYear','SourceTitle','SourceUrl','DocumentYear','PageRef','RetrievedOn','LastUpdatedOn','Conditions','RequirementJson','ContentHash','ArchivedCopyPath','Reviewer1','Reviewer2','Status'];
    if (!rows.length) return { dryRun, diff: [], message: 'CSV contains no programme rows.' };
    if (expected.some((field) => !Object.hasOwn(rows[0], field))) throw bad('CSV headers must match database/import/pilot-programmes.template.csv.');
    const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
    const seen = new Set(), review = [];
    for (const row of rows) {
      const institutionCode = row.InstitutionCode.toLowerCase(), programmeCode = row.ProgrammeCode.toLowerCase();
      if (!pilotCodes.has(institutionCode)) throw bad(`Unsupported institution code: ${row.InstitutionCode || '(blank)'}.`);
      if (!/^[a-z0-9][a-z0-9._-]{1,99}$/.test(programmeCode)) throw bad('Every row must have a valid ProgrammeCode.');
      const key = `${institutionCode}|${programmeCode}`;
      if (seen.has(key)) throw bad(`CSV contains duplicate programme row ${institutionCode}/${programmeCode}.`);
      seen.add(key);
      if (Number(row.IntakeYear) !== 2027) throw bad('Only undergraduate 2027 intake can be imported in this pilot.');
      if (!row.SourceTitle?.trim() || !/^https:\/\//i.test(row.SourceUrl || '') || !row.PageRef?.trim() || !validDate(row.RetrievedOn) || !validDate(row.LastUpdatedOn)) throw bad(`Each row for ${programmeCode} needs a source title, HTTPS URL, page reference and valid retrieval/update dates.`);
      const documentYear = Number(row.DocumentYear);
      if (!Number.isInteger(documentYear) || documentYear < 2000 || documentYear > 2100) throw bad(`Invalid DocumentYear for ${programmeCode}.`);
      const conditions = String(row.Conditions || '').split('|').map((x) => x.trim()).filter(Boolean);
      if (!conditions.length) throw bad(`At least one published condition is required for ${programmeCode}.`);
      if (!/^[a-f0-9]{64}$/i.test(row.ContentHash || '') || !/^evidence\/[a-zA-Z0-9._-]+\.pdf$/.test(row.ArchivedCopyPath || '')) throw bad(`Each row for ${programmeCode} needs an uploaded archived PDF path and SHA-256 hash.`);
      let requirement; try { requirement = JSON.parse(row.RequirementJson); } catch { throw bad(`Invalid RequirementJson for ${programmeCode}.`); }
      if (!requirement || typeof requirement !== 'object' || Array.isArray(requirement) || !Object.keys(requirement).length) throw bad(`Missing sourced requirement rules for ${programmeCode}.`);
      const dir = fileURLToPath(new URL('../.data/evidence/', import.meta.url));
      let evidence; try { evidence = await readFile(resolvePath(dir, basename(row.ArchivedCopyPath))); } catch { throw bad(`Archived source PDF is missing for ${programmeCode}; upload it before importing.`); }
      if (createHash('sha256').update(evidence).digest('hex') !== row.ContentHash.toLowerCase()) throw bad(`Evidence hash mismatch for ${programmeCode}.`);
      const existing = (await p.list('ScoringPolicyVerification', { InstitutionCode: institutionCode, ProgrammeCode: programmeCode, IntakeYear: 2027 }))[0];
      const provenance = existing?.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: existing.ProvenanceId }))[0] : null;
      const source = provenance?.SourceId ? (await p.list('Source', { SourceId: provenance.SourceId }))[0] : null;
      const unchanged = Boolean(existing && provenance && source
        && source.SourceTitle === row.SourceTitle && source.SourceUrl === row.SourceUrl
        && Number(source.DocumentYear) === documentYear && source.PageRef === row.PageRef
        && dateOnly(source.RetrievedOn) === row.RetrievedOn
        && String(source.ContentHash).toLowerCase() === row.ContentHash.toLowerCase()
        && source.ArchivedCopyPath === row.ArchivedCopyPath
        && dateOnly(provenance.LastUpdatedOn) === row.LastUpdatedOn
        && canonicalJson(parseConditions(provenance.Conditions)) === canonicalJson(conditions)
        && canonicalJson(parsedJson(provenance.RequirementJson, {})) === canonicalJson(requirement)
        && canonicalJson(parsedJson(existing.RequirementJson, {})) === canonicalJson(requirement));
      review.push({ institutionCode, programmeCode, action: unchanged ? 'unchanged' : existing ? 'update draft (reapproval required)' : 'create draft', status: unchanged ? existing.VerificationStatus : 'draft', sourceTitle: row.SourceTitle, existingVerificationId: existing?.VerificationId || null, unchanged });
    }
    if (dryRun) return { dryRun: true, diff: review, message: 'Dry run only. No rows were written. Rows marked unchanged will not be modified on apply.' };
    const created = await p.tx(async (tx) => {
      const out = [];
      for (let i = 0; i < rows.length; i += 1) {
        const row = rows[i], change = review[i];
        if (change.unchanged) { out.push({ institutionCode: change.institutionCode, programmeCode: change.programmeCode, status: change.status, action: 'unchanged' }); continue; }
        const existing = (await tx.list('ScoringPolicyVerification', { InstitutionCode: change.institutionCode, ProgrammeCode: change.programmeCode, IntakeYear: 2027 }))[0];
        let source, provenance;
        if (existing?.ProvenanceId) {
          const previous = (await tx.list('RequirementProvenance', { ProvenanceId: existing.ProvenanceId }))[0];
          source = previous ? (await tx.list('Source', { SourceId: previous.SourceId }))[0] : null;
          if (source) await tx.update('Source', { SourceId: source.SourceId }, { SourceTitle: row.SourceTitle, SourceUrl: row.SourceUrl, DocumentYear: Number(row.DocumentYear), PageRef: row.PageRef, RetrievedOn: row.RetrievedOn, ContentHash: row.ContentHash.toLowerCase(), ArchivedCopyPath: row.ArchivedCopyPath, SourceType: 'institution' });
          else source = await tx.insert('Source', { SourceTitle: row.SourceTitle, SourceUrl: row.SourceUrl, DocumentYear: Number(row.DocumentYear), PageRef: row.PageRef, RetrievedOn: row.RetrievedOn, ContentHash: row.ContentHash.toLowerCase(), ArchivedCopyPath: row.ArchivedCopyPath, SourceType: 'institution' });
          provenance = previous;
          if (provenance) await tx.update('RequirementProvenance', { ProvenanceId: provenance.ProvenanceId }, { SourceId: source.SourceId, RequirementJson: JSON.stringify(JSON.parse(row.RequirementJson)), LastUpdatedOn: row.LastUpdatedOn, Conditions: JSON.stringify(String(row.Conditions).split('|').map((x) => x.trim()).filter(Boolean)), Status: 'draft', ModifiedAt: now() });
        } else {
          source = await tx.insert('Source', { SourceTitle: row.SourceTitle, SourceUrl: row.SourceUrl, DocumentYear: Number(row.DocumentYear), PageRef: row.PageRef, RetrievedOn: row.RetrievedOn, ContentHash: row.ContentHash.toLowerCase(), ArchivedCopyPath: row.ArchivedCopyPath, SourceType: 'institution' });
          provenance = await tx.insert('RequirementProvenance', { InstitutionCode: change.institutionCode, ProgrammeCode: change.programmeCode, SourceId: source.SourceId, RequirementJson: JSON.stringify(JSON.parse(row.RequirementJson)), LastUpdatedOn: row.LastUpdatedOn, Conditions: JSON.stringify(String(row.Conditions).split('|').map((x) => x.trim()).filter(Boolean)), Status: 'draft', CreatedByPersonId: u.personId });
        }
        if (existing) {
          // An evidence/rule change invalidates the approvals tied to the previous evidence.
          await tx.remove('VerificationSignoff', { VerificationId: existing.VerificationId });
          await tx.update('ScoringPolicyVerification', { VerificationId: existing.VerificationId }, { ProvenanceId: provenance?.ProvenanceId || null, RequirementJson: JSON.stringify(JSON.parse(row.RequirementJson)), VerificationStatus: 'draft', Enabled: 0, ModifiedAt: now() });
        } else await tx.insert('ScoringPolicyVerification', { InstitutionCode: change.institutionCode, ProgrammeCode: change.programmeCode, IntakeYear: 2027, VerificationStatus: 'draft', ProvenanceId: provenance.ProvenanceId, RequirementJson: JSON.stringify(JSON.parse(row.RequirementJson)), Enabled: 0 });
        out.push({ institutionCode: change.institutionCode, programmeCode: change.programmeCode, status: 'draft', action: change.action });
      }
      return out;
    });
    await audit(db, u.personId, 'pilot.programmes.imported', { count: created.filter((row) => row.action !== 'unchanged').length });
    return { dryRun: false, imported: created, message: 'Imported or updated draft rules. Unchanged rows were left untouched; changed rules require two fresh approvals and a passing golden accuracy gate. CSV reviewer/status fields never count as real approvals.' };
  }));

  router.post('/admin/import/funding', wrap(async (db, u, req) => {
    role(u, 'admin');
    const p = requirePilot(), rows = parseCsv(req.body.csv), dryRun = req.body.dryRun !== false;
    const expected = ['FunderName','FunderType','OpportunityTitle','SourceTitle','SourceUrl','SourceYear','LastUpdatedOn','ApplicationOpens','ApplicationCloses','Conditions','PostgraduateOnly','RequiredDocumentsJson','CriteriaJson','Status'];
    if (!rows.length) return { dryRun, diff: [], message: 'CSV contains no funding records.' };
    if (expected.some((field) => !Object.hasOwn(rows[0], field))) throw bad('CSV headers must match database/import/funding.template.csv (including CriteriaJson).');
    const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
    const seen = new Set(), plan = [];
    for (const row of rows) {
      if (!row.FunderName?.trim() || !row.OpportunityTitle?.trim() || !row.SourceTitle?.trim() || !/^https:\/\//i.test(row.SourceUrl || '') || !validDate(row.LastUpdatedOn) || !row.Conditions?.trim()) throw bad('Funding CSV row is missing a source, valid last-updated date or conditions.');
      const key = `${row.FunderName.trim().toLowerCase()}|${row.OpportunityTitle.trim().toLowerCase()}`;
      if (seen.has(key)) throw bad(`Funding CSV contains duplicate opportunity ${row.OpportunityTitle}.`);
      seen.add(key);
      if (row.SourceYear && (!Number.isInteger(Number(row.SourceYear)) || Number(row.SourceYear) < 2000 || Number(row.SourceYear) > 2100)) throw bad('SourceYear must be a four-digit year when supplied.');
      if (row.ApplicationOpens && !validDate(row.ApplicationOpens)) throw bad(`Invalid opening date for ${row.OpportunityTitle}.`);
      if (row.ApplicationCloses && !validDate(row.ApplicationCloses)) throw bad(`Invalid closing date for ${row.OpportunityTitle}.`);
      if (row.ApplicationOpens && row.ApplicationCloses && row.ApplicationCloses < row.ApplicationOpens) throw bad('Funding closing date cannot be earlier than opening date.');
      const criteria = parsedJson(row.CriteriaJson, null);
      const docs = parsedJson(row.RequiredDocumentsJson || '[]', []);
      if (!Array.isArray(criteria) || !criteria.length) throw bad('Each funding row requires CriteriaJson as a non-empty JSON array from a published source.');
      if (!Array.isArray(docs)) throw bad('RequiredDocumentsJson must be an array.');
      for (const criterion of criteria) if (!['academicAverage','fieldOfStudy','province','citizenship','householdIncomeBand','yearOfStudy'].includes(criterion.field) || !['eq','lte','gte','in'].includes(criterion.operator) || !Object.hasOwn(criterion, 'value')) throw bad('Funding CSV contains an unsupported or incomplete criterion.');
      for (const doc of docs) {
        const label = typeof doc === 'string' ? doc : doc?.label;
        if (typeof label !== 'string' || !label.trim()) throw bad('Every required funding document must have a label.');
        if (typeof doc === 'object' && doc.url && !/^https:\/\//i.test(doc.url)) throw bad('Funding document guidance URLs must use HTTPS.');
      }
      const funders = await p.list('Funder');
      const existingFunder = funders.find((f) => f.FunderName.toLowerCase() === row.FunderName.toLowerCase());
      const existingOpportunity = existingFunder ? (await p.list('FundingOpportunity', { FunderId: existingFunder.FunderId })).find((o) => o.OpportunityTitle.toLowerCase() === row.OpportunityTitle.toLowerCase()) : null;
      let unchanged = false;
      if (existingOpportunity) {
        const existingCriteria = await p.list('FundingCriterion', { OpportunityId: existingOpportunity.OpportunityId });
        const existingDocs = await p.list('FundingDocumentRequirement', { OpportunityId: existingOpportunity.OpportunityId });
        const normalizedCriteria = (items) => items.map((item) => ({ field: item.field ?? item.FieldName, operator: item.operator ?? item.Operator, value: canonicalJson(item.value ?? parsedJson(item.CriterionValue, null)), label: item.label ?? item.CriterionLabel ?? item.field ?? item.FieldName })).sort((a,b) => String(a.field).localeCompare(String(b.field)) || String(a.operator).localeCompare(String(b.operator)));
        const normalizedDocs = (items) => items.map((item) => ({ label: typeof item === 'string' ? item : item.label ?? item.DocumentLabel, mandatory: typeof item === 'string' ? true : item.mandatory !== undefined ? item.mandatory !== false : item.IsMandatory !== undefined ? Boolean(item.IsMandatory) : true, url: typeof item === 'string' ? null : item.url ?? item.GuidanceUrl ?? null })).sort((a,b) => String(a.label).localeCompare(String(b.label)));
        unchanged = existingOpportunity.SourceUrl === row.SourceUrl && existingOpportunity.SourceTitle === row.SourceTitle && Number(existingOpportunity.SourceYear || 0) === Number(row.SourceYear || 0)
          && dateOnly(existingOpportunity.LastUpdatedOn) === row.LastUpdatedOn && String(existingOpportunity.Conditions) === row.Conditions
          && dateOnly(existingOpportunity.ApplicationOpens) === (row.ApplicationOpens || '') && dateOnly(existingOpportunity.ApplicationCloses) === (row.ApplicationCloses || '')
          && Boolean(existingOpportunity.PostgraduateOnly) === /^(1|true|yes)$/i.test(row.PostgraduateOnly)
          && canonicalJson(normalizedCriteria(criteria)) === canonicalJson(normalizedCriteria(existingCriteria))
          && canonicalJson(normalizedDocs(docs)) === canonicalJson(normalizedDocs(existingDocs));
      }
      plan.push({ title: row.OpportunityTitle, funder: row.FunderName, action: unchanged ? 'unchanged' : existingOpportunity ? 'update draft (reverification required)' : 'create draft', status: unchanged ? existingOpportunity.Status : 'draft', existingOpportunityId: existingOpportunity?.OpportunityId || null, unchanged });
    }
    if (dryRun) return { dryRun: true, diff: plan, message: 'Dry run only. No funding rows were written. Unchanged rows will be left as-is on apply.' };
    const imported = await p.tx(async (tx) => {
      const out = [];
      for (let index = 0; index < rows.length; index += 1) {
        const row = rows[index], review = plan[index];
        if (review.unchanged) { out.push({ opportunityId: review.existingOpportunityId, title: row.OpportunityTitle, status: review.status, action: 'unchanged' }); continue; }
        let funder = (await tx.list('Funder')).find((f) => f.FunderName.toLowerCase() === row.FunderName.toLowerCase());
        if (!funder) funder = await tx.insert('Funder', { FunderName: row.FunderName, FunderType: row.FunderType || 'other', WebsiteUrl: row.SourceUrl, Status: 'draft' });
        else if (funder.FunderType !== row.FunderType && row.FunderType) await tx.update('Funder', { FunderId: funder.FunderId }, { FunderType: row.FunderType, WebsiteUrl: row.SourceUrl, Status: 'draft' });
        const docs = parsedJson(row.RequiredDocumentsJson || '[]', []);
        let opportunity = (await tx.list('FundingOpportunity', { FunderId: funder.FunderId })).find((o) => o.OpportunityTitle.toLowerCase() === row.OpportunityTitle.toLowerCase());
        const opportunityData = { FunderId: funder.FunderId, OpportunityTitle: row.OpportunityTitle, SourceUrl: row.SourceUrl, SourceTitle: row.SourceTitle, SourceYear: Number(row.SourceYear) || null, LastUpdatedOn: row.LastUpdatedOn, Conditions: row.Conditions, ApplicationOpens: row.ApplicationOpens || null, ApplicationCloses: row.ApplicationCloses || null, Status: 'draft', PostgraduateOnly: /^(1|true|yes)$/i.test(row.PostgraduateOnly), RequiredDocumentsJson: JSON.stringify(docs), ModifiedAt: now() };
        if (opportunity) {
          await tx.update('FundingOpportunity', { OpportunityId: opportunity.OpportunityId }, opportunityData);
          await tx.remove('FundingCriterion', { OpportunityId: opportunity.OpportunityId });
          await tx.remove('FundingDocumentRequirement', { OpportunityId: opportunity.OpportunityId });
          opportunity = { ...opportunity, ...opportunityData };
        } else opportunity = await tx.insert('FundingOpportunity', { ...opportunityData, CreatedAt: now() });
        for (const c of parsedJson(row.CriteriaJson, [])) await tx.insert('FundingCriterion', { OpportunityId: opportunity.OpportunityId, FieldName: c.field, Operator: c.operator, CriterionValue: JSON.stringify(c.value), CriterionLabel: String(c.label || c.field).slice(0, 250) });
        for (const d of docs) await tx.insert('FundingDocumentRequirement', { OpportunityId: opportunity.OpportunityId, DocumentLabel: text(typeof d === 'string' ? d : d.label, 250), IsMandatory: typeof d === 'object' ? d.mandatory !== false : true, GuidanceUrl: typeof d === 'object' ? d.url || null : null });
        out.push({ opportunityId: opportunity.OpportunityId, title: opportunity.OpportunityTitle, status: 'draft', action: review.action });
      }
      return out;
    });
    await audit(db, u.personId, 'funding.imported', { count: imported.filter((row) => row.action !== 'unchanged').length });
    return { imported, message: 'Imported or updated funding opportunities as drafts. Unchanged rows were not modified, and CSV status values never bypass administrator verification.' };
  }));

  router.post('/deadline-alerts/schedule', wrap(async (db, u, req) => {
    role(u, 'learner'); const p = requirePilot(), itemType = req.body.itemType, itemId = id(req.body.itemId);
    if (!['programme', 'funding'].includes(itemType)) throw bad('Choose programme or funding.');
    let closingDate, sourceUrl, itemName;
    if (itemType === 'funding') {
      const opportunity = (await p.list('FundingOpportunity', { OpportunityId: itemId }))[0];
      if (!opportunity || !isFundingOpportunityActionable(opportunity)) throw bad('Only current, verified funding opportunities can have deadline alerts.', 409);
      closingDate = opportunity.ApplicationCloses; sourceUrl = opportunity.SourceUrl; itemName = opportunity.OpportunityTitle;
    } else {
      const verification = (await p.list('ScoringPolicyVerification', { VerificationId: itemId }))[0];
      if (!verification || verification.VerificationStatus !== 'verified' || !verification.Enabled) throw bad('Only verified programmes can have deadline alerts.', 409);
      const config = parsedJson(verification.RequirementJson, {}); closingDate = config.applicationCloses || config.closingDate;
      const provenance = verification.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: verification.ProvenanceId }))[0] : null;
      const src = provenance ? (await p.list('Source', { SourceId: provenance.SourceId }))[0] : null; sourceUrl = src?.SourceUrl; itemName = verification.ProgrammeCode;
    }
    if (!closingDate || !/^\d{4}-\d{2}-\d{2}/.test(String(closingDate))) throw bad('The source does not publish a usable closing date; no alert can be scheduled.');
    const todayDate = today(), days = Math.floor((Date.parse(String(closingDate).slice(0,10)) - Date.parse(todayDate)) / 86400000);
    if (days < 1) throw bad('The closing date has passed or is today. Verify directly with the institution.');
    const emailConsent = await pilotConsent(u, 'email-reminders'), made = [];
    for (const daysBefore of [14,7,3,1]) {
      if (days < daysBefore) continue;
      for (const channel of emailConsent ? ['in-app','email'] : ['in-app']) {
        const where = { PersonId: u.personId, ItemType: itemType, ItemId: itemId, DaysBefore: daysBefore, Channel: channel };
        if ((await p.list('DeadlineAlert', where)).length) continue;
        try { const row = await p.insert('DeadlineAlert', { ...where, ClosingDate: String(closingDate).slice(0,10), Status: 'pending' }); made.push(row.AlertId); } catch (error) { if (!/unique|constraint/i.test(error.message)) throw error; }
      }
    }
    const checklist = itemType === 'funding' ? await p.list('FundingDocumentRequirement', { OpportunityId: itemId }) : [];
    for (const document of checklist) {
      if (!(await p.list('ChecklistItem', { PersonId: u.personId, ItemType: itemType, ItemId: itemId, DocumentLabel: document.DocumentLabel })).length)
        await p.insert('ChecklistItem', { PersonId: u.personId, ItemType: itemType, ItemId: itemId, DocumentLabel: document.DocumentLabel, Status: 'missing', DueDate: String(closingDate).slice(0,10) });
    }
    await audit(db, u.personId, 'deadline.alerts.scheduled', { itemType, itemId, alertCount: made.length });
    return { alertIds: made, message: `${made.length} reminder records created for ${itemName}. ${emailConsent ? 'Email reminders are enabled by your consent.' : 'Only in-app reminders were created because email reminder consent is not enabled.'}`, sourceUrl };
  }));

  router.post('/privacy/delete-request/cancel', wrap(async (db, u) => {
    const p = requirePilot(), requests = (await p.list('DataSubjectRequest', { PersonId: u.personId, RequestType: 'delete', Status: 'scheduled' })).filter((row) => row.ScheduledFor && Date.parse(row.ScheduledFor) > Date.now());
    if (!requests.length) throw bad('No cancellable deletion request was found.', 404);
    for (const row of requests) await p.update('DataSubjectRequest', { RequestId: row.RequestId }, { Status: 'cancelled', Notes: 'Cancelled by the learner during the cooling-off period.' });
    await audit(db, u.personId, 'privacy.delete.cancelled', { count: requests.length });
    return { message: 'Deletion request cancelled during the cooling-off period.' };
  }));


  router.get('/admin/verification', wrap(async (db, u) => {
    role(u, 'admin');
    const p = requirePilot(), rows = await p.list('ScoringPolicyVerification'), output = [];
    for (const v of rows) {
      const provenance = v.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: v.ProvenanceId }))[0] : null;
      const source = provenance ? (await p.list('Source', { SourceId: provenance.SourceId }))[0] : null;
      const signoffs = await p.list('VerificationSignoff', { VerificationId: v.VerificationId });
      output.push({ ...v, requirement: parsedJson(v.RequirementJson, {}), provenance, source, accuracy: await goldenAccuracyGate(v.InstitutionCode, v.ProgrammeCode), signoffs: signoffs.map(({ ReviewerPersonId, ReviewerRole, Decision, Notes, SignedAt }) => ({ ReviewerPersonId, ReviewerRole, Decision, Notes, SignedAt })) });
    }
    return { verifications: output, institutions: pilotConfig.pilotInstitutions.map((code) => ({ code, name: pilotNames[code] })) };
  }));

  router.post('/admin/verification', wrap(async (db, u, req) => {
    role(u, 'admin', 'representative');
    const p = requirePilot(), b = req.body;
    const institutionCode = text(b.institutionCode, 20).toLowerCase();
    if (!pilotCodes.has(institutionCode)) throw bad('Only WSU, UFH and UJ are in the current learner pilot.');
    if (u.role === 'representative') {
      const university = await one(db, 'UNIVERSITIES', { UNIVERSITY_ID: u.universityId });
      if (institutionCodeFor(university.UNIVERSITY_NAME) !== institutionCode) throw bad('Representatives may only propose rules for their own institution.', 403);
    }
    const programmeCode = text(b.programmeCode, 100).toLowerCase();
    if (!/^[a-z0-9][a-z0-9._-]{1,99}$/.test(programmeCode)) throw bad('Programme code may contain letters, numbers, dots, underscores and hyphens.');
    if (Number(b.intakeYear) !== 2027) throw bad('The initial StudyPath pilot covers undergraduate 2027 entry only.');
    const sourceUrl = text(b.sourceUrl, 2048); if (!/^https:\/\//i.test(sourceUrl)) throw bad('Source URL must use HTTPS.');
    const sourceTitle = text(b.sourceTitle, 300), pageRef = text(b.pageRef, 100), contentHash = text(b.contentHash, 64).toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(contentHash)) throw bad('Evidence content hash must be a SHA-256 hex digest.');
    const archivedCopyPath = text(b.archivedCopyPath, 500);
    if (!/^evidence\/[a-zA-Z0-9._-]+\.pdf$/.test(archivedCopyPath)) throw bad('Use the evidence archive path returned by the PDF upload.');
    const retrievedOn = text(b.retrievedOn, 10), lastUpdatedOn = text(b.lastUpdatedOn, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(retrievedOn) || !/^\d{4}-\d{2}-\d{2}$/.test(lastUpdatedOn)) throw bad('Supply source retrieval and last-updated dates as YYYY-MM-DD.');
    const requirement = b.requirement;
    if (!requirement || typeof requirement !== 'object' || Array.isArray(requirement) || !Object.keys(requirement).length) throw bad('A sourced programme requirement object is required.');
    const conditions = Array.isArray(b.conditions) ? b.conditions.map((x) => text(x, 500)) : [];
    if (!conditions.length) throw bad('At least one published condition is required.');
    const documentYear = Number(b.documentYear);
    if (!Number.isInteger(documentYear) || documentYear < 2000 || documentYear > 2100) throw bad('Document year must be a four-digit year between 2000 and 2100.');
    const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
    if (!validDate(retrievedOn) || !validDate(lastUpdatedOn)) throw bad('Retrieval and last-updated dates must be real calendar dates in YYYY-MM-DD format.');
    const path = fileURLToPath(new URL('../.data/evidence/', import.meta.url));
    let evidence;
    try { evidence = await readFile(resolvePath(path, basename(archivedCopyPath))); } catch { throw bad('Archived PDF is missing from the server evidence directory. Upload it again.'); }
    if (createHash('sha256').update(evidence).digest('hex') !== contentHash) throw bad('Archived evidence hash does not match the uploaded file.');
    return p.tx(async (tx) => {
      let verification = (await tx.list('ScoringPolicyVerification', { InstitutionCode: institutionCode, ProgrammeCode: programmeCode, IntakeYear: 2027 }))[0];
      let provenance = verification?.ProvenanceId ? (await tx.list('RequirementProvenance', { ProvenanceId: verification.ProvenanceId }))[0] : null;
      let source = provenance?.SourceId ? (await tx.list('Source', { SourceId: provenance.SourceId }))[0] : null;
      if (source) await tx.update('Source', { SourceId: source.SourceId }, { SourceTitle: sourceTitle, SourceUrl: sourceUrl, DocumentYear: documentYear, PageRef: pageRef, RetrievedOn: retrievedOn, ContentHash: contentHash, ArchivedCopyPath: archivedCopyPath, SourceType: 'institution' });
      else source = await tx.insert('Source', { SourceTitle: sourceTitle, SourceUrl: sourceUrl, DocumentYear: documentYear, PageRef: pageRef, RetrievedOn: retrievedOn, ContentHash: contentHash, ArchivedCopyPath: archivedCopyPath, SourceType: 'institution' });
      if (provenance) await tx.update('RequirementProvenance', { ProvenanceId: provenance.ProvenanceId }, { SourceId: source.SourceId, RequirementJson: JSON.stringify(requirement), LastUpdatedOn: lastUpdatedOn, Conditions: JSON.stringify(conditions), Status: 'draft', ModifiedAt: now() });
      else provenance = await tx.insert('RequirementProvenance', { InstitutionCode: institutionCode, ProgrammeCode: programmeCode, SourceId: source.SourceId, RequirementJson: JSON.stringify(requirement), LastUpdatedOn: lastUpdatedOn, Conditions: JSON.stringify(conditions), Status: 'draft', CreatedByPersonId: u.personId });
      if (verification) {
        // A changed rule/source invalidates all prior approvals; sign-offs belong to this exact evidence version.
        await tx.remove('VerificationSignoff', { VerificationId: verification.VerificationId });
        await tx.update('ScoringPolicyVerification', { VerificationId: verification.VerificationId }, { ProvenanceId: provenance.ProvenanceId, RequirementJson: JSON.stringify(requirement), VerificationStatus: 'draft', Enabled: 0, ModifiedAt: now() });
      } else verification = await tx.insert('ScoringPolicyVerification', { InstitutionCode: institutionCode, ProgrammeCode: programmeCode, IntakeYear: 2027, VerificationStatus: 'draft', ProvenanceId: provenance.ProvenanceId, RequirementJson: JSON.stringify(requirement), Enabled: 0 });
      await audit(db, u.personId, 'pilot.verification.proposed', { institutionCode, programmeCode, verificationId: verification.VerificationId });
      return { verificationId: verification.VerificationId, status: 'draft', message: 'Submitted as a draft. Two independent administrator approvals are required before learner recommendations are enabled.' };
    });
  }));

  router.post('/admin/verification/:id/signoff', wrap(async (db, u, req) => {
    role(u, 'admin');
    const p = requirePilot(), verificationId = id(req.params.id), decision = req.body.decision;
    if (!['approve', 'reject'].includes(decision)) throw bad('Decision must be approve or reject.');
    const verification = (await p.list('ScoringPolicyVerification', { VerificationId: verificationId }))[0];
    if (!verification || !pilotCodes.has(verification.InstitutionCode)) throw bad('Verification record not found.', 404);
    const prov = verification.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: verification.ProvenanceId }))[0] : null;
    const src = prov ? (await p.list('Source', { SourceId: prov.SourceId }))[0] : null;
    if (decision === 'approve') {
      if (!src?.SourceUrl?.startsWith('https://') || !src.ContentHash || !src.ArchivedCopyPath || !prov?.LastUpdatedOn || !parseConditions(prov?.Conditions).length || !parsedJson(verification.RequirementJson, null)) throw bad('Cannot approve: provenance is incomplete.');
      const dir = fileURLToPath(new URL('../.data/evidence/', import.meta.url));
      let archive; try { archive = await readFile(resolvePath(dir, basename(src.ArchivedCopyPath))); } catch { throw bad('Archived source evidence is missing.'); }
      if (createHash('sha256').update(archive).digest('hex') !== src.ContentHash) throw bad('Archived source evidence failed its integrity check.');
    }
    const existing = await p.list('VerificationSignoff', { VerificationId: verificationId, ReviewerPersonId: u.personId });
    if (existing.length) throw bad('This administrator already signed off this programme. A second independent account is required.', 409);
    await p.insert('VerificationSignoff', { VerificationId: verificationId, ReviewerPersonId: u.personId, ReviewerRole: 'admin', Decision: decision, Notes: typeof req.body.notes === 'string' ? req.body.notes.trim().slice(0, 1000) : null });
    const approvals = (await p.list('VerificationSignoff', { VerificationId: verificationId })).filter((s) => s.Decision === 'approve');
    if (decision === 'reject') {
      await p.update('ScoringPolicyVerification', { VerificationId: verificationId }, { VerificationStatus: 'draft', Enabled: 0, ModifiedAt: now() });
      if (prov) await p.update('RequirementProvenance', { ProvenanceId: prov.ProvenanceId }, { Status: 'draft', ModifiedAt: now() });
    }
    const distinctApprovals = new Set(approvals.map((s) => String(s.ReviewerPersonId))).size;
    const accuracy = decision === 'approve' && distinctApprovals >= 2 ? await goldenAccuracyGate(verification.InstitutionCode, verification.ProgrammeCode) : { ready: false, reason: 'Two independent approvals are required.' };
    let activated = false;
    if (decision === 'approve' && distinctApprovals >= 2 && accuracy.ready) {
      await p.update('ScoringPolicyVerification', { VerificationId: verificationId }, { VerificationStatus: 'verified', Enabled: 1, ModifiedAt: now() });
      if (prov) await p.update('RequirementProvenance', { ProvenanceId: prov.ProvenanceId }, { Status: 'verified', ModifiedAt: now() });
      activated = true;
    }
    await audit(db, u.personId, 'pilot.verification.signoff', { verificationId, decision, approvalCount: approvals.length, accuracyReady: accuracy.ready });
    return { verificationId, approvalCount: distinctApprovals, accuracyReady: accuracy.ready, accuracyCases: accuracy.cases || 0, status: activated ? 'verified' : 'draft', message: activated ? 'Two independent approvals and the source-backed golden accuracy gate passed. The programme is enabled.' : distinctApprovals >= 2 ? `Approvals recorded, but the rule remains non-actionable: ${accuracy.reason || 'accuracy gate not passed'}` : 'Sign-off recorded; a second distinct administrator is required.' };
  }));

  router.post('/admin/verification/:id/activate', wrap(async (db, u, req) => {
    role(u, 'admin');
    const p = requirePilot(), verificationId = id(req.params.id);
    const verification = (await p.list('ScoringPolicyVerification', { VerificationId: verificationId }))[0];
    if (!verification || !pilotCodes.has(verification.InstitutionCode)) throw bad('Verification record not found.', 404);
    const signoffs = await p.list('VerificationSignoff', { VerificationId: verificationId });
    if (signoffs.some((row) => row.Decision === 'reject')) throw bad('This evidence version has a rejection sign-off. Submit the corrected source/rule as a new draft before activation.', 409);
    const approvals = signoffs.filter((row) => row.Decision === 'approve');
    if (new Set(approvals.map((row) => String(row.ReviewerPersonId))).size < 2) throw bad('Two distinct administrator approvals are required.', 409);
    const gate = await goldenAccuracyGate(verification.InstitutionCode, verification.ProgrammeCode);
    if (!gate.ready) throw bad(`Accuracy gate blocked (${gate.cases} programme cases): ${gate.reason}`, 409);
    const provenance = verification.ProvenanceId ? (await p.list('RequirementProvenance', { ProvenanceId: verification.ProvenanceId }))[0] : null;
    const source = provenance ? (await p.list('Source', { SourceId: provenance.SourceId }))[0] : null;
    if (!provenance || !source?.ArchivedCopyPath || !source.ContentHash) throw bad('Complete source provenance is required.', 409);
    const archivePath = fileURLToPath(new URL('../.data/evidence/', import.meta.url));
    let archive; try { archive = await readFile(resolvePath(archivePath, basename(source.ArchivedCopyPath))); } catch { throw bad('Archived source evidence is missing.', 409); }
    if (createHash('sha256').update(archive).digest('hex') !== source.ContentHash) throw bad('Archived source integrity check failed.', 409);
    await p.update('ScoringPolicyVerification', { VerificationId: verificationId }, { VerificationStatus: 'verified', Enabled: 1, ModifiedAt: now() });
    await p.update('RequirementProvenance', { ProvenanceId: provenance.ProvenanceId }, { Status: 'verified', ModifiedAt: now() });
    await audit(db, u.personId, 'pilot.verification.activated', { verificationId, accuracyCases: gate.cases });
    return { verificationId, status: 'verified', accuracyReady: true, accuracyCases: gate.cases, message: 'Programme enabled after source integrity, two independent approvals and exact golden accuracy checks.' };
  }));

  router.get('/funding/opportunities', wrap(async (db, u) => {
    role(u, 'learner');
    const p = requirePilot(), records = await p.list('FundingOpportunity'), results = [];
    for (const opportunity of records) {
      const funder = (await p.list('Funder', { FunderId: opportunity.FunderId }))[0];
      const current = isFundingOpportunityActionable(opportunity);
      if (!current) continue;
      const criteria = await p.list('FundingCriterion', { OpportunityId: opportunity.OpportunityId });
      const requirements = await p.list('FundingDocumentRequirement', { OpportunityId: opportunity.OpportunityId });
      results.push({ id: opportunity.OpportunityId, title: opportunity.OpportunityTitle, funder: funder?.FunderName || 'Funder', source: { title: opportunity.SourceTitle, url: opportunity.SourceUrl, year: opportunity.SourceYear || null }, lastUpdated: opportunity.LastUpdatedOn, deadline: opportunity.ApplicationCloses || null, opens: opportunity.ApplicationOpens || null, conditions: opportunity.Conditions, requiredDocuments: requirements.map((r) => ({ label: r.DocumentLabel, mandatory: Boolean(r.IsMandatory), link: '/learner/documents.html' })), criterionCount: criteria.length, note: DISCLAIMERS.funding });
    }
    return { opportunities: results, message: results.length ? null : 'No currently verified, in-date funding opportunities are available yet. Unverified and stale records are deliberately not presented as actionable recommendations.', disclaimer: DISCLAIMERS.funding };
  }));

  router.post('/admin/funding', wrap(async (db, u, req) => {
    role(u, 'admin');
    const p = requirePilot(), b = req.body;
    const requiredText = ['funderName', 'funderType', 'title', 'sourceTitle', 'sourceUrl', 'lastUpdatedOn', 'conditions'];
    for (const field of requiredText) text(b[field], field === 'sourceUrl' ? 2048 : 1000);
    if (!/^https:\/\//i.test(b.sourceUrl)) throw bad('Funding source URL must use HTTPS.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(b.lastUpdatedOn)) throw bad('Last-updated date must use YYYY-MM-DD.');
    if (b.applicationOpens && b.applicationCloses && b.applicationCloses < b.applicationOpens) throw bad('Closing date cannot be earlier than the opening date.');
    const criteria = Array.isArray(b.criteria) ? b.criteria : [];
    const allowedFields = new Set(['academicAverage', 'fieldOfStudy', 'province', 'citizenship', 'householdIncomeBand', 'yearOfStudy']);
    for (const c of criteria) if (!allowedFields.has(c.field) || !['eq', 'lte', 'gte', 'in'].includes(c.operator) || !Object.hasOwn(c, 'value')) throw bad('Funding criteria must use a supported profile field and comparison operator.');
    return p.tx(async (tx) => {
      let funder = (await tx.list('Funder')).find((row) => row.FunderName.toLowerCase() === b.funderName.trim().toLowerCase());
      if (!funder) funder = await tx.insert('Funder', { FunderName: text(b.funderName, 250), FunderType: text(b.funderType, 50), WebsiteUrl: b.funderWebsite || null, ContactUrl: b.contactUrl || null, Status: 'draft' });
      const opportunity = await tx.insert('FundingOpportunity', { FunderId: funder.FunderId, OpportunityTitle: text(b.title, 300), SourceUrl: text(b.sourceUrl, 2048), SourceTitle: text(b.sourceTitle, 300), SourceYear: Number.isInteger(Number(b.sourceYear)) ? Number(b.sourceYear) : null, LastUpdatedOn: b.lastUpdatedOn, Conditions: text(b.conditions, 4000), ApplicationOpens: b.applicationOpens || null, ApplicationCloses: b.applicationCloses || null, Status: 'draft', PostgraduateOnly: Boolean(b.postgraduateOnly), Province: b.province || null, StudyYear: b.studyYear || null, RequiredDocumentsJson: JSON.stringify(Array.isArray(b.requiredDocuments) ? b.requiredDocuments : []) });
      for (const c of criteria) await tx.insert('FundingCriterion', { OpportunityId: opportunity.OpportunityId, FieldName: c.field, Operator: c.operator, CriterionValue: JSON.stringify(c.value), CriterionLabel: typeof c.label === 'string' ? c.label.slice(0, 250) : c.field });
      for (const doc of Array.isArray(b.requiredDocuments) ? b.requiredDocuments : []) await tx.insert('FundingDocumentRequirement', { OpportunityId: opportunity.OpportunityId, DocumentLabel: text(doc.label || doc, 250), IsMandatory: doc.mandatory !== false, GuidanceUrl: doc.url || null });
      await audit(db, u.personId, 'funding.opportunity.draft', { opportunityId: opportunity.OpportunityId });
      return { opportunityId: opportunity.OpportunityId, status: 'draft', message: 'Saved as draft; it is not visible to learners until an administrator verifies source, dates, criteria and conditions.' };
    });
  }));

  router.get('/admin/funding', wrap(async (db, u) => {
    role(u, 'admin'); const p = requirePilot(), opportunities = await p.list('FundingOpportunity');
    return { opportunities: await Promise.all(opportunities.map(async (o) => ({ ...o, funder: (await p.list('Funder', { FunderId: o.FunderId }))[0]?.FunderName || null, criteria: (await p.list('FundingCriterion', { OpportunityId: o.OpportunityId })).map((c) => ({ ...c, value: parsedJson(c.CriterionValue, c.CriterionValue) })) }))) };
  }));

  router.post('/admin/funding/:id/verify', wrap(async (db, u, req) => {
    role(u, 'admin'); const p = requirePilot(), opportunityId = id(req.params.id);
    const item = (await p.list('FundingOpportunity', { OpportunityId: opportunityId }))[0];
    if (!item) throw bad('Funding opportunity not found.', 404);
    if (!item.SourceUrl?.startsWith('https://') || !item.SourceTitle || !item.LastUpdatedOn || !item.Conditions || !(await p.list('FundingCriterion', { OpportunityId: opportunityId })).length) throw bad('A funding record needs a source, last-updated date, conditions and at least one criterion before verification.');
    const funder = (await p.list('Funder', { FunderId: item.FunderId }))[0];
    await p.update('FundingOpportunity', { OpportunityId: opportunityId }, { Status: 'verified', ModifiedAt: now() });
    if (funder && funder.Status !== 'verified') await p.update('Funder', { FunderId: funder.FunderId }, { Status: 'verified' });
    await audit(db, u.personId, 'funding.opportunity.verified', { opportunityId });
    return { status: 'verified', message: 'Funding record verified. It will be demoted to stale after 90 days or hidden after its deadline.' };
  }));

  router.get('/funding/matches', wrap(async (db, u) => {
    role(u, 'learner'); const p = requirePilot();
    if (!pilotConfig.bursaryMatchingEnabled) return { matches: [], message: 'Funding matching is currently disabled.' };
    if (!(await pilotConsent(u, 'funding-matching'))) return { matches: [], consentRequired: true, message: 'Give funding-matching consent and complete age/guardian attestation in Privacy before funding data is unlocked.' };
    const encrypted = (await p.list('LearnerFinancialProfile', { PersonId: u.personId }))[0];
    if (!encrypted) return { matches: [], profileRequired: true, message: 'Save your minimum financial and study profile to compare it against sourced criteria.' };
    let profile; try { profile = JSON.parse(decryptDocument(encrypted.EncryptedPayload).toString('utf8')); } catch { throw bad('The encrypted funding profile could not be read. Contact the administrator.', 503); }
    const opportunities = await p.list('FundingOpportunity'), matches = [];
    for (const opportunity of opportunities) {
      if (!isFundingOpportunityActionable(opportunity)) continue;
      if (!pilotConfig.postgraduateEnabled && opportunity.PostgraduateOnly) continue;
      const criteria = (await p.list('FundingCriterion', { OpportunityId: opportunity.OpportunityId })).map((c) => ({ field: c.FieldName, operator: c.Operator, value: parsedJson(c.CriterionValue, c.CriterionValue), label: c.CriterionLabel }));
      const result = compareFundingCriteria(criteria, profile);
      const funder = (await p.list('Funder', { FunderId: opportunity.FunderId }))[0];
      const requirements = await p.list('FundingDocumentRequirement', { OpportunityId: opportunity.OpportunityId });
      matches.push({ id: opportunity.OpportunityId, title: opportunity.OpportunityTitle, funder: funder?.FunderName || 'Funder', ...result, source: { title: opportunity.SourceTitle, url: opportunity.SourceUrl, year: opportunity.SourceYear || null }, lastUpdated: opportunity.LastUpdatedOn, deadline: opportunity.ApplicationCloses || null, conditions: opportunity.Conditions, criteria, requiredDocuments: requirements.map((r) => ({ label: r.DocumentLabel, mandatory: Boolean(r.IsMandatory), link: '/learner/documents.html' })), disclaimer: DISCLAIMERS.funding });
    }
    return { matches, profileUpdatedAt: encrypted.UpdatedAt, disclaimer: DISCLAIMERS.funding };
  }));

  router.post('/funding/profile', wrap(async (db, u, req) => {
    role(u, 'learner'); const p = requirePilot(), b = req.body;
    if (!(await pilotConsent(u, 'funding-matching'))) throw bad('Funding-matching consent and age/guardian attestation are required first.', 403);
    const profile = {};
    for (const key of ['fieldOfStudy', 'province', 'citizenship', 'householdIncomeBand', 'yearOfStudy']) if (b[key] != null && b[key] !== '') {
      if (typeof b[key] !== 'string' || b[key].length > 120) throw bad('Profile values must be short text labels.');
      profile[key] = b[key].trim();
    }
    if (b.academicAverage != null && b.academicAverage !== '') {
      const average = Number(b.academicAverage); if (!Number.isFinite(average) || average < 0 || average > 100) throw bad('Academic average must be between 0 and 100.'); profile.academicAverage = average;
    }
    profile.disabilityOptIn = b.disabilityOptIn === true;
    if (profile.disabilityOptIn && typeof b.disabilityFlag === 'string') profile.disabilityFlag = b.disabilityFlag.slice(0, 80);
    const payload = encryptDocument(Buffer.from(JSON.stringify(profile)));
    const prior = (await p.list('LearnerFinancialProfile', { PersonId: u.personId }))[0];
    if (prior) await p.update('LearnerFinancialProfile', { PersonId: u.personId }, { EncryptedPayload: payload, KeyId: String(process.env.VAULT_KEY_ID || 'v1'), UpdatedAt: now() });
    else await p.insert('LearnerFinancialProfile', { PersonId: u.personId, EncryptedPayload: payload, KeyId: String(process.env.VAULT_KEY_ID || 'v1') });
    await audit(db, u.personId, 'funding.profile.saved', { fieldCount: Object.keys(profile).length, incomeBandProvided: Boolean(profile.householdIncomeBand) });
    return { message: 'Encrypted funding profile saved.', fieldCount: Object.keys(profile).length, disclaimer: 'Only the fields you entered are used for matching. Household income is stored as an encrypted band, not an exact amount.' };
  }));

  router.get('/credit-transfer/guidance', wrap(async (db, u) => {
    role(u, 'learner'); const p = requirePilot();
    if (!pilotConfig.creditTransferEnabled) return { guidance: [], message: 'Credit-transfer guidance is disabled.' };
    const all = await p.list('CreditTransferGuidance'), output = [];
    for (const row of all) {
      const src = (await p.list('Source', { SourceId: row.PolicySourceId }))[0];
      const result = withProvenance({ label: 'Indicative module alignment' }, { source: src ? { title: src.SourceTitle, url: src.SourceUrl, year: Number(src.DocumentYear), pageRef: src.PageRef } : null, lastUpdated: row.LastUpdatedOn, conditions: parseConditions(row.Conditions), status: row.Status }, { freshnessDays: 180 });
      output.push({ id: row.GuidanceId, institutionCode: row.ReceivingInstitutionCode, programmeCode: row.ProgrammeCode, priorInstitution: row.PriorInstitution, priorQualification: row.PriorQualification, moduleAlignment: parsedJson(row.ModuleAlignmentJson, []), status: result.label, source: result.provenance?.source || null, lastUpdated: result.provenance?.lastUpdated || null, conditions: result.provenance?.conditions || [], policyContact: row.ContactUrl, disclaimer: DISCLAIMERS.creditTransfer });
    }
    return { guidance: output, disclaimer: DISCLAIMERS.creditTransfer, message: output.length ? null : 'No source-verified credit-transfer policies have been submitted. We will not infer or promise credit outcomes.' };
  }));

  router.post('/privacy/consents', wrap(async (db, u, req) => {
    const p = requirePilot(), b = req.body;
    const allowedPurposes = new Set(['process-results', 'funding-matching', 'share-with-school', 'pilot-research', 'email-reminders', 'document-processing']);
    if (!allowedPurposes.has(b.purpose)) throw bad('Choose a supported consent purpose.');
    if (typeof b.granted !== 'boolean') throw bad('Consent decision must be true or false.');
    if (!['adult', 'under18'].includes(b.ageStatus)) throw bad('Choose the age/guardian attestation.');
    if (b.ageStatus === 'under18' && b.granted && b.guardianConfirmed !== true) throw bad('Under-18 learners need parent/guardian confirmation before this feature can be unlocked.', 403);
    const rows = await p.list('Consent', { PersonId: u.personId, Purpose: b.purpose, PolicyVersion: 'sp-privacy-v1' });
    const update = { Granted: b.granted, GrantedAt: b.granted ? now() : null, WithdrawnAt: b.granted ? null : now(), AgeAttested: b.ageStatus === 'adult', AgeAttestedAt: b.ageStatus === 'adult' ? now() : null, GuardianConfirmed: b.ageStatus === 'under18' && b.guardianConfirmed === true, GuardianConfirmedAt: b.ageStatus === 'under18' && b.guardianConfirmed === true ? now() : null };
    if (rows[0]) await p.update('Consent', { ConsentId: rows[0].ConsentId }, update);
    else await p.insert('Consent', { PersonId: u.personId, Purpose: b.purpose, PolicyVersion: 'sp-privacy-v1', ...update });
    await audit(db, u.personId, b.granted ? 'privacy.consent.granted' : 'privacy.consent.withdrawn', { purpose: b.purpose, ageStatus: b.ageStatus });
    return { purpose: b.purpose, granted: b.granted, message: b.granted ? 'Consent saved. You can withdraw it in Privacy.' : 'Consent withdrawn. Related matching/research features will stop using the permission.' };
  }));

  router.get('/privacy/consents', wrap(async (db, u) => {
    const p = requirePilot(), records = await p.list('Consent', { PersonId: u.personId });
    return { consents: records.map((row) => ({ purpose: row.Purpose, granted: Boolean(row.Granted && !row.WithdrawnAt), policyVersion: row.PolicyVersion, grantedAt: row.GrantedAt, withdrawnAt: row.WithdrawnAt, ageAttested: Boolean(row.AgeAttested), guardianConfirmed: Boolean(row.GuardianConfirmed) })), privacyVersion: 'sp-privacy-v1', notice: DISCLAIMERS.privacy };
  }));

  router.get('/privacy/export', wrap(async (db, u) => {
    const p = requirePilot(), person = await one(db, 'PERSONS', { PERSON_ID: u.personId });
    const learner = (await db.list('LEARNERS', { PERSON_ID: u.personId }))[0];
    const exportData = { exportedAt: now(), product: 'StudyPath SA', person: { firstName: person.FIRST_NAME, lastName: person.LAST_NAME, email: person.EMAIL, phone: person.PHONE_NUMBER }, learner: learner ? { learnerId: learner.LEARNER_ID, schoolId: learner.SCHOOL_ID } : null, results: [], subjects: [], applications: [], documents: [], consents: await p.list('Consent', { PersonId: u.personId }), documentAccess: await p.list('DocumentAccessLog', { PersonId: u.personId }), deadlineAlerts: await p.list('DeadlineAlert', { PersonId: u.personId }), checklist: await p.list('ChecklistItem', { PersonId: u.personId }), dataSubjectRequests: await p.list('DataSubjectRequest', { PersonId: u.personId }), financialProfile: null, pilot: null };
    if (learner) {
      exportData.results = await db.list('LEARNER_RESULTS', { LEARNER_ID: learner.LEARNER_ID });
      exportData.subjects = await db.list('LEARNER_SUBJECTS', { LEARNER_ID: learner.LEARNER_ID });
      exportData.applications = await db.list('APPLICATIONS', { LEARNER_ID: learner.LEARNER_ID });
    }
    for (const d of await db.list('DOCUMENTS', { PERSON_ID: u.personId })) {
      exportData.documents.push({ ...Object.fromEntries(Object.entries(d).filter(([key]) => key !== 'DOCUMENT_BLOB')), contentBase64: d.DOCUMENT_BLOB ? decryptDocument(d.DOCUMENT_BLOB).toString('base64') : null });
    }
    const financial = (await p.list('LearnerFinancialProfile', { PersonId: u.personId }))[0];
    if (financial) exportData.financialProfile = JSON.parse(decryptDocument(financial.EncryptedPayload).toString('utf8'));
    exportData.pilot = { participants: await p.list('PilotParticipant', { PersonId: u.personId }).then((rows) => rows.map(({ PersonId, ...item }) => item)), events: [] };
    for (const participant of await p.list('PilotParticipant', { PersonId: u.personId })) exportData.pilot.events.push(...await p.list('PilotEvent', { ParticipantId: participant.ParticipantId }));
    return { filename: `studypath-data-export-${new Date().toISOString().slice(0, 10)}.json`, data: exportData };
  }));

  router.post('/privacy/delete-request', wrap(async (db, u, req) => {
    const p = requirePilot();
    if (req.body.confirmation !== 'DELETE MY ACCOUNT') throw bad('Type DELETE MY ACCOUNT to schedule this request.');
    const scheduledFor = new Date(Date.now() + 30 * 86400000).toISOString();
    const request = await p.insert('DataSubjectRequest', { PersonId: u.personId, RequestType: 'delete', Status: 'scheduled', ScheduledFor: scheduledFor, ConfirmationHash: digest(`delete|${u.personId}|${scheduledFor}`), Notes: 'Learner-confirmed hard deletion scheduled with a 30-day cooling-off window.' });
    await audit(db, u.personId, 'privacy.delete.scheduled', { requestId: request.RequestId, scheduledFor });
    return { requestId: request.RequestId, status: 'scheduled', scheduledFor, message: 'Deletion is scheduled with a 30-day cooling-off period. Contact the Information Officer to cancel before the scheduled date.' };
  }));

  router.get('/vault/checklist', wrap(async (db, u) => {
    role(u, 'learner'); const p = requirePilot(), docs = await db.list('DOCUMENTS', { PERSON_ID: u.personId }), types = await db.list('DOCUMENT_TYPES'), list = [];
    for (const type of types) {
      const found = docs.filter((doc) => sameId(doc.DOCUMENT_TYPE_ID, type.DOCUMENT_TYPE_ID));
      list.push({ itemType: 'vault', documentTypeId: type.DOCUMENT_TYPE_ID, label: type.DOCUMENT_TYPE_NAME, status: found.length ? 'uploaded' : 'missing', documentCount: found.length });
    }
    for (const row of await p.list('ChecklistItem', { PersonId: u.personId })) list.push({ itemType: row.ItemType, itemId: row.ItemId, label: row.DocumentLabel, status: row.Status, dueDate: row.DueDate });
    return { checklist: list };
  }));

  router.get('/deadline-alerts', wrap(async (db, u) => {
    role(u, 'learner'); const p = requirePilot();
    return { alerts: (await p.list('DeadlineAlert', { PersonId: u.personId })).sort((a, b) => String(a.ClosingDate).localeCompare(String(b.ClosingDate))).map((row) => ({ ...row, muted: Boolean(row.Muted) })) };
  }));

  router.post('/deadline-alerts/mute', wrap(async (db, u, req) => {
    role(u, 'learner'); const p = requirePilot(), alertId = id(req.body.alertId);
    const row = (await p.list('DeadlineAlert', { AlertId: alertId, PersonId: u.personId }))[0];
    if (!row) throw bad('Deadline reminder not found.', 404);
    await p.update('DeadlineAlert', { AlertId: alertId }, { Muted: req.body.muted !== false, Status: req.body.muted === false ? 'pending' : 'muted' });
    return { message: req.body.muted === false ? 'Reminder unmuted.' : 'Reminder muted.' };
  }));

  router.post('/pilot/enrol', wrap(async (db, u) => {
    role(u, 'learner'); const p = requirePilot();
    if (!pilotConfig.researchInstrumentationEnabled || !(await pilotConsent(u, 'pilot-research'))) throw bad('Pilot research consent and age/guardian attestation are required.', 403);
    const existing = (await p.list('PilotParticipant', { PersonId: u.personId })).find((row) => !row.WithdrawnAt);
    if (existing) return { pilotCode: existing.PilotCode, message: 'You are already enrolled in the pilot.' };
    const cohort = (await p.list('PilotCohort')).find((row) => row.Status === 'active');
    if (!cohort) throw bad('The pilot is not currently open for enrolment.', 409);
    const pilotCode = randomUUID().replace(/-/g, '').slice(0, 12).toUpperCase();
    const participant = await p.insert('PilotParticipant', { CohortId: cohort.CohortId, PersonId: u.personId, PilotCode: pilotCode, ConsentedAt: now() });
    await audit(db, u.personId, 'pilot.enrolled', { cohortId: cohort.CohortId });
    return { pilotCode: participant.PilotCode, message: 'Pilot enrolment recorded. Dashboard exports use the pseudonymous pilot code.' };
  }));

  router.post('/pilot/tasks', wrap(async (db, u, req) => {
    role(u, 'learner'); const p = requirePilot(), participant = await researchParticipant(u);
    if (!participant) throw bad('Pilot research consent and enrolment are required.', 403);
    const type = req.body.taskType;
    if (!['baseline', 'studypath'].includes(type)) throw bad('Task must be baseline or studypath.');
    const started = Date.parse(req.body.startedAt), finished = Date.parse(req.body.finishedAt);
    if (!Number.isFinite(started) || !Number.isFinite(finished) || finished < started || finished - started > 86400000) throw bad('Start and finish times are invalid.');
    const coursesFound = Number(req.body.coursesFound);
    if (!Number.isInteger(coursesFound) || coursesFound < 0 || coursesFound > 500) throw bad('Courses found must be an integer from 0 to 500.');
    const task = await p.insert('PilotBaselineTask', { ParticipantId: participant.ParticipantId, TaskType: type, StartedAt: new Date(started).toISOString(), FinishedAt: new Date(finished).toISOString(), DurationSeconds: Math.round((finished - started) / 1000), CoursesFound: coursesFound, ToolVersion: packageInfo.version });
    await p.insert('PilotEvent', { ParticipantId: participant.ParticipantId, EventType: 'research-time-' + (type === 'baseline' ? 'baseline-complete' : 'studypath-complete'), MetadataJson: JSON.stringify({ durationSeconds: task.DurationSeconds, coursesFound }) });
    return { taskId: task.TaskId, durationSeconds: task.DurationSeconds, message: 'Research task recorded.' };
  }));

  router.post('/pilot/survey', wrap(async (db, u, req) => {
    role(u, 'learner'); const p = requirePilot(), participant = await researchParticipant(u), b = req.body;
    if (!participant) throw bad('Pilot research consent and enrolment are required.', 403);
    if (!['pre', 'post'].includes(b.stage)) throw bad('Survey stage must be pre or post.');
    const score = (value) => value == null || value === '' ? null : (Number.isInteger(Number(value)) && Number(value) >= 1 && Number(value) <= 5 ? Number(value) : (() => { throw bad('Survey ratings must be integers from 1 to 5.'); })());
    const row = await p.insert('PilotSurvey', { ParticipantId: participant.ParticipantId, SurveyStage: b.stage, ConfidenceScore: score(b.confidence), ClarityScore: score(b.clarity), TimeSavedMinutes: b.timeSavedMinutes == null ? null : Math.max(0, Math.min(1440, Number(b.timeSavedMinutes))), UsabilityScore: score(b.usability), BaselineMissedDeadlines: b.missedDeadlines == null ? null : Math.max(0, Math.min(500, Number(b.missedDeadlines))), FreeText: typeof b.freeText === 'string' ? b.freeText.slice(0, 2000) : null });
    return { surveyId: row.SurveyId, message: 'Survey response saved under your pseudonymous pilot code.' };
  }));

  router.post('/admin/pilot/cohorts', wrap(async (db, u, req) => {
    role(u, 'admin'); const p = requirePilot(), name = text(req.body.name, 150);
    const starts = req.body.startsOn || null, ends = req.body.endsOn || null;
    if (starts && !/^\d{4}-\d{2}-\d{2}$/.test(starts) || ends && !/^\d{4}-\d{2}-\d{2}$/.test(ends) || starts && ends && ends < starts) throw bad('Cohort dates must be valid ISO dates in chronological order.');
    const cohort = await p.insert('PilotCohort', { CohortName: name, StartsOn: starts, EndsOn: ends, Status: 'active' });
    await audit(db, u.personId, 'pilot.cohort.created', { cohortId: cohort.CohortId }); return { cohortId: cohort.CohortId, status: 'active' };
  }));

  router.get('/admin/pilot/dashboard', wrap(async (db, u) => {
    role(u, 'admin'); const p = requirePilot(), cohorts = await p.list('PilotCohort'), participants = await p.list('PilotParticipant'), events = await p.list('PilotEvent'), tasks = await p.list('PilotBaselineTask'), surveys = await p.list('PilotSurvey');
    const details = cohorts.map((cohort) => {
      const people = participants.filter((item) => item.CohortId === cohort.CohortId && !item.WithdrawnAt), participantIds = new Set(people.map((item) => item.ParticipantId));
      const cohortTasks = tasks.filter((item) => participantIds.has(item.ParticipantId));
      const avg = (items) => items.length ? Math.round(items.reduce((sum, item) => sum + item.DurationSeconds, 0) / items.length) : null;
      const baselines = cohortTasks.filter((item) => item.TaskType === 'baseline'), study = cohortTasks.filter((item) => item.TaskType === 'studypath');
      const paired = people.map((person) => { const a = baselines.filter((row) => row.ParticipantId === person.ParticipantId).sort((a,b) => String(b.CreatedAt).localeCompare(String(a.CreatedAt)))[0]; const b = study.filter((row) => row.ParticipantId === person.ParticipantId).sort((a,b) => String(b.CreatedAt).localeCompare(String(a.CreatedAt)))[0]; return a && b ? a.DurationSeconds - b.DurationSeconds : null; }).filter(Number.isFinite).sort((a,b) => a-b);
      const median = paired.length ? (paired.length % 2 ? paired[(paired.length-1)/2] : Math.round((paired[paired.length/2-1]+paired[paired.length/2])/2)) : null;
      const pre = surveys.filter((row) => participantIds.has(row.ParticipantId) && row.SurveyStage === 'pre'), post = surveys.filter((row) => participantIds.has(row.ParticipantId) && row.SurveyStage === 'post');
      const eventTypes = {}; for (const item of events.filter((row) => participantIds.has(row.ParticipantId))) eventTypes[item.EventType] = (eventTypes[item.EventType] || 0) + 1;
      const suppressed = people.length < 5;
      return { cohortId: cohort.CohortId, name: cohort.CohortName, status: cohort.Status, participantCount: people.length, suppressed, baselineComplete: suppressed ? null : baselines.length, studyPathComplete: suppressed ? null : study.length, meanBaselineSeconds: suppressed ? null : avg(baselines), meanStudyPathSeconds: suppressed ? null : avg(study), medianMinutesSaved: suppressed || median == null ? null : Math.round(median/60), pairedParticipants: suppressed ? null : paired.length, eventTypes: suppressed ? {} : eventTypes, preSurveyResponses: suppressed ? null : pre.length, postSurveyResponses: suppressed ? null : post.length };
    });
    return { cohorts: details, privacy: 'Groups with fewer than five participants are suppressed. CSV export contains pseudonymous codes only.' };
  }));

  router.get('/admin/pilot/export.csv', wrap(async (db, u, req, res) => {
    role(u, 'admin'); const p = requirePilot(), participants = await p.list('PilotParticipant'), tasks = await p.list('PilotBaselineTask'), events = await p.list('PilotEvent');
    const cohorts = await p.list('PilotCohort'), cells = cohorts.flatMap((cohort) => {
      const members = participants.filter((person) => person.CohortId === cohort.CohortId && !person.WithdrawnAt);
      if (members.length < 5) return [];
      return members.map((person) => ({ pilotCode: person.PilotCode, cohort: cohort.CohortName, baselineSeconds: tasks.find((row) => row.ParticipantId === person.ParticipantId && row.TaskType === 'baseline')?.DurationSeconds ?? '', studyPathSeconds: tasks.find((row) => row.ParticipantId === person.ParticipantId && row.TaskType === 'studypath')?.DurationSeconds ?? '', events: events.filter((row) => row.ParticipantId === person.ParticipantId).length }));
    });
    const quote = (value) => '"' + String(value ?? '').replace(/"/g, '""') + '"';
    const csv = ['PilotCode,Cohort,BaselineSeconds,StudyPathSeconds,EventCount', ...cells.map((row) => [row.pilotCode,row.cohort,row.baselineSeconds,row.studyPathSeconds,row.events].map(quote).join(','))].join('\r\n');
    res.type('text/csv').set('Content-Disposition', 'attachment; filename="studypath-pilot-pseudonymous.csv"').send(csv);
  }));

  router.get('/compare/data', wrap(async (db, u) => {
    const p = requirePilot(); const competitors = await p.list('Competitor');
    const result = [];
    for (const c of competitors) {
      const featureRows = await p.list('CompetitorFeature', { CompetitorId: c.CompetitorId });
      const features = [];
      for (const f of featureRows) features.push({ feature: f.FeatureLabel, finding: f.Finding, status: f.Status, lastUpdated: f.LastUpdatedOn, evidence: await p.list('CompetitorEvidence', { CompetitorFeatureId: f.CompetitorFeatureId }) });
      result.push({ name: c.CompetitorName, website: c.WebsiteUrl, lastUpdated: c.LastUpdatedOn, notes: c.Notes, status: c.Status, features });
    }
    return { competitors: result, StudyPath: { pilotScope: ['WSU', 'UFH', 'UJ'], postgraduate: 'Coming later', status: 'Feature scope is deliberately limited until programme verification and funding data are sourced.' } };
  }, { publicRoute: true }));

  router.get('/document-templates', wrap(async (db, u) => {
    const p = requirePilot(); return { templates: (await p.list('DocumentTemplate')).filter((row) => row.IsPublished).map((row) => ({ slug: row.TemplateSlug, title: row.Title, summary: row.Summary, href: '/templates/' + basename(row.FilePath), lastReviewedOn: row.LastReviewedOn })) };
  }, { publicRoute: true }));


  router.use((req, res) => res.status(404).json({ error: 'API route not found.' }));
  return router;
}
