import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { loadSqlDriver } from './db/driver.js';
import { pilotDatabaseConfig } from './db/config.js';

const int = { type: 'INT' }, bit = { type: 'BIT' }, date = { type: 'DATE' }, dt = { type: 'DATETIME2' }, blob = { type: 'VARBINARY' };
const text = (size = 250) => ({ type: 'NVARCHAR', size });
const json = text('MAX');
const table = (pk, columns, identity = null) => ({ pk: Array.isArray(pk) ? pk : [pk], columns, identity });
export const pilotMetadata = {
  Source: table('SourceId', { SourceId: int, SourceTitle: text(300), SourceUrl: text(2048), DocumentYear: { type: 'SMALLINT' }, PageRef: text(100), RetrievedOn: date, ContentHash: text(64), ArchivedCopyPath: text(500), SourceType: text(30), CreatedAt: dt }, 'SourceId'),
  RequirementProvenance: table('ProvenanceId', { ProvenanceId: int, InstitutionCode: text(20), ProgrammeCode: text(100), SourceId: int, RequirementJson: json, LastUpdatedOn: date, Conditions: json, Status: text(20), CreatedByPersonId: int, CreatedAt: dt, ModifiedAt: dt }, 'ProvenanceId'),
  ScoringPolicyVerification: table('VerificationId', { VerificationId: int, InstitutionCode: text(20), ProgrammeCode: text(100), IntakeYear: { type: 'SMALLINT' }, VerificationStatus: text(20), ProvenanceId: int, RequirementJson: json, Enabled: bit, CreatedAt: dt, ModifiedAt: dt }, 'VerificationId'),
  VerificationSignoff: table('SignoffId', { SignoffId: int, VerificationId: int, ReviewerPersonId: int, ReviewerRole: text(30), Decision: text(20), Notes: text(1000), SignedAt: dt }, 'SignoffId'),
  Funder: table('FunderId', { FunderId: int, FunderName: text(250), FunderType: text(50), WebsiteUrl: text(2048), ContactUrl: text(2048), Status: text(20), CreatedAt: dt }, 'FunderId'),
  FundingOpportunity: table('OpportunityId', { OpportunityId: int, FunderId: int, OpportunityTitle: text(300), SourceUrl: text(2048), SourceTitle: text(300), SourceYear: { type: 'SMALLINT' }, LastUpdatedOn: date, Conditions: json, ApplicationOpens: date, ApplicationCloses: date, Status: text(20), PostgraduateOnly: bit, Province: text(100), StudyYear: text(50), RequiredDocumentsJson: json, CreatedAt: dt, ModifiedAt: dt }, 'OpportunityId'),
  FundingCriterion: table('CriterionId', { CriterionId: int, OpportunityId: int, FieldName: text(80), Operator: text(20), CriterionValue: text(1000), CriterionLabel: text(250) }, 'CriterionId'),
  FundingDocumentRequirement: table('RequirementId', { RequirementId: int, OpportunityId: int, DocumentLabel: text(250), IsMandatory: bit, GuidanceUrl: text(2048) }, 'RequirementId'),
  CreditTransferGuidance: table('GuidanceId', { GuidanceId: int, ReceivingInstitutionCode: text(20), ProgrammeCode: text(100), PriorInstitution: text(250), PriorQualification: text(250), ModuleAlignmentJson: json, PolicySourceId: int, Conditions: json, LastUpdatedOn: date, Status: text(20), ContactUrl: text(2048), CreatedAt: dt }, 'GuidanceId'),
  Consent: table('ConsentId', { ConsentId: int, PersonId: int, Purpose: text(60), PolicyVersion: text(40), Granted: bit, GrantedAt: dt, WithdrawnAt: dt, GuardianConfirmed: bit, GuardianConfirmedAt: dt, AgeAttested: bit, AgeAttestedAt: dt, CreatedAt: dt }, 'ConsentId'),
  LearnerFinancialProfile: table('PersonId', { PersonId: int, EncryptedPayload: blob, KeyId: text(40), CreatedAt: dt, UpdatedAt: dt }),
  DocumentAccessLog: table('AccessLogId', { AccessLogId: int, PersonId: int, DocumentId: int, AccessedByPersonId: int, AccessedAt: dt, Purpose: text(150), Role: text(30) }, 'AccessLogId'),
  DataSubjectRequest: table('RequestId', { RequestId: int, PersonId: int, RequestType: text(20), Status: text(20), RequestedAt: dt, ScheduledFor: dt, CompletedAt: dt, ConfirmationHash: text(64), Notes: text(1000) }, 'RequestId'),
  RetentionPolicy: table('PolicyId', { PolicyId: int, RecordType: text(80), RetentionDays: int, Enabled: bit, UpdatedAt: dt }, 'PolicyId'),
  DeadlineAlert: table('AlertId', { AlertId: int, PersonId: int, ItemType: text(20), ItemId: int, ClosingDate: date, DaysBefore: { type: 'TINYINT' }, Channel: text(20), Status: text(20), SentAt: dt, Muted: bit, ErrorCode: text(50), CreatedAt: dt }, 'AlertId'),
  DocumentTemplate: table('TemplateId', { TemplateId: int, TemplateSlug: text(80), Title: text(200), Summary: text(1000), FilePath: text(500), LastReviewedOn: date, IsPublished: bit, CreatedAt: dt }, 'TemplateId'),
  ChecklistItem: table('ChecklistItemId', { ChecklistItemId: int, PersonId: int, ItemType: text(20), ItemId: int, DocumentLabel: text(250), DocumentTypeId: int, Status: text(20), DueDate: date, LinkedDocumentId: int, UpdatedAt: dt }, 'ChecklistItemId'),
  PilotCohort: table('CohortId', { CohortId: int, CohortName: text(150), StartsOn: date, EndsOn: date, Status: text(20), CreatedAt: dt }, 'CohortId'),
  PilotParticipant: table('ParticipantId', { ParticipantId: int, CohortId: int, PersonId: int, PilotCode: text(12), ConsentedAt: dt, WithdrawnAt: dt, CreatedAt: dt }, 'ParticipantId'),
  PilotEvent: table('EventId', { EventId: int, ParticipantId: int, EventType: text(60), EventDate: dt, MetadataJson: json }, 'EventId'),
  PilotBaselineTask: table('TaskId', { TaskId: int, ParticipantId: int, TaskType: text(30), StartedAt: dt, FinishedAt: dt, DurationSeconds: int, CoursesFound: int, ToolVersion: text(30), CreatedAt: dt }, 'TaskId'),
  PilotSurvey: table('SurveyId', { SurveyId: int, ParticipantId: int, SurveyStage: text(20), ConfidenceScore: { type: 'TINYINT' }, ClarityScore: { type: 'TINYINT' }, TimeSavedMinutes: int, UsabilityScore: { type: 'TINYINT' }, BaselineMissedDeadlines: int, FreeText: text(2000), SubmittedAt: dt }, 'SurveyId'),
  Competitor: table('CompetitorId', { CompetitorId: int, CompetitorName: text(200), WebsiteUrl: text(2048), LastUpdatedOn: date, Notes: text(2000), Status: text(20) }, 'CompetitorId'),
  CompetitorFeature: table('CompetitorFeatureId', { CompetitorFeatureId: int, CompetitorId: int, FeatureKey: text(80), FeatureLabel: text(200), Finding: text(1000), Status: text(20), LastUpdatedOn: date }, 'CompetitorFeatureId'),
  CompetitorEvidence: table('EvidenceId', { EvidenceId: int, CompetitorFeatureId: int, SourceUrl: text(2048), RetrievedOn: date, SourceTitle: text(300), Notes: text(1000) }, 'EvidenceId'),
  FeatureFlag: table('FeatureKey', { FeatureKey: text(100), IsEnabled: bit, ValueJson: json, UpdatedAt: dt, UpdatedByPersonId: int }),
};

const safeTable = (name) => {
  if (!Object.hasOwn(pilotMetadata, name)) throw new Error('Unknown StudyPath table.');
  return pilotMetadata[name];
};
const validate = (name, values) => {
  const meta = safeTable(name);
  for (const key of Object.keys(values)) if (!Object.hasOwn(meta.columns, key)) throw new Error('Unknown StudyPath column.');
  return meta;
};
const clone = (row) => Object.fromEntries(Object.entries(row).map(([key, value]) => [key, value instanceof Uint8Array ? Buffer.from(value) : value]));

export class LocalPilotStore {
  constructor(path = '.data/studypath-pilot.sqlite') {
    this.mode = 'local';
    if (path !== ':memory:') mkdirSync(dirname(resolve(path)), { recursive: true });
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
    this.queue = Promise.resolve();
    for (const [name, meta] of Object.entries(pilotMetadata)) {
      const cols = Object.entries(meta.columns).map(([key, spec]) => {
        const primary = meta.pk.includes(key) && !meta.identity;
        const type = spec.type === 'VARBINARY' ? 'BLOB' : ['INT', 'SMALLINT', 'TINYINT', 'BIT'].includes(spec.type) ? 'INTEGER' : 'TEXT';
        return `"${key}" ${meta.identity === key ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : type}${primary ? ' NOT NULL' : ''}`;
      });
      if (!meta.identity) cols.push('PRIMARY KEY (' + meta.pk.map((key) => `"${key}"`).join(',') + ')');
      this.db.exec(`CREATE TABLE IF NOT EXISTS "${name}" (${cols.join(',')})`);
    }
    this.db.exec('CREATE UNIQUE INDEX IF NOT EXISTS sp_consent_unique ON Consent(PersonId,Purpose,PolicyVersion); CREATE UNIQUE INDEX IF NOT EXISTS sp_funding_criteria_unique ON FundingCriterion(OpportunityId,FieldName); CREATE UNIQUE INDEX IF NOT EXISTS sp_pilot_person_unique ON PilotParticipant(CohortId,PersonId); CREATE UNIQUE INDEX IF NOT EXISTS sp_alert_idempotent ON DeadlineAlert(PersonId,ItemType,ItemId,DaysBefore,Channel);');
  }
  name(name) { safeTable(name); return `"${name}"`; }
  async list(name, where = {}) {
    validate(name, where); const keys = Object.keys(where);
    return this.db.prepare(`SELECT * FROM ${this.name(name)}${keys.length ? ' WHERE ' + keys.map((key) => `"${key}" IS ?`).join(' AND ') : ''}`).all(...keys.map((key) => where[key])).map(clone);
  }
  async insert(name, values) {
    const meta = validate(name, values); const keys = Object.keys(values); if (!keys.length) throw new Error('A record cannot be empty.');
    const result = this.db.prepare(`INSERT INTO ${this.name(name)} (${keys.map((key) => `"${key}"`).join(',')}) VALUES (${keys.map(() => '?').join(',')})`).run(...keys.map((key) => values[key] ?? null));
    return { ...values, ...(meta.identity ? { [meta.identity]: Number(result.lastInsertRowid) } : {}) };
  }
  async update(name, where, values) {
    validate(name, where); validate(name, values); const keys = Object.keys(where), fields = Object.keys(values);
    if (!keys.length || !fields.length) throw new Error('Scoped update required.');
    return this.db.prepare(`UPDATE ${this.name(name)} SET ${fields.map((key) => `"${key}"=?`).join(',')} WHERE ${keys.map((key) => `"${key}" IS ?`).join(' AND ')}`).run(...fields.map((key) => values[key] ?? null), ...keys.map((key) => where[key])).changes;
  }
  async remove(name, where) {
    validate(name, where); const keys = Object.keys(where); if (!keys.length) throw new Error('Scoped delete required.');
    return this.db.prepare(`DELETE FROM ${this.name(name)} WHERE ${keys.map((key) => `"${key}" IS ?`).join(' AND ')}`).run(...keys.map((key) => where[key])).changes;
  }
  tx(fn) { const op = this.queue.then(async () => { this.db.exec('BEGIN IMMEDIATE'); try { const value = await fn(this); this.db.exec('COMMIT'); return value; } catch (error) { this.db.exec('ROLLBACK'); throw error; } }); this.queue = op.catch(() => {}); return op; }
  async close() { this.db.close(); }
}

export class SqlPilotStore {
  constructor(pool, sql, transaction = null) { this.mode = 'sqlserver'; this.pool = pool; this.sql = sql; this.transaction = transaction; }
  static async open(env = process.env) {
    const config = pilotDatabaseConfig(env); const sql = await loadSqlDriver(env); const pool = new sql.ConnectionPool(config);
    pool.on('error', () => console.error('StudyPath pilot database pool error.'));
    await pool.connect();
    try {
      const r = await pool.request().query("SELECT OBJECT_ID(N'sp.FeatureFlag',N'U') AS FeatureFlagObjectId, OBJECT_ID(N'sp.MigrationLog',N'U') AS MigrationLogObjectId");
      if (!r.recordset[0]?.FeatureFlagObjectId || !r.recordset[0]?.MigrationLogObjectId) throw new Error('StudyPathPilot is missing required migrations. Run scripts/migrate.ps1 against your SQL Server instance.');
      return new SqlPilotStore(pool, sql);
    } catch (error) { await pool.close(); throw error; }
  }
  name(name) { safeTable(name); return `[sp].[${name}]`; }
  request() { return this.transaction ? new this.sql.Request(this.transaction) : this.pool.request(); }
  bind(req, name, data, prefix) {
    const meta = validate(name, data); let index = 0;
    return Object.entries(data).map(([key, value]) => {
      const spec = meta.columns[key]; const param = `${prefix}${index++}`;
      let type;
      if (spec.type === 'NVARCHAR') type = this.sql.NVarChar(spec.size === 'MAX' ? this.sql.MAX : Number(spec.size));
      else if (spec.type === 'VARBINARY') type = this.sql.VarBinary(this.sql.MAX);
      else if (spec.type === 'DATE') type = this.sql.Date;
      else if (spec.type === 'DATETIME2') type = this.sql.DateTime2(0);
      else if (spec.type === 'BIT') type = this.sql.Bit;
      else if (spec.type === 'SMALLINT') type = this.sql.SmallInt;
      else if (spec.type === 'TINYINT') type = this.sql.TinyInt;
      else type = this.sql.Int;
      req.input(param, type, value ?? null); return { key, param };
    });
  }
  async list(name, where = {}) {
    const req = this.request(), p = this.bind(req, name, where, 'w');
    const result = await req.query(`SELECT * FROM ${this.name(name)}${p.length ? ' WHERE ' + p.map((item) => `[${item.key}]${where[item.key] === null ? ' IS NULL' : '=@' + item.param}`).join(' AND ') : ''}`);
    return result.recordset;
  }
  async insert(name, values) {
    const meta = validate(name, values); const req = this.request(), p = this.bind(req, name, values, 'v');
    const output = meta.identity ? ' OUTPUT INSERTED.*' : '';
    const r = await req.query(`INSERT INTO ${this.name(name)} (${p.map((item) => `[${item.key}]`).join(',')})${output} VALUES (${p.map((item) => '@' + item.param).join(',')});`);
    if (meta.identity) return r.recordset?.[0] || null;
    return values;
  }
  async update(name, where, values) {
    const req = this.request(), p = this.bind(req, name, values, 'v'), w = this.bind(req, name, where, 'w');
    if (!w.length || !p.length) throw new Error('Scoped update required.');
    const r = await req.query(`UPDATE ${this.name(name)} SET ${p.map((item) => `[${item.key}]=@${item.param}`).join(',')} WHERE ${w.map((item) => `[${item.key}]=@${item.param}`).join(' AND ')}`);
    return r.rowsAffected[0];
  }
  async remove(name, where) {
    const req = this.request(), w = this.bind(req, name, where, 'w'); if (!w.length) throw new Error('Scoped delete required.');
    const r = await req.query(`DELETE FROM ${this.name(name)} WHERE ${w.map((item) => `[${item.key}]=@${item.param}`).join(' AND ')}`); return r.rowsAffected[0];
  }
  async tx(fn) {
    const transaction = new this.sql.Transaction(this.pool);
    await transaction.begin(this.sql.ISOLATION_LEVEL.SERIALIZABLE);
    try { const result = await fn(new SqlPilotStore(this.pool, this.sql, transaction)); await transaction.commit(); return result; }
    catch (error) { try { await transaction.rollback(); } catch {} throw error; }
  }
  async close() { if (!this.transaction) await this.pool.close(); }
}

export async function openPilotStore({ mode = 'sqlserver', path = '.data/studypath-pilot.sqlite' } = {}) {
  return mode === 'local' ? new LocalPilotStore(path) : SqlPilotStore.open();
}
