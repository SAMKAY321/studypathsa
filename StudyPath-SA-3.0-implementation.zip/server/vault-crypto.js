import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';

const MAGIC = Buffer.from('SPVLT01\n', 'ascii');
const IV_BYTES = 12;
const TAG_BYTES = 16;

function keyFrom(value) {
  const key = Buffer.from(String(value || ''), 'base64');
  if (key.length !== 32) throw new Error('VAULT_MASTER_KEY must be a base64-encoded 32-byte key.');
  return key;
}
function getKeyRing(env = process.env) {
  const ring = new Map();
  const activeId = String(env.VAULT_KEY_ID || 'v1');
  if (env.VAULT_MASTER_KEY) ring.set(activeId, keyFrom(env.VAULT_MASTER_KEY));
  if (env.VAULT_PREVIOUS_MASTER_KEYS) {
    let previous;
    try { previous = JSON.parse(env.VAULT_PREVIOUS_MASTER_KEYS); } catch { throw new Error('VAULT_PREVIOUS_MASTER_KEYS must be a JSON object of key IDs to base64 keys.'); }
    for (const [id, value] of Object.entries(previous)) ring.set(id, keyFrom(value));
  }
  if (!ring.size) throw new Error('Document encryption is unavailable: configure VAULT_MASTER_KEY.');
  return { activeId, ring, active: ring.get(activeId) };
}
function wrapKey(dataKey, key, keyId) {
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(keyId));
  const ciphertext = Buffer.concat([cipher.update(dataKey), cipher.final()]);
  return { keyId, iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), wrappedKey: ciphertext.toString('base64') };
}
function unwrapKey(header, key) {
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(header.wrapIv, 'base64'));
  decipher.setAAD(Buffer.from(header.keyId));
  decipher.setAuthTag(Buffer.from(header.wrapTag, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(header.wrappedKey, 'base64')), decipher.final()]);
}
function parseEnvelope(value) {
  const data = Buffer.from(value);
  if (data.length < MAGIC.length + 2 || !data.subarray(0, MAGIC.length).equals(MAGIC)) return null;
  const length = data.readUInt16BE(MAGIC.length);
  const start = MAGIC.length + 2;
  if (length < 2 || start + length > data.length) throw new Error('Invalid document envelope header.');
  const header = JSON.parse(data.subarray(start, start + length).toString('utf8'));
  return { data, header, cipher: data.subarray(start + length) };
}
export function isEncryptedDocument(value) {
  const data = Buffer.from(value || []);
  return data.length >= MAGIC.length && data.subarray(0, MAGIC.length).equals(MAGIC);
}
export function encryptDocument(plaintext, env = process.env) {
  const { activeId, active } = getKeyRing(env);
  const dek = randomBytes(32);
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv('aes-256-gcm', dek, iv);
  const ciphertext = Buffer.concat([cipher.update(Buffer.from(plaintext)), cipher.final()]);
  const wrapped = wrapKey(dek, active, activeId);
  const header = {
    version: 1,
    keyId: activeId,
    dataIv: iv.toString('base64'),
    dataTag: cipher.getAuthTag().toString('base64'),
    wrapIv: wrapped.iv,
    wrapTag: wrapped.tag,
    wrappedKey: wrapped.wrappedKey,
  };
  const json = Buffer.from(JSON.stringify(header));
  if (json.length > 65535) throw new Error('Document envelope header is too large.');
  const len = Buffer.alloc(2);
  len.writeUInt16BE(json.length);
  return Buffer.concat([MAGIC, len, json, ciphertext]);
}
export function decryptDocument(envelope, env = process.env) {
  const parsed = parseEnvelope(envelope);
  if (!parsed) return Buffer.from(envelope); // legacy plaintext rows are handled by migration tooling
  const { ring } = getKeyRing(env);
  const wrappingKey = ring.get(parsed.header.keyId);
  if (!wrappingKey) throw new Error(`The master key for vault key ID ${parsed.header.keyId} is unavailable.`);
  const dek = unwrapKey(parsed.header, wrappingKey);
  if (dek.length !== 32) throw new Error('Invalid wrapped document key.');
  const decipher = createDecipheriv('aes-256-gcm', dek, Buffer.from(parsed.header.dataIv, 'base64'));
  decipher.setAuthTag(Buffer.from(parsed.header.dataTag, 'base64'));
  return Buffer.concat([decipher.update(parsed.cipher), decipher.final()]);
}
export function rewrapDocument(envelope, env = process.env) {
  const parsed = parseEnvelope(envelope);
  if (!parsed) return Buffer.from(envelope);
  const { activeId, active, ring } = getKeyRing(env);
  if (parsed.header.keyId === activeId) return Buffer.from(envelope);
  const oldKey = ring.get(parsed.header.keyId);
  if (!oldKey) throw new Error(`The master key for vault key ID ${parsed.header.keyId} is unavailable.`);
  const dek = unwrapKey(parsed.header, oldKey);
  const wrapped = wrapKey(dek, active, activeId);
  const header = { ...parsed.header, keyId: activeId, wrapIv: wrapped.iv, wrapTag: wrapped.tag, wrappedKey: wrapped.wrappedKey };
  const json = Buffer.from(JSON.stringify(header));
  const len = Buffer.alloc(2); len.writeUInt16BE(json.length);
  return Buffer.concat([MAGIC, len, json, parsed.cipher]);
}
export function validateVaultKey(env = process.env) { getKeyRing(env); return true; }
