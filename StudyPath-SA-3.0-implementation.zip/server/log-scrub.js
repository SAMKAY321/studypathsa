const patterns = [
  { pattern: /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, replacement: '[redacted-email]' },
  { pattern: /\b\d{13}\b/g, replacement: '[redacted-id-number]' },
  { pattern: /\b(?:\+?27|0)[\s().-]*\d{2,3}[\s().-]*\d{3}[\s().-]*\d{3,4}\b/g, replacement: '[redacted-phone]' },
  { pattern: /\bR\s?\d[\d, ]*(?:\.\d{1,2})?(?:\s?(?:-|–|to)\s?R?\s?\d[\d, ]*(?:\.\d{1,2})?)?/gi, replacement: '[redacted-amount]' },
];

export function scrubSensitiveLogText(value) {
  let text = String(value ?? '');
  for (const { pattern, replacement } of patterns) text = text.replace(pattern, replacement);
  return text.slice(0, 500);
}
