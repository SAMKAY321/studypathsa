import { fileURLToPath } from 'node:url';
import { LocalStore, SqlStore } from '../storage.js';
import { openPilotStore } from '../pilot-store.js';
import { seedLocal } from '../seed.js';
import { seedPilotStore } from '../seed-pilot.js';

const now = () => new Date().toISOString();

export async function processDueDeletions(mainStore, pilotStore, at = new Date()) {
  const due = (await pilotStore.list('DataSubjectRequest', { RequestType: 'delete', Status: 'scheduled' })).filter((row) => row.ScheduledFor && Date.parse(row.ScheduledFor) <= at.getTime());
  const summary = { examined: due.length, completed: 0, failed: 0 };
  for (const request of due) {
    const personId = Number(request.PersonId), anonId = -Math.max(1, Number(request.RequestId));
    try {
      // Mark as processing with a conditional state change so parallel task runs do not both delete.
      const claim = await pilotStore.update('DataSubjectRequest', { RequestId: request.RequestId, Status: 'scheduled' }, { Status: 'processing' });
      if (!claim) continue;
      await mainStore.tx(async (tx) => {
        const learner = (await tx.list('LEARNERS', { PERSON_ID: personId }))[0];
        if (learner) {
          const apps = await tx.list('APPLICATIONS', { LEARNER_ID: learner.LEARNER_ID });
          for (const app of apps) await tx.remove('APPLICATION_PROCESSES', { APPLICATION_ID: app.APPLICATION_ID });
          await tx.remove('APPLICATIONS', { LEARNER_ID: learner.LEARNER_ID });
          await tx.remove('LEARNER_RESULTS', { LEARNER_ID: learner.LEARNER_ID });
          await tx.remove('LEARNER_SUBJECTS', { LEARNER_ID: learner.LEARNER_ID });
        }
        await tx.remove('DOCUMENTS', { PERSON_ID: personId });
        for (const table of ['security.AccountTokens','security.EmailVerifications','security.MfaChallenges','security.Mfa','security.Sessions','security.Accounts']) await tx.remove(table, { PERSON_ID: personId });
        await tx.remove('PERSON_ADDRESSES', { PERSON_ID: personId });
        await tx.remove('LEARNERS', { PERSON_ID: personId });
        await tx.remove('TEACHERS', { PERSON_ID: personId });
        await tx.remove('UNIVERSITY_REPS', { PERSON_ID: personId });
        await tx.remove('ITADMINS', { PERSON_ID: personId });
        // Preserve the security audit event without preserving the identity mapping.
        await tx.update('security.Audit', { PERSON_ID: personId }, { PERSON_ID: anonId });
        await tx.remove('PERSONS', { PERSON_ID: personId });
      });
      await pilotStore.tx(async (tx) => {
        const participants = await tx.list('PilotParticipant', { PersonId: personId });
        for (const participant of participants) {
          await tx.remove('PilotEvent', { ParticipantId: participant.ParticipantId });
          await tx.remove('PilotBaselineTask', { ParticipantId: participant.ParticipantId });
          await tx.remove('PilotSurvey', { ParticipantId: participant.ParticipantId });
          await tx.remove('PilotParticipant', { ParticipantId: participant.ParticipantId });
        }
        await tx.remove('LearnerFinancialProfile', { PersonId: personId });
        await tx.update('Consent', { PersonId: personId }, { PersonId: anonId });
        await tx.update('DocumentAccessLog', { PersonId: personId }, { PersonId: anonId });
        await tx.update('DocumentAccessLog', { AccessedByPersonId: personId }, { AccessedByPersonId: anonId });
        await tx.remove('DeadlineAlert', { PersonId: personId });
        await tx.remove('ChecklistItem', { PersonId: personId });
        await tx.update('DataSubjectRequest', { PersonId: personId }, { PersonId: anonId });
        await tx.update('DataSubjectRequest', { RequestId: request.RequestId }, { Status: 'completed', CompletedAt: now(), ConfirmationHash: null, Notes: 'Completed. Personal account data deleted; security records pseudonymised.' });
      });
      summary.completed += 1;
    } catch (error) {
      await pilotStore.update('DataSubjectRequest', { RequestId: request.RequestId }, { Status: 'failed', Notes: `Deletion failed; an administrator must reconcile the failed operation. Error code: ${String(error?.code || error?.name || 'error').slice(0, 100)}` }).catch(() => {});
      summary.failed += 1;
    }
  }
  return summary;
}

async function main() {
  const mode = process.env.APP_MODE || 'sqlserver';
  const mainStore = mode === 'local' ? new LocalStore(process.env.LOCAL_DATABASE || '.data/varsity-vault.sqlite') : await SqlStore.open();
  const pilotStore = await openPilotStore({ mode, path: process.env.PILOT_LOCAL_DATABASE || '.data/studypath-pilot.sqlite' });
  try {
    if (mode === 'local') await mainStore.tx(seedLocal);
    await seedPilotStore(pilotStore);
    console.log(JSON.stringify(await processDueDeletions(mainStore, pilotStore)));
  } finally { await pilotStore.close(); await mainStore.close(); }
}
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) main().catch((error) => { console.error('Privacy deletion job failed:', error.code || error.name); process.exitCode = 1; });
