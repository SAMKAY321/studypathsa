import pilotConfig from '../config/pilot.json' with { type: 'json' };

export async function seedPilotStore(store) {
  const flags = [
    ['pilotInstitutions', true, pilotConfig.pilotInstitutions],
    ['postgraduateEnabled', false, false],
    ['creditTransferEnabled', pilotConfig.creditTransferEnabled, pilotConfig.creditTransferEnabled],
    ['bursaryMatchingEnabled', pilotConfig.bursaryMatchingEnabled, pilotConfig.bursaryMatchingEnabled],
    ['researchInstrumentationEnabled', pilotConfig.researchInstrumentationEnabled, pilotConfig.researchInstrumentationEnabled],
  ];
  for (const [FeatureKey, IsEnabled, value] of flags) {
    const existing = (await store.list('FeatureFlag', { FeatureKey }))[0];
    if (!existing) await store.insert('FeatureFlag', { FeatureKey, IsEnabled, ValueJson: JSON.stringify(value) });
  }
  const retentionPolicies = [
    ['inactive-account', 730],
    ['expired-document', 365],
    ['rejected-document', 365],
  ];
  for (const [RecordType, RetentionDays] of retentionPolicies) {
    if (!(await store.list('RetentionPolicy', { RecordType })).length) {
      await store.insert('RetentionPolicy', { RecordType, RetentionDays, Enabled: 1, UpdatedAt: new Date().toISOString() });
    }
  }
  const today = new Date().toISOString().slice(0, 10);
  for (const [CompetitorName, WebsiteUrl, Notes] of [
    ['Careers Portal', 'https://www.careersportal.co.za/', 'Feature-level claims require dated evidence. Not verified in this seed.'],
    ['ApplyNow', null, 'Official website and feature claims require verification. Not verified in this seed.'],
  ]) {
    if (!(await store.list('Competitor', { CompetitorName })).length)
      await store.insert('Competitor', { CompetitorName, WebsiteUrl, LastUpdatedOn: today, Notes, Status: 'not-verified' });
  }
  const templates = [
    ['motivation-letter', 'Motivation letter guide', 'A planning template for a learner-authored motivation letter.', 'motivation-letter.md'],
    ['first-application-cv', 'First application CV', 'A simple CV structure for a first post-school application.', 'first-application-cv.md'],
    ['income-declaration-note', 'Income document cover note', 'A cover note checklist for funder-required income evidence.', 'income-declaration-note.md'],
    ['certified-copy-checklist', 'Certified copy checklist', 'A checklist to help prepare certified copies and check validity windows.', 'certified-copy-checklist.md'],
    ['bursary-checklist', 'Bursary application checklist', 'A general preparation checklist. Always follow the funder-specific instructions.', 'bursary-checklist.md'],
  ];
  for (const [TemplateSlug, Title, Summary, file] of templates) {
    if (!(await store.list('DocumentTemplate', { TemplateSlug })).length)
      await store.insert('DocumentTemplate', { TemplateSlug, Title, Summary, FilePath: file, LastReviewedOn: '2026-10-26', IsPublished: true });
  }
}
