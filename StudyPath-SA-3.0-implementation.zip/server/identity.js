/** Compare primary/foreign-key values consistently across SQL Server and SQLite drivers. */
export function sameId(left, right) {
  if (left === null || left === undefined || right === null || right === undefined) return false;
  const a = String(left).trim();
  const b = String(right).trim();
  if (!a || !b) return false;
  if (/^\d+$/.test(a) && /^\d+$/.test(b)) return Number(a) === Number(b);
  return a === b;
}
