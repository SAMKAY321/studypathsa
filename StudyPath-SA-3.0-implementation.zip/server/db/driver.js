// Load the native Windows driver only when a SQL Server connection needs it.
export async function loadSqlDriver(env = process.env) {
  const auth = env.DB_AUTH || 'sql';
  if (!['sql', 'windows'].includes(auth)) throw new Error('DB_AUTH must be sql or windows.');
  if (auth === 'windows') {
    if (process.platform !== 'win32')
      throw new Error(
        'Windows Authentication must run in native Windows Node.js, under your Windows account (not WSL).',
      );
    try {
      return (await import('mssql/msnodesqlv8.js')).default;
    } catch {
      throw new Error(
        'Windows SQL driver could not load. Run npm ci with optional dependencies enabled; install Microsoft ODBC Driver 18 for SQL Server (x64). See docs/windows-auth.md.',
      );
    }
  }
  return (await import('mssql')).default;
}
