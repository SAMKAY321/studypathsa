import { loadSqlDriver } from './driver.js';
import { databaseConfig, pilotDatabaseConfig } from './config.js';
import { readFile } from 'node:fs/promises';
import { schemaCheckQueries, securityReadinessQuery } from './schema-compare.js';
const expected = JSON.parse(
  await readFile(new URL('../../config/schema-contract.json', import.meta.url), 'utf8'),
);
let pool;
let pilotPool;
let securityReady = false;
let pilotReady = false;
try {
  const config = databaseConfig(),
    sql = await loadSqlDriver();
  pool = new sql.ConnectionPool(config);
  pool.on('error', () => console.error('SQL Server connection pool error.'));
  await pool.connect();
  const identity = await pool
    .request()
    .query(
      "SELECT SUSER_SNAME() AS LoginName, DB_NAME() AS DatabaseName, SERVERPROPERTY('IsIntegratedSecurityOnly') AS WindowsAuthOnly",
    );
  console.log('Connected:', identity.recordset[0]);
  const security = await pool
    .request()
    .query("SELECT name FROM sys.databases WHERE name='VarsityVaultSecurity'");
  if (!security.recordset.length)
    console.error(
      'VarsityVaultSecurity is not visible. Before setup/start, run database/security.sql in SSMS on this instance.',
    );
  else {
    const readiness = await pool.request().query(securityReadinessQuery);
    securityReady = Boolean(readiness.recordset[0]?.LoginAttemptsObjectId);
    if (!securityReady)
      console.error(
        'VarsityVaultSecurity.dbo.LoginAttempts is missing or not visible. Re-run database/security.sql in SSMS on this instance, then run db:check again.',
      );
  }
  // Metadata SELECTs only. Never run or recreate the submitted schema.
  const { objectChecks, columnChecks } = schemaCheckQueries(expected);
  const [objects, columns] = await Promise.all([
    pool.request().query(objectChecks),
    pool.request().query(columnChecks),
  ]);
  const missingObjects = objects.recordset.map((row) => row.object_name);
  const missingColumns = columns.recordset.map((row) => ({
    table: row.table_name,
    name: row.column_name,
  }));
  if (missingObjects.length || missingColumns.length) {
    console.error('Schema mismatch:', { missingObjects, missingColumns });
    process.exitCode = 1;
  }
  if (!securityReady) process.exitCode = 1;
  else
    console.log(
      `Read-only academic schema check passed: ${expected.objects.length} objects and ${expected.columns.length} columns. No academic database changes made.`,
    );

  // Check the separate StudyPathPilot database without touching the submitted academic schema.
  pilotPool = new sql.ConnectionPool(pilotDatabaseConfig());
  pilotPool.on('error', () => console.error('StudyPath pilot database connection pool error.'));
  await pilotPool.connect();
  const pilotObjects = await pilotPool.request().query(`
    SELECT required.object_name
    FROM (VALUES (N'sp.MigrationLog'), (N'sp.FeatureFlag'), (N'sp.Source'),
                 (N'sp.RequirementProvenance'), (N'sp.ScoringPolicyVerification'),
                 (N'sp.FundingOpportunity'), (N'sp.CreditTransferGuidance'),
                 (N'sp.Consent'), (N'sp.LearnerFinancialProfile'), (N'sp.DeadlineAlert'),
                 (N'sp.DataSubjectRequest'), (N'sp.PilotParticipant'), (N'sp.Competitor')) required(object_name)
    WHERE OBJECT_ID(required.object_name, N'U') IS NULL;
  `);
  const missingPilot = pilotObjects.recordset.map((row) => row.object_name);
  if (missingPilot.length) {
    console.error('StudyPathPilot migration objects are missing:', missingPilot);
    process.exitCode = 1;
  } else {
    pilotReady = true;
    console.log('StudyPathPilot readiness check passed: required pilot tables are present.');
  }
} catch (error) {
  console.error(
    'Database check failed:',
    error.code || '',
    error.message,
    'See docs/windows-auth.md for Windows connection troubleshooting.',
  );
  process.exitCode = 1;
} finally {
  if (pilotPool) await pilotPool.close();
  if (pool) await pool.close();
}
