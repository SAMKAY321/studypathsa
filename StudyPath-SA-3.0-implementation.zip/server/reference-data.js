/**
 * Idempotently seed only application-critical lookup options omitted from the
 * submitted academic schema's INSERT section. These are not universities,
 * programmes, learners, or other fabricated institutional records.
 */
const REQUIRED_STUDY_MODES = ['Full-time', 'Part-time'];

export async function ensureReferenceData(store) {
  return store.tx(async (db) => {
    const existing = await db.list('STUDY_MODES');
    const names = new Set(
      existing.map((row) =>
        String(row.STUDY_MODE_NAME || '')
          .trim()
          .toLocaleLowerCase('en-ZA'),
      ),
    );
    const inserted = [];
    for (const name of REQUIRED_STUDY_MODES) {
      const key = name.toLocaleLowerCase('en-ZA');
      if (names.has(key)) continue;
      const row = await db.insert('STUDY_MODES', { STUDY_MODE_NAME: name });
      names.add(key);
      inserted.push(row);
    }
    return { inserted: inserted.map((row) => row.STUDY_MODE_NAME), count: names.size };
  });
}
