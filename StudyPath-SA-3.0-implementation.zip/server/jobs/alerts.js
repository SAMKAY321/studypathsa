import { fileURLToPath } from 'node:url';
import { LocalStore, SqlStore } from '../storage.js';
import { openPilotStore } from '../pilot-store.js';
import { seedLocal } from '../seed.js';
import { seedPilotStore } from '../seed-pilot.js';
import { sendAccountEmail } from '../mailer.js';

const isoDay = (value) => {
  if (!value) return null;
  const parsed = value instanceof Date ? value : new Date(String(value).slice(0, 10) + 'T12:00:00Z');
  return Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : null;
};
const daysBetween = (a, b) => Math.floor((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86400000);
const localToday = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Johannesburg', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());

export async function runAlerts({ mainStore, pilotStore, sendEmail = sendAccountEmail, today = localToday() }) {
  const report = { evaluated: 0, sent: 0, inAppReady: 0, failed: 0, staleProgrammes: 0, staleFunding: 0 };
  const verifications = await pilotStore.list('ScoringPolicyVerification');
  const provenances = await pilotStore.list('RequirementProvenance');
  const sources = await pilotStore.list('Source');
  for (const verification of verifications) {
    if (verification.VerificationStatus !== 'verified' || !verification.Enabled) continue;
    const provenance = provenances.find((item) => item.ProvenanceId === verification.ProvenanceId);
    if (!provenance || !provenance.LastUpdatedOn || daysBetween(isoDay(provenance.LastUpdatedOn), today) > 180) {
      await pilotStore.update('ScoringPolicyVerification', { VerificationId: verification.VerificationId }, { VerificationStatus: 'stale', Enabled: 0, ModifiedAt: new Date().toISOString() });
      if (provenance) await pilotStore.update('RequirementProvenance', { ProvenanceId: provenance.ProvenanceId }, { Status: 'stale', ModifiedAt: new Date().toISOString() });
      report.staleProgrammes += 1;
    }
  }
  for (const opportunity of await pilotStore.list('FundingOpportunity')) {
    if (opportunity.Status !== 'verified') continue;
    const updated = isoDay(opportunity.LastUpdatedOn);
    if (!updated || daysBetween(updated, today) > 90 || (opportunity.ApplicationCloses && isoDay(opportunity.ApplicationCloses) < today)) {
      await pilotStore.update('FundingOpportunity', { OpportunityId: opportunity.OpportunityId }, { Status: opportunity.ApplicationCloses && isoDay(opportunity.ApplicationCloses) < today ? 'closed' : 'stale', ModifiedAt: new Date().toISOString() });
      report.staleFunding += 1;
    }
  }
  for (const alert of await pilotStore.list('DeadlineAlert', { Status: 'pending' })) {
    report.evaluated += 1;
    if (alert.Muted || isoDay(alert.ClosingDate) < today) {
      await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: alert.Muted ? 'muted' : 'failed', ErrorCode: alert.Muted ? null : 'deadline-past' });
      continue;
    }
    if (daysBetween(today, isoDay(alert.ClosingDate)) !== Number(alert.DaysBefore)) continue;
    if (alert.Channel === 'in-app') { report.inAppReady += 1; continue; }
    if (alert.Channel !== 'email') continue;
    const consent = (await pilotStore.list('Consent', { PersonId: alert.PersonId, Purpose: 'email-reminders', PolicyVersion: 'sp-privacy-v1' }))[0];
    if (!consent?.Granted || consent.WithdrawnAt || (!consent.AgeAttested && !consent.GuardianConfirmed)) {
      await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'muted', ErrorCode: 'consent-not-active' });
      continue;
    }
    const person = (await mainStore.list('PERSONS', { PERSON_ID: alert.PersonId }))[0];
    const email = person?.EMAIL_ADDRESS || person?.EMAIL || null;
    if (!email) { await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'failed', ErrorCode: 'email-not-found' }); report.failed += 1; continue; }
    let itemName = alert.ItemType === 'funding' ? 'funding opportunity' : 'programme';
    let sourceUrl = '';
    if (alert.ItemType === 'funding') {
      const opportunity = (await pilotStore.list('FundingOpportunity', { OpportunityId: alert.ItemId }))[0];
      if (!opportunity || opportunity.Status !== 'verified') { await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'failed', ErrorCode: 'item-not-actionable' }); continue; }
      itemName = opportunity.OpportunityTitle; sourceUrl = opportunity.SourceUrl;
    } else {
      const verification = (await pilotStore.list('ScoringPolicyVerification', { VerificationId: alert.ItemId }))[0];
      const provenance = verification && provenances.find((item) => item.ProvenanceId === verification.ProvenanceId);
      const source = provenance && sources.find((item) => item.SourceId === provenance.SourceId);
      if (!verification || verification.VerificationStatus !== 'verified' || !verification.Enabled || !source?.SourceUrl) { await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'failed', ErrorCode: 'item-not-actionable' }); continue; }
      itemName = verification.ProgrammeCode; sourceUrl = source.SourceUrl;
    }
    // Claim first so two overlapping Task Scheduler invocations cannot double-send.
    const claimed = await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId, Status: 'pending' }, { Status: 'sending' });
    if (!claimed) continue;
    try {
      await sendEmail({ to: email, subject: `StudyPath SA deadline reminder: ${itemName}`, text: `This is your ${alert.DaysBefore}-day reminder for ${itemName}. Published closing date: ${isoDay(alert.ClosingDate)}.\n\nSource: ${sourceUrl}\n\nVerify with the institution/funder before applying. Criteria, funding and deadlines change.` });
      await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'sent', SentAt: new Date().toISOString(), ErrorCode: null }); report.sent += 1;
    } catch (error) {
      await pilotStore.update('DeadlineAlert', { AlertId: alert.AlertId }, { Status: 'failed', ErrorCode: String(error?.code || 'delivery-failed').slice(0, 50) }); report.failed += 1;
    }
  }
  return report;
}

async function main() {
  const mode = process.env.APP_MODE || 'sqlserver';
  const mainStore = mode === 'local' ? new LocalStore(process.env.LOCAL_DATABASE || '.data/varsity-vault.sqlite') : await SqlStore.open();
  const pilotStore = await openPilotStore({ mode, path: process.env.PILOT_LOCAL_DATABASE || '.data/studypath-pilot.sqlite' });
  try {
    if (mode === 'local') await mainStore.tx(seedLocal);
    await seedPilotStore(pilotStore);
    const report = await runAlerts({ mainStore, pilotStore });
    console.log(JSON.stringify(report));
  } finally { await pilotStore.close(); await mainStore.close(); }
}
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) main().catch((error) => { console.error('Deadline alert job failed:', error.code || error.name); process.exitCode = 1; });
