import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { LocalStore, SqlStore } from '../storage.js';
import { openPilotStore } from '../pilot-store.js';
import { seedLocal } from '../seed.js';
import { seedPilotStore } from '../seed-pilot.js';
import { collectRejectedDocumentCandidates, validateRetentionManifest } from '../../shared/trust/retention.js';

const isoDay = (value) => (value instanceof Date ? value.toISOString() : String(value || '')).slice(0, 10);

export async function runRetention({ mainStore, pilotStore, asOf = new Date(), apply = false, manifest = null, enableDeletion = false }) {
  const report = { mode: apply ? 'apply' : 'dry-run', rejectedDocumentCandidates: 0, deletedDocuments: 0, skippedPolicies: [], errors: [] };
  const policies = await pilotStore.list('RetentionPolicy');
  const enabled = new Map(policies.filter((item) => item.Enabled).map((item) => [item.RecordType, Number(item.RetentionDays)]));
  const statuses = await mainStore.list('VERIFICATION_STATUSES');
  const documents = await mainStore.list('DOCUMENTS');
  const rejectedDays = enabled.get('rejected-document');
  let candidates = [];
  if (Number.isInteger(rejectedDays) && rejectedDays >= 1) {
    candidates = collectRejectedDocumentCandidates({ documents, statuses, retentionDays: rejectedDays, asOf });
    report.rejectedDocumentCandidates = candidates.length;
  } else report.skippedPolicies.push({ recordType: 'rejected-document', reason: 'No enabled rejected-document retention policy is configured.' });

  // The submitted academic schema contains no explicit document-expiry or last-account-activity field.
  // Do not infer expiry or inactivity from upload/registration timestamps. The job reports these blockers.
  if (enabled.has('expired-document')) report.skippedPolicies.push({ recordType: 'expired-document', reason: 'No authoritative expiry date exists in the preserved academic schema; no records were selected.' });
  if (enabled.has('inactive-account')) report.skippedPolicies.push({ recordType: 'inactive-account', reason: 'No authoritative last-activity field exists; audit-event absence is not treated as inactivity.' });

  if (!apply) return report;
  if (!enableDeletion) throw new Error('Retention deletion is disabled. Set RETENTION_DELETION_ENABLED=true only after the Information Officer approves the process.');
  if (!manifest || !Array.isArray(manifest)) throw new Error('Apply mode requires --manifest pointing to a reviewed JSON approval manifest.');
  if (!Number.isInteger(rejectedDays) || rejectedDays < 1) throw new Error('No enabled rejected-document retention policy is configured.');
  const approved = validateRetentionManifest(manifest, candidates, asOf);
  const candidateIds = new Set(candidates.map((row) => row.documentId));
  for (const row of approved) {
    if (!candidateIds.has(row.documentId)) continue;
    // Re-read the record immediately before deletion so a changed verification status/date fails closed.
    const current = (await mainStore.list('DOCUMENTS', { DOCUMENT_ID: row.documentId, PERSON_ID: row.personId }))[0];
    if (!current) continue;
    const latest = collectRejectedDocumentCandidates({ documents: [current], statuses, retentionDays: rejectedDays, asOf });
    if (!latest.length) { report.errors.push({ documentId: row.documentId, code: 'candidate-no-longer-eligible' }); continue; }
    const checklistRows = await pilotStore.list('ChecklistItem', { LinkedDocumentId: row.documentId });
    try {
      await pilotStore.tx(async (tx) => tx.update('ChecklistItem', { LinkedDocumentId: row.documentId }, { LinkedDocumentId: null, Status: 'missing', UpdatedAt: new Date().toISOString() }));
      const deleted = await mainStore.tx(async (tx) => {
        const count = await tx.remove('DOCUMENTS', { DOCUMENT_ID: row.documentId, PERSON_ID: row.personId });
        if (count) {
          // Keep a minimal security audit entry; never include names, email addresses, or document content.
          await tx.insert('security.Audit', { AUDIT_ID: randomUUID(), PERSON_ID: row.personId, EVENT: 'retention.document.deleted', DETAIL: JSON.stringify({ documentId: row.documentId, reason: row.reason, approvedBy1: row.approvedBy1, approvedBy2: row.approvedBy2, approvedAt: row.approvedAt }), CREATED_AT: new Date().toISOString() });
        }
        return count;
      });
      if (!deleted) {
        await pilotStore.tx(async (tx) => { for (const item of checklistRows) await tx.update('ChecklistItem', { ChecklistItemId: item.ChecklistItemId }, { LinkedDocumentId: row.documentId, Status: item.Status, UpdatedAt: new Date().toISOString() }); });
        continue;
      }
      report.deletedDocuments += 1;
    } catch (error) {
      // Best-effort reconciliation if the two databases disagree during a retention run.
      const stillPresent = (await mainStore.list('DOCUMENTS', { DOCUMENT_ID: row.documentId, PERSON_ID: row.personId }).catch(() => []))[0];
      if (stillPresent) await pilotStore.tx(async (tx) => { for (const item of checklistRows) await tx.update('ChecklistItem', { ChecklistItemId: item.ChecklistItemId }, { LinkedDocumentId: row.documentId, Status: item.Status, UpdatedAt: new Date().toISOString() }); }).catch(() => {});
      report.errors.push({ documentId: row.documentId, code: String(error?.code || error?.name || 'retention-failed').slice(0, 50) });
    }
  }
  report.mode = 'applied';
  return report;
}

async function main() {
  const argv = process.argv.slice(2);
  const apply = argv.includes('--apply');
  const manifestArg = argv.find((arg) => arg.startsWith('--manifest='));
  let manifest = null;
  if (manifestArg) manifest = JSON.parse(await readFile(resolve(manifestArg.slice('--manifest='.length)), 'utf8'));
  const mode = process.env.APP_MODE || 'sqlserver';
  const mainStore = mode === 'local' ? new LocalStore(process.env.LOCAL_DATABASE || '.data/varsity-vault.sqlite') : await SqlStore.open();
  const pilotStore = await openPilotStore({ mode, path: process.env.PILOT_LOCAL_DATABASE || '.data/studypath-pilot.sqlite' });
  try {
    if (mode === 'local') await mainStore.tx(seedLocal);
    await seedPilotStore(pilotStore);
    const report = await runRetention({ mainStore, pilotStore, apply, manifest, enableDeletion: process.env.RETENTION_DELETION_ENABLED === 'true' });
    console.log(JSON.stringify(report));
  } finally { await pilotStore.close(); await mainStore.close(); }
}
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) main().catch((error) => { console.error('Retention job failed:', error.code || error.name, error.message); process.exitCode = 1; });
