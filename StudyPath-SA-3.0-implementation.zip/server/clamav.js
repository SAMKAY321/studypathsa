import net from 'node:net';

const scannerError = (code) => Object.assign(new Error('The configured malware scanner could not confirm this upload is clean.'), { code });

export function buildInstreamFrames(input, chunkSize = 64 * 1024) {
  const buffer = Buffer.from(input || []);
  const frames = [Buffer.from('zINSTREAM\0', 'ascii')];
  for (let offset = 0; offset < buffer.length; offset += chunkSize) {
    const chunk = buffer.subarray(offset, Math.min(offset + chunkSize, buffer.length));
    const size = Buffer.alloc(4);
    size.writeUInt32BE(chunk.length, 0);
    frames.push(size, chunk);
  }
  frames.push(Buffer.alloc(4));
  return frames;
}

export async function scanBuffer(input, env = process.env) {
  if (env.CLAMAV_ENABLED !== 'true') return { enabled: false, clean: null };
  const port = Number(env.CLAMAV_PORT || 3310);
  const timeoutMs = Number(env.CLAMAV_TIMEOUT_MS || 8000);
  const host = env.CLAMAV_HOST || '127.0.0.1';
  if (!Number.isInteger(port) || port < 1 || port > 65535 || !Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 60000 || /[\r\n]/.test(host))
    throw scannerError('CLAMAV_CONFIGURATION_INVALID');
  const frames = buildInstreamFrames(input);
  return new Promise((resolve, reject) => {
    let response = '';
    let finished = false;
    const socket = net.createConnection({ host, port });
    const finish = () => {
      if (finished) return;
      if (response.includes('FOUND')) {
        finished = true;
        socket.destroy();
        reject(Object.assign(new Error('The uploaded file was detected as malicious and was rejected.'), { status: 422, code: 'CLAMAV_MALWARE_DETECTED' }));
      } else if (/stream:\s*OK/i.test(response)) {
        finished = true;
        socket.destroy();
        resolve({ enabled: true, clean: true });
      } else if (/ERROR|INSTREAM size limit exceeded/i.test(response)) {
        finished = true;
        socket.destroy();
        reject(scannerError('CLAMAV_SCAN_ERROR'));
      }
    };
    socket.setTimeout(timeoutMs, () => {
      if (finished) return;
      finished = true;
      socket.destroy();
      reject(scannerError('CLAMAV_TIMEOUT'));
    });
    socket.on('connect', () => {
      for (const frame of frames) socket.write(frame);
    });
    socket.on('data', (data) => { response += data.toString('utf8'); finish(); });
    socket.on('end', () => {
      if (!finished) {
        finished = true;
        socket.destroy();
        reject(scannerError('CLAMAV_NO_VERDICT'));
      }
    });
    socket.on('error', () => {
      if (finished) return;
      finished = true;
      reject(scannerError('CLAMAV_UNAVAILABLE'));
    });
  });
}
