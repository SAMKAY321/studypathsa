/* Optional SQL Server TDE hardening. Run as sysadmin on your own SQL Server instance after
   reviewing the local key-management/back-up procedure. Never commit the certificate/private key. */
USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'REPLACE_WITH_A_LONG_UNIQUE_SECRET_FROM_YOUR_SECRET_MANAGER';
GO
IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name = N'StudyPathTDECertificate')
    CREATE CERTIFICATE StudyPathTDECertificate WITH SUBJECT = N'StudyPath SQL Server TDE';
GO
/* Back up the certificate and private key to an access-controlled secure location before enabling TDE. */
BACKUP CERTIFICATE StudyPathTDECertificate
 TO FILE = 'D:\SQLKeyBackup\StudyPathTDECertificate.cer'
 WITH PRIVATE KEY (FILE = 'D:\SQLKeyBackup\StudyPathTDECertificate.pvk', ENCRYPTION BY PASSWORD = 'REPLACE_WITH_A_DIFFERENT_LONG_BACKUP_SECRET');
GO
USE VARSITYVAULT2;
GO
IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys WHERE database_id = DB_ID())
BEGIN
    CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256 ENCRYPTION BY SERVER CERTIFICATE StudyPathTDECertificate;
END;
GO
ALTER DATABASE VARSITYVAULT2 SET ENCRYPTION ON;
GO
USE StudyPathPilot;
GO
IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys WHERE database_id = DB_ID())
BEGIN
    CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256 ENCRYPTION BY SERVER CERTIFICATE StudyPathTDECertificate;
END;
GO
ALTER DATABASE StudyPathPilot SET ENCRYPTION ON;
GO
/* Also encrypt VarsityVaultSecurity, use encrypted client connections, least-privilege grants,
   and separately encrypt/off-site backups. Validate SQL Server version and operations first. */
