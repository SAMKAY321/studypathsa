USE StudyPathPilot;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRAN;
 /* No admissions or funding thresholds are seeded: each requires source evidence and review sign-offs. */
 IF NOT EXISTS(SELECT 1 FROM sp.FeatureFlag WHERE FeatureKey=N'pilotInstitutions')
   INSERT sp.FeatureFlag(FeatureKey,IsEnabled,ValueJson) VALUES(N'pilotInstitutions',1,N'["wsu","ufh","uj"]');
 IF NOT EXISTS(SELECT 1 FROM sp.FeatureFlag WHERE FeatureKey=N'postgraduateEnabled')
   INSERT sp.FeatureFlag(FeatureKey,IsEnabled,ValueJson) VALUES(N'postgraduateEnabled',0,N'false');
 IF NOT EXISTS(SELECT 1 FROM sp.FeatureFlag WHERE FeatureKey=N'creditTransferEnabled')
   INSERT sp.FeatureFlag(FeatureKey,IsEnabled,ValueJson) VALUES(N'creditTransferEnabled',1,N'true');
 IF NOT EXISTS(SELECT 1 FROM sp.FeatureFlag WHERE FeatureKey=N'bursaryMatchingEnabled')
   INSERT sp.FeatureFlag(FeatureKey,IsEnabled,ValueJson) VALUES(N'bursaryMatchingEnabled',1,N'true');
 IF NOT EXISTS(SELECT 1 FROM sp.FeatureFlag WHERE FeatureKey=N'researchInstrumentationEnabled')
   INSERT sp.FeatureFlag(FeatureKey,IsEnabled,ValueJson) VALUES(N'researchInstrumentationEnabled',1,N'true');
 IF NOT EXISTS(SELECT 1 FROM sp.Competitor WHERE CompetitorName=N'Careers Portal')
   INSERT sp.Competitor(CompetitorName,WebsiteUrl,LastUpdatedOn,Notes,Status) VALUES(N'Careers Portal',N'https://www.careersportal.co.za/',CONVERT(date,SYSUTCDATETIME()),N'Feature-level claims require retrieval-date evidence before publication.',N'not-verified');
 IF NOT EXISTS(SELECT 1 FROM sp.Competitor WHERE CompetitorName=N'ApplyNow')
   INSERT sp.Competitor(CompetitorName,WebsiteUrl,LastUpdatedOn,Notes,Status) VALUES(N'ApplyNow',NULL,CONVERT(date,SYSUTCDATETIME()),N'An authoritative URL and feature evidence are still required; not verified.',N'not-verified');
 COMMIT;
END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH;
GO
