USE StudyPathPilot; GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.Funder',N'U') IS NULL CREATE TABLE sp.Funder(
 FunderId BIGINT IDENTITY(1,1) PRIMARY KEY, FunderName NVARCHAR(250) NOT NULL, FunderType NVARCHAR(50) NOT NULL,
 WebsiteUrl NVARCHAR(2048), ContactUrl NVARCHAR(2048), Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Funder_Status DEFAULT N'draft',
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Funder_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Funder_Status CHECK(Status IN(N'draft',N'verified',N'stale',N'closed')));
IF OBJECT_ID(N'sp.FundingOpportunity',N'U') IS NULL CREATE TABLE sp.FundingOpportunity(
 OpportunityId BIGINT IDENTITY(1,1) PRIMARY KEY, FunderId BIGINT NOT NULL, OpportunityTitle NVARCHAR(300) NOT NULL,
 SourceUrl NVARCHAR(2048) NOT NULL, SourceTitle NVARCHAR(300) NOT NULL, SourceYear SMALLINT,
 LastUpdatedOn DATE NOT NULL, Conditions NVARCHAR(MAX) NOT NULL, ApplicationOpens DATE, ApplicationCloses DATE,
 Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Funding_Status DEFAULT N'draft', PostgraduateOnly BIT NOT NULL CONSTRAINT DF_sp_Funding_PG DEFAULT 0,
 Province NVARCHAR(100), StudyYear NVARCHAR(50), RequiredDocumentsJson NVARCHAR(MAX) NOT NULL CONSTRAINT DF_sp_Funding_Docs DEFAULT N'[]',
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Funding_Created DEFAULT SYSUTCDATETIME(), ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Funding_Modified DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Funding_Funder FOREIGN KEY(FunderId) REFERENCES sp.Funder(FunderId),
 CONSTRAINT CK_sp_Funding_Status CHECK(Status IN(N'draft',N'verified',N'stale',N'closed')),
 CONSTRAINT CK_sp_Funding_Url CHECK(SourceUrl LIKE N'https://%'), CONSTRAINT CK_sp_Funding_Dates CHECK(ApplicationCloses IS NULL OR ApplicationOpens IS NULL OR ApplicationCloses>=ApplicationOpens),
 CONSTRAINT CK_sp_Funding_Docs CHECK(ISJSON(RequiredDocumentsJson)=1));
IF OBJECT_ID(N'sp.FundingCriterion',N'U') IS NULL CREATE TABLE sp.FundingCriterion(
 CriterionId BIGINT IDENTITY(1,1) PRIMARY KEY, OpportunityId BIGINT NOT NULL, FieldName NVARCHAR(80) NOT NULL,
 Operator NVARCHAR(20) NOT NULL, CriterionValue NVARCHAR(1000) NOT NULL, CriterionLabel NVARCHAR(250) NOT NULL,
 CONSTRAINT FK_sp_FundingCriterion_Opportunity FOREIGN KEY(OpportunityId) REFERENCES sp.FundingOpportunity(OpportunityId) ON DELETE CASCADE,
 CONSTRAINT CK_sp_FundingCriterion_Operator CHECK(Operator IN(N'eq',N'lte',N'gte',N'in')));
IF OBJECT_ID(N'sp.FundingDocumentRequirement',N'U') IS NULL CREATE TABLE sp.FundingDocumentRequirement(
 RequirementId BIGINT IDENTITY(1,1) PRIMARY KEY, OpportunityId BIGINT NOT NULL, DocumentLabel NVARCHAR(250) NOT NULL,
 IsMandatory BIT NOT NULL CONSTRAINT DF_sp_FundingDoc_Mandatory DEFAULT 1, GuidanceUrl NVARCHAR(2048),
 CONSTRAINT FK_sp_FundingDoc_Opportunity FOREIGN KEY(OpportunityId) REFERENCES sp.FundingOpportunity(OpportunityId) ON DELETE CASCADE);
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'003_funding.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'003_funding.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH; GO
