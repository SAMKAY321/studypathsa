USE StudyPathPilot; GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.PilotCohort',N'U') IS NULL CREATE TABLE sp.PilotCohort(
 CohortId INT IDENTITY(1,1) PRIMARY KEY, CohortName NVARCHAR(150) NOT NULL, StartsOn DATE, EndsOn DATE,
 Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Cohort_Status DEFAULT N'planned', CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Cohort_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Cohort_Status CHECK(Status IN(N'planned',N'active',N'closed')));
IF OBJECT_ID(N'sp.PilotParticipant',N'U') IS NULL CREATE TABLE sp.PilotParticipant(
 ParticipantId BIGINT IDENTITY(1,1) PRIMARY KEY, CohortId INT NOT NULL, PersonId INT NOT NULL, PilotCode CHAR(12) NOT NULL UNIQUE,
 ConsentedAt DATETIME2(0) NOT NULL, WithdrawnAt DATETIME2(0), CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Participant_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Participant_Cohort FOREIGN KEY(CohortId) REFERENCES sp.PilotCohort(CohortId), CONSTRAINT UQ_sp_Participant_CohortPerson UNIQUE(CohortId,PersonId));
IF OBJECT_ID(N'sp.PilotEvent',N'U') IS NULL CREATE TABLE sp.PilotEvent(
 EventId BIGINT IDENTITY(1,1) PRIMARY KEY, ParticipantId BIGINT NOT NULL, EventType NVARCHAR(60) NOT NULL, EventDate DATETIME2(0) NOT NULL CONSTRAINT DF_sp_PilotEvent_Date DEFAULT SYSUTCDATETIME(),
 MetadataJson NVARCHAR(MAX) NOT NULL CONSTRAINT DF_sp_PilotEvent_Metadata DEFAULT N'{}', CONSTRAINT FK_sp_PilotEvent_Participant FOREIGN KEY(ParticipantId) REFERENCES sp.PilotParticipant(ParticipantId), CONSTRAINT CK_sp_PilotEvent_Json CHECK(ISJSON(MetadataJson)=1));
IF OBJECT_ID(N'sp.PilotBaselineTask',N'U') IS NULL CREATE TABLE sp.PilotBaselineTask(
 TaskId BIGINT IDENTITY(1,1) PRIMARY KEY, ParticipantId BIGINT NOT NULL, TaskType NVARCHAR(30) NOT NULL,
 StartedAt DATETIME2(0), FinishedAt DATETIME2(0), DurationSeconds INT, CoursesFound INT, ToolVersion NVARCHAR(30), CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Baseline_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Baseline_Participant FOREIGN KEY(ParticipantId) REFERENCES sp.PilotParticipant(ParticipantId), CONSTRAINT CK_sp_Baseline_Type CHECK(TaskType IN(N'baseline',N'studypath')), CONSTRAINT CK_sp_Baseline_Duration CHECK(DurationSeconds IS NULL OR DurationSeconds BETWEEN 0 AND 86400));
IF OBJECT_ID(N'sp.PilotSurvey',N'U') IS NULL CREATE TABLE sp.PilotSurvey(
 SurveyId BIGINT IDENTITY(1,1) PRIMARY KEY, ParticipantId BIGINT NOT NULL, SurveyStage NVARCHAR(20) NOT NULL,
 ConfidenceScore TINYINT, ClarityScore TINYINT, TimeSavedMinutes INT, UsabilityScore TINYINT, BaselineMissedDeadlines INT,
 FreeText NVARCHAR(2000), SubmittedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Survey_Submitted DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Survey_Participant FOREIGN KEY(ParticipantId) REFERENCES sp.PilotParticipant(ParticipantId), CONSTRAINT CK_sp_Survey_Stage CHECK(SurveyStage IN(N'pre',N'post')));
IF OBJECT_ID(N'sp.Competitor',N'U') IS NULL CREATE TABLE sp.Competitor(
 CompetitorId INT IDENTITY(1,1) PRIMARY KEY, CompetitorName NVARCHAR(200) NOT NULL UNIQUE, WebsiteUrl NVARCHAR(2048), LastUpdatedOn DATE NOT NULL,
 Notes NVARCHAR(2000), Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Competitor_Status DEFAULT N'not-verified', CONSTRAINT CK_sp_Competitor_Status CHECK(Status IN(N'verified',N'not-verified')));
IF OBJECT_ID(N'sp.CompetitorFeature',N'U') IS NULL CREATE TABLE sp.CompetitorFeature(
 CompetitorFeatureId BIGINT IDENTITY(1,1) PRIMARY KEY, CompetitorId INT NOT NULL, FeatureKey NVARCHAR(80) NOT NULL, FeatureLabel NVARCHAR(200) NOT NULL,
 Finding NVARCHAR(1000) NOT NULL, Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_CompetitorFeature_Status DEFAULT N'not-verified', LastUpdatedOn DATE NOT NULL,
 CONSTRAINT FK_sp_CompetitorFeature_Competitor FOREIGN KEY(CompetitorId) REFERENCES sp.Competitor(CompetitorId) ON DELETE CASCADE, CONSTRAINT UQ_sp_CompetitorFeature UNIQUE(CompetitorId,FeatureKey), CONSTRAINT CK_sp_CompetitorFeature_Status CHECK(Status IN(N'verified',N'not-verified')));
IF OBJECT_ID(N'sp.CompetitorEvidence',N'U') IS NULL CREATE TABLE sp.CompetitorEvidence(
 EvidenceId BIGINT IDENTITY(1,1) PRIMARY KEY, CompetitorFeatureId BIGINT NOT NULL, SourceUrl NVARCHAR(2048) NOT NULL, RetrievedOn DATE NOT NULL,
 SourceTitle NVARCHAR(300) NOT NULL, Notes NVARCHAR(1000), CONSTRAINT FK_sp_CompetitorEvidence_Feature FOREIGN KEY(CompetitorFeatureId) REFERENCES sp.CompetitorFeature(CompetitorFeatureId) ON DELETE CASCADE,
 CONSTRAINT CK_sp_CompetitorEvidence_Url CHECK(SourceUrl LIKE N'https://%'));
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'007_pilot_and_competitors.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'007_pilot_and_competitors.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH; GO
