USE StudyPathPilot; GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.CreditTransferGuidance',N'U') IS NULL CREATE TABLE sp.CreditTransferGuidance(
 GuidanceId BIGINT IDENTITY(1,1) PRIMARY KEY, ReceivingInstitutionCode NVARCHAR(20) NOT NULL, ProgrammeCode NVARCHAR(100) NOT NULL,
 PriorInstitution NVARCHAR(250), PriorQualification NVARCHAR(250), ModuleAlignmentJson NVARCHAR(MAX) NOT NULL CONSTRAINT DF_sp_CreditAlignment DEFAULT N'[]',
 PolicySourceId BIGINT NOT NULL, Conditions NVARCHAR(MAX) NOT NULL, LastUpdatedOn DATE NOT NULL,
 Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Credit_Status DEFAULT N'draft', ContactUrl NVARCHAR(2048),
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Credit_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Credit_Source FOREIGN KEY(PolicySourceId) REFERENCES sp.Source(SourceId),
 CONSTRAINT CK_sp_Credit_Status CHECK(Status IN(N'draft',N'verified',N'stale',N'closed')),
 CONSTRAINT CK_sp_Credit_Alignment CHECK(ISJSON(ModuleAlignmentJson)=1));
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'004_credit_transfer.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'004_credit_transfer.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH; GO
