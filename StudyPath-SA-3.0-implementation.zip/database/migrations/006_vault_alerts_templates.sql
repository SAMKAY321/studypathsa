USE StudyPathPilot; GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.DeadlineAlert',N'U') IS NULL CREATE TABLE sp.DeadlineAlert(
 AlertId BIGINT IDENTITY(1,1) PRIMARY KEY, PersonId INT NOT NULL, ItemType NVARCHAR(20) NOT NULL, ItemId BIGINT NOT NULL,
 ClosingDate DATE NOT NULL, DaysBefore TINYINT NOT NULL, Channel NVARCHAR(20) NOT NULL, Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Alert_Status DEFAULT N'pending',
 SentAt DATETIME2(0), Muted BIT NOT NULL CONSTRAINT DF_sp_Alert_Muted DEFAULT 0, ErrorCode NVARCHAR(50), CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Alert_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Alert_Type CHECK(ItemType IN(N'programme',N'funding')), CONSTRAINT CK_sp_Alert_Channel CHECK(Channel IN(N'email',N'in-app')),
 CONSTRAINT CK_sp_Alert_Status CHECK(Status IN(N'pending',N'sending',N'sent',N'failed',N'muted')), CONSTRAINT CK_sp_Alert_Days CHECK(DaysBefore IN(14,7,3,1)),
 CONSTRAINT UQ_sp_Alert_Idempotent UNIQUE(PersonId,ItemType,ItemId,DaysBefore,Channel));
IF OBJECT_ID(N'sp.DocumentTemplate',N'U') IS NULL CREATE TABLE sp.DocumentTemplate(
 TemplateId INT IDENTITY(1,1) PRIMARY KEY, TemplateSlug NVARCHAR(80) NOT NULL UNIQUE, Title NVARCHAR(200) NOT NULL,
 Summary NVARCHAR(1000) NOT NULL, FilePath NVARCHAR(500) NOT NULL, LastReviewedOn DATE NOT NULL,
 IsPublished BIT NOT NULL CONSTRAINT DF_sp_Template_Published DEFAULT 1, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Template_Created DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'sp.ChecklistItem',N'U') IS NULL CREATE TABLE sp.ChecklistItem(
 ChecklistItemId BIGINT IDENTITY(1,1) PRIMARY KEY, PersonId INT NOT NULL, ItemType NVARCHAR(20) NOT NULL, ItemId BIGINT NOT NULL,
 DocumentLabel NVARCHAR(250) NOT NULL, DocumentTypeId INT, Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Checklist_Status DEFAULT N'missing',
 DueDate DATE, LinkedDocumentId INT, UpdatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Checklist_Updated DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Checklist_ItemType CHECK(ItemType IN(N'programme',N'funding')), CONSTRAINT CK_sp_Checklist_Status CHECK(Status IN(N'missing',N'uploaded',N'verified',N'expired')));
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'006_vault_alerts_templates.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'006_vault_alerts_templates.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH; GO
