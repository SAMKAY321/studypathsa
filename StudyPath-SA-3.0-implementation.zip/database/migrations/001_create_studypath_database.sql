SET NOCOUNT ON;
SET XACT_ABORT ON;
IF DB_ID(N'StudyPathPilot') IS NULL
BEGIN
    CREATE DATABASE StudyPathPilot;
END;
GO
USE StudyPathPilot;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRAN;
    IF SCHEMA_ID(N'sp') IS NULL EXEC(N'CREATE SCHEMA sp AUTHORIZATION dbo;');
    IF OBJECT_ID(N'sp.MigrationLog', N'U') IS NULL
    BEGIN
        CREATE TABLE sp.MigrationLog (
            MigrationId NVARCHAR(100) NOT NULL CONSTRAINT PK_sp_MigrationLog PRIMARY KEY,
            AppliedOn DATETIME2(0) NOT NULL CONSTRAINT DF_sp_MigrationLog_AppliedOn DEFAULT SYSUTCDATETIME(),
            AppliedBy NVARCHAR(128) NOT NULL CONSTRAINT DF_sp_MigrationLog_AppliedBy DEFAULT ORIGINAL_LOGIN()
        );
    END;
    IF NOT EXISTS (SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'001_create_studypath_database.sql')
        INSERT sp.MigrationLog(MigrationId) VALUES(N'001_create_studypath_database.sql');
    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    THROW;
END CATCH;
GO
