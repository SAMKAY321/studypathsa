USE StudyPathPilot;
GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.Source',N'U') IS NULL CREATE TABLE sp.Source(
 SourceId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_sp_Source PRIMARY KEY,
 SourceTitle NVARCHAR(300) NOT NULL, SourceUrl NVARCHAR(2048) NOT NULL, DocumentYear SMALLINT NOT NULL,
 PageRef NVARCHAR(100), RetrievedOn DATE NOT NULL, ContentHash CHAR(64), ArchivedCopyPath NVARCHAR(500),
 SourceType NVARCHAR(30) NOT NULL CONSTRAINT DF_sp_Source_Type DEFAULT N'institution',
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Source_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Source_Url CHECK(SourceUrl LIKE N'https://%'), CONSTRAINT CK_sp_Source_Year CHECK(DocumentYear BETWEEN 2000 AND 2100));
IF OBJECT_ID(N'sp.RequirementProvenance',N'U') IS NULL CREATE TABLE sp.RequirementProvenance(
 ProvenanceId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_sp_RequirementProvenance PRIMARY KEY,
 InstitutionCode NVARCHAR(20) NOT NULL, ProgrammeCode NVARCHAR(100) NOT NULL, SourceId BIGINT NOT NULL,
 RequirementJson NVARCHAR(MAX) NOT NULL, LastUpdatedOn DATE NOT NULL, Conditions NVARCHAR(MAX) NOT NULL,
 Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Requirement_Status DEFAULT N'draft',
 CreatedByPersonId INT, CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Requirement_Created DEFAULT SYSUTCDATETIME(),
 ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Requirement_Modified DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Requirement_Source FOREIGN KEY(SourceId) REFERENCES sp.Source(SourceId),
 CONSTRAINT CK_sp_Requirement_Status CHECK(Status IN(N'draft',N'verified',N'stale',N'closed')),
 CONSTRAINT CK_sp_Requirement_Json CHECK(ISJSON(RequirementJson)=1),
 CONSTRAINT UQ_sp_Requirement_Programme UNIQUE(InstitutionCode,ProgrammeCode));
IF OBJECT_ID(N'sp.ScoringPolicyVerification',N'U') IS NULL CREATE TABLE sp.ScoringPolicyVerification(
 VerificationId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_sp_ScoringPolicyVerification PRIMARY KEY,
 InstitutionCode NVARCHAR(20) NOT NULL, ProgrammeCode NVARCHAR(100) NOT NULL, IntakeYear SMALLINT NOT NULL,
 VerificationStatus NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_Verification_Status DEFAULT N'draft',
 ProvenanceId BIGINT, RequirementJson NVARCHAR(MAX), Enabled BIT NOT NULL CONSTRAINT DF_sp_Verification_Enabled DEFAULT 0,
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Verification_Created DEFAULT SYSUTCDATETIME(),
 ModifiedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Verification_Modified DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Verification_Provenance FOREIGN KEY(ProvenanceId) REFERENCES sp.RequirementProvenance(ProvenanceId),
 CONSTRAINT CK_sp_Verification_Status CHECK(VerificationStatus IN(N'draft',N'verified',N'stale',N'closed')),
 CONSTRAINT CK_sp_Verification_Json CHECK(RequirementJson IS NULL OR ISJSON(RequirementJson)=1),
 CONSTRAINT UQ_sp_Verification_Programme UNIQUE(InstitutionCode,ProgrammeCode,IntakeYear));
IF OBJECT_ID(N'sp.VerificationSignoff',N'U') IS NULL CREATE TABLE sp.VerificationSignoff(
 SignoffId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_sp_VerificationSignoff PRIMARY KEY,
 VerificationId BIGINT NOT NULL, ReviewerPersonId INT NOT NULL, ReviewerRole NVARCHAR(30) NOT NULL,
 Decision NVARCHAR(20) NOT NULL, Notes NVARCHAR(1000), SignedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Signoff_Signed DEFAULT SYSUTCDATETIME(),
 CONSTRAINT FK_sp_Signoff_Verification FOREIGN KEY(VerificationId) REFERENCES sp.ScoringPolicyVerification(VerificationId),
 CONSTRAINT CK_sp_Signoff_Decision CHECK(Decision IN(N'approve',N'reject')),
 CONSTRAINT CK_sp_Signoff_Role CHECK(ReviewerRole IN(N'admin',N'representative')),
 CONSTRAINT UQ_sp_Signoff_Reviewer UNIQUE(VerificationId,ReviewerPersonId));
IF OBJECT_ID(N'sp.trg_VerifiedNeedsTwoSignoffs',N'TR') IS NULL
EXEC(N'CREATE TRIGGER sp.trg_VerifiedNeedsTwoSignoffs ON sp.ScoringPolicyVerification AFTER INSERT, UPDATE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS (SELECT 1 FROM inserted i WHERE i.VerificationStatus=N''verified'' AND
   (i.ProvenanceId IS NULL OR (SELECT COUNT(DISTINCT s.ReviewerPersonId) FROM sp.VerificationSignoff s WHERE s.VerificationId=i.VerificationId AND s.Decision=N''approve'')<2))
 BEGIN RAISERROR(''A verified policy requires provenance and two independent approvals.'',16,1); ROLLBACK TRANSACTION; RETURN; END
END');
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'002_trust_and_verification.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'002_trust_and_verification.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH;
GO
