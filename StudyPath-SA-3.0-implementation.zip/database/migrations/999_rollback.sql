/* Destructive rollback: only drops StudyPathPilot objects; never touches VARSITYVAULT2. Run only after backup/approval. */
USE StudyPathPilot;
GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRAN;
 IF OBJECT_ID(N'sp.vw_PilotOutcomes',N'V') IS NOT NULL DROP VIEW sp.vw_PilotOutcomes;
 IF OBJECT_ID(N'sp.vw_RecommendationProvenance',N'V') IS NOT NULL DROP VIEW sp.vw_RecommendationProvenance;
 IF OBJECT_ID(N'sp.vw_StaleRecords',N'V') IS NOT NULL DROP VIEW sp.vw_StaleRecords;
 IF OBJECT_ID(N'sp.trg_VerifiedNeedsTwoSignoffs',N'TR') IS NOT NULL DROP TRIGGER sp.trg_VerifiedNeedsTwoSignoffs;
 IF OBJECT_ID(N'sp.CompetitorEvidence',N'U') IS NOT NULL DROP TABLE sp.CompetitorEvidence;
 IF OBJECT_ID(N'sp.CompetitorFeature',N'U') IS NOT NULL DROP TABLE sp.CompetitorFeature;
 IF OBJECT_ID(N'sp.Competitor',N'U') IS NOT NULL DROP TABLE sp.Competitor;
 IF OBJECT_ID(N'sp.PilotSurvey',N'U') IS NOT NULL DROP TABLE sp.PilotSurvey;
 IF OBJECT_ID(N'sp.PilotBaselineTask',N'U') IS NOT NULL DROP TABLE sp.PilotBaselineTask;
 IF OBJECT_ID(N'sp.PilotEvent',N'U') IS NOT NULL DROP TABLE sp.PilotEvent;
 IF OBJECT_ID(N'sp.PilotParticipant',N'U') IS NOT NULL DROP TABLE sp.PilotParticipant;
 IF OBJECT_ID(N'sp.PilotCohort',N'U') IS NOT NULL DROP TABLE sp.PilotCohort;
 IF OBJECT_ID(N'sp.ChecklistItem',N'U') IS NOT NULL DROP TABLE sp.ChecklistItem;
 IF OBJECT_ID(N'sp.DocumentTemplate',N'U') IS NOT NULL DROP TABLE sp.DocumentTemplate;
 IF OBJECT_ID(N'sp.DeadlineAlert',N'U') IS NOT NULL DROP TABLE sp.DeadlineAlert;
 IF OBJECT_ID(N'sp.RetentionPolicy',N'U') IS NOT NULL DROP TABLE sp.RetentionPolicy;
 IF OBJECT_ID(N'sp.DataSubjectRequest',N'U') IS NOT NULL DROP TABLE sp.DataSubjectRequest;
 IF OBJECT_ID(N'sp.DocumentAccessLog',N'U') IS NOT NULL DROP TABLE sp.DocumentAccessLog;
 IF OBJECT_ID(N'sp.LearnerFinancialProfile',N'U') IS NOT NULL DROP TABLE sp.LearnerFinancialProfile;
 IF OBJECT_ID(N'sp.Consent',N'U') IS NOT NULL DROP TABLE sp.Consent;
 IF OBJECT_ID(N'sp.CreditTransferGuidance',N'U') IS NOT NULL DROP TABLE sp.CreditTransferGuidance;
 IF OBJECT_ID(N'sp.FundingDocumentRequirement',N'U') IS NOT NULL DROP TABLE sp.FundingDocumentRequirement;
 IF OBJECT_ID(N'sp.FundingCriterion',N'U') IS NOT NULL DROP TABLE sp.FundingCriterion;
 IF OBJECT_ID(N'sp.FundingOpportunity',N'U') IS NOT NULL DROP TABLE sp.FundingOpportunity;
 IF OBJECT_ID(N'sp.Funder',N'U') IS NOT NULL DROP TABLE sp.Funder;
 IF OBJECT_ID(N'sp.FeatureFlag',N'U') IS NOT NULL DROP TABLE sp.FeatureFlag;
 IF OBJECT_ID(N'sp.VerificationSignoff',N'U') IS NOT NULL DROP TABLE sp.VerificationSignoff;
 IF OBJECT_ID(N'sp.ScoringPolicyVerification',N'U') IS NOT NULL DROP TABLE sp.ScoringPolicyVerification;
 IF OBJECT_ID(N'sp.RequirementProvenance',N'U') IS NOT NULL DROP TABLE sp.RequirementProvenance;
 IF OBJECT_ID(N'sp.Source',N'U') IS NOT NULL DROP TABLE sp.Source;
 IF OBJECT_ID(N'sp.MigrationLog',N'U') IS NOT NULL DROP TABLE sp.MigrationLog;
 COMMIT;
END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH;
GO
/* Database itself is intentionally not dropped. */
