USE StudyPathPilot; GO
SET NOCOUNT ON; SET XACT_ABORT ON;
BEGIN TRY BEGIN TRAN;
IF OBJECT_ID(N'sp.Consent',N'U') IS NULL CREATE TABLE sp.Consent(
 ConsentId BIGINT IDENTITY(1,1) PRIMARY KEY, PersonId INT NOT NULL, Purpose NVARCHAR(60) NOT NULL, PolicyVersion NVARCHAR(40) NOT NULL,
 Granted BIT NOT NULL, GrantedAt DATETIME2(0), WithdrawnAt DATETIME2(0), GuardianConfirmed BIT NOT NULL CONSTRAINT DF_sp_Consent_Guardian DEFAULT 0,
 GuardianConfirmedAt DATETIME2(0), AgeAttested BIT NOT NULL CONSTRAINT DF_sp_Consent_AgeAttested DEFAULT 0, AgeAttestedAt DATETIME2(0), CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Consent_Created DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Consent_Purpose CHECK(Purpose IN(N'process-results',N'funding-matching',N'share-with-school',N'pilot-research',N'email-reminders',N'document-processing')),
 CONSTRAINT UQ_sp_Consent_PersonPurposeVersion UNIQUE(PersonId,Purpose,PolicyVersion));
IF OBJECT_ID(N'sp.LearnerFinancialProfile',N'U') IS NULL CREATE TABLE sp.LearnerFinancialProfile(
 PersonId INT NOT NULL PRIMARY KEY, EncryptedPayload VARBINARY(MAX) NOT NULL, KeyId NVARCHAR(40) NOT NULL,
 CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_FinProfile_Created DEFAULT SYSUTCDATETIME(), UpdatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_FinProfile_Updated DEFAULT SYSUTCDATETIME());
IF OBJECT_ID(N'sp.DocumentAccessLog',N'U') IS NULL CREATE TABLE sp.DocumentAccessLog(
 AccessLogId BIGINT IDENTITY(1,1) PRIMARY KEY, PersonId INT NOT NULL, DocumentId INT NOT NULL, AccessedByPersonId INT NOT NULL,
 AccessedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_DocumentAccess_Date DEFAULT SYSUTCDATETIME(), Purpose NVARCHAR(150) NOT NULL, Role NVARCHAR(30) NOT NULL);
IF OBJECT_ID(N'sp.DataSubjectRequest',N'U') IS NULL CREATE TABLE sp.DataSubjectRequest(
 RequestId BIGINT IDENTITY(1,1) PRIMARY KEY, PersonId INT NOT NULL, RequestType NVARCHAR(20) NOT NULL,
 Status NVARCHAR(20) NOT NULL CONSTRAINT DF_sp_DSR_Status DEFAULT N'received', RequestedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_DSR_Requested DEFAULT SYSUTCDATETIME(),
 ScheduledFor DATETIME2(0), CompletedAt DATETIME2(0), ConfirmationHash CHAR(64), Notes NVARCHAR(1000),
 CONSTRAINT CK_sp_DSR_Type CHECK(RequestType IN(N'export',N'delete')), CONSTRAINT CK_sp_DSR_Status CHECK(Status IN(N'received',N'scheduled',N'processing',N'completed',N'cancelled',N'failed')));
IF OBJECT_ID(N'sp.RetentionPolicy',N'U') IS NULL CREATE TABLE sp.RetentionPolicy(
 PolicyId INT IDENTITY(1,1) PRIMARY KEY, RecordType NVARCHAR(80) NOT NULL UNIQUE, RetentionDays INT NOT NULL,
 Enabled BIT NOT NULL CONSTRAINT DF_sp_Retention_Enabled DEFAULT 1, UpdatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_sp_Retention_Updated DEFAULT SYSUTCDATETIME(),
 CONSTRAINT CK_sp_Retention_Days CHECK(RetentionDays BETWEEN 1 AND 7300));
IF NOT EXISTS(SELECT 1 FROM sp.RetentionPolicy WHERE RecordType=N'inactive-account') INSERT sp.RetentionPolicy(RecordType,RetentionDays) VALUES(N'inactive-account',730);
IF NOT EXISTS(SELECT 1 FROM sp.RetentionPolicy WHERE RecordType=N'expired-document') INSERT sp.RetentionPolicy(RecordType,RetentionDays) VALUES(N'expired-document',365);
IF NOT EXISTS(SELECT 1 FROM sp.RetentionPolicy WHERE RecordType=N'rejected-document') INSERT sp.RetentionPolicy(RecordType,RetentionDays) VALUES(N'rejected-document',365);
IF NOT EXISTS(SELECT 1 FROM sp.MigrationLog WHERE MigrationId=N'005_privacy.sql') INSERT sp.MigrationLog(MigrationId) VALUES(N'005_privacy.sql');
COMMIT; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; THROW; END CATCH; GO
