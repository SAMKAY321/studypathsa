import { assessSubjects } from './subjects.js';

const validMark = (value) => Number.isFinite(value) && value >= 0 && value <= 100;

export function validateHypotheticalMarks(input) {
  if (!Array.isArray(input) || input.length > 20) throw new Error('Provide at most 20 hypothetical subjects.');
  const seen = new Set();
  return input.map((row) => {
    if (!row || typeof row.SUBJECT_CODE !== 'string' || !row.SUBJECT_CODE.trim())
      throw new Error('Each hypothetical subject needs a subject code.');
    const code = row.SUBJECT_CODE.trim().toUpperCase();
    if (seen.has(code)) throw new Error('Duplicate subjects are not allowed in a hypothetical profile.');
    seen.add(code);
    if (!validMark(row.PERCENTAGE)) throw new Error('Marks must be numeric percentages from 0 to 100.');
    if (typeof row.SUBJECT_CATEGORY !== 'string' || !row.SUBJECT_CATEGORY.trim())
      throw new Error('Each subject needs its category.');
    return {
      ...row,
      SUBJECT_CODE: code,
      SUBJECT_CATEGORY: row.SUBJECT_CATEGORY.trim().toUpperCase(),
      PERCENTAGE: row.PERCENTAGE,
    };
  });
}

export function runWhatIf(baseSubjects, changes, policy, config) {
  const base = validateHypotheticalMarks(baseSubjects);
  const changed = validateHypotheticalMarks(changes ?? baseSubjects);
  const before = assessSubjects(base, policy, config);
  const after = assessSubjects(changed, policy, config);
  return {
    saved: false,
    label: 'Hypothetical — not saved',
    before: { total: before.total, status: before.status, eligible: before.eligible, issues: before.issues },
    after: { total: after.total, status: after.status, eligible: after.eligible, issues: after.issues },
    delta: Number.isFinite(before.total) && Number.isFinite(after.total) ? after.total - before.total : null,
    outcome: before.eligible === after.eligible ? 'unchanged' : after.eligible ? 'gained' : 'lost',
    disclaimer: 'Hypothetical — not saved. Results are indicative and do not guarantee admission.',
  };
}

export function unsuitableApplicationReason(subjects, config) {
  const codes = new Set(subjects.map((row) => row.SUBJECT_CODE));
  const needsMath = (config?.requiredCodes || []).some((code) => /^(MAT|MATH)/i.test(code) && !/LIT/i.test(code)) ||
    Object.keys(config?.subjectMinimums || {}).some((code) => /^(MAT|MATH)/i.test(code) && !/LIT/i.test(code)) ||
    (config?.subjectGroups || []).some((group) => /^(MAT|MATH)/i.test(group.code || '') && !/LIT/i.test(group.code || '')) ||
    Boolean(config?.requiresMathematics);
  const hasMath = subjects.some((row) => row.SUBJECT_CATEGORY === 'MATHEMATICS' || /^(MAT|MATH)/i.test(row.SUBJECT_CODE) && !/LIT/i.test(row.SUBJECT_CODE));
  const hasLit = subjects.some((row) => row.SUBJECT_CATEGORY === 'MATHEMATICAL_LITERACY' || /^(MAT|MATH).*LIT/i.test(row.SUBJECT_CODE));
  if (needsMath && !hasMath && hasLit)
    return 'This programme requires Mathematics; your profile has Mathematical Literacy. Check the institution’s requirements before applying.';
  const missing = (config?.requiredCodes || []).filter((code) => !codes.has(code));
  return missing.length ? `Your profile is missing required subject(s): ${missing.join(', ')}.` : null;
}
