import { evaluateConfiguredScoring } from './policy-engine.js';

export function validateScoring(scoring, codes) {
  if (scoring == null) return null;
  const fail = (message) => {
    throw new Error(message);
  };
  if (!['BANDS', 'RAW'].includes(scoring.mode)) fail('Choose bands or percentage scoring.');
  if (!Number.isInteger(scoring.count) || scoring.count < 1 || scoring.count > 10)
    fail('Count between 1 and 10 subjects.');
  if (!Number.isFinite(scoring.divisor) || scoring.divisor <= 0 || scoring.divisor > 1000)
    fail('Use a positive score divisor, at most 1000.');
  if (!Number.isFinite(scoring.floor) || scoring.floor < 0 || scoring.floor > 100)
    fail('The scoring floor must be 0–100.');
  if (typeof scoring.label !== 'string' || !scoring.label.trim() || scoring.label.length > 80)
    fail('Give the score a label of up to 80 characters.');
  if (!Array.isArray(scoring.exclude) || scoring.exclude.some((c) => !codes.has(c)))
    fail('Excluded subjects must exist in the subject directory.');
  if (!Array.isArray(scoring.bands) || scoring.bands.length > 30)
    fail('Use at most 30 scoring bands.');
  const bands = [...scoring.bands].sort((a, b) => a[0] - b[0]);
  if (scoring.mode === 'BANDS') {
    let next = 0;
    for (const band of bands) {
      if (
        !Array.isArray(band) ||
        band.length !== 3 ||
        !band.every(Number.isFinite) ||
        band[0] !== next ||
        band[1] <= band[0] ||
        band[1] > 101 ||
        band[2] < 0 ||
        band[2] > 1000
      )
        fail(
          'Bands must cover 0 through 100 without gaps or overlaps; the last upper boundary is 101.',
        );
      next = band[1];
    }
    if (next !== 101) fail('Scoring bands must cover all marks through 100.');
  }
  const overrides = scoring.overrides ?? [];
  if (!Array.isArray(overrides) || overrides.length > 100) fail('Too many subject weightings.');
  const seen = new Set();
  for (const o of overrides) {
    if (
      !Array.isArray(o.codes) ||
      o.codes.length !== 1 ||
      !codes.has(o.codes[0]) ||
      seen.has(o.codes[0]) ||
      !Number.isFinite(o.weight) ||
      o.weight <= 0 ||
      o.weight > 10
    )
      fail(
        'Each weighting needs one unique known subject and a multiplier above 0 and at most 10.',
      );
    seen.add(o.codes[0]);
  }
  return {
    version: 1,
    qualification: 'NSC',
    status: 'READY',
    mode: scoring.mode,
    count: scoring.count,
    divisor: scoring.divisor,
    floor: scoring.floor,
    label: scoring.label.trim(),
    bands,
    exclude: [...new Set(scoring.exclude)],
    overrides: overrides.map((o) => ({ codes: o.codes, weight: o.weight })),
    groups: [],
    bonuses: [],
    requirements: 'SELECTED',
  };
}

export function validateGroups(groups, codes) {
  if (groups == null) return [];
  if (!Array.isArray(groups) || groups.length > 100)
    throw new Error('Use at most 100 subject requirements.');
  const seen = new Set();
  return groups.map((r) => {
    const key = r.group + ':' + r.code;
    if (
      !Number.isInteger(r.group) ||
      r.group < 1 ||
      r.group > 100 ||
      !codes.has(r.code) ||
      !Number.isFinite(r.minimum) ||
      r.minimum < 0 ||
      r.minimum > 100 ||
      seen.has(key)
    )
      throw new Error(
        'Each requirement needs a group from 1–100, a known subject and a minimum percentage from 0–100. Do not repeat a subject in the same group.',
      );
    seen.add(key);
    return { group: r.group, code: r.code, minimum: r.minimum };
  });
}

export function configuredAssessment(records, config) {
  const reqs = [...(config.subjectGroups || [])];
  let group = 101;
  for (const code of config.requiredCodes || []) reqs.push({ group: group++, code, minimum: 0 });
  const report = evaluateConfiguredScoring(
    config.scoring,
    records.map((r) => ({ id: r.SUBJECT_ID, code: r.SUBJECT_CODE, mark: r.PERCENTAGE })),
    reqs,
  );
  const result = {
    total: null,
    contributions: [],
    eligible: false,
    status: report.message || report.status,
    issues: [],
    metric: config.scoring.label,
  };
  if (report.status !== 'OK') {
    result.issues.push(report.message || 'Scoring could not be completed.');
    return result;
  }
  result.total = report.score;
  result.contributions = report.selected.map((r) => ({
    ...records.find((s) => s.SUBJECT_CODE === r.code),
    points: r.points_before_divisor / report.divisor,
  }));
  if (
    config.status !== 'verified' ||
    (config.intake !== 2028 && config.allowPilotYear !== true) ||
    !Number.isFinite(config.minScore) ||
    !String(config.source).startsWith('https://')
  ) {
    result.status = 'Programme requirements pending verification';
    return result;
  }
  if (result.total < config.minScore)
    result.issues.push('Below minimum ' + config.scoring.label + ' of ' + config.minScore + '.');
  const best = (filter) => Math.max(-1, ...records.filter(filter).map((r) => r.PERCENTAGE));
  if (
    config.minEnglish != null &&
    best((r) => /^ENG(HL|FAL)$/.test(r.SUBJECT_CODE)) < config.minEnglish
  )
    result.issues.push('English requirement not met.');
  if (
    config.minMath != null &&
    best((r) => ['MATHEMATICS', 'MATHEMATICAL_LITERACY'].includes(r.SUBJECT_CATEGORY)) <
      config.minMath
  )
    result.issues.push('Mathematics or Mathematical Literacy requirement not met.');
  for (const [code, min] of Object.entries(config.subjectMinimums || {}))
    if (best((r) => r.SUBJECT_CODE === code) < min) result.issues.push(code + ' minimum not met.');
  result.eligible = result.issues.length === 0;
  result.status = result.eligible ? 'Listed minimum requirements met' : 'Below listed requirements';
  return result;
}

export function offeringAvailability(config, closingDate, now = new Date()) {
  if (config.active === false) return 'Inactive';
  if (config.status !== 'verified') return 'Requirements pending verification';
  // SQL Server DATE values arrive as Date objects before JSON serialization.
  const close =
    closingDate instanceof Date
      ? Number.isNaN(closingDate.getTime())
        ? ''
        : closingDate.toISOString().slice(0, 10)
      : String(closingDate || '')
          .trim()
          .slice(0, 10);
  const valid = (d) =>
    /^\d{4}-\d{2}-\d{2}$/.test(d) &&
    !Number.isNaN(Date.parse(d)) &&
    new Date(d).toISOString().slice(0, 10) === d;
  const open = config.openingDate;
  if (!valid(close) || (open && (!valid(open) || open > close))) return 'Invalid dates';
  const time = config.closingTime ?? '23:59';
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return 'Invalid closing time';
  if (open && now < new Date(open + 'T00:00:00+02:00')) return 'Not yet open';
  return now >= new Date(close + 'T' + time + ':00+02:00') ? 'Closed' : 'Open';
}
