/**
 * Attach current subject catalogue metadata to learner result rows.
 *
 * SQL Server/seeded/local data can expose integer identifiers as either numbers
 * or numeric strings depending on the adapter and source. Normalize IDs before
 * joining, otherwise results lose SUBJECT_CODE/SUBJECT_CATEGORY and APS review
 * incorrectly reports that no complete results exist.
 */
function normalizedId(value) {
  if (value === null || value === undefined || String(value).trim() === '') return null;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? String(numeric) : String(value).trim();
}

export function attachSubjectsToResults(resultRows, subjects) {
  const subjectsById = new Map();
  for (const subject of subjects) {
    const key = normalizedId(subject.SUBJECT_ID);
    if (key !== null) subjectsById.set(key, subject);
  }

  return resultRows.map((row) => {
    const subject = subjectsById.get(normalizedId(row.SUBJECT_ID));
    if (!subject) {
      return {
        ...row,
        SUBJECT_NAME: row.SUBJECT_NAME || `Unknown subject (${row.SUBJECT_ID ?? 'missing ID'})`,
      };
    }
    // The saved result's values/status take precedence; catalogue metadata fills
    // the fields required by display and APS calculations.
    return { ...subject, ...row };
  });
}
