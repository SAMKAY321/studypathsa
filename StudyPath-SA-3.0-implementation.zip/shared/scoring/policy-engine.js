// Configurable scoring and admission-route evaluators. Reviewed policy data must supply the rules.
const reply = (status, message) => ({ status, message });
const number = (n) => typeof n === 'number' && Number.isFinite(n);
const includes = (a, value) => Array.isArray(a) && a.includes(value);
function points(bands, mark) {
  if (!Array.isArray(bands)) throw new Error('Missing scoring bands');
  const matches = bands.filter((b) => Array.isArray(b) && mark >= b[0] && mark < b[1]);
  if (matches.length !== 1 || !number(matches[0][2]))
    throw new Error('Scoring bands missing or overlapping');
  return matches[0][2];
}
export function evaluateConfiguredScoring(cfg, marks, requirements = [], quintile = null) {
  try {
    if (cfg?.version !== 1 || cfg.qualification !== 'NSC')
      return reply('CONFIG_ERROR', 'Unsupported policy version or qualification');
    if (cfg.status !== 'READY') return reply('REVIEW_REQUIRED', cfg.note || 'Policy needs review');
    const { count, divisor, mode } = cfg;
    if (
      !Number.isInteger(count) ||
      count < 1 ||
      count > 10 ||
      !number(divisor) ||
      divisor <= 0 ||
      !['BANDS', 'RAW'].includes(mode) ||
      !['SELECTED', 'ALL'].includes(cfg.requirements)
    )
      return reply('CONFIG_ERROR', 'Invalid scoring parameters');
    if (!Array.isArray(marks) || !Array.isArray(requirements)) throw new Error('Invalid inputs');
    if (cfg.max_input != null && marks.length > cfg.max_input)
      return reply('REVIEW_REQUIRED', 'Extra-subject selection requires programme review');
    if (marks.length > 20) return reply('INPUT_ERROR', 'At most 20 NSC subjects are supported');
    for (const key of ['exclude', 'overrides', 'groups', 'bonuses', 'bands'])
      if (!Array.isArray(cfg[key])) throw new Error('Missing policy array: ' + key);
    if (cfg.groups.length > 40 || requirements.length > 100)
      throw new Error('Too many subject rules');
    const seen = new Set(),
      rows = [];
    let lo = null;
    for (const m of marks) {
      const code = typeof m.code === 'string' ? m.code.trim().toUpperCase() : '';
      if (!code || !number(m.mark) || m.mark < 0 || m.mark > 100)
        return reply('INPUT_ERROR', 'Subject code or percentage is invalid');
      if (seen.has(code)) return reply('INPUT_ERROR', 'Duplicate subject code');
      seen.add(code);
      if (code === 'LO') lo = m.mark;
      if (includes(cfg.exclude, code)) continue;
      let p = mode === 'RAW' ? m.mark : points(cfg.bands, m.mark),
        weight = 1;
      for (const override of cfg.overrides)
        if (includes(override.codes, code)) {
          if (override.bands) p = points(override.bands, m.mark);
          if ('weight' in override) weight = override.weight;
        }
      if (m.mark < cfg.floor) p = 0;
      if (!number(p) || !number(weight) || weight <= 0)
        throw new Error('Invalid subject points or weighting');
      rows.push({
        subject_id: m.id ?? null,
        code,
        mark: m.mark,
        points_before_divisor: p * weight,
      });
    }
    if (rows.length < count) return reply('INCOMPLETE', 'Not enough eligible subjects');
    let bonus = 0;
    for (const b of cfg.bonuses) {
      if (b.subject !== 'LO') throw new Error('Unsupported bonus input');
      if (lo == null)
        return reply('INCOMPLETE', 'Life Orientation mark needed for bonus calculation');
      let eligible = lo >= b.minimum;
      if (eligible && b.quintiles) {
        if (quintile == null)
          return reply('CONTEXT_REQUIRED', 'Verified school quintile is required');
        eligible = includes(b.quintiles, quintile);
      }
      if (eligible) {
        if (!number(b.points)) throw new Error('Invalid bonus points');
        bonus += b.points;
      }
    }
    const valid = (selected) =>
      cfg.groups.every((g) => {
        const n = selected.filter((r) => includes(g.codes, r.code)).length;
        return n >= g.min && n <= g.max;
      }) &&
      (cfg.requirements !== 'SELECTED' ||
        requirements.every((r) =>
          requirements.some(
            (other) =>
              other.group === r.group &&
              selected.some((m) => m.code === other.code && m.mark >= other.minimum),
          ),
        ));
    let best = null,
      selected = [];
    function choose(start, picked, total) {
      if (picked.length === count) {
        if (valid(picked) && (best == null || total > best)) {
          best = total;
          selected = [...picked];
        }
        return;
      }
      for (let i = start; i <= rows.length - (count - picked.length); i++) {
        picked.push(rows[i]);
        choose(i + 1, picked, total + rows[i].points_before_divisor);
        picked.pop();
      }
    }
    choose(0, [], 0);
    if (best == null)
      return reply(
        'NO_VALID_SELECTION',
        'Languages or required subjects cannot form a valid selection',
      );
    return {
      status: 'OK',
      score: Math.round((best / divisor + bonus + Number.EPSILON) * 100) / 100,
      label: cfg.label,
      bonus,
      divisor,
      selected,
      ...(quintile == null ? {} : { school_quintile: quintile }),
    };
  } catch (e) {
    return reply('CONFIG_ERROR', 'Policy or input cannot be evaluated: ' + e.message);
  }
}

export function evaluateAdmissionRoutes(config, marks, base, examType = '') {
  const has = (a, code) =>
    Array.isArray(a) && a.some((v) => String(v).trim().toUpperCase() === code);
  try {
    if (!number(base) || base < 0)
      return reply('CONFIG_ERROR', 'Minimum academic score is missing or invalid');
    if (config == null)
      return { status: 'OK', required_score: base, route_label: 'Standard requirements' };
    if (config.version !== 1) throw new Error('Unsupported admission route version');
    if ('accepted_exam_types' in config) {
      if (!Array.isArray(config.accepted_exam_types) || !config.accepted_exam_types.length)
        throw new Error('Accepted examination stages are missing');
      if (!has(config.accepted_exam_types, examType.trim().toUpperCase()))
        return reply(
          'RESULT_STAGE_NOT_ALLOWED',
          'This examination stage is not accepted for this offering',
        );
    }
    if (
      !Array.isArray(config.routes) ||
      config.routes.length < 1 ||
      config.routes.length > 50 ||
      !Array.isArray(marks) ||
      marks.length > 20
    )
      throw new Error('Invalid number of admission routes or subjects');
    const seen = new Set();
    const normalized = marks.map((m) => ({
      ...m,
      code: String(m.code || '')
        .trim()
        .toUpperCase(),
    }));
    for (const m of normalized) {
      if (!m.code || !number(m.mark) || m.mark < 0 || m.mark > 100)
        return reply('INPUT_ERROR', 'Invalid subject code or percentage');
      if (seen.has(m.code)) return reply('INPUT_ERROR', 'Duplicate subject code');
      seen.add(m.code);
    }
    let best = null;
    for (const route of config.routes) {
      if (
        !number(route.minimum_score) ||
        route.minimum_score < base ||
        !route.label ||
        !Array.isArray(route.groups) ||
        !route.groups.length ||
        route.groups.length > 20
      )
        throw new Error('Admission route is incomplete or below the base minimum');
      let ok = true;
      for (const g of route.groups) {
        if (
          !Number.isInteger(g.count) ||
          g.count < 1 ||
          g.count > 20 ||
          !number(g.minimum) ||
          g.minimum < 0 ||
          g.minimum > 100 ||
          (g.codes && !g.codes.length)
        )
          throw new Error('Invalid admission subject count or minimum');
        if (
          g.minimum_points != null &&
          (!number(g.minimum_points) || g.minimum_points < 0 || g.minimum_points > 7 * g.count)
        )
          throw new Error('Invalid additional-subject NSC points total');
        const qualified = normalized.filter((m) => {
          const threshold = g.minimums?.[m.code] ?? g.minimum;
          if (!number(threshold) || threshold < 0 || threshold > 100)
            throw new Error('Invalid subject-specific threshold');
          return (
            (!g.codes || has(g.codes, m.code)) &&
            !has(g.exclude_codes, m.code) &&
            m.mark >= threshold
          );
        });
        const p = qualified
          .map((m) =>
            m.mark >= 80
              ? 7
              : m.mark >= 70
                ? 6
                : m.mark >= 60
                  ? 5
                  : m.mark >= 50
                    ? 4
                    : m.mark >= 40
                      ? 3
                      : m.mark >= 30
                        ? 2
                        : 1,
          )
          .sort((a, b) => b - a)
          .slice(0, g.count)
          .reduce((a, b) => a + b, 0);
        if (qualified.length < g.count || (g.minimum_points != null && p < g.minimum_points))
          ok = false;
      }
      if (ok && (best == null || route.minimum_score < best.required_score))
        best = { status: 'OK', required_score: route.minimum_score, route_label: route.label };
    }
    return best || reply('NO_ROUTE', 'Admission route subject requirements not met');
  } catch (e) {
    return reply('CONFIG_ERROR', e.message);
  }
}
