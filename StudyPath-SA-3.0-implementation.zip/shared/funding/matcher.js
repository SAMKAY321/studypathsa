const known = (value) => value !== undefined && value !== null && value !== '';

export function compareFundingCriteria(criteria, profile) {
  const checks = (criteria || []).map((criterion) => {
    const actual = profile?.[criterion.field];
    if (!known(actual)) return { field: criterion.field, expected: criterion.value, actual: null, result: 'unknown' };
    let match;
    if (criterion.operator === 'lte') match = Number(actual) <= Number(criterion.value);
    else if (criterion.operator === 'gte') match = Number(actual) >= Number(criterion.value);
    else if (criterion.operator === 'in') match = Array.isArray(criterion.value) && criterion.value.includes(actual);
    else match = String(actual).toLowerCase() === String(criterion.value).toLowerCase();
    return { field: criterion.field, expected: criterion.value, actual, result: match ? 'match' : 'no-match' };
  });
  const missing = checks.some((check) => check.result === 'unknown');
  const mismatch = checks.some((check) => check.result === 'no-match');
  return {
    criteriaCompared: checks,
    label: mismatch ? 'Does not match on known criteria' : missing ? 'Possibly eligible — check' : 'May be eligible',
    matchesKnownCriteria: !mismatch,
    needsVerification: true,
  };
}

export function isFundingOpportunityActionable(opportunity, today = new Date().toISOString().slice(0, 10)) {
  if (!opportunity || opportunity.Status !== 'verified') return false;
  if (!opportunity.SourceUrl || !opportunity.SourceTitle || !opportunity.LastUpdatedOn || !opportunity.Conditions) return false;
  if (opportunity.ApplicationCloses && String(opportunity.ApplicationCloses).slice(0, 10) < today) return false;
  const updated = Date.parse(opportunity.LastUpdatedOn);
  if (!Number.isFinite(updated) || (Date.parse(today) - updated) / 86400000 > 90) return false;
  return true;
}
