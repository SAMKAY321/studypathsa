export const DISCLAIMERS = Object.freeze({
  eligibility:
    'Guidance only. Meeting a published minimum does not guarantee admission; selection, space, NBTs and final results may affect the outcome.',
  funding:
    'Verify with the institution/funder before applying. Criteria, funding and deadlines change.',
  creditTransfer:
    'Guidance only — each institution decides credit and exemption. Final decision by the institution.',
  hypothetical: 'Hypothetical — not saved. Results are indicative and do not guarantee admission.',
  accuracy: 'Not yet verified. We cannot calculate a reliable outcome until the rule is verified.',
  privacy: 'Your data is used only for the purposes you consent to. You can withdraw consent and request access or deletion.',
});

export function disclaimer(key) {
  if (!(key in DISCLAIMERS)) throw new Error('Unknown disclaimer key.');
  return DISCLAIMERS[key];
}
