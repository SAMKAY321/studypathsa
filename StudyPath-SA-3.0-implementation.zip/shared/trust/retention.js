const dayMs = 24 * 60 * 60 * 1000;

export function retentionCutoff(asOf, retentionDays) {
  const anchor = asOf instanceof Date ? asOf : new Date(asOf);
  const days = Number(retentionDays);
  if (!Number.isFinite(anchor.getTime()) || !Number.isInteger(days) || days < 1 || days > 7300) {
    throw new TypeError('Retention date or retention period is invalid.');
  }
  return new Date(anchor.getTime() - days * dayMs).toISOString().slice(0, 10);
}

export function collectRejectedDocumentCandidates({ documents, statuses, retentionDays, asOf = new Date() }) {
  const cutoff = retentionCutoff(asOf, retentionDays);
  const rejectedIds = new Set(statuses.filter((row) => String(row.VERIFICATION_STATUS_NAME || '').toLowerCase() === 'rejected').map((row) => String(row.VERIFICATION_STATUS_ID)));
  return documents.filter((doc) => {
    const uploaded = String(doc.UPLOAD_DATE || '').slice(0, 10);
    return rejectedIds.has(String(doc.VERIFICATION_STATUS_ID)) && /^\d{4}-\d{2}-\d{2}$/.test(uploaded) && uploaded <= cutoff;
  }).map((doc) => ({ documentId: Number(doc.DOCUMENT_ID), personId: Number(doc.PERSON_ID), uploadDate: String(doc.UPLOAD_DATE).slice(0, 10), cutoff }));
}

export function validateRetentionManifest(manifest, candidates, asOf = new Date()) {
  if (!Array.isArray(manifest)) throw new TypeError('Retention approval manifest must be a JSON array.');
  const eligible = new Map(candidates.map((item) => [Number(item.documentId), item]));
  const seen = new Set();
  const valid = [];
  for (const item of manifest) {
    const id = Number(item?.documentId);
    if (!Number.isInteger(id) || id <= 0 || seen.has(id)) throw new TypeError('Retention manifest contains an invalid or duplicate document ID.');
    seen.add(id);
    if (item.reason !== 'rejected-document') throw new TypeError(`Document ${id} is not approved for this retention job classification.`);
    const candidate = eligible.get(id);
    if (!candidate) throw new TypeError(`Document ${id} is not an old, rejected document in the current scan.`);
    const first = String(item.approvedBy1 || '').trim();
    const second = String(item.approvedBy2 || '').trim();
    if (!first || !second || first === second) throw new TypeError(`Document ${id} requires two distinct approver identifiers.`);
    const approvedAt = new Date(item.approvedAt);
    const anchor = asOf instanceof Date ? asOf : new Date(asOf);
    if (!item.approvedAt || !Number.isFinite(approvedAt.getTime()) || approvedAt > anchor) throw new TypeError(`Document ${id} requires a valid approval timestamp not in the future.`);
    if (typeof item.notes !== 'string' || item.notes.trim().length < 8 || item.notes.length > 500) throw new TypeError(`Document ${id} requires a short, meaningful retention justification.`);
    valid.push({ ...candidate, approvedBy1: first, approvedBy2: second, approvedAt: approvedAt.toISOString(), notes: item.notes.trim() });
  }
  return valid;
}
