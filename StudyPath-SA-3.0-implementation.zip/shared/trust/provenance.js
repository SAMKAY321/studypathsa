const dateOnly = (value) => {
  if (value == null || value === '') return null;
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value.toISOString().slice(0, 10) : null;
  const raw = String(value).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    const parsed = new Date(`${raw}T00:00:00Z`);
    return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === raw ? raw : null;
  }
  const parsed = new Date(raw);
  return Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : null;
};

export function withProvenance(recommendation, provenance, { freshnessDays = 180, now = new Date() } = {}) {
  const source = provenance?.source;
  const conditions = Array.isArray(provenance?.conditions)
    ? provenance.conditions.filter((value) => typeof value === 'string' && value.trim())
    : [];
  const lastUpdated = dateOnly(provenance?.lastUpdated);
  const sourceYear = Number(source?.year);
  const sourceValid = source && typeof source.title === 'string' && source.title.trim() &&
    typeof source.url === 'string' && /^https:\/\//i.test(source.url) &&
    Number.isInteger(sourceYear) && sourceYear >= 2000 && sourceYear <= 2100 &&
    typeof source.pageRef === 'string' && source.pageRef.trim();
  if (!sourceValid || !lastUpdated || !conditions.length) {
    return {
      kind: 'cannot-confirm',
      label: 'Cannot confirm — see institution',
      reason: 'A source, last-updated date and conditions are required before this can be recommended.',
      recommendation: null,
      provenance: null,
    };
  }
  const age = Math.floor((Date.parse(dateOnly(now)) - Date.parse(lastUpdated)) / 86400000);
  if (age < 0) {
    return { kind: 'cannot-confirm', label: 'Cannot confirm — see institution', reason: 'The last-updated date is in the future and must be verified.', recommendation: null, provenance: null };
  }
  const stale = age > freshnessDays || provenance.status === 'stale';
  const verified = provenance.status === 'verified' && !stale;
  return {
    kind: verified ? 'recommendation' : 'guidance',
    label: verified ? recommendation?.label || 'Indicative guidance' : 'Not yet verified',
    recommendation: verified ? recommendation : null,
    provenance: {
      source: {
        title: source.title.trim(),
        url: source.url,
        year: Number(source.year),
        pageRef: source.pageRef || null,
      },
      lastUpdated,
      lastVerifiedBy: provenance.lastVerifiedByRole || null,
      conditions,
      status: stale ? 'stale' : provenance.status || 'draft',
      staleAfter: freshnessDays,
      stale,
      freshnessNotice: stale ? 'May be out of date — verify with the institution' : null,
    },
  };
}

export function hasCompleteProvenance(value) {
  return Boolean(
    value?.provenance?.source?.title && value.provenance.source.url &&
    value.provenance.lastUpdated && Array.isArray(value.provenance.conditions) &&
    value.provenance.conditions.length,
  );
}
